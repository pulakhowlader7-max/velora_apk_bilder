// Service worker: offline app shell, runtime cache for fonts/cmaps, Web Share Target receiver.
const VER = 'velora-v5';
const SHELL = ["/", "/index.html", "/manifest.webmanifest", "/css/app.css", "/js/ai.js", "/js/app.js", "/js/convert.js", "/js/db.js", "/js/docx.js", "/js/edkit.js", "/js/formula.js", "/js/imgproc.js", "/js/lock.js", "/js/native.js", "/js/numfmt.js", "/js/ocr.js", "/js/pdfexport.js", "/js/pdfview.js", "/js/photo.js", "/js/scanner.js", "/js/screen.js", "/js/sheet.js", "/js/slides.js", "/js/templates.js", "/js/tools.js", "/js/util.js", "/js/word.js", "/js/xlsx.js", "/icons/apple-touch-icon.png", "/icons/favicon-32.png", "/icons/logo-96.png", "/icons/icon-192.png", "/icons/icon-512.png", "/icons/maskable-512.png"];
const VENDOR = ["/vendor/jszip.min.js", "/vendor/pdf-lib.min.js", "/vendor/pdf.min.mjs", "/vendor/pdf.worker.min.mjs", "/vendor/pptxgen.bundle.js"];
self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const c = await caches.open(VER);
    await Promise.all(SHELL.map(u => c.add(new Request(u, { cache: 'reload' })).catch(() => {})));
    await Promise.all(VENDOR.map(u => c.add(u).catch(() => {})));
    self.skipWaiting();
  })());
});
self.addEventListener('activate', e => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k !== VER && k !== 'ao-share') await caches.delete(k);
    await self.clients.claim();
  })());
});
async function receiveShare(req) {
  try {
    const fd = await req.formData(); const c = await caches.open('ao-share'); let n = 0;
    for (const f of fd.getAll('files')) {
      if (!(f instanceof File)) continue;
      await c.put('/__share/' + Date.now() + '-' + (n++), new Response(f, { headers: { 'x-name': encodeURIComponent(f.name), 'content-type': f.type || 'application/octet-stream' } }));
    }
  } catch (e) { console.warn(e); }
  return Response.redirect('/?shared=1', 303);
}
self.addEventListener('fetch', e => {
  const req = e.request, url = new URL(req.url);
  if (req.method === 'POST' && url.pathname === '/share-target') { e.respondWith(receiveShare(req)); return; }
  if (req.method !== 'GET' || url.origin !== location.origin) return;
  if (req.mode === 'navigate') {
    e.respondWith((async () => {
      try { const r = await fetch(req); return r; } catch { return (await caches.match('/index.html')) || (await caches.match('/')) || Response.error(); }
    })());
    return;
  }
  if (url.pathname.startsWith('/vendor/') || url.pathname.startsWith('/icons/')) {
    e.respondWith((async () => {
      const hit = await caches.match(req); if (hit) return hit;
      const r = await fetch(req); if (r.ok) (await caches.open(VER)).put(req, r.clone()); return r;
    })());
    return;
  }
  // app code: network first (fresh when online), cache fallback offline
  e.respondWith((async () => {
    try { const r = await fetch(req); if (r.ok) (await caches.open(VER)).put(req, r.clone()); return r; }
    catch { return (await caches.match(req, { ignoreSearch: true })) || Response.error(); }
  })());
});
