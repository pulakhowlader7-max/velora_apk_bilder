// Velora tools — one registry used by the Tools tab, the home shortcuts and the search bar.
import { h, sheet, modal, toast, pickFiles, withBusy, busy, errMsg, baseName, extOf, kindOf, toBn, readBuf, KINDS } from './util.js';
import { db } from './db.js';

const A = () => window.__ao;

/** Ask where the input file comes from: phone storage or Velora's own library. Resolves File | null. */
export function pickInput({ kind, accept, title = 'ফাইল বেছে নিন', multiple = false }) {
  return new Promise(async res => {
    const recent = (await db.list()).filter(m => !m.trashed && (!kind || m.kind === kind)).sort((a, b) => b.modified - a.modified).slice(0, 8);
    let done = false, chosen = false; const fin = v => { if (!done) { done = true; res(v); } };
    // NOTE: the sheet closes the moment a row is tapped, but the phone's file/gallery picker stays open for many seconds.
    // `chosen` makes sure the "sheet was dismissed" watcher never resolves null while a pick is still in progress.
    const items = [{ title }, { icon: 'open', label: 'ফোন থেকে বাছুন', sub: 'গ্যালারি / ফাইল ম্যানেজার', onClick: async () => { chosen = true; const fs = await pickFiles({ accept, multiple }); fin(fs.length ? (multiple ? fs : fs[0]) : null); } }];
    if (recent.length) { items.push({ sep: true }, { title: 'আমার ফাইল থেকে' }); for (const m of recent) items.push({ icon: KINDS[m.kind].icon, label: m.name, onClick: async () => { chosen = true; try { fin(new File([await db.buf(m.id)], m.name, { type: KINDS[m.kind].mime })); } catch (e) { toast('ফাইল পড়া যায়নি: ' + errMsg(e)); fin(null); } } }); }
    const ov = sheet('', items); const o = ov.el;
    const obs = new MutationObserver(() => { if (!document.body.contains(o)) { obs.disconnect(); setTimeout(() => { if (!chosen) fin(null); }, 900); } }); obs.observe(document.body, { childList: true });
  });
}

async function pdfToWord(file) {
  if (!file) return;
  let mode = 'auto';
  const opts = [['auto', 'অটো (প্রস্তাবিত)', 'লেখা থাকলে সরাসরি, স্ক্যান/ভাঙা লেখা হলে OCR'], ['text', 'শুধু টেক্সট (দ্রুত, অফলাইন)', 'স্ক্যান করা পাতা ছবি হয়ে থাকবে'], ['ocr', 'সব পাতা OCR/AI দিয়ে', 'বাংলা ও স্ক্যান PDF-এ সবচেয়ে ভালো']];
  const list = h('div', { class: 'optlist' }, opts.map(([k, t, s]) => h('button', { type: 'button', class: 'opt' + (k === mode ? ' on' : ''), onclick: e => { mode = k; [...list.children].forEach(b => b.classList.toggle('on', b === e.currentTarget)); } }, h('b', null, t), h('small', null, s))));
  const go = await new Promise(r => { let ok = false; const ov = modal({ title: 'PDF → Word', body: list, actions: [{ label: 'বাতিল', ghost: true }, { label: 'রূপান্তর', primary: true, onClick: () => { ok = true; } }] }); const o = ov.el; const obs = new MutationObserver(() => { if (!document.body.contains(o)) { obs.disconnect(); r(ok); } }); obs.observe(document.body, { childList: true }); });
  if (!go) return;
  const b = busy('শুরু হচ্ছে…');
  try {
    const { pdfToHtml } = await import('./convert.js'); const buf = await readBuf(file);
    const r = await pdfToHtml(buf, { mode, onProgress: (i, n, msg) => b.set(`${toBn(i)}/${toBn(n)} — ${msg}`) });
    b.done();
    if (r.warnings.length) toast(r.warnings[0], 5000);
    await A().importFiles([new File([`<html><body>${r.html}</body></html>`], baseName(file.name) + '.html', { type: 'text/html' })], { open: true });
  } catch (e) { b.done(); console.error(e); toast('রূপান্তর ব্যর্থ: ' + errMsg(e), 5000); }
}
export const pdfToWordFile = pdfToWord;
async function wordToPdf() {
  const f = await pickInput({ kind: 'word', accept: '.docx,.txt,.md,.html,.htm', title: 'Word ফাইল বেছে নিন' }); if (!f) return;
  try {
    const r = await withBusy('PDF তৈরি হচ্ছে…', async b => { const { wordFileToPdf } = await import('./convert.js'); return wordFileToPdf(f, { onProgress: (i, n) => b.set(`পাতা ${toBn(i)}/${toBn(n)}`) }); });
    await A().importFiles([new File([r.blob], r.name, { type: 'application/pdf' })], { open: true });
  } catch (e) { console.error(e); toast('PDF তৈরি ব্যর্থ: ' + errMsg(e), 5000); }
}
async function imageOcr(thenWord = true) {
  const f = await pickInput({ kind: 'image', accept: 'image/*', title: 'ছবি বেছে নিন' }); if (!f) return;
  try {
    const { ocrCanvas } = await import('./ocr.js'); const { loadImage } = await import('./util.js'); const url = URL.createObjectURL(f);
    const r = await withBusy('লেখা চেনা হচ্ছে…', async b => { const img = await loadImage(url); const s = Math.min(1, 2200 / Math.max(img.naturalWidth, img.naturalHeight)); const c = document.createElement('canvas'); c.width = Math.round(img.naturalWidth * s); c.height = Math.round(img.naturalHeight * s); c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); return ocrCanvas(c, { onStatus: m => b.set(m) }); }); URL.revokeObjectURL(url);
    if (thenWord) await A().importFiles([new File([`<html><body>${r.html}</body></html>`], baseName(f.name) + '.html', { type: 'text/html' })], { open: true });
  } catch (e) { console.error(e); toast(errMsg(e), 5000); }
}
async function editPhoto(tool) {
  const f = await pickInput({ kind: 'image', accept: 'image/*', title: 'ছবি বেছে নিন' }); if (!f) return;
  const { openPhotoEditor } = await import('./photo.js'); openPhotoEditor(f, { tool });
}
async function imagesToPdf() {
  const fs = await pickInput({ kind: 'image', accept: 'image/*', multiple: true, title: 'ছবি বেছে নিন' }); if (!fs) return; const list = Array.isArray(fs) ? fs : [fs];
  try { const m = await import('./pdfview.js'); const r = await withBusy('PDF তৈরি হচ্ছে…', () => m.imagesToPdf(list)); await A().importFiles([new File([r.buf], r.name, { type: 'application/pdf' })], { open: true }); } catch (e) { toast('ব্যর্থ: ' + errMsg(e), 4000); }
}
async function openPdf() { const f = await pickInput({ kind: 'pdf', accept: '.pdf,application/pdf', title: 'PDF বেছে নিন' }); if (f) await A().importFiles([f], { open: true }); }

export const GROUPS = ['স্ক্যান ও OCR', 'PDF', 'ছবি', 'AI সহায়ক', 'ডকুমেন্ট'];
export const TOOLS = [
  { g: 0, id: 'scan', icon: 'camera', color: '#0e9f6e', name: 'ডকুমেন্ট স্ক্যানার', sub: 'ক্যামেরায় কাগজ → PDF', kw: 'scan scanner স্ক্যান ক্যামেরা', run: () => import('./scanner.js').then(m => m.openScanner()) },
  { g: 0, id: 'img2word', icon: 'word', color: '#2b5fd9', name: 'ছবি → Word', sub: 'ছবির লেখা এডিটযোগ্য করুন (OCR)', kw: 'ocr picture word ছবি', run: () => imageOcr(true) },
  { g: 0, id: 'img2pdf', icon: 'pdf', color: '#d92d20', name: 'ছবি → PDF', sub: 'এক বা একাধিক ছবি জোড়া', kw: 'image pdf ছবি', run: imagesToPdf },
  { g: 1, id: 'pdf2word', icon: 'word', color: '#2b5fd9', name: 'PDF → Word', sub: 'এডিটযোগ্য ডকুমেন্টে', kw: 'pdf to word convert রূপান্তর', run: async () => pdfToWord(await pickInput({ kind: 'pdf', accept: '.pdf,application/pdf', title: 'PDF বেছে নিন' })) },
  { g: 1, id: 'word2pdf', icon: 'pdf', color: '#d92d20', name: 'Word → PDF', sub: '.docx থেকে PDF', kw: 'word to pdf converter', run: wordToPdf },
  { g: 1, id: 'pdfedit', icon: 'pen', color: '#d92d20', name: 'PDF এডিটর', sub: 'কলম, হাইলাইট, লেখা, পাতা সাজান, জোড়া', kw: 'pdf editor edit merge split', run: openPdf },
  { g: 2, id: 'photo', icon: 'image', color: '#8a4fd8', name: 'ছবি এডিটর', sub: 'ক্রপ, ফিল্টার, লেখা, আঁকা', kw: 'photo edit ছবি এডিট', run: () => editPhoto('adjust') },
  { g: 2, id: 'bg', icon: 'drop', color: '#8a4fd8', name: 'ব্যাকগ্রাউন্ড রিমুভ', sub: 'ছবির পেছনের অংশ সরান', kw: 'background remove ব্যাকগ্রাউন্ড', run: () => editPhoto('bg') },
  { g: 2, id: 'eraser', icon: 'eraser', color: '#8a4fd8', name: 'অবজেক্ট মুছুন', sub: 'অবাঞ্ছিত জিনিস সরান', kw: 'eraser object remove মোছা', run: () => editPhoto('erase') },
  { g: 2, id: 'enhance', icon: 'sparkle', color: '#8a4fd8', name: 'ছবির মান বাড়ান', sub: 'শার্প, HD, নয়েজ কমানো', kw: 'enhance quality improve hd', run: () => editPhoto('enhance') },
  { g: 3, id: 'chat', icon: 'sparkle', color: '#7c3aed', name: 'AI সহায়ক', sub: 'যেকোনো প্রশ্ন, লেখা, অনুবাদ', kw: 'ai gemini chat assistant', run: () => import('./ai.js').then(m => m.aiChat()) },
  { g: 3, id: 'aidoc', icon: 'word', color: '#7c3aed', name: 'AI দিয়ে ডকুমেন্ট', sub: 'আবেদন, চিঠি, রিপোর্ট লেখান', kw: 'ai document letter application', run: () => import('./ai.js').then(m => m.aiDocument()) },
  { g: 3, id: 'aippt', icon: 'ppt', color: '#7c3aed', name: 'AI দিয়ে প্রেজেন্টেশন', sub: 'বিষয় দিন, স্লাইড তৈরি', kw: 'ai presentation slides powerpoint', run: () => import('./ai.js').then(m => m.aiPresentation()) },
  { g: 3, id: 'aisheet', icon: 'excel', color: '#7c3aed', name: 'AI দিয়ে Excel', sub: 'টেবিল ও ফর্মুলা সহ', kw: 'ai excel sheet table', run: () => import('./ai.js').then(m => m.aiSheet()) },
  { g: 4, id: 'nword', icon: 'word', color: '#2b5fd9', name: 'নতুন Word', sub: 'ফাঁকা বা টেমপ্লেট', kw: 'word new document', run: () => A().createNew('word') },
  { g: 4, id: 'nexcel', icon: 'excel', color: '#14884f', name: 'নতুন Excel', sub: 'স্প্রেডশিট ও ফর্মুলা', kw: 'excel new spreadsheet', run: () => A().createNew('excel') },
  { g: 4, id: 'nppt', icon: 'ppt', color: '#e4572e', name: 'নতুন PowerPoint', sub: 'থিম বেছে নিন', kw: 'powerpoint new slides', run: () => A().createNew('ppt') },
];

export function toolCard(t) {
  return h('button', { class: 'tool', type: 'button', onclick: () => t.run() }, h('div', { class: 'ti', style: { background: t.color } }, window.__icon(t.icon, 22)), h('div', { class: 'tt' }, h('b', null, t.name), h('small', null, t.sub)));
}
