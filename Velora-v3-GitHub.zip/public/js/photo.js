// Velora Photo Editor — crop/rotate, adjust, filters, text, draw, object eraser, background remover, enhance, AI edit.
import { h, icon, btn, toast, sheet, modal, pickColor, withBusy, busy, loadImage, errMsg, baseName, toBn, shareFile, saveToDevice, confirmDlg } from './util.js';
import { screen } from './screen.js';
import * as P from './imgproc.js';
import { db, uniqueName } from './db.js';

const MAXB = 2400;
const cnv = (w, hh) => { const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(hh)); return c; };
const g2 = c => c.getContext('2d', { willReadFrequently: true });
const clone = c => { const n = cnv(c.width, c.height); g2(n).drawImage(c, 0, 0); return n; };
const down = (c, max) => { const s = Math.min(1, max / Math.max(c.width, c.height)); if (s === 1) return c; const n = cnv(c.width * s, c.height * s); const g = g2(n); g.imageSmoothingQuality = 'high'; g.drawImage(c, 0, 0, n.width, n.height); return n; };
const tick = () => new Promise(r => setTimeout(r, 16));
const FILTERS = [['', 'আসল'], ['saturate(1.5) contrast(1.1)', 'ভিভিড'], ['sepia(.25) saturate(1.25) hue-rotate(-8deg) brightness(1.03)', 'উষ্ণ'], ['hue-rotate(14deg) saturate(1.1) brightness(1.04)', 'শীতল'], ['grayscale(1) contrast(1.15)', 'সাদা-কালো'], ['grayscale(1) contrast(1.55) brightness(.9)', 'নোয়ার'], ['sepia(.9)', 'সেপিয়া'], ['contrast(.85) brightness(1.1) saturate(.8)', 'ফেড'], ['sepia(.4) contrast(1.1) saturate(.9) brightness(.95)', 'ভিন্টেজ'], ['contrast(1.4) saturate(1.2) brightness(.9)', 'ড্রামাটিক'], ['brightness(1.1) contrast(.92) saturate(1.1) blur(.5px)', 'নরম'], ['invert(1)', 'নেগেটিভ']];
const SW = ['#ffffff', '#000000', '#ff3b30', '#ff9500', '#ffd60a', '#34c759', '#0a84ff', '#af52de', '#ff2d92'];
const FONTS = [['"Noto Sans Bengali","Kalpurush",system-ui,sans-serif', 'সাধারণ'], ['"Kalpurush","Noto Serif Bengali",Georgia,serif', 'কালপুরুষ'], ['Georgia,"Times New Roman",serif', 'Serif'], ['Impact,"Arial Black",sans-serif', 'Bold'], ['"Courier New",monospace', 'Mono'], ['"Brush Script MT",cursive', 'Script']];

async function loadBase(file) {
  const url = URL.createObjectURL(file);
  try { const img = await loadImage(url); const s = Math.min(1, MAXB / Math.max(img.naturalWidth, img.naturalHeight)); const c = cnv(img.naturalWidth * s, img.naturalHeight * s); const g = g2(c); g.imageSmoothingQuality = 'high'; g.drawImage(img, 0, 0, c.width, c.height); return c; }
  finally { URL.revokeObjectURL(url); }
}
function adjustCanvas(src, p) {
  const c = cnv(src.width, src.height), g = g2(c);
  g.filter = `brightness(${1 + p.b / 100}) contrast(${1 + p.c / 100}) saturate(${1 + p.s / 100}) ${p.fx || ''}`.trim(); g.drawImage(src, 0, 0); g.filter = 'none';
  if (p.w || p.sharp || p.vig) { const id = g.getImageData(0, 0, c.width, c.height); if (p.w) P.warmth(id, p.w); if (p.sharp) P.unsharp(id, p.sharp / 50, 1.2); if (p.vig) P.vignette(id, p.vig); g.putImageData(id, 0, 0); }
  return c;
}

export async function openPhotoEditor(file, { meta, tool: startTool } = {}) {
  let base; try { base = await withBusy('ছবি খোলা হচ্ছে…', () => loadBase(file)); } catch (e) { return toast('ছবি খোলা যায়নি: ' + errMsg(e), 4000); }
  const undoS = [], redoS = []; let dirty = false, tool = 'adjust', bgOrig = null, bgFill = null;
  let preview = null, adj = { b: 0, c: 0, s: 0, w: 0, sharp: 0, vig: 0, fx: '' };
  const texts = []; let selT = -1; let crop = null; let mask = null, brush = 28, penColor = '#ff3b30', mode = 'erase';
  const undoB = btn('undo', 'আনডু', () => undo(), { keepFocus: false }), redoB = btn('redo', 'রিডু', () => redo(), { keepFocus: false });
  const saveB = btn('save', 'সেভ', () => saveMenu(), { keepFocus: false, text: 'সেভ' });
  const scr = screen({ title: 'ছবি এডিটর', cls: 'photo', actions: [undoB, redoB, saveB] });
  scr.setGuard(async () => !dirty || confirmDlg('পরিবর্তন ফেলে দেবেন?', 'সেভ না করা পরিবর্তন হারিয়ে যাবে।', { ok: 'ফেলে দিন', cancel: 'থাকুন', danger: true }));
  const view = document.createElement('canvas'); const overlay = h('div', { class: 'ph-ov' }); const stage = h('div', { class: 'ph-stage' }, h('div', { class: 'ph-canvas' }, view, overlay));
  const panel = h('div', { class: 'ph-panel' }); const tabs = h('div', { class: 'ph-tabs' });
  scr.body.append(stage, panel, tabs);
  const wrapEl = stage.firstChild;

  /* ---------- rendering ---------- */
  function layout() { const bw = stage.clientWidth - 16, bh = stage.clientHeight - 16, s = Math.min(bw / base.width, bh / base.height); wrapEl.style.width = base.width * s + 'px'; wrapEl.style.height = base.height * s + 'px'; }
  function drawTexts(g, W, withBox) {
    texts.forEach((t, i) => {
      const fs = t.size * W / 100; g.save(); g.font = `${t.bold ? '700 ' : ''}${fs}px ${t.font}`; g.textBaseline = 'top'; const lines = t.text.split('\n'), lh = fs * 1.25; const w = Math.max(...lines.map(l => g.measureText(l).width), 1), hh = lh * lines.length;
      const x = t.x * W - w / 2, y = t.y * W - hh / 2; t.box = { x, y, w, h: hh };
      if (t.bg) { g.fillStyle = t.bg; g.fillRect(x - fs * .3, y - fs * .1, w + fs * .6, hh + fs * .2); }
      if (t.shadow) { g.shadowColor = 'rgba(0,0,0,.6)'; g.shadowBlur = fs * .18; g.shadowOffsetY = fs * .05; }
      g.fillStyle = t.color; lines.forEach((l, k) => { g.textAlign = 'center'; g.fillText(l, x + w / 2, y + k * lh); });
      g.restore(); if (withBox && i === selT) { g.save(); g.strokeStyle = '#3157e0'; g.lineWidth = Math.max(2, W / 300); g.setLineDash([W / 100, W / 150]); g.strokeRect(x - fs * .3, y - fs * .1, w + fs * .6, hh + fs * .2); g.restore(); }
    });
  }
  function render() {
    if (view.width !== base.width || view.height !== base.height) { view.width = base.width; view.height = base.height; layout(); }
    const g = view.getContext('2d'); g.clearRect(0, 0, view.width, view.height);
    if (bgFill) { g.fillStyle = bgFill; g.fillRect(0, 0, view.width, view.height); }
    g.drawImage(preview || base, 0, 0, view.width, view.height);
    if (tool === 'text') drawTexts(g, view.width, true);
    if (mask && tool === 'erase') { g.globalAlpha = .55; g.drawImage(mask, 0, 0); g.globalAlpha = 1; }
    stage.classList.toggle('checker', !bgFill);
    undoB.disabled = !undoS.length; redoB.disabled = !redoS.length;
  }
  function commit(c, keepBgFill) { undoS.push({ c: base, fill: bgFill }); if (undoS.length > 8) undoS.shift(); redoS.length = 0; base = c; if (!keepBgFill) { /* fill is a view option */ } dirty = true; preview = null; render(); }
  function undo() { if (!undoS.length) return; bakeTexts(); redoS.push({ c: base, fill: bgFill }); const s = undoS.pop(); base = s.c; bgFill = s.fill; preview = null; render(); showTool(tool); }
  function redo() { if (!redoS.length) return; undoS.push({ c: base, fill: bgFill }); const s = redoS.pop(); base = s.c; bgFill = s.fill; preview = null; render(); showTool(tool); }
  function bakeTexts() { if (!texts.length) return; const c = clone(base); drawTexts(g2(c), c.width, false); texts.length = 0; selT = -1; commit(c); }

  /* ---------- pointer helpers ---------- */
  const pt = e => { const r = view.getBoundingClientRect(); return { x: (e.clientX - r.left) / r.width * view.width, y: (e.clientY - r.top) / r.height * view.height, fx: (e.clientX - r.left) / r.width, fy: (e.clientY - r.top) / r.height }; };
  let drag = null;
  view.addEventListener('pointerdown', e => {
    const p = pt(e);
    if (tool === 'text') { let hit = -1; for (let i = texts.length - 1; i >= 0; i--) { const b = texts[i].box; if (b && p.x >= b.x - 20 && p.x <= b.x + b.w + 20 && p.y >= b.y - 20 && p.y <= b.y + b.h + 20) { hit = i; break; } } selT = hit; if (hit >= 0) drag = { i: hit, dx: texts[hit].x * view.width - p.x, dy: texts[hit].y * view.width - p.y }; render(); showTool('text'); }
    else if (tool === 'draw' || tool === 'erase' || tool === 'bgfix') {
      if (tool === 'erase' && !mask) { mask = cnv(base.width, base.height); }
      if (tool === 'draw' || (tool === 'bgfix')) { undoS.push({ c: clone(base), fill: bgFill }); if (undoS.length > 8) undoS.shift(); redoS.length = 0; dirty = true; }
      drag = { last: p }; view.setPointerCapture(e.pointerId); stroke(p, p);
    }
    e.preventDefault();
  });
  view.addEventListener('pointermove', e => {
    if (!drag) return; const p = pt(e);
    if (tool === 'text' && drag.i !== undefined) { const t = texts[drag.i]; t.x = (p.x + drag.dx) / view.width; t.y = (p.y + drag.dy) / view.width; render(); }
    else if (drag.last) { stroke(drag.last, p); drag.last = p; }
  });
  const endDrag = () => { drag = null; };
  view.addEventListener('pointerup', endDrag); view.addEventListener('pointercancel', endDrag);
  function stroke(a, b) {
    const r = brush * base.width / 1000;
    if (tool === 'draw') { const g = g2(base); g.strokeStyle = g.fillStyle = penColor; g.lineWidth = r; g.lineCap = g.lineJoin = 'round'; g.beginPath(); g.moveTo(a.x, a.y); g.lineTo(b.x, b.y); g.stroke(); }
    else if (tool === 'erase') { const g = g2(mask); g.strokeStyle = '#ff2d55'; g.lineWidth = r; g.lineCap = g.lineJoin = 'round'; g.beginPath(); g.moveTo(a.x, a.y); g.lineTo(b.x, b.y); g.stroke(); }
    else if (tool === 'bgfix') {
      const g = g2(base); const steps = Math.max(1, Math.ceil(Math.hypot(b.x - a.x, b.y - a.y) / (r / 3)));
      for (let i = 0; i <= steps; i++) { const x = a.x + (b.x - a.x) * i / steps, y = a.y + (b.y - a.y) * i / steps; g.save(); g.beginPath(); g.arc(x, y, r / 2, 0, 7); if (mode === 'erase') { g.globalCompositeOperation = 'destination-out'; g.fill(); } else if (bgOrig) { g.clip(); g.drawImage(bgOrig, 0, 0, base.width, base.height); } g.restore(); }
    }
    render();
  }

  /* ---------- panel helpers ---------- */
  const slider = (label, min, max, val, on, fmt = v => v) => { const out = h('b', null, fmt(val)); const i = h('input', { type: 'range', min, max, value: val, step: 1 }); i.addEventListener('input', () => { out.textContent = fmt(+i.value); on(+i.value); }); return h('label', { class: 'ph-sl' }, h('span', null, label), i, out); };
  const chip = (t, on, active) => h('button', { type: 'button', class: 'chip' + (active ? ' on' : ''), onclick: on }, t);
  const swatches = (cur, on) => h('div', { class: 'ph-sw' }, SW.map(c => h('button', { type: 'button', class: 'sw' + (c === cur ? ' on' : ''), style: { background: c }, 'aria-label': c, onclick: () => on(c) })), h('button', { type: 'button', class: 'sw custom', onclick: async () => { const c = await pickColor({ current: cur }); if (c) on(c); } }, '+'));
  const okRow = (apply, cancel) => h('div', { class: 'ph-ok' }, h('button', { class: 'btn', type: 'button', onclick: cancel }, 'বাতিল'), h('button', { class: 'btn primary', type: 'button', onclick: apply }, 'প্রয়োগ করুন'));
  const act = (label, ic, fn, sub) => h('button', { class: 'ph-act', type: 'button', onclick: fn }, icon(ic, 22), h('b', null, label), sub ? h('small', null, sub) : null);
  async function run(msg, fn) { const b = busy(msg); await tick(); try { return await fn(b); } catch (e) { console.warn(e); toast(errMsg(e), 4500); } finally { b.done(); } }

  /* ---------- tools ---------- */
  const TOOLS = [['crop', 'crop', 'ক্রপ'], ['adjust', 'settings', 'অ্যাডজাস্ট'], ['filter', 'image', 'ফিল্টার'], ['text', 'type', 'লেখা'], ['draw', 'pen', 'আঁকা'], ['erase', 'eraser', 'মুছুন'], ['bg', 'drop', 'ব্যাকগ্রাউন্ড'], ['enhance', 'sparkle', 'এনহান্স'], ['ai', 'sparkle', 'AI']];
  function drawTabs() { tabs.replaceChildren(...TOOLS.map(([k, ic, t]) => h('button', { type: 'button', class: 'ph-tab' + (tool === k || (tool === 'bgfix' && k === 'bg') ? ' on' : ''), onclick: () => { switchTool(k); } }, icon(ic === 'crop' ? 'maximize' : ic, 20), t))); }
  function switchTool(k) { if (tool === 'text' && k !== 'text') bakeTexts(); preview = null; adj = { b: 0, c: 0, s: 0, w: 0, sharp: 0, vig: 0, fx: '' }; crop = null; if (k !== 'erase') mask = null; tool = k; overlay.replaceChildren(); render(); showTool(k); drawTabs(); }
  function showTool(k) {
    panel.replaceChildren();
    if (k === 'crop') return cropPanel();
    if (k === 'adjust') return adjustPanel();
    if (k === 'filter') return filterPanel();
    if (k === 'text') return textPanel();
    if (k === 'draw') return panel.append(h('div', { class: 'ph-row' }, h('span', { class: 'hint' }, 'আঙুল দিয়ে ছবির ওপর আঁকুন'), swatches(penColor, c => { penColor = c; showTool('draw'); })), slider('ব্রাশ', 4, 80, brush, v => { brush = v; }));
    if (k === 'erase') return erasePanel();
    if (k === 'bg' || k === 'bgfix') return bgPanel();
    if (k === 'enhance') return enhancePanel();
    if (k === 'ai') return aiPanel();
  }

  /* crop / rotate */
  function cropPanel() {
    const r = crop ||= { x: .05, y: .05, w: .9, h: .9, ratio: 0 };
    const ov = overlay; ov.replaceChildren(); const box = h('div', { class: 'ph-crop' }); const hs = ['nw', 'ne', 'se', 'sw'].map(k => h('i', { 'data-k': k })); box.append(...hs); ov.append(box);
    const upd = () => { box.style.left = r.x * 100 + '%'; box.style.top = r.y * 100 + '%'; box.style.width = r.w * 100 + '%'; box.style.height = r.h * 100 + '%'; };
    const fixRatio = () => { if (!r.ratio) return; const R = r.ratio * base.height / base.width; if (r.w / r.h > R) r.w = r.h * R; else r.h = r.w / R; r.w = Math.min(r.w, 1 - r.x); r.h = Math.min(r.h, 1 - r.y); if (r.w / r.h > R) r.w = r.h * R; else r.h = r.w / R; };
    box.addEventListener('pointerdown', e => {
      const k = e.target.dataset.k, p0 = pt(e), s = { ...r }; box.setPointerCapture(e.pointerId);
      box.onpointermove = ev => { const p = pt(ev), dx = p.fx - p0.fx, dy = p.fy - p0.fy;
        if (!k) { r.x = Math.min(1 - s.w, Math.max(0, s.x + dx)); r.y = Math.min(1 - s.h, Math.max(0, s.y + dy)); }
        else { let x0 = s.x, y0 = s.y, x1 = s.x + s.w, y1 = s.y + s.h; if (k.includes('w')) x0 = Math.min(x1 - .05, Math.max(0, s.x + dx)); if (k.includes('e')) x1 = Math.max(x0 + .05, Math.min(1, x1 + dx)); if (k.includes('n')) y0 = Math.min(y1 - .05, Math.max(0, s.y + dy)); if (k.includes('s')) y1 = Math.max(y0 + .05, Math.min(1, y1 + dy)); r.x = x0; r.y = y0; r.w = x1 - x0; r.h = y1 - y0; fixRatio(); }
        upd(); };
      box.onpointerup = () => { box.onpointermove = null; }; e.preventDefault(); e.stopPropagation();
    });
    upd();
    const rot = (deg) => { const c = deg % 180 ? cnv(base.height, base.width) : cnv(base.width, base.height); const g = g2(c); g.translate(c.width / 2, c.height / 2); g.rotate(deg * Math.PI / 180); g.drawImage(base, -base.width / 2, -base.height / 2); commit(c); crop = null; showTool('crop'); };
    const flip = (hz) => { const c = cnv(base.width, base.height), g = g2(c); g.translate(hz ? c.width : 0, hz ? 0 : c.height); g.scale(hz ? -1 : 1, hz ? 1 : -1); g.drawImage(base, 0, 0); commit(c); };
    panel.append(h('div', { class: 'ph-chips' }, [[0, 'ফ্রি'], [1, '১:১'], [4 / 3, '৪:৩'], [3 / 4, '৩:৪'], [16 / 9, '১৬:৯'], [9 / 16, '৯:১৬'], [210 / 297, 'A4']].map(([v, t]) => chip(t, () => { r.ratio = v; fixRatio(); upd(); showTool('crop'); }, r.ratio === v))),
      h('div', { class: 'ph-acts' }, act('বাঁয়ে', 'rotate', () => rot(270)), act('ডানে', 'rotate', () => rot(90)), act('আড়াআড়ি', 'left', () => flip(true)), act('উল্টো', 'up', () => flip(false))),
      okRow(() => { const c = cnv(r.w * base.width, r.h * base.height); g2(c).drawImage(base, r.x * base.width, r.y * base.height, r.w * base.width, r.h * base.height, 0, 0, c.width, c.height); crop = null; overlay.replaceChildren(); commit(c); showTool('crop'); }, () => { crop = null; overlay.replaceChildren(); showTool('crop'); }));
  }
  /* adjust */
  let pvT = 0;
  function livePreview() { clearTimeout(pvT); pvT = setTimeout(() => { const small = down(base, 900); preview = adjustCanvas(small, adj); render(); }, 40); }
  function adjustPanel() {
    panel.append(slider('উজ্জ্বলতা', -100, 100, adj.b, v => { adj.b = v; livePreview(); }), slider('কনট্রাস্ট', -100, 100, adj.c, v => { adj.c = v; livePreview(); }), slider('রঙের তীব্রতা', -100, 100, adj.s, v => { adj.s = v; livePreview(); }), slider('উষ্ণতা', -100, 100, adj.w, v => { adj.w = v; livePreview(); }), slider('ধার (শার্প)', 0, 100, adj.sharp, v => { adj.sharp = v; livePreview(); }), slider('ভিনিয়েট', 0, 100, adj.vig, v => { adj.vig = v; livePreview(); }),
      okRow(() => run('প্রয়োগ হচ্ছে…', () => { const c = adjustCanvas(base, adj); adj = { b: 0, c: 0, s: 0, w: 0, sharp: 0, vig: 0, fx: '' }; commit(c); showTool('adjust'); }), () => { adj = { b: 0, c: 0, s: 0, w: 0, sharp: 0, vig: 0, fx: '' }; preview = null; render(); showTool('adjust'); }));
  }
  /* filters */
  function filterPanel() {
    const small = down(base, 120); const row = h('div', { class: 'ph-filters' });
    FILTERS.forEach(([fx, name]) => { const t = adjustCanvas(small, { b: 0, c: 0, s: 0, w: 0, sharp: 0, vig: 0, fx }); t.className = 'ph-ft'; row.append(h('button', { type: 'button', class: 'ph-f' + (adj.fx === fx ? ' on' : ''), onclick: () => { adj.fx = fx; livePreview(); [...row.children].forEach(b => b.classList.remove('on')); event.currentTarget.classList.add('on'); } }, t, h('small', null, name))); });
    panel.append(row, okRow(() => run('প্রয়োগ হচ্ছে…', () => { const c = adjustCanvas(base, adj); adj.fx = ''; commit(c); showTool('filter'); }), () => { adj.fx = ''; preview = null; render(); showTool('filter'); }));
  }
  /* text */
  function textPanel() {
    const t = texts[selT];
    const add = act('লেখা যোগ', 'plus', () => { texts.push({ text: 'এখানে লিখুন', x: .5, y: .5 * base.height / base.width, size: 9, color: '#ffffff', bold: true, font: FONTS[0][0], shadow: true, bg: '' }); selT = texts.length - 1; render(); showTool('text'); });
    if (!t) return panel.append(h('div', { class: 'ph-acts' }, add), h('div', { class: 'hint', style: { textAlign: 'center' } }, 'লেখা বেছে নিয়ে আঙুলে টেনে সরান'));
    const ta = h('textarea', { class: 'inp', rows: 2 }); ta.value = t.text; ta.addEventListener('input', () => { t.text = ta.value || ' '; render(); });
    panel.append(ta, slider('আকার', 2, 30, t.size, v => { t.size = v; render(); }), swatches(t.color, c => { t.color = c; render(); showTool('text'); }),
      h('div', { class: 'ph-chips' }, FONTS.map(([f, n]) => chip(n, () => { t.font = f; render(); showTool('text'); }, t.font === f)), chip('B', () => { t.bold = !t.bold; render(); showTool('text'); }, t.bold), chip('ছায়া', () => { t.shadow = !t.shadow; render(); showTool('text'); }, t.shadow), chip('ব্যাকগ্রাউন্ড', () => { t.bg = t.bg ? '' : 'rgba(0,0,0,.55)'; render(); showTool('text'); }, !!t.bg)),
      h('div', { class: 'ph-acts' }, add, act('মুছুন', 'trash', () => { texts.splice(selT, 1); selT = -1; render(); showTool('text'); })));
  }
  /* object eraser */
  function erasePanel() {
    panel.append(h('div', { class: 'hint', style: { textAlign: 'center' } }, 'যা মুছতে চান তার ওপর আঙুল দিয়ে রং করুন, তারপর "মুছে ফেলুন" চাপুন'), slider('ব্রাশ', 6, 90, brush, v => { brush = v; }),
      h('div', { class: 'ph-ok' }, h('button', { class: 'btn', type: 'button', onclick: () => { mask = cnv(base.width, base.height); render(); } }, 'দাগ মুছুন'),
        h('button', { class: 'btn primary', type: 'button', onclick: () => doErase() }, 'মুছে ফেলুন')));
  }
  async function doErase() {
    if (!mask) return toast('আগে মুছতে চাওয়া অংশে রং করুন');
    const md = g2(mask).getImageData(0, 0, mask.width, mask.height); const m = new Uint8Array(mask.width * mask.height); let any = 0; for (let i = 0; i < m.length; i++) if (md.data[i * 4 + 3] > 40) { m[i] = 1; any++; }
    if (!any) return toast('আগে মুছতে চাওয়া অংশে রং করুন');
    await run('অবজেক্ট মোছা হচ্ছে…', () => { const c = clone(base), g = g2(c), id = g.getImageData(0, 0, c.width, c.height); P.inpaint(id, m, { grow: 3, radius: 5 }); g.putImageData(id, 0, 0); mask = null; commit(c); });
    showTool('erase');
  }
  /* background */
  function bgPanel() {
    const manual = tool === 'bgfix';
    if (manual) return panel.append(h('div', { class: 'ph-chips' }, chip('মুছুন', () => { mode = 'erase'; showTool('bgfix'); }, mode === 'erase'), chip('ফিরিয়ে আনুন', () => { mode = 'restore'; showTool('bgfix'); }, mode === 'restore')), slider('ব্রাশ', 6, 90, brush, v => { brush = v; }), h('div', { class: 'ph-ok' }, h('button', { class: 'btn primary', type: 'button', onclick: () => { tool = 'bg'; drawTabs(); showTool('bg'); } }, 'হয়েছে')));
    let tol = 40;
    panel.append(slider('সহনশীলতা', 10, 90, tol, v => { tol = v; clearTimeout(pvT); pvT = setTimeout(() => { const s = down(base, 700), id = g2(s).getImageData(0, 0, s.width, s.height), o = P.removeBackground(id, { tol, feather: 1 }); const c = cnv(s.width, s.height); g2(c).putImageData(new ImageData(o.data, s.width, s.height), 0, 0); preview = c; render(); }, 60); }),
      h('div', { class: 'ph-acts' },
        act('অটো মুছুন', 'drop', () => run('ব্যাকগ্রাউন্ড সরানো হচ্ছে…', () => { bgOrig = clone(base); const id = g2(base).getImageData(0, 0, base.width, base.height), o = P.removeBackground(id, { tol, feather: 1 }); const c = cnv(base.width, base.height); g2(c).putImageData(new ImageData(o.data, base.width, base.height), 0, 0); commit(c); showTool('bg'); }), 'সাধারণ ব্যাকগ্রাউন্ডে ভালো'),
        act('AI দিয়ে মুছুন', 'sparkle', () => aiRemoveBg(), 'জটিল ছবিতে ভালো'),
        act('হাতে ঠিক করুন', 'pen', () => { if (!bgOrig) bgOrig = clone(base); tool = 'bgfix'; drawTabs(); showTool('bgfix'); })),
      h('div', { class: 'hint' }, 'ব্যাকগ্রাউন্ড রং:'), h('div', { class: 'ph-sw' }, [['', 'স্বচ্ছ'], ...SW.map(c => [c, ''])].map(([c]) => h('button', { type: 'button', class: 'sw' + ((bgFill || '') === c ? ' on' : '') + (c ? '' : ' none'), style: c ? { background: c } : {}, 'aria-label': c || 'স্বচ্ছ', onclick: () => { bgFill = c || null; dirty = true; render(); showTool('bg'); } }, c ? '' : '∅'))),
      okRow(() => { preview = null; render(); }, () => { preview = null; render(); }));
  }
  async function aiRemoveBg() {
    const { generate, canvasToPart } = await import('./ai.js');
    await run('AI ব্যাকগ্রাউন্ড সরাচ্ছে…', async () => {
      const r = await generate({ kind: 'image', parts: [await canvasToPart(base, .9, 1400)], prompt: 'Keep the main subject exactly unchanged (same pose, colours, details, edges) and replace the ENTIRE background with a flat, uniform, pure bright green (#00FF00) with no shadows or gradients. Output only the edited image.' });
      const img = await loadImage(`data:${r.image.mime};base64,${r.image.data}`); const s = cnv(img.naturalWidth, img.naturalHeight); g2(s).drawImage(img, 0, 0);
      const id = g2(s).getImageData(0, 0, s.width, s.height), o = P.chromaKey(id, [0, 255, 0], 80); const c = cnv(s.width, s.height); g2(c).putImageData(new ImageData(o.data, s.width, s.height), 0, 0);
      bgOrig = clone(base); commit(c); showTool('bg');
    });
  }
  /* enhance */
  function enhancePanel() {
    const go = (msg, fn) => run(msg, () => { const c = clone(base), g = g2(c), id = g.getImageData(0, 0, c.width, c.height); fn(id); g.putImageData(id, 0, 0); commit(c); });
    panel.append(h('div', { class: 'ph-acts wrap' },
      act('অটো এনহান্স', 'sparkle', () => go('উন্নত করা হচ্ছে…', id => P.enhance(id)), 'আলো, রং, ধার'),
      act('শার্প করুন', 'zoomIn', () => go('শার্প হচ্ছে…', id => P.unsharp(id, 1.1, 1.3))),
      act('নয়েজ কমান', 'drop', () => go('নয়েজ কমছে…', id => P.denoise(id, 22))),
      act('২× HD বড় করুন', 'maximize', () => run('বড় করা হচ্ছে…', () => { const s = Math.min(2, 4096 / Math.max(base.width, base.height)); if (s < 1.05) return toast('ছবি আগে থেকেই অনেক বড়'); const c = cnv(base.width * s, base.height * s), g = g2(c); g.imageSmoothingQuality = 'high'; g.drawImage(base, 0, 0, c.width, c.height); const id = g.getImageData(0, 0, c.width, c.height); P.unsharp(id, .7, 1.2); P.denoise(id, 10); g.putImageData(id, 0, 0); commit(c); }), 'ধার ঠিক রেখে'),
      act('AI এনহান্স', 'sparkle', () => aiEdit('Enhance this photo: restore fine detail and sharpness, reduce noise and blur, fix exposure and colours naturally. Keep the composition, people and content exactly identical. Output only the image.'), 'Gemini দিয়ে')));
  }
  /* AI */
  async function aiEdit(prompt) {
    const { generate, canvasToPart } = await import('./ai.js');
    await run('AI ছবি বানাচ্ছে… (একটু সময় লাগতে পারে)', async () => {
      const r = await generate({ kind: 'image', parts: [await canvasToPart(base, .9, 1400)], prompt });
      const img = await loadImage(`data:${r.image.mime};base64,${r.image.data}`); const c = cnv(img.naturalWidth, img.naturalHeight); g2(c).drawImage(img, 0, 0); commit(c);
    });
  }
  function aiPanel() {
    const ta = h('textarea', { class: 'inp', rows: 2, placeholder: 'যেমন: ব্যাকগ্রাউন্ডে সমুদ্র সৈকত বসাও / ছবিটি কার্টুন স্টাইলে করো' });
    panel.append(ta, h('div', { class: 'ph-chips' }, ['পুরনো ছবি রঙিন ও পরিষ্কার করো', 'ব্যাকগ্রাউন্ড ঝাপসা করো', 'আকাশ নীল ও সুন্দর করো', 'কার্টুন স্টাইলে করো'].map(t => chip(t, () => { ta.value = t; }))),
      h('div', { class: 'ph-ok' }, h('button', { class: 'btn primary', type: 'button', onclick: () => { if (!ta.value.trim()) return toast('কী করতে হবে লিখুন'); aiEdit(ta.value.trim() + '. Keep everything else unchanged. Output only the edited image.'); } }, 'AI দিয়ে এডিট করুন')),
      h('div', { class: 'hint' }, 'বিনামূল্যের কী-তে ছবি-AI সীমিত বা বন্ধ থাকতে পারে; তখন ওপরের লোকাল টুল ব্যবহার করুন।'));
  }

  /* ---------- save ---------- */
  async function toBlob(type, q) { bakeTexts(); const c = cnv(base.width, base.height), g = g2(c); if (bgFill || type === 'image/jpeg') { g.fillStyle = bgFill || '#ffffff'; g.fillRect(0, 0, c.width, c.height); } g.drawImage(base, 0, 0); return { blob: await new Promise(r => c.toBlob(r, type, q)), c }; }
  function saveMenu() {
    const nm = baseName(meta ? meta.name : file.name || 'ছবি');
    const save = async (type, ext, replace) => {
      const { blob } = await toBlob(type, .92); const buf = await blob.arrayBuffer();
      if (replace && meta) { await db.save(meta.id, { buf, name: baseName(meta.name) + '.' + ext }); toast('ছবি আপডেট হয়েছে'); } else { await db.create({ name: await uniqueName(nm + ' (এডিট).' + ext), buf, kind: 'image' }); toast('নতুন ফাইল হিসেবে সেভ হয়েছে'); }
      dirty = false; window.__ao && window.__ao.refresh();
    };
    sheet('সেভ', [
      ...(meta ? [{ icon: 'save', label: 'মূল ছবি বদলে দিন', onClick: () => save(meta.ext === 'png' ? 'image/png' : 'image/jpeg', meta.ext === 'png' ? 'png' : 'jpg', true) }] : []),
      { icon: 'image', label: 'JPG হিসেবে সেভ', sub: 'ছোট সাইজ', onClick: () => save('image/jpeg', 'jpg') },
      { icon: 'image', label: 'PNG হিসেবে সেভ', sub: 'স্বচ্ছ ব্যাকগ্রাউন্ড থাকবে', onClick: () => save('image/png', 'png') },
      { icon: 'pdf', label: 'PDF করুন', onClick: async () => { const { blob } = await toBlob('image/jpeg', .92); const m = await import('./pdfview.js'); const r = await m.imagesToPdf([new File([blob], nm + '.jpg', { type: 'image/jpeg' })]); const mt = await db.create({ name: await uniqueName(r.name), buf: r.buf, kind: 'pdf' }); window.__ao.refresh(); toast('PDF ফাইলে যোগ হয়েছে'); dirty = false; } },
      { icon: 'text', label: 'ছবির লেখা → Word', onClick: async () => { const { blob } = await toBlob('image/jpeg', .9); const { ocrCanvas } = await import('./ocr.js'); try { const r = await withBusy('লেখা চেনা হচ্ছে…', () => ocrCanvas(clone(base))); scr.close(); await window.__ao.importFiles([new File([`<html><body>${r.html}</body></html>`], nm + '.html', { type: 'text/html' })], { open: true }); } catch (e) { toast(errMsg(e), 5000); } void blob; } },
      { icon: 'share', label: 'শেয়ার', onClick: async () => { const { blob } = await toBlob('image/jpeg', .92); shareFile(blob, nm + '.jpg'); } },
      { icon: 'download', label: 'ফোনে সেভ (Download)', onClick: async () => { const { blob } = await toBlob('image/png', 1); saveToDevice(blob, nm + '.png'); } },
    ]);
  }

  new ResizeObserver(() => layout()).observe(stage);
  render(); drawTabs(); switchTool(startTool || 'adjust');
}
