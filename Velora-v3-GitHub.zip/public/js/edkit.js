// Shared editor chrome: header bar, autosave, common menu actions.
import { h, icon, btn, sheet, toast, promptDlg, confirmDlg, saveToDevice, shareFile, fmtSize, fmtDate, KINDS, debounce, errMsg, baseName, extOf } from './util.js';
import { db, uniqueName } from './db.js';

// opts: { serialize: async()=>({buf,snap}), exports:[{icon,label,sub,run:async(ctx)=>{blob,name}}], extraMenu:[], undo, redo, canUndo, canRedo, readOnly }
export function makeHeader(ctx, opts) {
  const meta = () => ctx.meta;
  const titleB = h('b', null, meta().name);
  const status = h('small', null, KINDS[meta().kind].label);
  const titleBtn = h('button', { class: 'ed-title', type: 'button', onclick: rename, 'aria-label': 'নাম পরিবর্তন' }, titleB, status);
  const back = btn('back', 'ফিরুন', () => ctx.close(), { keepFocus: false });
  const undo = opts.undo ? btn('undo', 'আনডু', opts.undo) : null;
  const redo = opts.redo ? btn('redo', 'রিডু', opts.redo) : null;
  const more = btn('more', 'আরও', openMenu, { keepFocus: false });
  const saveB = btn('save', 'সংরক্ষণ', () => ctx.saveNow(true), { keepFocus: false });
  const el = h('div', { class: 'ed-top' }, back, titleBtn, undo, redo, saveB, more);

  async function rename() {
    const cur = meta().name; const b = baseName(cur), e = extOf(cur);
    const v = await promptDlg('ফাইলের নাম', { value: b });
    if (v == null) return; const nb = v.trim().replace(/[\\/:*?"<>|]/g, ''); if (!nb) return;
    const nn = nb + (e ? '.' + e : '');
    ctx.meta = await db.patch(meta().id, { name: nn }); titleB.textContent = nn; ctx.onRenamed && ctx.onRenamed(nn);
  }
  async function exportFile(ex) {
    try { await ctx.saveNow(); const r = await ex.run(ctx); if (!r) return; ctx.afterExport ? ctx.afterExport(r) : await offerOutput(ctx, r); } catch (e) { console.error(e); toast('ব্যর্থ: ' + errMsg(e), 4000); }
  }
  function openMenu() {
    const items = [];
    if (opts.extraMenu) items.push(...opts.extraMenu, { sep: true });
    items.push({ icon: 'pen', label: 'নাম পরিবর্তন', onClick: rename });
    items.push({ icon: 'share', label: 'শেয়ার করুন', sub: 'অন্য অ্যাপ বা ফোনে পাঠান', onClick: async () => { await ctx.saveNow(); const b = await ctx.currentBlob(); await shareFile(b, meta().name); } });
    items.push({ icon: 'download', label: 'ফোনে সেভ করুন', sub: 'ডাউনলোড / Documents ফোল্ডার', onClick: async () => { await ctx.saveNow(); const b = await ctx.currentBlob(); await saveToDevice(b, meta().name); } });
    if (opts.exports && opts.exports.length) { items.push({ sep: true }, { title: 'রূপান্তর / এক্সপোর্ট' }); for (const ex of opts.exports) items.push({ icon: ex.icon || 'file', label: ex.label, sub: ex.sub, onClick: () => exportFile(ex) }); }
    items.push({ sep: true });
    items.push({ icon: 'star', label: meta().starred ? 'তারকা সরান' : 'তারকা দিন', onClick: async () => { ctx.meta = await db.patch(meta().id, { starred: !meta().starred }); toast(ctx.meta.starred ? 'তারকা দেওয়া হয়েছে' : 'তারকা সরানো হয়েছে'); } });
    items.push({ icon: 'copy', label: 'কপি তৈরি করুন', onClick: async () => { await ctx.saveNow(); const buf = await db.buf(meta().id); const snap = await db.snap(meta().id); const nm = await uniqueName(baseName(meta().name) + ' - কপি.' + meta().ext); await db.create({ name: nm, buf, snap, kind: meta().kind }); toast('কপি তৈরি হয়েছে: ' + nm); } });
    items.push({ icon: 'info', label: 'ফাইলের তথ্য', onClick: () => info() });
    items.push({ icon: 'trash', label: 'মুছে ফেলুন', danger: true, onClick: async () => { if (await confirmDlg('ফাইল মুছবেন?', 'ফাইলটি ট্র্যাশে যাবে। চাইলে পরে ফিরিয়ে আনতে পারবেন।', { ok: 'মুছুন', danger: true })) { await db.patch(meta().id, { trashed: true, trashedAt: Date.now() }); ctx.discard(); toast('ট্র্যাশে সরানো হয়েছে'); } } });
    sheet(meta().name, items);
  }
  function info() {
    const m = meta();
    const rows = [['ধরন', KINDS[m.kind].label + ' (.' + m.ext + ')'], ['আকার', fmtSize(m.size)], ['তৈরি', fmtDate(m.created)], ['পরিবর্তন', fmtDate(m.modified)]];
    const box = h('div', null, rows.map(([a, b]) => h('div', { class: 'row', style: { padding: '8px 0' } }, h('div', { class: 'rt' }, a), h('div', null, b))));
    import('./util.js').then(u => u.modal({ title: 'ফাইলের তথ্য', body: box, actions: [{ label: 'ঠিক আছে', primary: true }] }));
  }
  const api = {
    el, status,
    setStatus(t) { status.textContent = t; },
    setUndo(canU, canR) { if (undo) undo.disabled = !canU; if (redo) redo.disabled = !canR; },
    setSaving(s) { api.setStatus(s === 'saving' ? 'সংরক্ষণ হচ্ছে…' : s === 'dirty' ? 'অসংরক্ষিত পরিবর্তন' : s === 'saved' ? 'সংরক্ষিত ✓' : s); },
  };
  return api;
}

// Autosave controller
export function autosave(ctx, serialize, hdr) {
  let dirty = false, saving = null, lastErr = false;
  const run = async (manual) => {
    if (!dirty && !manual) return;
    if (saving) { await saving; if (!dirty && !manual) return; }
    saving = (async () => {
      hdr && hdr.setSaving('saving'); dirty = false;
      try {
        const out = await serialize();
        ctx.meta = await db.save(ctx.meta.id, { buf: out.buf, snap: out.snap });
        ctx.lastBlob = null;
        hdr && hdr.setSaving('saved'); lastErr = false;
        if (manual) toast('সংরক্ষিত হয়েছে');
      } catch (e) {
        dirty = true; hdr && hdr.setSaving('সংরক্ষণ ব্যর্থ'); if (!lastErr) toast('সংরক্ষণ ব্যর্থ: ' + errMsg(e), 4500); lastErr = true; console.error(e);
      }
    })();
    await saving; saving = null;
  };
  const deb = debounce(() => run(false), 1400);
  const onHide = () => { if (document.hidden && dirty) run(false); };
  document.addEventListener('visibilitychange', onHide);
  const onPageHide = () => { if (dirty) run(false); };
  window.addEventListener('pagehide', onPageHide);
  return {
    mark() { dirty = true; hdr && hdr.setSaving('dirty'); deb(); },
    now: m => { deb.cancel(); return run(!!m); },
    isDirty: () => dirty,
    destroy() { deb.cancel(); document.removeEventListener('visibilitychange', onHide); window.removeEventListener('pagehide', onPageHide); },
  };
}

// After an export: save into the library and/or share.
export async function offerOutput(ctx, { blob, name, kind }) {
  const buf = await blob.arrayBuffer();
  const nm = await uniqueName(name);
  const meta = await db.create({ name: nm, buf, kind: kind || undefined });
  const body = h('p', { class: 'modal-p' }, `"${nm}" আপনার ফাইলে যোগ হয়েছে।`);
  const { modal } = await import('./util.js');
  modal({
    title: 'তৈরি হয়েছে ✓', body, actions: [
      { label: 'শেয়ার', ghost: true, onClick: () => { shareFile(blob, nm); } },
      { label: 'ফোনে সেভ', ghost: true, onClick: () => { saveToDevice(blob, nm); } },
      { label: 'খুলুন', primary: true, onClick: () => { ctx.openFile && ctx.openFile(meta.id); } }]
  });
  return meta;
}
