// Shared helpers: DOM, icons, dialogs, files
export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];

export function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  if (attrs) for (const k in attrs) {
    const v = attrs[k];
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'html') el.innerHTML = v;
    else if (k === 'dataset') Object.assign(el.dataset, v);
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat(Infinity)) {
    if (kid == null || kid === false) continue;
    el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return el;
}

const P = {
  back: '<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>',
  undo: '<polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/>',
  redo: '<polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>',
  save: '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/>',
  more: '<circle cx="12" cy="5" r="1.6" fill="currentColor"/><circle cx="12" cy="12" r="1.6" fill="currentColor"/><circle cx="12" cy="19" r="1.6" fill="currentColor"/>',
  plus: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
  minus: '<line x1="5" y1="12" x2="19" y2="12"/>',
  home: '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
  folder: '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
  settings: '<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
  search: '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
  star: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
  trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
  share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
  upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>',
  lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  unlock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/>',
  bold: '<path d="M6 4h8a4 4 0 0 1 0 8H6z"/><path d="M6 12h9a4 4 0 0 1 0 8H6z"/>',
  italic: '<line x1="19" y1="4" x2="10" y2="4"/><line x1="14" y1="20" x2="5" y2="20"/><line x1="15" y1="4" x2="9" y2="20"/>',
  underline: '<path d="M6 3v7a6 6 0 0 0 12 0V3"/><line x1="4" y1="21" x2="20" y2="21"/>',
  strike: '<path d="M17.3 5.5C16.5 4.3 14.6 3.5 12 3.5 9 3.5 7 5 7 7c0 4 10 2.5 10 7 0 2.2-2.2 3.5-5 3.5-2.8 0-4.8-1.2-5.3-3"/><line x1="3" y1="12" x2="21" y2="12"/>',
  alignL: '<line x1="17" y1="10" x2="3" y2="10"/><line x1="21" y1="6" x2="3" y2="6"/><line x1="21" y1="14" x2="3" y2="14"/><line x1="17" y1="18" x2="3" y2="18"/>',
  alignC: '<line x1="18" y1="10" x2="6" y2="10"/><line x1="21" y1="6" x2="3" y2="6"/><line x1="21" y1="14" x2="3" y2="14"/><line x1="18" y1="18" x2="6" y2="18"/>',
  alignR: '<line x1="21" y1="10" x2="7" y2="10"/><line x1="21" y1="6" x2="3" y2="6"/><line x1="21" y1="14" x2="3" y2="14"/><line x1="21" y1="18" x2="7" y2="18"/>',
  alignJ: '<line x1="21" y1="10" x2="3" y2="10"/><line x1="21" y1="6" x2="3" y2="6"/><line x1="21" y1="14" x2="3" y2="14"/><line x1="21" y1="18" x2="3" y2="18"/>',
  ul: '<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>',
  ol: '<line x1="10" y1="6" x2="21" y2="6"/><line x1="10" y1="12" x2="21" y2="12"/><line x1="10" y1="18" x2="21" y2="18"/><path d="M4 6h1v4"/><path d="M4 10h2"/><path d="M6 18H4c0-1 2-2 2-3s-1-1.5-2-1"/>',
  indent: '<polyline points="3 8 7 12 3 16"/><line x1="21" y1="12" x2="11" y2="12"/><line x1="21" y1="6" x2="11" y2="6"/><line x1="21" y1="18" x2="11" y2="18"/>',
  outdent: '<polyline points="7 8 3 12 7 16"/><line x1="21" y1="12" x2="11" y2="12"/><line x1="21" y1="6" x2="11" y2="6"/><line x1="21" y1="18" x2="11" y2="18"/>',
  image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/>',
  table: '<rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="3" y1="15" x2="21" y2="15"/><line x1="9" y1="3" x2="9" y2="21"/><line x1="15" y1="3" x2="15" y2="21"/>',
  link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
  x: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
  check: '<polyline points="20 6 9 17 4 12"/>',
  down: '<polyline points="6 9 12 15 18 9"/>',
  up: '<polyline points="18 15 12 9 6 15"/>',
  left: '<polyline points="15 18 9 12 15 6"/>',
  right: '<polyline points="9 18 15 12 9 6"/>',
  file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>',
  play: '<polygon points="5 3 19 12 5 21 5 3"/>',
  text: '<polyline points="4 7 4 4 20 4 20 7"/><line x1="9" y1="20" x2="15" y2="20"/><line x1="12" y1="4" x2="12" y2="20"/>',
  square: '<rect x="3" y="3" width="18" height="18" rx="2"/>',
  circle: '<circle cx="12" cy="12" r="10"/>',
  triangle: '<path d="M12 3L2 20h20z"/>',
  copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  cut: '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><line x1="20" y1="4" x2="8.12" y2="15.88"/><line x1="14.47" y1="14.48" x2="20" y2="20"/><line x1="8.12" y1="8.12" x2="12" y2="12"/>',
  paste: '<path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1"/>',
  camera: '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>',
  pen: '<path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  grid: '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>',
  pages: '<polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/>',
  zoomIn: '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><line x1="11" y1="8" x2="11" y2="14"/><line x1="8" y1="11" x2="14" y2="11"/>',
  zoomOut: '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><line x1="8" y1="11" x2="14" y2="11"/>',
  print: '<polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>',
  fontColor: '<path d="M7 16l5-12 5 12M9 12h6"/><path d="M4 21h16" stroke-width="3"/>',
  highlighter: '<path d="M9 11l-6 6v3h9l3-3"/><path d="M22 12l-4.6 4.6a2 2 0 0 1-2.8 0l-5.2-5.2a2 2 0 0 1 0-2.8L14 4"/>',
  fill: '<path d="M19 11l-8-8-8.6 8.6a2 2 0 0 0 0 2.8l5.2 5.2c.8.8 2 .8 2.8 0L19 11z"/><path d="M5 2l5 5"/><path d="M2 13h15"/><path d="M22 20a2 2 0 1 1-4 0c0-1.1 2-4 2-4s2 2.9 2 4z"/>',
  borders: '<rect x="3" y="3" width="18" height="18"/><line x1="12" y1="3" x2="12" y2="21"/><line x1="3" y1="12" x2="21" y2="12"/>',
  merge: '<path d="M8 3H5a2 2 0 0 0-2 2v3M21 8V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3M16 21h3a2 2 0 0 0 2-2v-3"/><line x1="8" y1="12" x2="16" y2="12"/><polyline points="10 9 8 12 10 15"/><polyline points="14 9 16 12 14 15"/>',
  sort: '<path d="M3 6h7M3 12h5M3 18h3"/><path d="M17 4v16M13 16l4 4 4-4"/>',
  filter: '<polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>',
  moon: '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>',
  info: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>',
  hand: '<path d="M18 11V6a2 2 0 0 0-4 0v5M14 10V4a2 2 0 0 0-4 0v6M10 10.5V5a2 2 0 0 0-4 0v9"/><path d="M18 11a2 2 0 1 1 4 0v3a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.9-5.9-2.4L3.4 16a2 2 0 0 1 3.2-2.4L8 15"/>',
  move: '<polyline points="5 9 2 12 5 15"/><polyline points="9 5 12 2 15 5"/><polyline points="15 19 12 22 9 19"/><polyline points="19 9 22 12 19 15"/><line x1="2" y1="12" x2="22" y2="12"/><line x1="12" y1="2" x2="12" y2="22"/>',
  arrowUp: '<line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/>',
  arrowDown: '<line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/>',
  arrowR: '<line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
  drop: '<path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/>',
  maximize: '<path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/>',
  list: '<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>',
  eraser: '<path d="M20 20H9L3.5 14.5a2 2 0 0 1 0-2.8l8-8a2 2 0 0 1 2.8 0l6 6a2 2 0 0 1 0 2.8L13 20"/>',
  rotate: '<polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>',
  hr: '<line x1="3" y1="12" x2="21" y2="12"/>',
  pageBreak: '<path d="M4 7V4h16v3"/><path d="M4 17v3h16v-3"/><line x1="2" y1="12" x2="6" y2="12"/><line x1="10" y1="12" x2="14" y2="12"/><line x1="18" y1="12" x2="22" y2="12"/>',
  clock: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
  open: '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/><line x1="12" y1="11" x2="12" y2="17"/><polyline points="9 14 12 11 15 14"/>',
  tpl: '<rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/>',
  sigma: '<path d="M18 7V4H6l6 8-6 8h12v-3"/>',
  chart: '<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>',
  word: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><path d="M8 12l1.5 6 2.5-6 2.5 6 1.5-6"/>',
  excel: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><path d="M9 12l6 6M15 12l-6 6"/>',
  ppt: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><path d="M9 18v-6h3a2 2 0 0 1 0 4H9"/>',
  pdf: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><path d="M8 17c1-4 3-6 4-8 1 2 1 5 4 7-3-1-6 0-8 1z"/>',
  sparkle: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/>',
  history: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><polyline points="3 3 3 8 8 8"/><polyline points="12 7 12 12 15 14"/>',
  type: '<polyline points="4 7 4 4 20 4 20 7"/><line x1="9" y1="20" x2="15" y2="20"/><line x1="12" y1="4" x2="12" y2="20"/>',
  eye: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
  sup: '<path d="M4 19l8-8M12 19L4 11"/><path d="M20 8h-4c0-1 1-2 2-2.5s2-1 2-2a1.5 1.5 0 0 0-3-.5"/>',
  sub: '<path d="M4 5l8 8M12 5l-8 8"/><path d="M20 21h-4c0-1 1-2 2-2.5s2-1 2-2a1.5 1.5 0 0 0-3-.5"/>',
};
export function icon(name, size = 20, cls = '') {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 24 24');
  s.setAttribute('width', size); s.setAttribute('height', size);
  s.setAttribute('fill', 'none'); s.setAttribute('stroke', 'currentColor');
  s.setAttribute('stroke-width', '2'); s.setAttribute('stroke-linecap', 'round'); s.setAttribute('stroke-linejoin', 'round');
  s.setAttribute('aria-hidden', 'true');
  if (cls) s.setAttribute('class', cls);
  s.innerHTML = P[name] || P.file;
  return s;
}
export const hasIcon = n => n in P;

export function btn(iconName, label, onClick, opts = {}) {
  const b = h('button', { class: 'tb ' + (opts.class || ''), type: 'button', title: label, 'aria-label': label, ...(opts.attrs || {}) });
  if (iconName) b.append(icon(iconName, opts.size || 20));
  if (opts.text) b.append(h('span', { class: 'tb-t' }, opts.text));
  if (onClick) b.addEventListener('click', onClick);
  // keep editor selection when tapping toolbar buttons
  if (opts.keepFocus !== false) b.addEventListener('mousedown', e => e.preventDefault());
  return b;
}

// ---- formatting ----
const bnDigits = '০১২৩৪৫৬৭৮৯';
export const toBn = s => String(s).replace(/\d/g, d => bnDigits[d]);
export const fromBn = s => String(s).replace(/[০-৯]/g, d => bnDigits.indexOf(d));
export function fmtSize(n) {
  if (n == null) return '';
  if (n < 1024) return n + ' B';
  if (n < 1048576) return (n / 1024).toFixed(n < 10240 ? 1 : 0) + ' KB';
  if (n < 1073741824) return (n / 1048576).toFixed(1) + ' MB';
  return (n / 1073741824).toFixed(2) + ' GB';
}
export function fmtDate(t) {
  const d = new Date(t), now = new Date();
  const day = 864e5, diff = Math.floor((new Date(now.getFullYear(), now.getMonth(), now.getDate()) - new Date(d.getFullYear(), d.getMonth(), d.getDate())) / day);
  const hm = d.toLocaleTimeString('bn-BD', { hour: 'numeric', minute: '2-digit' });
  if (diff === 0) return 'আজ ' + hm;
  if (diff === 1) return 'গতকাল ' + hm;
  return d.toLocaleDateString('bn-BD', { day: 'numeric', month: 'short', year: d.getFullYear() === now.getFullYear() ? undefined : 'numeric' });
}
export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
export const debounce = (fn, ms) => { let t; const f = (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; f.flush = () => { clearTimeout(t); fn(); }; f.cancel = () => clearTimeout(t); return f; };
export const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
export const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export const KINDS = {
  word: { label: 'Word', color: 'var(--word)', ext: 'docx', icon: 'word', mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' },
  excel: { label: 'Excel', color: 'var(--excel)', ext: 'xlsx', icon: 'excel', mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' },
  ppt: { label: 'PowerPoint', color: 'var(--ppt)', ext: 'pptx', icon: 'ppt', mime: 'application/vnd.openxmlformats-officedocument.presentationml.presentation' },
  pdf: { label: 'PDF', color: 'var(--pdf)', ext: 'pdf', icon: 'pdf', mime: 'application/pdf' },
  image: { label: 'ছবি', color: 'var(--img)', ext: 'png', icon: 'image', mime: 'image/png' },
  other: { label: 'ফাইল', color: 'var(--muted)', ext: 'txt', icon: 'file', mime: 'application/octet-stream' },
};
export function extOf(name) { const m = /\.([a-z0-9]+)$/i.exec(name || ''); return m ? m[1].toLowerCase() : ''; }
export function baseName(name) { return (name || '').replace(/\.[a-z0-9]+$/i, ''); }
export function kindOf(name, mime = '') {
  const e = extOf(name);
  if (['docx', 'dotx', 'doc', 'odt', 'rtf', 'md', 'markdown', 'html', 'htm'].includes(e)) return 'word';
  if (['xlsx', 'xlsm', 'xltx', 'xls', 'csv', 'tsv', 'ods'].includes(e)) return 'excel';
  if (['pptx', 'potx', 'ppsx', 'ppt', 'pps', 'odp'].includes(e)) return 'ppt';
  if (e === 'pdf' || mime === 'application/pdf') return 'pdf';
  if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'svg', 'avif'].includes(e) || mime.startsWith('image/')) return 'image';
  if (e === 'txt' || e === 'log' || e === 'json' || e === 'xml') return 'word';
  return 'other';
}

// ---- script loading ----
const loaded = {};
export function loadScript(src) {
  return loaded[src] ||= new Promise((res, rej) => {
    const s = document.createElement('script'); s.src = src; s.onload = () => res(); s.onerror = () => { delete loaded[src]; rej(new Error('লোড করা যায়নি: ' + src)); };
    document.head.append(s);
  });
}
export const needJSZip = async () => { if (!window.JSZip) await loadScript('/vendor/jszip.min.js'); return window.JSZip; };
export const needPDFLib = async () => { if (!window.PDFLib) await loadScript('/vendor/pdf-lib.min.js'); return window.PDFLib; };
export const needPptx = async () => { if (!window.PptxGenJS) await loadScript('/vendor/pptxgen.bundle.js'); return window.PptxGenJS; };
let pdfjsP;
export function needPdfJs() {
  return pdfjsP ||= import('/vendor/pdf.min.mjs').then(m => { m.GlobalWorkerOptions.workerSrc = '/vendor/pdf.worker.min.mjs'; return m; });
}

// ---- files in/out ----
export const readBuf = b => b.arrayBuffer ? b.arrayBuffer() : new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsArrayBuffer(b); });
export const readText = b => b.text ? b.text() : new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsText(b); });
export const readDataURL = b => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(b); });
export const dataURLtoBlob = u => { const [m, d] = u.split(','); const mime = /:(.*?);/.exec(m)[1]; const bin = atob(d); const a = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i); return new Blob([a], { type: mime }); };
export const blobToB64 = async b => { const u = await readDataURL(b); return u.slice(u.indexOf(',') + 1); };

// Android's picker (Samsung Gallery / My Files) matches on MIME types far better than on bare extensions,
// so every extension in `accept` is also sent as its MIME type.
const EXT_MIME = {
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation', '.pdf': 'application/pdf', '.csv': 'text/csv', '.txt': 'text/plain',
  '.md': 'text/markdown', '.html': 'text/html', '.htm': 'text/html', '.zip': 'application/zip',
};
function normAccept(accept) {
  if (!accept || accept === '*/*') return '*/*';
  const parts = accept.split(',').map(x => x.trim()).filter(Boolean), out = new Set(parts);
  for (const p of parts) if (EXT_MIME[p.toLowerCase()]) out.add(EXT_MIME[p.toLowerCase()]);
  return [...out].join(',');
}
const liveInputs = new Set();   // keep a reference so the input can't be garbage-collected while the picker is open
export function pickFiles({ accept = '*/*', multiple = false, capture } = {}) {
  return new Promise(res => {
    const i = document.createElement('input');
    i.type = 'file'; i.accept = normAccept(accept); i.multiple = !!multiple;
    i.setAttribute('style', 'position:fixed;left:-9999px;top:0;width:1px;height:1px;opacity:0;pointer-events:none');
    if (capture) i.setAttribute('capture', capture);
    let done = false;
    const fin = list => { if (done) return; done = true; liveInputs.delete(i); res(list); setTimeout(() => i.remove(), 1000); };
    i.addEventListener('change', () => fin([...(i.files || [])]));
    i.addEventListener('cancel', () => fin([]));
    liveInputs.add(i); document.body.append(i); i.click();
  });
}
const cap = () => window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform();
export const plugin = name => { const C = window.Capacitor; if (!C) return null; return (C.Plugins && C.Plugins[name]) || (C.registerPlugin ? C.registerPlugin(name) : null); };
async function nativeWrite(blob, name, dir) {
  const FS = plugin('Filesystem');
  const data = await blobToB64(blob);
  const path = (dir === 'DOCUMENTS' ? 'Velora/' : '') + name;
  const r = await FS.writeFile({ path, data, directory: dir, recursive: true });
  return r.uri;
}
export async function saveToDevice(blob, name) {
  if (cap() && plugin('Filesystem')) {
    // Android: copy into Downloads/Velora (no permission needed), so the file shows up in any file manager
    try {
      const V = plugin('VeloraIntent'); const uri = await nativeWrite(blob, name, 'CACHE');
      if (V) { await V.saveToDownloads({ uri, name, mime: blob.type || 'application/octet-stream' }); toast('সেভ হয়েছে: Download/Velora/' + name, 3600); return; }
    } catch (e) { console.warn(e); }
    // fallback: the share sheet lets the person pick "Save to…" themselves
    return shareFile(blob, name);
  }
  const a = h('a', { href: URL.createObjectURL(blob), download: name });
  document.body.append(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
  toast('ডাউনলোড শুরু হয়েছে: ' + name);
}
export async function shareFile(blob, name) {
  if (cap() && plugin('Share') && plugin('Filesystem')) {
    try { const uri = await nativeWrite(blob, name, 'CACHE'); await plugin('Share').share({ title: name, files: [uri] }); return; } catch (e) { if (e && /cancel/i.test(e.message || '')) return; console.warn(e); }
  }
  const f = new File([blob], name, { type: blob.type || 'application/octet-stream' });
  if (navigator.canShare && navigator.canShare({ files: [f] })) {
    try { await navigator.share({ files: [f], title: name }); return; } catch (e) { if (e.name === 'AbortError') return; }
  }
  if (cap()) { toast('শেয়ার করা যায়নি'); return; }
  await saveToDevice(blob, name);
}

// ---- toast ----
let toastEl, toastT;
export function toast(msg, ms = 2400) {
  if (!toastEl) { toastEl = h('div', { class: 'toast', role: 'status', 'aria-live': 'polite' }); document.body.append(toastEl); }
  toastEl.textContent = msg; toastEl.classList.add('show');
  clearTimeout(toastT); toastT = setTimeout(() => toastEl.classList.remove('show'), ms);
}

// ---- layers: modals / sheets, integrated with the Back button ----
const layers = [];
export function pushLayer(close) {
  const l = { close, done: false };
  layers.push(l);
  history.pushState({ layer: true }, '');
  return () => {
    if (l.done) return; l.done = true;
    const i = layers.indexOf(l); if (i >= 0) layers.splice(i, 1);
    // pop the dummy history entry we added, without re-triggering close
    skipPop++; history.back();
  };
}
let skipPop = 0;
window.addEventListener('popstate', e => {
  if (skipPop > 0) { skipPop--; e.stopImmediatePropagation(); return; }
  const l = layers.pop();
  if (l) { l.done = true; l.close(); e.stopImmediatePropagation(); }
}, true);
export const layerCount = () => layers.length;

function overlay(contentEl, { onClose, cls = '' } = {}) {
  const wrap = h('div', { class: 'ov ' + cls });
  const back = h('div', { class: 'ov-back' });
  wrap.append(back, contentEl);
  document.body.append(wrap);
  requestAnimationFrame(() => wrap.classList.add('in'));
  let closed = false;
  let release;
  const close = (fromPop) => {
    if (closed) return; closed = true;
    wrap.classList.remove('in');
    setTimeout(() => wrap.remove(), 180);
    if (!fromPop) release();
    onClose && onClose();
  };
  release = pushLayer(() => close(true));
  back.addEventListener('click', () => close());
  return { close, el: wrap };
}

export function modal({ title, body, actions = [], cls = '', wide = false }) {
  const box = h('div', { class: 'modal' + (wide ? ' wide' : ''), role: 'dialog', 'aria-modal': 'true', 'aria-label': title || '' });
  if (title) box.append(h('div', { class: 'modal-h' }, title));
  const b = h('div', { class: 'modal-b' }); if (body) b.append(body.nodeType ? body : h('p', null, body)); box.append(b);
  let ov;
  if (actions.length) {
    const f = h('div', { class: 'modal-f' });
    for (const a of actions) f.append(h('button', {
      class: 'btn ' + (a.primary ? 'primary ' : '') + (a.danger ? 'danger ' : '') + (a.ghost ? 'ghost' : ''), type: 'button',
      onclick: async () => { if (a.onClick) { const r = await a.onClick(ov); if (r === false) return; } ov.close(); }
    }, a.label));
    box.append(f);
  }
  ov = overlay(box, { cls: 'center ' + cls });
  return ov;
}
export function confirmDlg(title, msg, { ok = 'হ্যাঁ', cancel = 'বাতিল', danger = false } = {}) {
  return new Promise(res => {
    let result = false;
    const ov = modal({
      title, body: h('p', { class: 'modal-p' }, msg), actions: [
        { label: cancel, ghost: true, onClick: () => { result = false; } },
        { label: ok, primary: true, danger, onClick: () => { result = true; } }]
    });
    const o = ov.el; const obs = new MutationObserver(() => { if (!document.body.contains(o)) { obs.disconnect(); res(result); } });
    obs.observe(document.body, { childList: true });
  });
}
export function promptDlg(title, { value = '', placeholder = '', ok = 'ঠিক আছে', type = 'text', hint = '', inputmode, maxlength, multiline = false } = {}) {
  return new Promise(res => {
    let result = null;
    const inp = multiline ? h('textarea', { class: 'inp', rows: 4, placeholder }) : h('input', { class: 'inp', type, placeholder, value, inputmode, maxlength, autocomplete: 'off', spellcheck: 'false' });
    if (multiline) inp.value = value;
    const body = h('div', null, inp, hint ? h('div', { class: 'hint' }, hint) : null);
    const ov = modal({
      title, body, actions: [
        { label: 'বাতিল', ghost: true, onClick: () => { result = null; } },
        { label: ok, primary: true, onClick: () => { result = inp.value; } }]
    });
    inp.addEventListener('keydown', e => { if (e.key === 'Enter' && !multiline) { result = inp.value; ov.close(); } });
    setTimeout(() => { inp.focus(); inp.select && inp.select(); }, 80);
    const o = ov.el; const obs = new MutationObserver(() => { if (!document.body.contains(o)) { obs.disconnect(); res(result); } });
    obs.observe(document.body, { childList: true });
  });
}
// action sheet: items [{icon,label,sub,onClick,danger,disabled} | {sep:true} | {title:''}]
export function sheet(title, items, { cls = '' } = {}) {
  const box = h('div', { class: 'sheet ' + cls, role: 'menu' });
  box.append(h('div', { class: 'sheet-grip' }));
  if (title) box.append(h('div', { class: 'sheet-h' }, title));
  const list = h('div', { class: 'sheet-l' });
  let ov;
  for (const it of items) {
    if (!it) continue;
    if (it.sep) { list.append(h('div', { class: 'sheet-sep' })); continue; }
    if (it.title) { list.append(h('div', { class: 'sheet-t' }, it.title)); continue; }
    const row = h('button', {
      class: 'sheet-i' + (it.danger ? ' danger' : '') + (it.active ? ' active' : ''), type: 'button', role: 'menuitem', disabled: it.disabled,
      onclick: () => { ov.close(); setTimeout(() => it.onClick && it.onClick(), 60); }
    }, it.icon ? icon(it.icon, 20) : h('span', { class: 'sheet-ic' }),
      h('span', { class: 'sheet-tx' }, h('span', null, it.label), it.sub ? h('small', null, it.sub) : null),
      it.active ? icon('check', 18) : null);
    list.append(row);
  }
  box.append(list);
  ov = overlay(box, { cls: 'bottom' });
  return ov;
}
const PALETTE = ['#000000', '#434343', '#666666', '#999999', '#b7b7b7', '#cccccc', '#efefef', '#ffffff',
  '#d92d20', '#f04438', '#f79009', '#fdb022', '#fde047', '#a3e635', '#17b26a', '#12b76a',
  '#06aed4', '#2e90fa', '#3157e0', '#7a5af8', '#a855f7', '#ee46bc', '#f63d68', '#e8590c',
  '#fecdca', '#fed7aa', '#fef0c7', '#d1fadf', '#cff9fe', '#d1e9ff', '#e0eaff', '#ebe9fe',
  '#912018', '#b54708', '#7a5d00', '#05603a', '#0e7090', '#175cd3', '#2a3fa0', '#5925dc'];
export function pickColor({ title = 'রঙ বাছাই করুন', current, none = false, noneLabel = 'কোনো রঙ নয়' } = {}) {
  return new Promise(res => {
    let result;
    const grid = h('div', { class: 'swatches' });
    let ov;
    const done = c => { result = c; ov.close(); };
    for (const c of PALETTE) grid.append(h('button', { class: 'sw' + (current && current.toLowerCase() === c ? ' on' : ''), type: 'button', style: { background: c }, 'aria-label': c, onclick: () => done(c) }));
    const custom = h('input', { type: 'color', class: 'sw-custom', value: /^#[0-9a-f]{6}$/i.test(current || '') ? current : '#3157e0' });
    custom.addEventListener('change', () => done(custom.value));
    const row = h('div', { class: 'sw-row' }, h('label', { class: 'btn ghost' }, 'কাস্টম রঙ ', custom), none ? h('button', { class: 'btn ghost', type: 'button', onclick: () => done(null) }, noneLabel) : null);
    const box = h('div', { class: 'sheet colorsheet' }, h('div', { class: 'sheet-grip' }), h('div', { class: 'sheet-h' }, title), grid, row);
    ov = overlay(box, { cls: 'bottom', onClose: () => res(result) });
  });
}
export function busy(msg) {
  const box = h('div', { class: 'busy' }, h('div', { class: 'spin' }), h('div', { class: 'busy-t' }, msg));
  const wrap = h('div', { class: 'ov in center busy-ov' }, h('div', { class: 'ov-back' }), box);
  document.body.append(wrap);
  return { set: m => { box.lastChild.textContent = m; }, done: () => wrap.remove() };
}
export async function withBusy(msg, fn) {
  const b = busy(msg);
  try { return await fn(b); } finally { b.done(); }
}
export function errMsg(e) { return (e && (e.message || e.name)) || String(e); }

// ---- images ----
export function loadImage(src) { return new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('ছবি পড়া যায়নি')); i.src = src; }); }
export async function imageToDataURL(file, maxW = 1600, quality = 0.88) {
  const url = URL.createObjectURL(file);
  try {
    const img = await loadImage(url);
    let w = img.naturalWidth, hh = img.naturalHeight;
    if (/svg/.test(file.type)) return { url: await readDataURL(file), w: w || 300, h: hh || 200 };
    const sc = Math.min(1, maxW / w); w = Math.round(w * sc); hh = Math.round(hh * sc);
    const c = document.createElement('canvas'); c.width = w; c.height = hh;
    const g = c.getContext('2d');
    const png = /png|gif|webp/.test(file.type);
    if (!png) { g.fillStyle = '#fff'; g.fillRect(0, 0, w, hh); }
    g.drawImage(img, 0, 0, w, hh);
    return { url: c.toDataURL(png ? 'image/png' : 'image/jpeg', quality), w, h: hh };
  } finally { URL.revokeObjectURL(url); }
}
