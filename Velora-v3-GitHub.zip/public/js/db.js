// IndexedDB storage — files live in the phone's own app storage.
import { uid, extOf, kindOf, baseName } from './util.js';

const DB_NAME = 'amar-office', VER = 1;
let dbp;
function open() {
  return dbp ||= new Promise((res, rej) => {
    const r = indexedDB.open(DB_NAME, VER);
    r.onupgradeneeded = () => {
      const d = r.result;
      if (!d.objectStoreNames.contains('meta')) d.createObjectStore('meta', { keyPath: 'id' });
      if (!d.objectStoreNames.contains('data')) d.createObjectStore('data');
      if (!d.objectStoreNames.contains('snap')) d.createObjectStore('snap');
      if (!d.objectStoreNames.contains('kv')) d.createObjectStore('kv');
    };
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
    r.onblocked = () => rej(new Error('ডাটাবেস ব্লকড'));
  });
}
function tx(stores, mode, fn) {
  return open().then(db => new Promise((res, rej) => {
    const t = db.transaction(stores, mode);
    let out;
    Promise.resolve(fn(...[].concat(stores).map(s => t.objectStore(s)))).then(v => { out = v; }, rej);
    t.oncomplete = () => res(out);
    t.onerror = () => rej(t.error);
    t.onabort = () => rej(t.error || new Error('সংরক্ষণ ব্যর্থ (স্টোরেজ ভরে গেছে?)'));
  }));
}
const req = r => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });

export const db = {
  async list() { return tx('meta', 'readonly', s => req(s.getAll())); },
  async meta(id) { return tx('meta', 'readonly', s => req(s.get(id))); },
  async buf(id) { const r = await tx('data', 'readonly', s => req(s.get(id))); return r || null; },
  async snap(id) { return tx('snap', 'readonly', s => req(s.get(id))); },
  async create({ name, buf, snap, kind, folder = '' }) {
    const id = uid();
    const now = Date.now();
    const meta = { id, name, kind: kind || kindOf(name), ext: extOf(name), size: buf.byteLength, created: now, modified: now, opened: now, starred: false, trashed: false, folder };
    await tx(['meta', 'data', 'snap'], 'readwrite', (m, d, s) => {
      m.put(meta); d.put(buf, id); if (snap !== undefined) s.put(snap, id);
    });
    return meta;
  },
  async save(id, { buf, snap, name }) {
    const meta = await this.meta(id);
    if (!meta) throw new Error('ফাইল পাওয়া যায়নি');
    if (buf) meta.size = buf.byteLength;
    if (name) { meta.name = name; meta.ext = extOf(name); }
    meta.modified = Date.now();
    await tx(['meta', 'data', 'snap'], 'readwrite', (m, d, s) => {
      m.put(meta); if (buf) d.put(buf, id); if (snap !== undefined) s.put(snap, id);
    });
    return meta;
  },
  async patch(id, p) {
    const meta = await this.meta(id); if (!meta) return null;
    Object.assign(meta, p);
    await tx('meta', 'readwrite', s => { s.put(meta); });
    return meta;
  },
  async remove(id) { await tx(['meta', 'data', 'snap'], 'readwrite', (m, d, s) => { m.delete(id); d.delete(id); s.delete(id); }); },
  async clearSnap(id) { await tx('snap', 'readwrite', s => { s.delete(id); }); },
  async kvGet(k, def) { const v = await tx('kv', 'readonly', s => req(s.get(k))); return v === undefined ? def : v; },
  async kvSet(k, v) { await tx('kv', 'readwrite', s => { s.put(v, k); }); },
  async kvDel(k) { await tx('kv', 'readwrite', s => { s.delete(k); }); },
  async wipeAll() { await tx(['meta', 'data', 'snap', 'kv'], 'readwrite', (a, b, c, d) => { a.clear(); b.clear(); c.clear(); d.clear(); }); },
  async usage() {
    const metas = await this.list();
    const total = metas.reduce((a, m) => a + (m.size || 0), 0);
    let quota = null, used = null;
    try { const e = await navigator.storage.estimate(); quota = e.quota; used = e.usage; } catch { }
    return { count: metas.length, total, quota, used };
  },
};

export async function requestPersist() {
  try { if (navigator.storage && navigator.storage.persist) return await navigator.storage.persist(); } catch { }
  return false;
}
export async function isPersisted() { try { return navigator.storage && navigator.storage.persisted ? await navigator.storage.persisted() : false; } catch { return false; } }

// Settings with defaults
export const defaults = { theme: 'auto', lockOn: false, autoLock: 60, view: 'grid', sort: 'modified', author: '', fontSize: 'md' };
let cache = null;
export async function getSettings() { if (!cache) cache = { ...defaults, ...(await db.kvGet('settings', {})) }; return cache; }
export async function setSetting(k, v) { const s = await getSettings(); s[k] = v; await db.kvSet('settings', s); return s; }

// Unique name helper
export async function uniqueName(name) {
  const all = (await db.list()).filter(m => !m.trashed).map(m => m.name.toLowerCase());
  if (!all.includes(name.toLowerCase())) return name;
  const b = baseName(name), e = extOf(name) ? '.' + extOf(name) : '';
  for (let i = 2; i < 999; i++) { const n = `${b} (${i})${e}`; if (!all.includes(n.toLowerCase())) return n; }
  return name;
}
