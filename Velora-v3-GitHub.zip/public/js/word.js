// Word processor: contenteditable editor with DOCX import/export, templates, tables, images, PDF export.
import { h, icon, btn, sheet, modal, promptDlg, pickColor, pickFiles, toast, withBusy, busy, imageToDataURL, readText, readBuf, baseName, extOf, debounce, errMsg, toBn, esc, pushLayer } from './util.js';
import { getSettings } from './db.js';
import { makeHeader, autosave } from './edkit.js';
import { htmlToDocx, docxToHtml } from './docx.js';
import { WORD_TPLS } from './templates.js';

export const PRINT_CSS = `.pdfdoc{font-family:'Noto Serif Bengali','Noto Sans Bengali','Kalpurush','Nirmala UI',Calibri,'Segoe UI',Arial,sans-serif;font-size:16px;line-height:1.5;color:#111;word-wrap:break-word;overflow-wrap:anywhere}
.pdfdoc p{margin:0 0 .6em}.pdfdoc h1{font-size:2em;margin:.4em 0 .3em;line-height:1.2}.pdfdoc h2{font-size:1.6em;margin:.4em 0 .3em;line-height:1.2}.pdfdoc h3{font-size:1.3em;margin:.4em 0 .3em}.pdfdoc h4{font-size:1.1em;margin:.4em 0 .3em}
.pdfdoc table{border-collapse:collapse;width:100%;margin:.4em 0 .8em}.pdfdoc td,.pdfdoc th{border:1px solid #888;padding:6px 8px;vertical-align:top}.pdfdoc th{font-weight:bold;text-align:center}.pdfdoc table.nob td,.pdfdoc table.nob th{border:0}
.pdfdoc img{max-width:100%;height:auto}.pdfdoc blockquote{border-left:4px solid #c3c9de;margin:.6em 0;padding:.2em 1em;color:#444}.pdfdoc hr{border:0;border-top:1px solid #999;margin:1em 0}.pdfdoc ul,.pdfdoc ol{margin:0 0 .6em;padding-left:1.6em}.pdfdoc a{color:#0563c1;text-decoration:underline}.pdfdoc .pagebreak{height:0;border:0;margin:0}`;

const TAGS = new Set('a b strong i em u s strike del ins sub sup span font p div br h1 h2 h3 h4 h5 h6 ul ol li table thead tbody tfoot tr td th colgroup col blockquote pre code hr img mark small big center caption'.split(' '));
const STYLE_OK = /^(color|background-color|background|font-size|font-family|font-weight|font-style|text-decoration|text-decoration-line|text-align|margin-left|text-indent|width|height|vertical-align|line-height)$/;
export function sanitize(html) {
  const doc = new DOMParser().parseFromString('<body>' + html + '</body>', 'text/html');
  const walk = n => {
    for (const c of [...n.childNodes]) {
      if (c.nodeType === 8) { c.remove(); continue; }
      if (c.nodeType !== 1) continue;
      const t = c.tagName.toLowerCase();
      if (!TAGS.has(t)) { if (/^(script|style|iframe|object|embed|link|meta|form|input|button|textarea|select|svg|math|noscript|template|head|title)$/.test(t)) { c.remove(); continue; } walk(c); c.replaceWith(...c.childNodes); continue; }
      for (const a of [...c.attributes]) {
        const nm = a.name.toLowerCase(), v = a.value;
        let ok = false;
        if (nm === 'style') { const keep = []; for (const part of v.split(';')) { const [k, ...r] = part.split(':'); const kk = (k || '').trim().toLowerCase(), vv = r.join(':').trim(); if (STYLE_OK.test(kk) && vv && !/url\(|expression|javascript|@import/i.test(vv)) keep.push(kk + ':' + vv); } if (keep.length) { c.setAttribute('style', keep.join(';')); } else c.removeAttribute('style'); continue; }
        else if (nm === 'href') ok = /^(https?:|mailto:|tel:|#)/i.test(v.trim());
        else if (nm === 'src') ok = /^(data:image\/(png|jpe?g|gif|webp|bmp|svg\+xml);|https?:|blob:)/i.test(v.trim());
        else if (['colspan', 'rowspan', 'start', 'alt', 'width', 'height', 'align', 'color', 'face', 'size', 'bgcolor', 'type'].includes(nm)) ok = true;
        else if (nm === 'class') ok = /^(pagebreak|nob)( |$)/.test(v);
        else if (nm === 'contenteditable') ok = v === 'false';
        if (!ok) c.removeAttribute(a.name);
      }
      if (t === 'a') { c.setAttribute('rel', 'noopener noreferrer'); c.setAttribute('target', '_blank'); }
      walk(c);
    }
  };
  walk(doc.body); return doc.body.innerHTML;
}

const mdInline = s => esc(s).replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>').replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<i>$2</i>').replace(/~~([^~]+)~~/g, '<s>$1</s>').replace(/\[([^\]]+)\]\((https?:[^)\s]+)\)/g, '<a href="$2">$1</a>');
export function mdToHtml(md) {
  const lines = md.replace(/\r/g, '').split('\n'); let out = '', list = null, para = [];
  const fp = () => { if (para.length) { out += '<p>' + para.map(mdInline).join('<br>') + '</p>'; para = []; } };
  const fl = () => { if (list) { out += `</${list}>`; list = null; } };
  for (const ln of lines) {
    let m;
    if (/^\s*$/.test(ln)) { fp(); fl(); continue; }
    if ((m = /^(#{1,6})\s+(.*)$/.exec(ln))) { fp(); fl(); out += `<h${m[1].length}>${mdInline(m[2])}</h${m[1].length}>`; continue; }
    if (/^(-{3,}|\*{3,})\s*$/.test(ln)) { fp(); fl(); out += '<hr>'; continue; }
    if ((m = /^\s*[-*+]\s+(.*)$/.exec(ln))) { fp(); if (list !== 'ul') { fl(); out += '<ul>'; list = 'ul'; } out += `<li>${mdInline(m[1])}</li>`; continue; }
    if ((m = /^\s*\d+[.)]\s+(.*)$/.exec(ln))) { fp(); if (list !== 'ol') { fl(); out += '<ol>'; list = 'ol'; } out += `<li>${mdInline(m[1])}</li>`; continue; }
    if ((m = /^>\s?(.*)$/.exec(ln))) { fp(); fl(); out += `<blockquote><p>${mdInline(m[1])}</p></blockquote>`; continue; }
    fl(); para.push(ln);
  }
  fp(); fl(); return out || '<p><br></p>';
}
const textToHtml = t => t.replace(/\r/g, '').split('\n').map(l => `<p>${l ? esc(l) : '<br>'}</p>`).join('');

async function docxFromHtml(html, meta = {}) {
  const d = document.createElement('div'); d.innerHTML = sanitize(html);
  const s = await getSettings();
  return htmlToDocx(d, { title: meta.title || '', author: s.author || '' });
}
const today = () => new Date().toLocaleDateString('bn-BD', { day: 'numeric', month: 'long', year: 'numeric' });

export async function blank({ tpl } = {}) {
  const t = WORD_TPLS.find(x => x.id === tpl) || WORD_TPLS[0];
  const html = t.html.replace('০১ জানুয়ারি ২০২৬', today()).replace('1 January 2026', new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }));
  return { name: t.file + '.docx', buf: await docxFromHtml(html, { title: t.file }), snap: sanitize(html) };
}
export async function importFile(file) {
  const ext = extOf(file.name), name = baseName(file.name) + '.docx';
  let html;
  if (ext === 'dotx') html = (await docxToHtml(await readBuf(file))).html;
  else if (ext === 'md' || ext === 'markdown') html = mdToHtml(await readText(file));
  else if (ext === 'html' || ext === 'htm') { const t = await readText(file); const m = /<body[^>]*>([\s\S]*)<\/body>/i.exec(t); html = sanitize(m ? m[1] : t); }
  else html = textToHtml(await readText(file));
  return { name, buf: await docxFromHtml(html, { title: baseName(file.name) }), snap: sanitize(html) };
}

/* ====================== editor ====================== */
const FONTS = [['', 'ডিফল্ট'], ['Noto Sans Bengali', 'Noto Sans Bengali'], ['Kalpurush', 'কালপুরুষ'], ['SolaimanLipi', 'সোলায়মানলিপি'], ['Siyam Rupali', 'সিয়াম রূপালী'], ['Nirmala UI', 'Nirmala UI'], ['Calibri', 'Calibri'], ['Arial', 'Arial'], ['Times New Roman', 'Times New Roman'], ['Georgia', 'Georgia'], ['Verdana', 'Verdana'], ['Courier New', 'Courier New']];
const SIZES = [8, 9, 10, 11, 12, 14, 16, 18, 20, 24, 28, 32, 36, 48, 72];

export async function mount(ctx) {
  let html;
  if (typeof ctx.snap === 'string') html = ctx.snap;
  else if (ctx.buf && ctx.buf.byteLength) html = (await docxToHtml(ctx.buf)).html;
  else html = '<p><br></p>';
  html = sanitize(html) || '<p><br></p>';

  const page = h('div', { class: 'wd-page', contenteditable: 'true', spellcheck: 'false', lang: 'bn', role: 'textbox', 'aria-multiline': 'true', 'aria-label': 'ডকুমেন্ট' });
  page.innerHTML = html;
  const wrap = h('div', { class: 'wd-wrap' }, page);
  const count = h('div', { class: 'wd-count' }, '');
  let hdr, as;

  /* ---- history (snapshot based, works with tables/images) ---- */
  const hist = [{ html: page.innerHTML, c: 0 }]; let hi = 0, pending = false, restoring = false;
  const caretOffset = () => { const s = getSelection(); if (!s.rangeCount || !page.contains(s.anchorNode)) return 0; const r = document.createRange(); r.selectNodeContents(page); r.setEnd(s.anchorNode, s.anchorOffset); return r.toString().length; };
  const setCaret = off => {
    const w = document.createTreeWalker(page, NodeFilter.SHOW_TEXT); let n, acc = 0;
    while ((n = w.nextNode())) { if (acc + n.data.length >= off) { const r = document.createRange(); r.setStart(n, off - acc); r.collapse(true); const s = getSelection(); s.removeAllRanges(); s.addRange(r); return; } acc += n.data.length; }
    const r = document.createRange(); r.selectNodeContents(page); r.collapse(false); const s = getSelection(); s.removeAllRanges(); s.addRange(r);
  };
  const commit = () => {
    if (restoring) return; pending = false; const cur = page.innerHTML; if (cur === hist[hi].html) return;
    hist.length = hi + 1; hist.push({ html: cur, c: caretOffset() }); if (hist.length > 150) hist.shift(); hi = hist.length - 1; upd();
  };
  const commitDeb = debounce(commit, 500);
  function go(d) {
    commit(); const n = hi + d; if (n < 0 || n >= hist.length) return;
    hi = n; restoring = true; page.innerHTML = hist[hi].html; page.focus(); setCaret(hist[hi].c); restoring = false; changed(true); upd();
  }
  const undo = () => go(-1), redo = () => go(1);
  const upd = () => hdr && hdr.setUndo(hi > 0 || pending, hi < hist.length - 1);

  function changed(skipHist) {
    if (!skipHist) { pending = true; commitDeb(); }
    as && as.mark(); countDeb(); upd();
  }
  const countDeb = debounce(() => {
    const t = page.innerText || ''; const words = t.trim() ? t.trim().split(/\s+/).length : 0;
    count.textContent = `${toBn(words)} শব্দ · ${toBn(t.replace(/\s/g, '').length)} অক্ষর`;
  }, 300);

  /* ---- selection helpers ---- */
  let saved = null;
  document.addEventListener('selectionchange', onSel);
  function onSel() {
    const s = getSelection(); if (s.rangeCount && page.contains(s.anchorNode)) { saved = s.getRangeAt(0).cloneRange(); syncState(); }
  }
  function restore() {
    page.focus({ preventScroll: true });
    if (saved) { const s = getSelection(); s.removeAllRanges(); s.addRange(saved); }
    try { document.execCommand('styleWithCSS', false, true); } catch { }
  }
  const cmd = (c, v) => { restore(); document.execCommand(c, false, v ?? null); changed(); syncState(); };
  let pendingPx = null;
  function fixFonts() {
    const els = page.querySelectorAll('font[size="7"], span[style*="xxx-large"]');
    els.forEach(f => {
      const sp = document.createElement('span'); sp.style.fontSize = (pendingPx || 16) + 'px';
      while (f.firstChild) sp.append(f.firstChild);
      sp.querySelectorAll('[style*="font-size"]').forEach(x => { x.style.fontSize = ''; if (!x.getAttribute('style')) x.removeAttribute('style'); });
      f.replaceWith(sp);
    });
    page.querySelectorAll('font[face]').forEach(f => { const sp = document.createElement('span'); sp.style.fontFamily = f.getAttribute('face'); while (f.firstChild) sp.append(f.firstChild); f.replaceWith(sp); });
  }
  function applySize(pt) { restore(); pendingPx = Math.round(pt * 4 / 3 * 10) / 10; document.execCommand('styleWithCSS', false, false); document.execCommand('fontSize', false, '7'); document.execCommand('styleWithCSS', false, true); fixFonts(); changed(); syncState(); }
  const curPx = () => { const s = getSelection(); let n = s.anchorNode; if (!n || !page.contains(n)) return 16; if (n.nodeType === 3) n = n.parentElement; return parseFloat(getComputedStyle(n).fontSize) || 16; };
  function stepSize(d) { const pt = Math.round(curPx() * 0.75); let i = SIZES.findIndex(v => v >= pt); if (i < 0) i = SIZES.length - 1; if (d > 0) i = SIZES[i] > pt ? i : Math.min(SIZES.length - 1, i + 1); else i = SIZES[i] < pt ? i : Math.max(0, i - 1); applySize(SIZES[i]); }

  /* ---- toolbar ---- */
  const T = {}; // state-aware buttons
  const sizeLab = h('span', { class: 'tb-t' }, '12');
  const sizeBox = h('button', { class: 'tb', type: 'button', title: 'ফন্টের মাপ', style: { minWidth: '46px' }, onmousedown: e => e.preventDefault(), onclick: () => sheet('ফন্টের মাপ (pt)', SIZES.map(s => ({ icon: 'type', label: toBn(s), onClick: () => applySize(s) }))) }, sizeLab);
  const fontSel = h('select', { class: 'tsel', 'aria-label': 'ফন্ট', onchange: () => { const v = fontSel.value; restore(); if (v) document.execCommand('fontName', false, v); else document.execCommand('removeFormat'); fixFonts(); changed(); } }, FONTS.map(([v, t]) => h('option', { value: v }, t)));
  const mk = (id, ic, label, fn, o) => (T[id] = btn(ic, label, fn, o));
  let fcColor = '#d92d20', hlColor = '#fde047';
  const colorBtn = (ic, label, get, set, cmdName, none) => {
    const sw = h('i', { style: { background: get() } });
    const b = h('button', { class: 'tb colorbtn', type: 'button', title: label, 'aria-label': label, onmousedown: e => e.preventDefault() }, icon(ic, 20), sw);
    b.addEventListener('click', async () => { const keep = saved; const c = await pickColor({ title: label, current: get(), none, noneLabel: 'রঙ সরান' }); saved = keep; if (c === undefined) return; if (c === null) { restore(); document.execCommand(cmdName, false, cmdName === 'foreColor' ? '#000000' : 'transparent'); if (cmdName !== 'foreColor') document.execCommand('removeFormat', false); changed(); return; } set(c); sw.style.background = c; restore(); document.execCommand(cmdName, false, c); changed(); });
    return b;
  };
  const headSel = h('select', { class: 'tsel', 'aria-label': 'অনুচ্ছেদের ধরন', onchange: () => { restore(); document.execCommand('formatBlock', false, '<' + headSel.value + '>'); changed(); } }, [['p', 'সাধারণ'], ['h1', 'শিরোনাম ১'], ['h2', 'শিরোনাম ২'], ['h3', 'শিরোনাম ৩'], ['h4', 'শিরোনাম ৪']].map(([v, t]) => h('option', { value: v }, t)));

  const tabs = {
    home: () => [fontSel, sizeBox, mk('b', 'bold', 'বোল্ড', () => cmd('bold')), mk('i', 'italic', 'ইটালিক', () => cmd('italic')), mk('u', 'underline', 'আন্ডারলাইন', () => cmd('underline')), mk('s', 'strike', 'কাটা লেখা', () => cmd('strikeThrough')),
      colorBtn('fontColor', 'লেখার রঙ', () => fcColor, c => fcColor = c, 'foreColor'), colorBtn('highlighter', 'হাইলাইট', () => hlColor, c => hlColor = c, 'hiliteColor', true),
      h('span', { class: 'tsep' }), mk('sup', 'sup', 'উপরে লেখা', () => cmd('superscript')), mk('sub', 'sub', 'নিচে লেখা', () => cmd('subscript')), btn('eraser', 'ফরম্যাট মুছুন', () => { restore(); document.execCommand('removeFormat'); changed(); })],
    para: () => [headSel, mk('aL', 'alignL', 'বামে', () => cmd('justifyLeft')), mk('aC', 'alignC', 'মাঝে', () => cmd('justifyCenter')), mk('aR', 'alignR', 'ডানে', () => cmd('justifyRight')), mk('aJ', 'alignJ', 'দুই পাশে', () => cmd('justifyFull')), h('span', { class: 'tsep' }),
      mk('ul', 'ul', 'বুলেট তালিকা', () => cmd('insertUnorderedList')), mk('ol', 'ol', 'ক্রমিক তালিকা', () => cmd('insertOrderedList')), btn('outdent', 'ইনডেন্ট কমান', () => cmd('outdent')), btn('indent', 'ইনডেন্ট বাড়ান', () => cmd('indent')), btn('text', 'ব্লককোট', () => cmd('formatBlock', '<blockquote>'))],
    insert: () => [btn('image', 'ছবি', insertImage, { text: 'ছবি' }), btn('camera', 'ক্যামেরা', () => insertImage(true), { text: 'ক্যামেরা' }), btn('table', 'টেবিল', insertTable, { text: 'টেবিল' }), btn('link', 'লিংক', insertLink, { text: 'লিংক' }), btn('hr', 'রেখা', () => cmd('insertHorizontalRule'), { text: 'রেখা' }), btn('pageBreak', 'পৃষ্ঠা বিরতি', insertPageBreak, { text: 'নতুন পাতা' }), btn('clock', 'তারিখ', () => { restore(); document.execCommand('insertText', false, today()); changed(); }, { text: 'তারিখ' })],
    table: () => [btn('plus', 'উপরে সারি', () => tbl('rowAbove'), { text: 'সারি ↑' }), btn('plus', 'নিচে সারি', () => tbl('rowBelow'), { text: 'সারি ↓' }), btn('plus', 'বামে কলাম', () => tbl('colLeft'), { text: 'কলাম ←' }), btn('plus', 'ডানে কলাম', () => tbl('colRight'), { text: 'কলাম →' }), h('span', { class: 'tsep' }),
      btn('merge', 'ডানের সাথে মেলান', () => tbl('merge'), { text: 'মেলান' }), btn('grid', 'ঘর ভাগ', () => tbl('split'), { text: 'ভাগ' }), btn('fill', 'ঘরের রঙ', () => tbl('bg'), { text: 'রঙ' }), btn('borders', 'বর্ডার', () => tbl('border'), { text: 'বর্ডার' }), h('span', { class: 'tsep' }),
      btn('minus', 'সারি মুছুন', () => tbl('delRow'), { text: 'সারি' }), btn('minus', 'কলাম মুছুন', () => tbl('delCol'), { text: 'কলাম' }), btn('trash', 'টেবিল মুছুন', () => tbl('delTable'), { text: 'টেবিল' })],
    view: () => [btn('search', 'খুঁজুন ও বদলান', openFind, { text: 'খুঁজুন' }), btn('zoomOut', 'ছোট', () => zoom(-.1)), zoomLab,btn('zoomIn', 'বড়', () => zoom(.1)), btn('maximize', 'পুরো প্রস্থ', () => { z = 1; applyZoom(); }, { text: 'ফিট' }), btn('print', 'প্রিন্ট', doPrint, { text: 'প্রিন্ট' })],
  };
  const zoomLab = h('span', { class: 'tb-t', style: { minWidth: '44px', textAlign: 'center' } }, '১০০%');
  const TABS = [['home', 'হোম'], ['para', 'অনুচ্ছেদ'], ['insert', 'ঢোকান'], ['table', 'টেবিল'], ['view', 'দেখুন']];
  let curTab = localStorage.getItem('ao-wtab') || 'home'; if (!tabs[curTab]) curTab = 'home';
  const tabsEl = h('div', { class: 'tabs', role: 'tablist' });
  const toolsEl = h('div', { class: 'tools' });
  const toolCache = {};
  function showTab(k) {
    curTab = k; try { localStorage.setItem('ao-wtab', k); } catch { }
    [...tabsEl.children].forEach((b, i) => b.classList.toggle('on', TABS[i][0] === k));
    toolsEl.replaceChildren(...(toolCache[k] ||= tabs[k]().filter(Boolean))); syncState();
  }
  TABS.forEach(([k, t]) => tabsEl.append(h('button', { class: 'tab', type: 'button', role: 'tab', onclick: () => showTab(k) }, t)));

  function syncState() {
    const q = c => { try { return document.queryCommandState(c); } catch { return false; } };
    const set = (id, on) => T[id] && T[id].classList.toggle('on', !!on);
    set('b', q('bold')); set('i', q('italic')); set('u', q('underline')); set('s', q('strikeThrough')); set('sup', q('superscript')); set('sub', q('subscript'));
    set('aL', q('justifyLeft')); set('aC', q('justifyCenter')); set('aR', q('justifyRight')); set('aJ', q('justifyFull')); set('ul', q('insertUnorderedList')); set('ol', q('insertOrderedList'));
    sizeLab.textContent = toBn(Math.round(curPx() * 0.75));
    try { let b = document.queryCommandValue('formatBlock').toLowerCase().replace(/[<>]/g, ''); if (!/^(h[1-4]|p)$/.test(b)) b = 'p'; headSel.value = b; } catch { }
    try { const f = (document.queryCommandValue('fontName') || '').replace(/["']/g, ''); const o = [...fontSel.options].find(o => o.value && f.toLowerCase().startsWith(o.value.toLowerCase())); fontSel.value = o ? o.value : ''; } catch { }
  }

  /* ---- inserts ---- */
  async function insertImage(cam) {
    const keep = saved;
    const fs = await pickFiles({ accept: 'image/*', capture: cam === true ? 'environment' : undefined }); if (!fs.length) return; saved = keep;
    try {
      const { url, w } = await withBusy('ছবি যোগ হচ্ছে…', () => imageToDataURL(fs[0]));
      restore(); const width = Math.min(w, 520);
      document.execCommand('insertHTML', false, `<img src="${url}" style="width:${width}px" alt=""><br>`); changed();
    } catch (e) { toast('ছবি যোগ করা যায়নি: ' + errMsg(e)); }
  }
  async function insertTable() {
    const keep = saved;
    const r = h('input', { class: 'inp', type: 'number', min: 1, max: 50, value: 3, inputmode: 'numeric' }), c = h('input', { class: 'inp', type: 'number', min: 1, max: 12, value: 3, inputmode: 'numeric' });
    const body = h('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' } }, h('label', null, 'সারি', r), h('label', null, 'কলাম', c));
    modal({
      title: 'টেবিল ঢোকান', body, actions: [{ label: 'বাতিল', ghost: true }, {
        label: 'ঢোকান', primary: true, onClick: () => {
          saved = keep; const R = Math.min(50, Math.max(1, +r.value || 3)), C = Math.min(12, Math.max(1, +c.value || 3)); restore();
          const row = '<tr>' + '<td><br></td>'.repeat(C) + '</tr>';
          document.execCommand('insertHTML', false, `<table><tbody>${row.repeat(R)}</tbody></table><p><br></p>`); changed(); showTab('table');
        }
      }]
    });
  }
  async function insertLink() {
    const keep = saved; const sel = getSelection().toString();
    const u = await promptDlg('লিংক ঢোকান', { placeholder: 'https://', type: 'url', hint: sel ? 'নির্বাচিত লেখায় লিংক বসবে' : 'লিংকের ঠিকানা দিন' }); if (!u) return; saved = keep;
    let url = u.trim(); if (!/^(https?:|mailto:|tel:)/i.test(url)) url = 'https://' + url;
    restore(); if (sel) document.execCommand('createLink', false, url); else document.execCommand('insertHTML', false, `<a href="${esc(url)}">${esc(url)}</a>&nbsp;`); sanitizeLinks(); changed();
  }
  const sanitizeLinks = () => page.querySelectorAll('a').forEach(a => { a.setAttribute('rel', 'noopener noreferrer'); a.setAttribute('target', '_blank'); });
  function insertPageBreak() { restore(); document.execCommand('insertHTML', false, '<div class="pagebreak" contenteditable="false"></div><p><br></p>'); changed(); }

  /* ---- tables ---- */
  function cellNow() { const s = getSelection(); const n = (s.rangeCount && s.anchorNode) || (saved && saved.startContainer); const e = n && (n.nodeType === 3 ? n.parentElement : n); return e && page.contains(e) ? e.closest('td,th') : null; }
  async function tbl(op) {
    const td = cellNow(); if (!td) { toast('টেবিলের ঘরের ভেতরে ট্যাপ করুন'); return; }
    const tr = td.parentElement, table = td.closest('table'), rows = [...table.rows], ri = tr.rowIndex, ci = td.cellIndex;
    const mkCell = (tag = 'td') => { const c = document.createElement(tag); c.innerHTML = '<br>'; return c; };
    if (op === 'rowAbove' || op === 'rowBelow') { const nr = document.createElement('tr'); for (let i = 0; i < tr.cells.length; i++) nr.append(mkCell()); (op === 'rowAbove' ? tr.before(nr) : tr.after(nr)); }
    else if (op === 'colLeft' || op === 'colRight') rows.forEach(r => { const c = r.cells[Math.min(ci, r.cells.length - 1)]; const n = mkCell(c && c.tagName === 'TH' ? 'th' : 'td'); if (!c) r.append(n); else op === 'colLeft' ? c.before(n) : c.after(n); });
    else if (op === 'delRow') { if (rows.length <= 1) table.remove(); else tr.remove(); }
    else if (op === 'delCol') { if (tr.cells.length <= 1) table.remove(); else rows.forEach(r => r.cells[Math.min(ci, r.cells.length - 1)] && r.cells[Math.min(ci, r.cells.length - 1)].remove()); }
    else if (op === 'delTable') table.remove();
    else if (op === 'merge') { const nx = td.nextElementSibling; if (!nx) return toast('ডানে মেলানোর মতো ঘর নেই'); td.colSpan = (td.colSpan || 1) + (nx.colSpan || 1); if (nx.textContent.trim()) td.append(document.createTextNode(' '), ...nx.childNodes); nx.remove(); }
    else if (op === 'split') { const n = td.colSpan || 1; if (n < 2) return toast('এই ঘর আগে মেলানো হয়নি'); td.colSpan = 1; for (let i = 1; i < n; i++) td.after(mkCell()); }
    else if (op === 'bg') { const c = await pickColor({ title: 'ঘরের রঙ', none: true, noneLabel: 'রঙ সরান' }); if (c === undefined) return; td.style.backgroundColor = c || ''; if (!c && !td.getAttribute('style')) td.removeAttribute('style'); }
    else if (op === 'border') table.classList.toggle('nob');
    changed(); commit();
  }

  /* ---- images (select + resize) ---- */
  let selImg = null;
  const imgBar = h('div', { class: 'tools', style: { position: 'absolute', left: '8px', right: '8px', bottom: 'calc(8px + var(--safe-b))', borderRadius: '14px', border: '1px solid var(--line)', boxShadow: 'var(--shadow-lg)', display: 'none', zIndex: 5, justifyContent: 'center' } },
    btn('minus', 'ছোট', () => sizeImg(.85)), btn('plus', 'বড়', () => sizeImg(1.18)), btn('alignL', 'বামে', () => alignImg('left')), btn('alignC', 'মাঝে', () => alignImg('center')), btn('alignR', 'ডানে', () => alignImg('right')), btn('trash', 'মুছুন', () => { if (selImg) { selImg.remove(); selectImg(null); changed(); commit(); } }));
  function selectImg(i) { if (selImg) selImg.classList.remove('sel'); selImg = i; if (i) i.classList.add('sel'); imgBar.style.display = i ? 'flex' : 'none'; }
  function sizeImg(f) { if (!selImg) return; const w = selImg.getBoundingClientRect().width / (parseFloat(page.style.zoom) || 1); selImg.style.width = Math.max(30, Math.min(page.clientWidth - 40, Math.round(w * f))) + 'px'; selImg.style.height = ''; changed(); commit(); }
  function alignImg(a) { if (!selImg) return; const p = selImg.parentElement; selImg.style.display = 'block'; selImg.style.marginLeft = a === 'left' ? '0' : 'auto'; selImg.style.marginRight = a === 'right' ? '0' : 'auto'; changed(); commit(); }
  page.addEventListener('click', e => { selectImg(e.target.tagName === 'IMG' ? e.target : null); });
  page.addEventListener('keydown', () => selectImg(null));

  /* ---- zoom ---- */
  let z = 1; const applyZoom = () => { page.style.zoom = z; zoomLab.textContent = toBn(Math.round(z * 100)) + '%'; };
  const zoom = d => { z = Math.min(2.5, Math.max(.4, Math.round((z + d) * 100) / 100)); applyZoom(); };
  let pinch = null;
  wrap.addEventListener('touchstart', e => { if (e.touches.length === 2) pinch = { d: Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY), z }; }, { passive: true });
  wrap.addEventListener('touchmove', e => { if (pinch && e.touches.length === 2) { e.preventDefault(); const d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY); z = Math.min(2.5, Math.max(.4, pinch.z * d / pinch.d)); applyZoom(); } }, { passive: false });
  wrap.addEventListener('touchend', () => { pinch = null; });

  /* ---- find & replace ---- */
  let findBar = null;
  function openFind() {
    if (findBar) { findBar.remove(); findBar = null; return; }
    const f = h('input', { class: 'inp', placeholder: 'খুঁজুন', style: { height: '38px' }, 'aria-label': 'খুঁজুন' }), r = h('input', { class: 'inp', placeholder: 'বদলে লিখুন', style: { height: '38px' }, 'aria-label': 'বদলান' });
    const cnt = h('span', { class: 'saved' }, '');
    const esc2 = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const total = () => { const q = f.value; if (!q) return 0; return (page.textContent.match(new RegExp(esc2(q), 'gi')) || []).length; };
    const next = back => { const q = f.value; if (!q) return; page.focus(); const ok = window.find(q, false, !!back, true, false, false, false); cnt.textContent = ok ? `${toBn(total())}টি পাওয়া গেছে` : 'পাওয়া যায়নি'; };
    const repl = () => { const s = getSelection(); if (s.toString().toLowerCase() === f.value.toLowerCase() && f.value) { document.execCommand('insertText', false, r.value); changed(); } next(); };
    const replAll = () => { const q = f.value; if (!q) return; const re = new RegExp(esc2(q), 'gi'); let n = 0; const w = document.createTreeWalker(page, NodeFilter.SHOW_TEXT); const nodes = []; let t; while ((t = w.nextNode())) nodes.push(t); nodes.forEach(t => { if (re.test(t.data)) { re.lastIndex = 0; t.data = t.data.replace(re, () => { n++; return r.value; }); } re.lastIndex = 0; }); cnt.textContent = `${toBn(n)}টি বদলানো হয়েছে`; changed(); commit(); };
    f.addEventListener('input', () => { cnt.textContent = f.value ? `${toBn(total())}টি` : ''; }); f.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); next(e.shiftKey); } });
    findBar = h('div', { class: 'tools', style: { flexWrap: 'wrap', gap: '6px', padding: '8px', height: 'auto', overflow: 'visible' } },
      h('div', { style: { display: 'flex', gap: '6px', width: '100%' } }, f, btn('up', 'আগের', () => next(true), { keepFocus: false }), btn('down', 'পরের', () => next(false), { keepFocus: false }), btn('x', 'বন্ধ', () => { findBar.remove(); findBar = null; }, { keepFocus: false })),
      h('div', { style: { display: 'flex', gap: '6px', width: '100%', alignItems: 'center' } }, r, h('button', { class: 'btn', type: 'button', onclick: repl }, 'বদলান'), h('button', { class: 'btn', type: 'button', onclick: replAll }, 'সব'), cnt));
    ctxBody.insertBefore(findBar, wrap); f.focus();
  }

  /* ---- export ---- */
  const exportsList = [
    {
      icon: 'pdf', label: 'PDF বানান', sub: 'ডকুমেন্ট সরাসরি PDF ফাইল হয়ে ফাইলে যোগ হবে', async run() {
        const b = busy('PDF তৈরি হচ্ছে…');
        try { const { paginatedPdf } = await import('./pdfexport.js'); const bytes = await paginatedPdf(page, { css: PRINT_CSS, title: ctx.meta.name, onProgress: (i, n) => b.set(`পাতা ${toBn(i)}/${toBn(n)}`) }); return { blob: new Blob([bytes], { type: 'application/pdf' }), name: baseName(ctx.meta.name) + '.pdf', kind: 'pdf' }; } finally { b.done(); }
      }
    },
    { icon: 'print', label: 'প্রিন্ট / টেক্সট-সহ PDF', sub: 'ব্রাউজারের প্রিন্ট থেকে "Save as PDF" বেছে নিন', async run() { doPrint(); return null; } },
    { icon: 'file', label: 'প্লেইন টেক্সট (.txt)', async run() { return { blob: new Blob([page.innerText], { type: 'text/plain' }), name: baseName(ctx.meta.name) + '.txt', kind: 'word', raw: true }; } },
  ];
  async function doPrint() { const { printElement } = await import('./pdfexport.js'); printElement(page, PRINT_CSS, ctx.meta.name); }
  ctx.afterExport = async r => {
    if (r.raw) { const { saveToDevice } = await import('./util.js'); return saveToDevice(r.blob, r.name); }
    const { offerOutput } = await import('./edkit.js'); return offerOutput(ctx, r);
  };

  /* ---- assemble ---- */
  async function serialize() {
    selectImg(null);
    const clone = page.cloneNode(true); clone.querySelectorAll('.sel').forEach(x => x.classList.remove('sel'));
    const s = await getSettings();
    const buf = await htmlToDocx(clone, { title: baseName(ctx.meta.name), author: s.author || '' });
    return { buf, snap: clone.innerHTML };
  }
  const aiApi = {
    getSelected: () => (saved && !saved.collapsed ? saved.toString() : ''),
    getAll: () => page.innerText || '',
    replaceSelected: html => { restore(); document.execCommand('insertHTML', false, html); changed(); },
    replaceAll: html => { page.innerHTML = sanitize(html) || '<p><br></p>'; commit(); changed(); },
    insertHtml: html => { if (saved) { restore(); document.execCommand('insertHTML', false, html); } else page.insertAdjacentHTML('beforeend', html); changed(); },
  };
  const r = ctx.setup({ serialize, undo, redo, exports: exportsList, extraMenu: [{ icon: 'sparkle', label: 'AI সহায়ক', sub: 'ভুল ঠিক, সংক্ষেপ, অনুবাদ, নতুন লেখা', onClick: () => import('./ai.js').then(m => m.wordAssistant(aiApi)) }] });
  hdr = r.hdr; as = r.as; hdr.setUndo(false, false);
  const ctxBody = h('div', { class: 'ed-body' }, tabsEl, toolsEl, wrap, count, imgBar);
  ctx.root.replaceChildren(hdr.el, ctxBody);
  showTab(curTab); countDeb();

  page.addEventListener('input', () => { fixFonts(); sanitizeLinks(); changed(); });
  page.addEventListener('beforeinput', e => { if (e.inputType === 'historyUndo') { e.preventDefault(); undo(); } else if (e.inputType === 'historyRedo') { e.preventDefault(); redo(); } });
  page.addEventListener('keydown', e => {
    const k = e.key.toLowerCase();
    if ((e.ctrlKey || e.metaKey) && k === 'z') { e.preventDefault(); e.shiftKey ? redo() : undo(); }
    else if ((e.ctrlKey || e.metaKey) && k === 'y') { e.preventDefault(); redo(); }
    else if ((e.ctrlKey || e.metaKey) && k === 's') { e.preventDefault(); as.now(true); }
    else if ((e.ctrlKey || e.metaKey) && k === 'f') { e.preventDefault(); openFind(); }
    else if (e.key === 'Tab') { e.preventDefault(); const td = cellNow(); if (td) { const n = td.nextElementSibling || (td.parentElement.nextElementSibling && td.parentElement.nextElementSibling.cells[0]); if (n) { const r = document.createRange(); r.selectNodeContents(n); r.collapse(true); const s = getSelection(); s.removeAllRanges(); s.addRange(r); } } else document.execCommand('insertText', false, ' '); }
  });
  page.addEventListener('paste', async e => {
    const cd = e.clipboardData; if (!cd) return;
    const file = [...(cd.files || [])].find(f => f.type.startsWith('image/'));
    if (file) { e.preventDefault(); const { url, w } = await imageToDataURL(file); document.execCommand('insertHTML', false, `<img src="${url}" style="width:${Math.min(w, 520)}px" alt="">`); return; }
    const hh = cd.getData('text/html');
    if (hh) { e.preventDefault(); const m = /<body[^>]*>([\s\S]*)<\/body>/i.exec(hh); document.execCommand('insertHTML', false, sanitize(m ? m[1] : hh).replace(/<!--[\s\S]*?-->/g, '')); }
  });
  page.addEventListener('drop', e => { const f = [...(e.dataTransfer?.files || [])].find(x => x.type.startsWith('image/')); if (f) { e.preventDefault(); imageToDataURL(f).then(({ url, w }) => { document.execCommand('insertHTML', false, `<img src="${url}" style="width:${Math.min(w, 520)}px" alt="">`); }); } });
  // ensure at least one paragraph, keep wrapper clean
  page.addEventListener('focus', () => { if (!page.firstChild) page.innerHTML = '<p><br></p>'; try { document.execCommand('styleWithCSS', false, true); document.execCommand('defaultParagraphSeparator', false, 'p'); } catch { } });
  if (!ctx.buf || !ctx.buf.byteLength) setTimeout(() => page.focus(), 100);

  return { destroy() { document.removeEventListener('selectionchange', onSel); commitDeb.cancel(); } };
}
