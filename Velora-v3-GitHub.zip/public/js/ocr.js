// Velora OCR — turns a picture of text into editable HTML/text.
//  1) Gemini vision (needs the free API key) — handles Bangla, tables and layout best.
//  2) Tesseract.js (loaded once from a CDN, needs internet the first time) — no key needed.
import { loadScript, esc } from './util.js';
import { hasKey, generate, canvasToPart, stripFences } from './ai.js';

const TESS_URL = 'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js';
const PROMPT = 'You are a precise OCR engine. Transcribe ALL the text in this image exactly as written (Bangla, English, digits, punctuation) — do not translate, summarise or correct anything. Keep the reading order and structure as clean semantic HTML: h1-h3 for headings, p for paragraphs, ul/ol/li for lists, table/tr/th/td for tables, b/i for emphasis. No CSS, no markdown fences, no commentary. If a region is unreadable write [?]. If the image has no text output <p></p>.';

export const textToHtml = t => t.replace(/\r/g, '').split(/\n{2,}/).map(p => p.trim()).filter(Boolean).map(p => '<p>' + esc(p).replace(/\n/g, '<br>') + '</p>').join('') || '<p><br></p>';
export const htmlToText = html => { const d = document.createElement('div'); d.innerHTML = html.replace(/<\/(p|h[1-6]|li|tr|div)>/gi, '$&\n').replace(/<br\s*\/?>/gi, '\n').replace(/<\/t[dh]>/gi, '\t'); return (d.textContent || '').replace(/\n{3,}/g, '\n\n').trim(); };

/**
 * Create an OCR session (re-usable for many pages).
 * opts.engine: 'auto' | 'ai' | 'local'; opts.lang: tesseract language codes (default Bangla+English)
 * session.run(canvas) → { html, text, engine }
 */
export async function ocrSession({ engine = 'auto', lang = 'ben+eng', onStatus = () => { } } = {}) {
  const useAI = engine === 'ai' || (engine === 'auto' && await hasKey());
  let worker = null, localFailed = false;
  async function local(canvas) {
    if (!worker) {
      onStatus('OCR ইঞ্জিন লোড হচ্ছে (প্রথমবার ইন্টারনেট লাগে)…');
      await loadScript(TESS_URL);
      worker = await window.Tesseract.createWorker(lang, 1, { logger: m => { if (m.status === 'recognizing text') onStatus('লেখা পড়া হচ্ছে… ' + Math.round((m.progress || 0) * 100) + '%'); else if (m.status && /load|init/.test(m.status)) onStatus('ভাষা ডেটা লোড হচ্ছে…'); } });
    }
    const { data } = await worker.recognize(canvas);
    return { html: textToHtml(data.text || ''), text: (data.text || '').trim(), engine: 'local' };
  }
  async function ai(canvas) {
    const part = await canvasToPart(canvas, .86, 1800);
    const out = stripFences(await generate({ parts: [part], prompt: PROMPT, temperature: .1, system: 'You output only the requested HTML.' }));
    const w = await import('./word.js'); const html = w.sanitize(/<(p|h1|h2|h3|ul|ol|table)\b/i.test(out) ? out : textToHtml(out)) || '<p><br></p>';
    return { html, text: htmlToText(html), engine: 'ai' };
  }
  return {
    useAI,
    async run(canvas) {
      if (useAI) {
        try { onStatus('AI লেখা পড়ছে…'); return await ai(canvas); }
        catch (e) { if (engine === 'ai' || localFailed) throw e; console.warn('AI OCR failed, using local', e); onStatus('AI ব্যর্থ — লোকাল OCR চালানো হচ্ছে…'); }
      }
      try { return await local(canvas); } catch (e) { localFailed = true; throw new Error(/load|script|লোড/i.test(e.message || '') ? 'OCR ইঞ্জিন লোড হয়নি — ইন্টারনেট চালু করে আবার চেষ্টা করুন, অথবা সেটিংসে AI কী দিন' : (e.message || 'OCR ব্যর্থ')); }
    },
    async close() { if (worker) { try { await worker.terminate(); } catch { } worker = null; } },
  };
}
export async function ocrCanvas(canvas, opts) { const s = await ocrSession(opts); try { return await s.run(canvas); } finally { await s.close(); } }
