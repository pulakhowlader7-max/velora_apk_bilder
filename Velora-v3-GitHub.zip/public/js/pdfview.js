// PDF viewer + annotator: pdf.js rendering, own text layer, pen/highlight/notes baked in via pdf-lib, page tools.
import { h, icon, btn, sheet as actionSheet, modal, promptDlg, confirmDlg, pickColor, pickFiles, toast, busy, toBn, baseName, readBuf, errMsg, clamp, uid, needPdfJs, needPDFLib, imageToDataURL, saveToDevice, dataURLtoBlob } from './util.js';

/* ---------- images -> PDF ---------- */
export async function imagesToPdf(files) {
  const { PDFDocument } = await needPDFLib(); const pdf = await PDFDocument.create(); pdf.setProducer('Velora');
  for (const f of files) {
    const { url } = await imageToDataURL(f, 2200, .9); const blob = dataURLtoBlob(url); const bytes = new Uint8Array(await blob.arrayBuffer());
    const img = /png/.test(blob.type) ? await pdf.embedPng(bytes) : await pdf.embedJpg(bytes);
    const sc = Math.min(1, 842 / Math.max(img.width, img.height)); const w = img.width * sc, hh = img.height * sc;
    pdf.addPage([w, hh]).drawImage(img, { x: 0, y: 0, width: w, height: hh });
  }
  return { name: (files.length === 1 ? baseName(files[0].name || 'ছবি') : 'স্ক্যান ' + new Date().toLocaleDateString('en-GB').replace(/\//g, '-')) + '.pdf', buf: (await pdf.save()).buffer };
}
export async function blank() { const { PDFDocument } = await needPDFLib(); const pdf = await PDFDocument.create(); pdf.addPage([595, 842]); return { name: 'নতুন.pdf', buf: (await pdf.save()).buffer }; }
export async function importFile(file) { return { name: file.name, buf: await readBuf(file) }; }

const COLORS = ['#d92d20', '#2e5bff', '#14884f', '#111111', '#f5a623', '#a855f7'];
const HL = ['#ffe600', '#7be495', '#ff9ecb', '#7cc6ff'];
const hexRgb = c => { const x = c.replace('#', ''); return [parseInt(x.slice(0, 2), 16) / 255, parseInt(x.slice(2, 4), 16) / 255, parseInt(x.slice(4, 6), 16) / 255]; };
const FONT = '"Noto Sans Bengali","Kalpurush","Nirmala UI",system-ui,sans-serif';

export async function mount(ctx) {
  const pdfjs = await needPdfJs(); let base = new Uint8Array(ctx.buf.slice ? ctx.buf.slice(0) : ctx.buf); let doc = null, readOnly = false, pages = [];
  let annots = []; // {id,p,t:'ink'|'hl'|'note',pts?,c,w,x,y,bw,text,fs}
  let tool = 'view', penC = COLORS[0], hlC = HL[0], zoom = 1, cur = 0, hdr, as; const hist = []; let hi = -1; let redoS = [];
  let password;

  async function load() {
    if (doc) { try { doc.destroy(); } catch { } }
    const task = pdfjs.getDocument({ data: base.slice(), cMapUrl: '/vendor/pdfjs/cmaps/', cMapPacked: true, standardFontDataUrl: '/vendor/pdfjs/standard_fonts/', password });
    task.onPassword = async (cb, reason) => { const v = await promptDlg(reason === 2 ? 'ভুল পাসওয়ার্ড — আবার দিন' : 'পাসওয়ার্ড দিন', { type: 'password', ok: 'খুলুন' }); if (v == null) { cb(''); } else { password = v; cb(v); } };
    doc = await task.promise;
  }
  try { await load(); } catch (e) { if (/password/i.test(e && (e.name + e.message))) throw new Error('পাসওয়ার্ড ছাড়া খোলা যায়নি'); throw e; }
  // can pdf-lib edit it?
  const PL = await needPDFLib(); try { await PL.PDFDocument.load(base, { ignoreEncryption: false, updateMetadata: false }); } catch { readOnly = true; toast('এই PDF সুরক্ষিত — শুধু পড়া যাবে', 3500); }

  /* ---------- layout ---------- */
  const scroll = h('div', { class: 'pdf-scroll' }); const pill = h('div', { class: 'pdf-pill' }, ''); const holder = h('div', { class: 'pdf-host', style: { position: 'relative', flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column' } }, scroll, pill);
  const textCache = new Map();
  const baseW = () => Math.max(260, scroll.clientWidth - 12);
  async function buildPages() {
    scroll.replaceChildren(); pages = [];
    for (let i = 1; i <= doc.numPages; i++) {
      const pg = await doc.getPage(i); const vp = pg.getViewport({ scale: 1 }); const el = h('div', { class: 'pdf-page', 'data-i': i - 1 });
      const cv = h('canvas'); const tl = h('div', { class: 'tl' }); const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); svg.setAttribute('class', 'ink'); svg.setAttribute('viewBox', `0 0 ${vp.width} ${vp.height}`); svg.setAttribute('preserveAspectRatio', 'none'); const notes = h('div', { style: { position: 'absolute', inset: 0, pointerEvents: 'none' } });
      el.append(cv, tl, svg, notes); scroll.append(el); pages.push({ i: i - 1, pg, vp, el, cv, tl, svg, notes, state: 0, rs: 0, tlDone: false, task: null });
      bindInk(pages[i - 1]);
    }
    layout(); redrawAnn(); io && io.disconnect(); io = new IntersectionObserver(onVis, { root: scroll, rootMargin: '700px 0px' }); pages.forEach(p => io.observe(p.el));
  }
  let io = null;
  function layout() { const w = baseW() * zoom; for (const p of pages) { const f = w / p.vp.width; p.f = f; p.el.style.width = w + 'px'; p.el.style.height = p.vp.height * f + 'px'; p.tl.style.fontSize = '1px'; p.notes.style.fontSize = f * 10 + 'px'; } pages.forEach(p => { p.rs = 0; if (p.vis) render(p); }); noteScale(); }
  function onVis(es) { for (const e of es) { const p = pages[+e.target.dataset.i]; p.vis = e.isIntersecting; if (e.isIntersecting) render(p); else free(p); } }
  async function render(p) {
    const dpr = Math.min(window.devicePixelRatio || 1, 2.5); const css = p.vp.width * p.f; let sc = css / p.vp.width * dpr; const px = p.vp.width * sc * p.vp.height * sc; if (px > 14e6) sc *= Math.sqrt(14e6 / px);
    if (Math.abs(p.rs - sc) < .01 && p.state === 2) return; if (p.task) { try { p.task.cancel(); } catch { } } const myTok = p.tok = (p.tok || 0) + 1;
    const vp = p.pg.getViewport({ scale: sc }); const c = document.createElement('canvas'); c.width = Math.round(vp.width); c.height = Math.round(vp.height); p.state = 1;
    try { p.task = p.pg.render({ canvasContext: c.getContext('2d'), viewport: vp }); await p.task.promise; } catch (e) { if (e && e.name === 'RenderingCancelledException') return; console.warn(e); return; }
    if (p.tok !== myTok) return; p.cv.width = c.width; p.cv.height = c.height; p.cv.getContext('2d').drawImage(c, 0, 0); p.rs = sc; p.state = 2; if (!p.tlDone) textLayer(p);
  }
  function free(p) { if (p.task) { try { p.task.cancel(); } catch { } } p.cv.width = p.cv.height = 1; p.state = 0; p.rs = 0; }
  async function getText(p) { if (textCache.has(p.i)) return textCache.get(p.i); const tc = await p.pg.getTextContent(); textCache.set(p.i, tc); return tc; }
  const mctx = document.createElement('canvas').getContext('2d');
  async function textLayer(p) {
    p.tlDone = true; const tc = await getText(p); const frag = document.createDocumentFragment(); p.spans = [];
    for (const it of tc.items) { if (!it.str || !it.str.trim()) continue; const m = pdfjs.Util.transform(p.vp.transform, it.transform); const fh = Math.hypot(m[2], m[3]); const ang = Math.atan2(m[1], m[0]); const sp = h('span', null, it.str); sp.style.cssText = `left:${m[4]}px;top:${m[5] - fh}px;font-size:${fh}px;font-family:sans-serif;transform:rotate(${ang}rad);`; sp._w = it.width * p.vp.scale; sp._it = it; frag.append(sp); p.spans.push(sp); }
    p.tl.append(frag); p.tl.style.fontSize = ''; p.tl.style.transformOrigin = '0 0'; p.tl.style.width = p.vp.width + 'px'; p.tl.style.height = p.vp.height + 'px'; p.tl.style.inset = 'auto'; p.tl.style.left = p.tl.style.top = '0'; p.tl.style.transform = `scale(${p.f})`;
    for (const sp of p.spans) { mctx.font = `${sp.style.fontSize} sans-serif`; const w = mctx.measureText(sp.textContent).width; if (w > 0 && sp._w > 0) sp.style.transform += ` scaleX(${sp._w / w})`; }
    applyHits(p);
  }
  new ResizeObserver(() => { const w = baseW(); if (pages.length && Math.abs((layout.w || 0) - w) > 4) { layout.w = w; layout(); } }).observe(scroll);
  scroll.addEventListener('scroll', () => { const mid = scroll.scrollTop + scroll.clientHeight * .35; for (const p of pages) { if (p.el.offsetTop + p.el.offsetHeight > mid) { if (cur !== p.i) { cur = p.i; pill.textContent = `${toBn(cur + 1)} / ${toBn(pages.length)}`; } break; } } pill.classList.add('show'); clearTimeout(pill._t); pill._t = setTimeout(() => pill.classList.remove('show'), 1400); for (const p of pages) if (p.tlDone) p.tl.style.transform = `scale(${p.f})`; }, { passive: true });
  const gotoPage = i => { i = clamp(i, 0, pages.length - 1); scroll.scrollTo({ top: pages[i].el.offsetTop - 8, behavior: 'smooth' }); };
  // pinch zoom
  let pz = null; scroll.addEventListener('touchstart', e => { if (e.touches.length === 2) pz = { d: Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY), z: zoom }; }, { passive: true });
  scroll.addEventListener('touchmove', e => { if (pz && e.touches.length === 2) { e.preventDefault(); const d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY); setZoom(pz.z * d / pz.d, true); } }, { passive: false });
  scroll.addEventListener('touchend', () => { pz = null; });
  let zt; function setZoom(z, soft) { z = clamp(z, .5, 5); const ratio = z / zoom; const top = scroll.scrollTop * ratio, left = scroll.scrollLeft * ratio; zoom = z; for (const p of pages) { const w = baseW() * zoom; p.f = w / p.vp.width; p.el.style.width = w + 'px'; p.el.style.height = p.vp.height * p.f + 'px'; if (p.tlDone) p.tl.style.transform = `scale(${p.f})`; } scroll.scrollTop = top; scroll.scrollLeft = left; noteScale(); clearTimeout(zt); zt = setTimeout(() => { pages.forEach(p => { if (p.vis) render(p); }); }, 220); zl.textContent = toBn(Math.round(zoom * 100)) + '%'; }

  /* ---------- annotations ---------- */
  const snapA = () => JSON.stringify(annots);
  function pushHist() { hist.length = hi + 1; hist.push(snapA()); hi = hist.length - 1; redoS = []; hdr && hdr.setUndo(true, false); }
  function annChanged() { redrawAnn(); as && as.mark(); }
  function undo() { if (hi < 0) return; redoS.push(snapA()); annots = JSON.parse(hist[hi]); hist.length = hi; hi--; hdr.setUndo(hi >= 0, true); annChanged(); }
  function redo() { if (!redoS.length) return; hist.push(snapA()); hi = hist.length - 1; annots = JSON.parse(redoS.pop()); hdr.setUndo(true, redoS.length > 0); annChanged(); }
  const SVGNS = 'http://www.w3.org/2000/svg';
  function redrawAnn() {
    for (const p of pages) { p.svg.replaceChildren(); p.notes.replaceChildren(); }
    for (const a of annots) { const p = pages[a.p]; if (!p) continue; if (a.t === 'note') { const d = h('div', { class: 'note', 'data-id': a.id, style: { left: a.x / p.vp.width * 100 + '%', top: a.y / p.vp.height * 100 + '%', width: a.bw / p.vp.width * 100 + '%', fontSize: a.fs + 'px', color: a.c, pointerEvents: tool === 'view' || tool === 'erase' || tool === 'note' ? 'auto' : 'none', fontFamily: FONT, lineHeight: 1.25, whiteSpace: 'pre-wrap', wordBreak: 'break-word' } }, a.text); d._fs = a.fs; d.addEventListener('click', () => noteMenu(a)); p.notes.append(d); } else { const pl = document.createElementNS(SVGNS, 'polyline'); pl.setAttribute('points', a.pts.map(q => q.join(',')).join(' ')); pl.setAttribute('fill', 'none'); pl.setAttribute('stroke', a.c); pl.setAttribute('stroke-width', a.w); pl.setAttribute('stroke-linecap', 'round'); pl.setAttribute('stroke-linejoin', 'round'); if (a.t === 'hl') { pl.setAttribute('stroke-opacity', '.4'); pl.style.mixBlendMode = 'multiply'; } p.svg.append(pl); } }
    noteScale();
  }
  function noteScale() { for (const p of pages) for (const n of p.notes.children) n.style.fontSize = (n._fs || 14) * (p.f || 1) + 'px'; }
  function noteMenu(a) { if (tool === 'erase') { pushHist(); annots = annots.filter(x => x !== a && x.id !== a.id); annChanged(); return; } if (readOnly) return; actionSheet('নোট', [{ icon: 'pen', label: 'লেখা বদলান', onClick: async () => { const v = await promptDlg('নোটের লেখা', { value: a.text, multiline: true }); if (v == null) return; pushHist(); a.text = v; annChanged(); } }, { icon: 'maximize', label: 'ফন্ট বড় করুন', onClick: () => { pushHist(); a.fs = Math.min(80, a.fs + 3); a.bw = Math.min(a.bw * 1.1, 800); annChanged(); } }, { icon: 'minus', label: 'ফন্ট ছোট করুন', onClick: () => { pushHist(); a.fs = Math.max(8, a.fs - 3); annChanged(); } }, { icon: 'trash', label: 'মুছুন', danger: true, onClick: () => { pushHist(); annots = annots.filter(x => x.id !== a.id); annChanged(); } }]); }
  function bindInk(p) {
    let cur2 = null;
    const pt = e => { const r = p.svg.getBoundingClientRect(); return [+((e.clientX - r.left) / r.width * p.vp.width).toFixed(1), +((e.clientY - r.top) / r.height * p.vp.height).toFixed(1)]; };
    p.svg.addEventListener('pointerdown', e => {
      if (tool === 'view' || readOnly) return; const q = pt(e);
      if (tool === 'note') { e.preventDefault(); addNote(p, q); return; }
      if (tool === 'erase') { e.preventDefault(); const hit = annots.find(a => a.p === p.i && a.t !== 'note' && a.pts.some((z, k) => Math.hypot(z[0] - q[0], z[1] - q[1]) < Math.max(10, a.w))); if (hit) { pushHist(); annots = annots.filter(a => a !== hit); annChanged(); } return; }
      e.preventDefault(); p.svg.setPointerCapture(e.pointerId); const a = { id: uid(), p: p.i, t: tool === 'hl' ? 'hl' : 'ink', pts: [q], c: tool === 'hl' ? hlC : penC, w: tool === 'hl' ? 16 : 2.2 }; cur2 = { a, el: document.createElementNS(SVGNS, 'polyline') }; const el = cur2.el; el.setAttribute('fill', 'none'); el.setAttribute('stroke', a.c); el.setAttribute('stroke-width', a.w); el.setAttribute('stroke-linecap', 'round'); el.setAttribute('stroke-linejoin', 'round'); if (a.t === 'hl') { el.setAttribute('stroke-opacity', '.4'); el.style.mixBlendMode = 'multiply'; } p.svg.append(el);
    });
    p.svg.addEventListener('pointermove', e => { if (!cur2) return; const evs = e.getCoalescedEvents ? e.getCoalescedEvents() : [e]; for (const ev of evs) { const q = pt(ev); const l = cur2.a.pts[cur2.a.pts.length - 1]; if (Math.hypot(q[0] - l[0], q[1] - l[1]) > .6) cur2.a.pts.push(q); } if (cur2.a.t === 'hl') { const f = cur2.a.pts[0]; const l = cur2.a.pts[cur2.a.pts.length - 1]; cur2.a.pts = [f, [l[0], f[1]]]; } cur2.el.setAttribute('points', cur2.a.pts.map(z => z.join(',')).join(' ')); });
    const up = () => { if (!cur2) return; const a = cur2.a; cur2 = null; if (a.pts.length < 2) a.pts.push([a.pts[0][0] + .1, a.pts[0][1]]); pushHist(); annots.push(a); annChanged(); };
    p.svg.addEventListener('pointerup', up); p.svg.addEventListener('pointercancel', up);
  }
  async function addNote(p, q) { const v = await promptDlg('নোট লিখুন', { multiline: true, placeholder: 'এখানে যা লিখবেন PDF-এ বসবে' }); if (!v || !v.trim()) return; pushHist(); annots.push({ id: uid(), p: p.i, t: 'note', x: q[0], y: q[1], bw: Math.min(260, p.vp.width - q[0] - 10), text: v.trim(), fs: 16, c: penC }); annChanged(); }
  function setTool(t) { if (readOnly && t !== 'view') return toast('এই PDF সুরক্ষিত — সম্পাদনা সম্ভব নয়'); tool = t; scroll.classList.toggle('drawing', t === 'pen' || t === 'hl'); scroll.style.touchAction = (t === 'pen' || t === 'hl') ? 'none' : ''; for (const p of pages) { p.svg.style.pointerEvents = t === 'view' ? 'none' : 'auto'; p.svg.style.touchAction = t === 'pen' || t === 'hl' ? 'none' : 'auto'; p.tl.style.pointerEvents = t === 'view' ? 'auto' : 'none'; p.notes.querySelectorAll('.note').forEach(n => n.style.pointerEvents = (t === 'view' || t === 'erase' || t === 'note') ? 'auto' : 'none'); } Object.entries(TB).forEach(([k, b]) => b.classList.toggle('on', k === t)); }

  /* ---------- flatten (pdf-lib) ---------- */
  const mapPt = (rot, W, Hh, vx, vy) => rot === 90 ? [vy, vx] : rot === 180 ? [W - vx, vy] : rot === 270 ? [W - vy, Hh - vx] : [vx, Hh - vy];
  async function noteImage(a, rot) {
    const S = 3, fs = a.fs, w = a.bw; const c = document.createElement('canvas'); const g = c.getContext('2d'); g.font = `${fs * S}px ${FONT}`; const maxW = w * S; const lines = []; for (const para of a.text.split('\n')) { let line = ''; for (const wd of para.split(/(\s+)/)) { if (g.measureText(line + wd).width > maxW && line) { lines.push(line.trimEnd()); line = wd.trimStart(); } else line += wd; } lines.push(line); }
    const lh = fs * 1.25 * S; const cw = Math.ceil(maxW), chh = Math.ceil(lines.length * lh + 4 * S); c.width = cw; c.height = chh; g.font = `${fs * S}px ${FONT}`; g.fillStyle = a.c; g.textBaseline = 'top'; lines.forEach((l, i) => g.fillText(l, 0, i * lh + 2 * S));
    let out = c; if (rot) { out = document.createElement('canvas'); const swap = rot === 90 || rot === 270; out.width = swap ? chh : cw; out.height = swap ? cw : chh; const o = out.getContext('2d'); o.translate(out.width / 2, out.height / 2); o.rotate(-rot * Math.PI / 180); o.drawImage(c, -cw / 2, -chh / 2); }
    const png = await new Promise(r => out.toBlob(r, 'image/png')); return { bytes: new Uint8Array(await png.arrayBuffer()), vw: w, vh: chh / S };
  }
  async function flatten(bytes, list) {
    const { PDFDocument, rgb, LineCapStyle } = await needPDFLib(); const pdf = await PDFDocument.load(bytes, { updateMetadata: false }); const pgs = pdf.getPages();
    for (const a of list) { const pg = pgs[a.p]; if (!pg) continue; const { width: W0, height: H0 } = pg.getSize(); const rot = ((pg.getRotation().angle % 360) + 360) % 360; const sw = rot === 90 || rot === 270; const W = W0, Hh = H0; const k = 1; // view scale-1 units == pt
      const mp = (vx, vy) => mapPt(rot, W, Hh, vx, vy);
      if (a.t === 'note') { const { bytes: ib, vw, vh } = await noteImage(a, rot); const img = await pdf.embedPng(ib); const p1 = mp(a.x, a.y), p2 = mp(a.x + vw, a.y + vh); const x = Math.min(p1[0], p2[0]), y = Math.min(p1[1], p2[1]); pg.drawImage(img, { x, y, width: Math.abs(p2[0] - p1[0]), height: Math.abs(p2[1] - p1[1]) }); }
      else { const [r, g, b] = hexRgb(a.c); const col = rgb(r, g, b); for (let i = 1; i < a.pts.length; i++) { const s = mp(...a.pts[i - 1]), e = mp(...a.pts[i]); pg.drawLine({ start: { x: s[0], y: s[1] }, end: { x: e[0], y: e[1] }, thickness: a.w, color: col, opacity: a.t === 'hl' ? .4 : 1, lineCap: LineCapStyle.Round }); } }
    }
    return pdf.save();
  }
  async function serialize() { if (readOnly || !annots.length) return { buf: base.slice().buffer, snap: undefined }; const out = await flatten(base, annots); return { buf: out.buffer.slice(out.byteOffset, out.byteOffset + out.byteLength), snap: undefined }; }

  /* ---------- page operations ---------- */
  async function bake() { if (annots.length) { base = await flatten(base, annots); annots = []; hist.length = 0; hi = -1; redoS = []; } }
  async function pageOp(fn, keepPage) { if (readOnly) return toast('এই PDF সুরক্ষিত — সম্পাদনা সম্ভব নয়'); const b = busy('কাজ চলছে…'); try { await bake(); const { PDFDocument } = await needPDFLib(); const pdf = await PDFDocument.load(base, { updateMetadata: false }); const r = await fn(pdf); if (r === false) return; base = await pdf.save(); textCache.clear(); await load(); const at = keepPage == null ? cur : keepPage; await buildPages(); setTool('view'); hdr.setUndo(false, false); as.mark(); gotoPage(at); } catch (e) { console.error(e); toast('ব্যর্থ: ' + errMsg(e), 4000); } finally { b.done(); } }
  const rotatePage = (i, d) => pageOp(pdf => { const pg = pdf.getPage(i); pg.setRotation(PL.degrees(((pg.getRotation().angle + d) % 360 + 360) % 360)); }, i);
  const deletePage = async i => { if (pages.length < 2) return toast('শেষ পাতা মোছা যাবে না'); if (!(await confirmDlg('পাতা মুছবেন?', `পাতা ${toBn(i + 1)} মুছে যাবে।`, { ok: 'মুছুন', danger: true }))) return; pageOp(pdf => pdf.removePage(i), Math.max(0, i - 1)); };
  const movePage = (i, d) => { const j = i + d; if (j < 0 || j >= pages.length) return; pageOp(async pdf => { const pg = pdf.getPage(i); const [cp] = await pdf.copyPages(pdf, [i]); pdf.removePage(i); pdf.insertPage(j, cp); }, j); };
  const insertBlank = i => pageOp(pdf => { const s = pdf.getPage(Math.min(i, pdf.getPageCount() - 1)).getSize(); pdf.insertPage(i + 1, [s.width, s.height]); }, i + 1);
  async function extractPages(idx) { const b = busy('আলাদা করা হচ্ছে…'); try { await bake(); const { PDFDocument } = await needPDFLib(); const src = await PDFDocument.load(base); const out = await PDFDocument.create(); const cp = await out.copyPages(src, idx); cp.forEach(p => out.addPage(p)); const bytes = await out.save(); const { offerOutput } = await import('./edkit.js'); b.done(); await offerOutput(ctx, { blob: new Blob([bytes], { type: 'application/pdf' }), name: baseName(ctx.meta.name) + ` (পাতা ${idx.map(x => x + 1).join(',')}).pdf`, kind: 'pdf' }); } catch (e) { b.done(); toast('ব্যর্থ: ' + errMsg(e)); } finally { b.done(); } }
  async function mergeWith() { const f = await pickFiles({ accept: 'application/pdf,.pdf,image/*', multiple: true }); if (!f || !f.length) return; pageOp(async pdf => { for (const file of f) { if (/pdf/i.test(file.type) || /\.pdf$/i.test(file.name)) { const o = await PL.PDFDocument.load(await readBuf(file), { ignoreEncryption: true }); const cp = await pdf.copyPages(o, o.getPageIndices()); cp.forEach(p => pdf.addPage(p)); } else { const r = await imagesToPdf([file]); const o = await PL.PDFDocument.load(r.buf); const cp = await pdf.copyPages(o, o.getPageIndices()); cp.forEach(p => pdf.addPage(p)); } } }, pages.length); }
  function pageMenu(i) { actionSheet(`পাতা ${toBn(i + 1)}`, [{ icon: 'rotate', label: 'ডানে ঘোরান', onClick: () => rotatePage(i, 90) }, { icon: 'rotate', label: 'বামে ঘোরান', onClick: () => rotatePage(i, -90) }, { icon: 'left', label: 'আগে সরান', disabled: i === 0, onClick: () => movePage(i, -1) }, { icon: 'right', label: 'পরে সরান', disabled: i === pages.length - 1, onClick: () => movePage(i, 1) }, { icon: 'plus', label: 'এর পরে ফাঁকা পাতা', onClick: () => insertBlank(i) }, { icon: 'file', label: 'শুধু এই পাতা আলাদা ফাইল', onClick: () => extractPages([i]) }, { icon: 'trash', label: 'পাতা মুছুন', danger: true, onClick: () => deletePage(i) }]); }
  async function organizer() {
    const grid = h('div', { class: 'pdf-thumbs', style: { maxHeight: '60vh' } }); let m;
    for (const p of pages) { const c = h('canvas'); const vp = p.pg.getViewport({ scale: 140 / p.vp.width }); c.width = vp.width; c.height = vp.height; const b = h('button', { class: 'pdf-thumb' + (p.i === cur ? ' on' : ''), type: 'button', onclick: () => { m.close(); gotoPage(p.i); setTimeout(() => pageMenu(p.i), 250); } }, c, h('div', null, toBn(p.i + 1))); grid.append(b); p.pg.render({ canvasContext: c.getContext('2d'), viewport: vp }).promise.catch(() => { }); }
    m = modal({ title: 'পাতা সাজান', body: grid, wide: true, actions: [{ label: 'আরেকটি PDF/ছবি জুড়ুন', ghost: true, onClick: mergeWith }, { label: 'বন্ধ', primary: true }] });
  }

  /* ---------- search ---------- */
  let hits = [], hitPos = -1, query = '';
  function applyHits(p) { if (!p.spans) return; const q = query.toLowerCase(); p.spans.forEach(sp => { const on = q && sp.textContent.toLowerCase().includes(q); sp.style.background = on ? 'rgba(255,196,0,.9)' : ''; sp.style.color = on ? 'transparent' : ''; }); }
  async function search(q) { query = q.trim(); hits = []; hitPos = -1; if (!query) { pages.forEach(applyHits); return; } const lq = query.toLowerCase(); for (const p of pages) { const tc = await getText(p); const n = tc.items.filter(it => it.str.toLowerCase().includes(lq)).length; for (let k = 0; k < n; k++) hits.push(p.i); } pages.forEach(applyHits); return hits.length; }
  function findDlg() {
    const inp = h('input', { class: 'inp', placeholder: 'শব্দ খুঁজুন…' }), info = h('div', { class: 'hint' }, ''); const next = d => { if (!hits.length) return; hitPos = (hitPos + d + hits.length) % hits.length; info.textContent = `${toBn(hitPos + 1)} / ${toBn(hits.length)} — পাতা ${toBn(hits[hitPos] + 1)}`; gotoPage(hits[hitPos]); };
    const go = async () => { const n = await search(inp.value); info.textContent = n === undefined ? '' : n ? `${toBn(n)}টি পাওয়া গেছে` : 'পাওয়া যায়নি'; if (n) next(1); };
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); hits.length && inp.value.trim() === query ? next(1) : go(); } }); inp.value = query;
    modal({ title: 'PDF-এ খুঁজুন', body: h('div', { style: { display: 'grid', gap: '10px' } }, inp, info, h('div', { style: { display: 'flex', gap: '8px' } }, h('button', { class: 'btn', type: 'button', onclick: go }, 'খুঁজুন'), h('button', { class: 'btn', type: 'button', onclick: () => next(-1) }, 'আগেরটি'), h('button', { class: 'btn', type: 'button', onclick: () => next(1) }, 'পরেরটি'))), actions: [{ label: 'বন্ধ', primary: true, onClick: () => { } }] }); setTimeout(() => inp.focus(), 100);
  }
  async function gotoDlg() { const v = await promptDlg(`পাতায় যান (১–${toBn(pages.length)})`, { type: 'number', inputmode: 'numeric', value: String(cur + 1) }); if (v) gotoPage(parseInt(v) - 1); }

  /* ---------- toolbar ---------- */
  const TB = {}; const zl = h('span', { class: 'tb-t', style: { minWidth: '46px', textAlign: 'center' } }, '১০০%');
  const mk = (id, ic, label, fn, o) => (TB[id] = btn(ic, label, fn, o));
  const swatch = (arr, get, set) => () => pickColor({ title: 'রঙ', current: get() }).then(c => { if (c) set(c); });
  const bar = h('div', { class: 'tools' }, mk('view', 'hand', 'দেখুন / স্ক্রল', () => setTool('view'), { text: 'দেখুন' }), mk('pen', 'pen', 'কলম', () => tool === 'pen' ? swatch(COLORS, () => penC, c => penC = c)() : setTool('pen'), { text: 'কলম' }), mk('hl', 'highlighter', 'হাইলাইট (ড্র্যাগ করে লাইনের উপর টানুন)', () => tool === 'hl' ? swatch(HL, () => hlC, c => hlC = c)() : setTool('hl'), { text: 'হাইলাইট' }), mk('note', 'text', 'টেক্সট নোট', () => setTool('note'), { text: 'লেখা' }), mk('erase', 'eraser', 'ইরেজার', () => setTool('erase'), { text: 'রাবার' }), h('span', { class: 'tsep' }),
    btn('search', 'খুঁজুন', findDlg, { text: 'খুঁজুন' }), btn('pages', 'পাতা সাজান', organizer, { text: 'পাতা' }), btn('arrowR', 'পাতায় যান', gotoDlg, { text: 'যান' }), h('span', { class: 'tsep' }), btn('zoomOut', 'ছোট', () => setZoom(zoom - .25)), zl, btn('zoomIn', 'বড়', () => setZoom(zoom + .25)), btn('maximize', 'ফিট', () => setZoom(1), { text: 'ফিট' }), h('span', { class: 'tsep' }), btn('rotate', 'এই পাতা ঘোরান', () => rotatePage(cur, 90), { text: 'ঘোরান' }));
  async function aiAsk() {
    const b = busy('PDF পড়া হচ্ছে…'); let text = '', parts = [];
    try {
      for (const p of pages.slice(0, 60)) { const tc = await getText(p); text += tc.items.map(i => i.str + (i.hasEOL ? '\n' : '')).join('') + '\n'; if (text.length > 90000) break; }
      if (text.replace(/\s/g, '').length < 80) { const { canvasToPart } = await import('./ai.js'); for (const p of pages.slice(0, 5)) { const vp = p.pg.getViewport({ scale: 1.5 }); const c = document.createElement('canvas'); c.width = vp.width; c.height = vp.height; await p.pg.render({ canvasContext: c.getContext('2d'), viewport: vp }).promise; parts.push(await canvasToPart(c, .8, 1400)); } }
    } finally { b.done(); }
    const { aiChat } = await import('./ai.js');
    aiChat({ title: 'AI: ' + ctx.meta.name, context: text, contextParts: parts, chips: ['সারাংশ লিখুন', 'মূল পয়েন্টগুলো বলুন', 'গুরুত্বপূর্ণ তারিখ ও সংখ্যা কী কী?', '৫টি প্রশ্ন-উত্তর বানান', 'বাংলায় অনুবাদ করুন'], intro: parts.length ? 'এটি স্ক্যান করা PDF — প্রথম ৫টি পাতা ছবি হিসেবে পড়া হবে।' : '' });
  }
  const exportsList = [
    { icon: 'image', label: 'বর্তমান পাতা ছবি (PNG)', async run() { const p = pages[cur]; const c = document.createElement('canvas'); const vp = p.pg.getViewport({ scale: 2 }); c.width = vp.width; c.height = vp.height; await p.pg.render({ canvasContext: c.getContext('2d'), viewport: vp }).promise; const g = c.getContext('2d'); const f = vp.width / p.vp.width; await new Promise(r => { /* overlay annotations */ r(); }); const blob = await new Promise(r => c.toBlob(r, 'image/png')); return { blob, name: baseName(ctx.meta.name) + ` পাতা ${cur + 1}.png`, kind: 'image' }; } },
    { icon: 'text', label: 'লেখা বের করুন (.txt)', async run() { const b = busy('লেখা আলাদা হচ্ছে…'); try { let out = ''; for (const p of pages) { const tc = await getText(p); let line = '', y = null; for (const it of tc.items) { const yy = Math.round(it.transform[5]); if (y !== null && Math.abs(yy - y) > 3) { out += line.trimEnd() + '\n'; line = ''; } line += it.str + (it.hasEOL ? '\n' : ''); y = yy; } out += line + '\n\n— পাতা ' + (p.i + 1) + ' —\n\n'; } if (!out.replace(/—.*—/g, '').trim()) { toast('এই PDF-এ কোনো লেখা পাওয়া যায়নি (স্ক্যান করা ছবি হতে পারে)', 4000); return null; } return { blob: new Blob([out], { type: 'text/plain;charset=utf-8' }), name: baseName(ctx.meta.name) + '.txt', kind: 'word' }; } finally { b.done(); } } },
    { icon: 'print', label: 'প্রিন্ট', async run() { await ctx.saveNow(); const blob = await ctx.currentBlob(); const url = URL.createObjectURL(blob); const f = document.createElement('iframe'); f.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0'; f.src = url; document.body.append(f); f.onload = () => { try { f.contentWindow.print(); } catch { window.open(url); } }; setTimeout(() => { f.remove(); URL.revokeObjectURL(url); }, 120000); return null; } },
  ];
  ctx.afterExport = async r => { const { offerOutput } = await import('./edkit.js'); return offerOutput(ctx, r); };
  const r0 = ctx.setup({ serialize, undo, redo, exports: exportsList, extraMenu: [{ icon: 'word', label: 'Word-এ রূপান্তর', sub: 'এডিটযোগ্য ডকুমেন্ট (স্ক্যান হলে OCR)', onClick: async () => { await ctx.saveNow(); const b = await ctx.currentBlob(); const { pdfToWordFile } = await import('./tools.js'); pdfToWordFile(new File([b], ctx.meta.name, { type: 'application/pdf' })); } },
    { icon: 'sparkle', label: 'AI: সারাংশ / প্রশ্ন করুন', sub: 'এই PDF নিয়ে Gemini-কে জিজ্ঞাসা করুন', onClick: aiAsk },
    { icon: 'pages', label: 'পাতা সাজান / জুড়ুন', onClick: organizer }, { icon: 'search', label: 'খুঁজুন', onClick: findDlg }] }); hdr = r0.hdr; as = r0.as; hdr.setUndo(false, false);
  ctx.root.replaceChildren(hdr.el, h('div', { class: 'ed-body' }, bar, holder));
  await new Promise(r => requestAnimationFrame(r)); layout.w = baseW(); await buildPages(); setTool('view'); pill.textContent = `১ / ${toBn(pages.length)}`;
  window.__pdf = { get annots() { return annots; }, serialize, pageOp, rotatePage, get pages() { return pages; }, setTool, flatten: (...a) => flatten(...a), get base() { return base; } };
  return { destroy() { io && io.disconnect(); try { doc && doc.destroy(); } catch { } } };
}
