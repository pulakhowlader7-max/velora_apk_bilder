// Velora — app shell: home, file library, settings, editor host.
import { $, h, icon, btn, sheet, modal, confirmDlg, promptDlg, toast, withBusy, pickFiles, saveToDevice, shareFile, fmtSize, fmtDate, toBn, KINDS, kindOf, extOf, baseName, errMsg, needJSZip, readBuf, debounce, layerCount } from './util.js';
import { db, getSettings, setSetting, requestPersist, isPersisted, uniqueName } from './db.js';
import { initLock, lockNow, askNewPin, askCurrentPin, setPin, removePin, hasPin } from './lock.js';
import { makeHeader, autosave } from './edkit.js';
import { initIncoming, isNative } from './native.js';
import { TOOLS, toolCard } from './tools.js';
window.__icon = icon;

const EDITORS = {
  word: () => import('./word.js'),
  excel: () => import('./sheet.js'),
  ppt: () => import('./slides.js'),
  pdf: () => import('./pdfview.js'),
};
const NATIVE = { word: ['docx'], excel: ['xlsx'], ppt: ['pptx'], pdf: ['pdf'] };
const CONVERT = { word: ['txt', 'md', 'markdown', 'html', 'htm', 'dotx', 'log'], excel: ['csv', 'tsv', 'xlsm', 'xltx'], ppt: ['ppsx', 'potx'] };
const LEGACY = ['doc', 'xls', 'ppt', 'pps', 'odt', 'ods', 'odp', 'rtf'];

const root = $('#app');
const state = { tab: 'home', filter: 'all', q: '', metas: [], settings: null, editor: null, trash: false };

/* ---------- theme ---------- */
function applyTheme(t) {
  const dark = t === 'dark' || (t === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  try { localStorage.setItem('ao-theme', t); } catch { }
  const m = $('#themeColor'); if (m) m.content = dark ? '#0f1220' : '#f4f5fa';
}
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => state.settings && applyTheme(state.settings.theme));

/* ---------- import / create ---------- */
export async function importFiles(files, { open = false } = {}) {
  if (!files.length) return [];
  const out = [];
  await withBusy('ফাইল যোগ হচ্ছে…', async b => {
    let i = 0;
    for (const f of files) {
      b.set(`${toBn(++i)}/${toBn(files.length)}  ${f.name}`);
      try {
        const kind = kindOf(f.name, f.type), ext = extOf(f.name);
        let name = f.name, buf, snap, k = kind;
        if (CONVERT[kind] && CONVERT[kind].includes(ext)) {
          const mod = await EDITORS[kind]();
          const r = await mod.importFile(f); name = r.name; buf = r.buf; snap = r.snap;
        } else buf = await readBuf(f);
        if (kind === 'pdf' || kind === 'image') { /* stored as is */ }
        const meta = await db.create({ name: await uniqueName(name), buf, snap, kind: k });
        if (LEGACY.includes(ext)) await db.patch(meta.id, { legacy: true });
        out.push(meta);
      } catch (e) { console.error(e); toast(`"${f.name}" যোগ করা যায়নি: ${errMsg(e)}`, 4200); }
    }
  });
  if (out.length) { toast(out.length === 1 ? 'ফাইল যোগ হয়েছে' : `${toBn(out.length)}টি ফাইল যোগ হয়েছে`); await refresh(); }
  if (open && out.length === 1) openFile(out[0].id);
  return out;
}
async function createNew(kind, opts) {
  try {
    const meta = await withBusy('তৈরি হচ্ছে…', async () => {
      const mod = await EDITORS[kind](); const r = await mod.blank(opts || {});
      return db.create({ name: await uniqueName(r.name), buf: r.buf, snap: r.snap, kind });
    });
    await refresh(); openFile(meta.id);
  } catch (e) { console.error(e); toast('তৈরি করা যায়নি: ' + errMsg(e), 4000); }
}
async function newDialog() {
  const mod = await import('./templates.js');
  const items = [
    { title: 'নতুন তৈরি করুন' },
    { icon: 'word', label: 'Word ডকুমেন্ট', sub: 'ফাঁকা পাতা', onClick: () => createNew('word') },
    { icon: 'tpl', label: 'চিঠি, CV, আবেদন…', sub: 'তৈরি টেমপ্লেট থেকে', onClick: () => mod.pickWordTemplate(t => createNew('word', { tpl: t })) },
    { icon: 'excel', label: 'Excel স্প্রেডশিট', sub: 'ফাঁকা শিট', onClick: () => createNew('excel') },
    { icon: 'tpl', label: 'Excel টেমপ্লেট', sub: 'হিসাব, বাজেট, উপস্থিতি…', onClick: () => mod.pickSheetTemplate(t => createNew('excel', { tpl: t })) },
    { icon: 'ppt', label: 'PowerPoint প্রেজেন্টেশন', sub: 'থিম বেছে নিন', onClick: () => mod.pickSlideTheme(t => createNew('ppt', { theme: t })) },
    { sep: true },
    { icon: 'camera', label: 'ডকুমেন্ট স্ক্যানার', sub: 'ক্যামেরায় কাগজ → PDF / Word', onClick: () => openScan() },
    { icon: 'image', label: 'ছবি থেকে PDF', sub: 'গ্যালারি থেকে ছবি বেছে নিন', onClick: () => imagesToPdf(false) },
    { icon: 'sparkle', label: 'AI দিয়ে ডকুমেন্ট / স্লাইড', sub: 'বিষয় দিন, AI বানাবে', onClick: () => { state.tab = 'tools'; renderMain(); } },
    { sep: true },
    { icon: 'open', label: 'ফাইল খুলুন / আনুন', sub: 'Word, Excel, PPT, PDF, ছবি, CSV…', onClick: () => openPicker() },
  ];
  sheet('', items);
}
async function openScan() { const m = await import('./scanner.js'); m.openScanner(); }
async function openPicker() { const fs = await pickFiles({ multiple: true }); await importFiles(fs, { open: true }); }
async function imagesToPdf(camera) {
  const fs = await pickFiles({ accept: 'image/*', multiple: !camera, capture: camera ? 'environment' : undefined });
  if (!fs.length) return;
  try {
    const mod = await EDITORS.pdf();
    const r = await withBusy('PDF তৈরি হচ্ছে…', () => mod.imagesToPdf(fs));
    const meta = await db.create({ name: await uniqueName(r.name), buf: r.buf, kind: 'pdf' });
    await refresh(); openFile(meta.id);
  } catch (e) { console.error(e); toast('PDF তৈরি ব্যর্থ: ' + errMsg(e), 4000); }
}

/* ---------- editor host ---------- */
function navigateHome() { if (history.state && history.state.edit) history.back(); else { history.replaceState(null, '', '#/'); route(); } }
export function openFile(id, fromRoute) {
  if (!fromRoute) history.pushState({ edit: true }, '', '#/edit/' + id);
  route();
}
async function mountEditor(id) {
  if (state.editor) return;
  const meta = await db.meta(id);
  if (!meta || meta.trashed) { toast('ফাইল পাওয়া যায়নি'); history.replaceState(null, '', '#/'); return route(); }
  if (meta.legacy) { legacyDialog(meta); history.replaceState(null, '', '#/'); return; }
  const kind = meta.kind;
  if (!EDITORS[kind] && kind !== 'image') { otherDialog(meta); history.replaceState(null, '', '#/'); return; }
  const el = document.createElement('div'); el.className = 'ed'; document.body.append(el);
  const ctx = {
    meta, root: el, buf: null, snap: undefined, hdrApi: null, as: null,
    close: async () => { await finish(); navigateHome(); },
    discard: () => { finishQuiet(); navigateHome(); },
    saveNow: async () => { }, currentBlob: async () => new Blob([await db.buf(ctx.meta.id)], { type: KINDS[ctx.meta.kind].mime }),
    openFile: nid => { finishQuiet(); history.replaceState({ edit: true }, '', '#/edit/' + nid); route(); },
    setup(opts) {
      ctx.hdrApi = makeHeader(ctx, opts); ctx.as = autosave(ctx, opts.serialize, ctx.hdrApi);
      ctx.saveNow = ctx.as.now;
      return { hdr: ctx.hdrApi, as: ctx.as };
    },
  };
  let inst = null;
  async function finish() { try { if (ctx.as) await ctx.as.now(); } catch { } finishQuiet(); }
  function finishQuiet() {
    if (!state.editor) return; try { inst && inst.destroy && inst.destroy(); } catch { }
    if (ctx.as) ctx.as.destroy(); el.remove(); state.editor = null; db.patch(meta.id, { opened: Date.now() }).then(refresh);
  }
  state.editor = { ctx, finish, finishQuiet };
  try {
    el.append(Object.assign(document.createElement('div'), { className: 'boot', innerHTML: '<div class="spin"></div>' }));
    ctx.buf = await db.buf(id); ctx.snap = await db.snap(id);
    if (kind === 'image') inst = await mountImage(ctx);
    else { const mod = await EDITORS[kind](); el.replaceChildren(); inst = await mod.mount(ctx); }
  } catch (e) {
    console.error(e); finishQuiet(); toast('ফাইল খোলা যায়নি: ' + errMsg(e), 5000); history.replaceState(null, '', '#/'); route();
  }
}
async function mountImage(ctx) {
  const url = URL.createObjectURL(new Blob([ctx.buf], { type: 'image/' + (ctx.meta.ext === 'jpg' ? 'jpeg' : ctx.meta.ext) }));
  ctx.root.replaceChildren();
  const hdr = makeHeader(ctx, { serialize: async () => ({ buf: ctx.buf }), exports: [{ icon: 'pdf', label: 'PDF-এ রূপান্তর', run: async () => { const m = await EDITORS.pdf(); const r = await m.imagesToPdf([new File([ctx.buf], ctx.meta.name, { type: 'image/' + ctx.meta.ext })]); return { blob: new Blob([r.buf], { type: 'application/pdf' }), name: r.name, kind: 'pdf' }; } }] });
  ctx.currentBlob = async () => new Blob([ctx.buf]);
  const editB = h('button', { class: 'fab imgedit', type: 'button', onclick: async () => { const { openPhotoEditor } = await import('./photo.js'); openPhotoEditor(new File([ctx.buf], ctx.meta.name, { type: 'image/' + (ctx.meta.ext === 'jpg' ? 'jpeg' : ctx.meta.ext) }), { meta: ctx.meta }); } }, icon('pen', 20), 'এডিট');
  ctx.root.append(hdr.el, h('div', { class: 'imgview' }, h('img', { src: url, alt: ctx.meta.name })), editB);
  return { destroy() { URL.revokeObjectURL(url); } };
}
function legacyDialog(meta) {
  modal({
    title: 'এই ফরম্যাট সরাসরি খোলা যাচ্ছে না', body: h('p', { class: 'modal-p' }, `"${meta.name}" পুরনো ফরম্যাটের (.${meta.ext}) ফাইল। ফাইলটি নিরাপদে সংরক্ষিত আছে। খুলতে হলে মূল ফোন/কম্পিউটারে এটি .docx / .xlsx / .pptx হিসেবে "Save As" করে আবার আনুন।`),
    actions: [{ label: 'শেয়ার', ghost: true, onClick: async () => shareFile(new Blob([await db.buf(meta.id)]), meta.name) }, { label: 'ঠিক আছে', primary: true }]
  });
}
function otherDialog(meta) {
  modal({
    title: 'ফাইল সংরক্ষিত আছে', body: h('p', { class: 'modal-p' }, `"${meta.name}" এই অ্যাপে সম্পাদনা করা যায় না, কিন্তু নিরাপদে রাখা আছে। শেয়ার বা ফোনে সেভ করতে পারেন।`),
    actions: [{ label: 'ফোনে সেভ', ghost: true, onClick: async () => saveToDevice(new Blob([await db.buf(meta.id)]), meta.name) }, { label: 'শেয়ার', primary: true, onClick: async () => shareFile(new Blob([await db.buf(meta.id)]), meta.name) }]
  });
}

/* ---------- library ---------- */
async function refresh() { state.metas = await db.list(); if (!state.editor) renderMain(); }
function filtered(recent) {
  let l = state.metas.filter(m => !!m.trashed === (state.trash && !recent));
  const f = state.filter;
  if (f === 'star') l = l.filter(m => m.starred); else if (f !== 'all') l = l.filter(m => m.kind === f || (f === 'other' && !EDITORS[m.kind] && m.kind !== 'image'));
  const q = state.q.trim().toLowerCase(); if (q) l = l.filter(m => m.name.toLowerCase().includes(q));
  const s = state.settings.sort;
  l.sort((a, b) => s === 'name' ? a.name.localeCompare(b.name, 'bn') : s === 'size' ? b.size - a.size : s === 'opened' ? b.opened - a.opened : b.modified - a.modified);
  return l;
}
function fileCard(m, view) {
  const K = KINDS[m.kind] || KINDS.other;
  const ic = h('div', { class: 'ficon', style: { background: K.color } }, icon(K.icon, view === 'grid' ? 26 : 22));
  const info = h('div', { class: 'finfo' }, h('div', { class: 'fname' }, m.starred ? h('span', { class: 'fstar' }, '★ ') : null, m.name), h('div', { class: 'fsub' }, `${fmtDate(m.modified)} · ${toBn(fmtSize(m.size))}`));
  const main = h('button', { class: 'fmain', type: 'button', onclick: () => m.trashed ? fileMenu(m) : openFile(m.id), 'aria-label': m.name },
    h('div', { class: 'fthumb', style: { '--k': K.color } }, ic), info);
  const more = h('button', { class: 'fmore', type: 'button', 'aria-label': 'আরও', onclick: e => { e.stopPropagation(); fileMenu(m); } }, icon('more', 20));
  return h('div', { class: 'fcard' }, main, more);
}
function fileMenu(m) {
  const items = [];
  if (m.trashed) {
    items.push({ icon: 'rotate', label: 'ফিরিয়ে আনুন', onClick: async () => { await db.patch(m.id, { trashed: false }); toast('ফিরিয়ে আনা হয়েছে'); refresh(); } });
    items.push({ icon: 'trash', label: 'স্থায়ীভাবে মুছুন', danger: true, onClick: async () => { if (await confirmDlg('স্থায়ীভাবে মুছবেন?', 'এটি আর ফেরানো যাবে না।', { ok: 'মুছুন', danger: true })) { await db.remove(m.id); refresh(); } } });
  } else {
    items.push({ icon: 'open', label: 'খুলুন', onClick: () => openFile(m.id) });
    items.push({ icon: 'pen', label: 'নাম পরিবর্তন', onClick: async () => { const b = baseName(m.name), e = extOf(m.name); const v = await promptDlg('ফাইলের নাম', { value: b }); if (v && v.trim()) { await db.patch(m.id, { name: v.trim().replace(/[\\/:*?"<>|]/g, '') + (e ? '.' + e : '') }); refresh(); } } });
    items.push({ icon: 'star', label: m.starred ? 'তারকা সরান' : 'তারকা দিন', onClick: async () => { await db.patch(m.id, { starred: !m.starred }); refresh(); } });
    if (m.kind === 'image') items.push({ icon: 'pen', label: 'ছবি এডিট করুন', onClick: async () => { const { openPhotoEditor } = await import('./photo.js'); openPhotoEditor(new File([await db.buf(m.id)], m.name, { type: KINDS.image.mime }), { meta: m }); } });
    if (m.kind === 'pdf') items.push({ icon: 'word', label: 'Word-এ রূপান্তর', onClick: async () => { const t = TOOLS.find(x => x.id === 'pdf2word'); const f = new File([await db.buf(m.id)], m.name, { type: 'application/pdf' }); const mod = await import('./tools.js'); mod.pdfToWordFile ? mod.pdfToWordFile(f) : t.run(); } });
    items.push({ icon: 'share', label: 'শেয়ার', onClick: async () => shareFile(new Blob([await db.buf(m.id)], { type: KINDS[m.kind].mime }), m.name) });
    items.push({ icon: 'download', label: 'ফোনে সেভ / ডাউনলোড', onClick: async () => saveToDevice(new Blob([await db.buf(m.id)], { type: KINDS[m.kind].mime }), m.name) });
    items.push({ icon: 'copy', label: 'কপি', onClick: async () => { const buf = await db.buf(m.id), snap = await db.snap(m.id); await db.create({ name: await uniqueName(baseName(m.name) + ' - কপি.' + m.ext), buf, snap, kind: m.kind }); refresh(); toast('কপি হয়েছে'); } });
    items.push({ sep: true }, { icon: 'trash', label: 'ট্র্যাশে পাঠান', danger: true, onClick: async () => { await db.patch(m.id, { trashed: true, trashedAt: Date.now() }); toast('ট্র্যাশে সরানো হয়েছে'); refresh(); } });
  }
  sheet(m.name, items);
}

function emptyState(msg, sub) {
  return h('div', { class: 'empty' }, h('div', { class: 'big' }, icon('folder', 40)), h('h3', null, msg), h('div', null, sub || ''));
}
const CHIPS = [['all', 'সব'], ['word', 'Word'], ['excel', 'Excel'], ['ppt', 'PowerPoint'], ['pdf', 'PDF'], ['image', 'ছবি'], ['star', '★ তারকা']];

const snapText = new Map();
async function textOf(m) {
  const k = m.id + ':' + m.modified; if (snapText.has(k)) return snapText.get(k);
  let t = ''; try { const sn = await db.snap(m.id); if (typeof sn === 'string') t = sn.replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ').toLowerCase(); } catch { }
  snapText.set(k, t); return t;
}
function renderHome() {
  const top = h('div', { class: 'topbar' }, h('img', { src: 'icons/logo-96.png', alt: '', width: 34, height: 34, style: { borderRadius: '9px', marginRight: '10px' } }), h('h1', null, 'Velora'),
    h('button', { class: 'iconbtn', type: 'button', 'aria-label': 'AI সহায়ক', onclick: () => TOOLS.find(t => t.id === 'chat').run() }, icon('sparkle', 22)),
    h('button', { class: 'iconbtn', type: 'button', 'aria-label': 'ফাইল খুলুন', onclick: openPicker }, icon('open', 22)));
  const q = h('input', { type: 'search', placeholder: 'ফাইল, টুল বা লেখা খুঁজুন…', value: state.hq || '', 'aria-label': 'খুঁজুন' });
  const res = h('div', { id: 'hres' });
  const quick = h('div', { class: 'quick' }, [['scan', 'স্ক্যান', 'camera', '#0e9f6e'], ['pdf2word', 'PDF→Word', 'word', '#2b5fd9'], ['photo', 'ছবি এডিট', 'image', '#8a4fd8'], ['chat', 'AI', 'sparkle', '#7c3aed']].map(([id, t, ic, c]) =>
    h('button', { type: 'button', onclick: () => TOOLS.find(x => x.id === id).run() }, h('div', { class: 'ci', style: { background: c } }, icon(ic, 22)), t)));
  const create = h('div', { class: 'create' }, ...[['word', 'Word'], ['excel', 'Excel'], ['ppt', 'PPT'], ['pdf', 'PDF']].map(([k, t]) =>
    h('button', { type: 'button', onclick: () => k === 'pdf' ? TOOLS.find(x => x.id === 'pdfedit').run() : createNew(k) }, h('div', { class: 'ci', style: { background: KINDS[k].color } }, icon(KINDS[k].icon, 22)), t)));
  const recents = state.metas.filter(m => !m.trashed).sort((a, b) => b.opened - a.opened).slice(0, 6);
  const main = h('div', { id: 'hmain' }, quick, h('div', { class: 'sec' }, 'নতুন তৈরি'), create, h('div', { class: 'sec' }, 'সাম্প্রতিক'),
    recents.length ? h('div', { class: 'files list' }, recents.map(m => fileCard(m, 'list'))) : emptyState('এখনো কোনো ফাইল নেই', 'স্ক্যান করুন, নতুন ফাইল বানান বা বাইরের ফাইল খুলুন'));
  async function doSearch() {
    const v = (state.hq || '').trim().toLowerCase(); main.hidden = !!v; res.replaceChildren(); if (!v) return;
    const tl = TOOLS.filter(t => (t.name + ' ' + t.sub + ' ' + t.kw).toLowerCase().includes(v)).slice(0, 5);
    const files = state.metas.filter(m => !m.trashed); const byName = files.filter(m => m.name.toLowerCase().includes(v)); const seen = new Set(byName.map(m => m.id)); const inside = [];
    for (const m of files) { if (!seen.has(m.id) && m.kind === 'word' && (await textOf(m)).includes(v)) inside.push(m); if (state.hq.trim().toLowerCase() !== v) return; }
    res.replaceChildren();
    if (tl.length) res.append(h('div', { class: 'sec' }, 'টুল'), h('div', { class: 'toolgrid' }, tl.map(toolCard)));
    if (byName.length) res.append(h('div', { class: 'sec' }, 'ফাইল'), h('div', { class: 'files list' }, byName.map(m => fileCard(m, 'list'))));
    if (inside.length) res.append(h('div', { class: 'sec' }, 'ফাইলের ভেতরে পাওয়া গেছে'), h('div', { class: 'files list' }, inside.map(m => fileCard(m, 'list'))));
    if (!tl.length && !byName.length && !inside.length) res.append(emptyState('কিছু পাওয়া যায়নি', 'অন্য শব্দে খুঁজুন'));
  }
  q.addEventListener('input', debounce(() => { state.hq = q.value; doSearch(); }, 160));
  const sc = h('div', { class: 'scroll' }, h('div', { class: 'search' }, icon('search', 18), q), res, main);
  if (state.hq) doSearch();
  return [top, sc];
}
function renderTools() {
  const top = h('div', { class: 'topbar' }, h('h1', null, 'টুলস'));
  const groups = ['স্ক্যান ও OCR', 'PDF', 'ছবি', 'AI সহায়ক', 'ডকুমেন্ট'];
  return [top, h('div', { class: 'scroll' }, groups.map((g, i) => [h('div', { class: 'sec' }, g), h('div', { class: 'toolgrid' }, TOOLS.filter(t => t.g === i).map(toolCard))]))];
}
function renderFiles() {
  const s = state.settings;
  const q = h('input', { type: 'search', placeholder: 'ফাইল খুঁজুন…', value: state.q, 'aria-label': 'ফাইল খুঁজুন' });
  q.addEventListener('input', debounce(() => { state.q = q.value; renderList(); }, 150));
  const top = h('div', { class: 'topbar' }, h('h1', null, state.trash ? 'ট্র্যাশ' : 'আমার ফাইল'),
    h('button', { class: 'iconbtn', type: 'button', 'aria-label': 'দেখার ধরন', onclick: async () => { await setSetting('view', s.view === 'grid' ? 'list' : 'grid'); renderMain(); } }, icon(s.view === 'grid' ? 'list' : 'grid', 22)),
    h('button', { class: 'iconbtn', type: 'button', 'aria-label': 'সাজান', onclick: () => sheet('সাজান', [['modified', 'সর্বশেষ পরিবর্তন'], ['opened', 'সর্বশেষ খোলা'], ['name', 'নাম'], ['size', 'আকার']].map(([k, t]) => ({ icon: 'sort', label: t, active: s.sort === k, onClick: async () => { await setSetting('sort', k); renderMain(); } }))) }, icon('sort', 22)),
    h('button', { class: 'iconbtn', type: 'button', 'aria-label': state.trash ? 'ফাইলে ফিরুন' : 'ট্র্যাশ', onclick: () => { state.trash = !state.trash; renderMain(); } }, icon(state.trash ? 'folder' : 'trash', 22)));
  const chips = h('div', { class: 'chips' }, CHIPS.map(([k, t]) => h('button', { class: 'chip' + (state.filter === k ? ' on' : ''), type: 'button', onclick: () => { state.filter = k; renderMain(); } }, t)));
  const listEl = h('div', { id: 'flist' });
  const sc = h('div', { class: 'scroll' }, h('div', { class: 'search' }, icon('search', 18), q), chips, listEl);
  function renderList() {
    const l = filtered(); listEl.replaceChildren();
    if (!l.length) { listEl.append(emptyState(state.q ? 'কিছু পাওয়া যায়নি' : state.trash ? 'ট্র্যাশ খালি' : 'কোনো ফাইল নেই', state.q ? 'অন্য নামে খুঁজুন' : '')); return; }
    listEl.append(h('div', { class: 'files ' + s.view }, l.map(m => fileCard(m, s.view))));
  }
  renderList();
  return [top, sc];
}
function renderSettings() {
  const s = state.settings;
  const top = h('div', { class: 'topbar' }, h('h1', null, 'সেটিংস'));
  const sw = (on) => h('span', { class: 'switch' + (on ? ' on' : '') });
  const themeSeg = h('div', { class: 'seg' }, [['auto', 'অটো'], ['light', 'দিন'], ['dark', 'রাত']].map(([k, t]) => h('button', { type: 'button', class: s.theme === k ? 'on' : '', onclick: async () => { await setSetting('theme', k); applyTheme(k); renderMain(); } }, t)));
  const pinOn = s.lockOn;
  const lockCard = h('div', { class: 'card' }, h('div', { class: 'card-h' }, 'নিরাপত্তা'),
    h('button', { class: 'row', type: 'button', onclick: async () => {
      if (pinOn) { if (!(await askCurrentPin('পিন বন্ধ করতে বর্তমান পিন দিন'))) return; await removePin(); toast('পিন লক বন্ধ হয়েছে'); }
      else { const p = await askNewPin(4); if (!p) return; await setPin(p); toast('পিন লক চালু হয়েছে'); }
      state.settings = await getSettings(); renderMain();
    } }, icon('lock', 22), h('div', { class: 'rt' }, 'পিন লক', h('small', null, pinOn ? 'চালু — অ্যাপ খুলতে পিন লাগবে' : 'বন্ধ')), sw(pinOn)),
    pinOn ? h('button', { class: 'row', type: 'button', onclick: async () => { if (!(await askCurrentPin())) return; const p = await askNewPin(4); if (!p) return; await setPin(p); toast('পিন বদলানো হয়েছে'); } }, icon('shield', 22), h('div', { class: 'rt' }, 'পিন পরিবর্তন')) : null,
    pinOn ? h('button', { class: 'row', type: 'button', onclick: () => sheet('অটো-লক', [[0, 'সাথে সাথে'], [30, '৩০ সেকেন্ড পরে'], [60, '১ মিনিট পরে'], [300, '৫ মিনিট পরে'], [-1, 'কখনো নয় (শুধু অ্যাপ খুললে)']].map(([v, t]) => ({ icon: 'clock', label: t, active: s.autoLock === v, onClick: async () => { await setSetting('autoLock', v); renderMain(); } }))) },
      icon('clock', 22), h('div', { class: 'rt' }, 'অটো-লক', h('small', null, ({ '-1': 'কখনো নয়', 0: 'সাথে সাথে', 30: '৩০ সেকেন্ড', 60: '১ মিনিট', 300: '৫ মিনিট' })[s.autoLock]))) : null,
    pinOn ? h('button', { class: 'row', type: 'button', onclick: () => lockNow() }, icon('lock', 22), h('div', { class: 'rt' }, 'এখনই লক করুন')) : null);
  const aiCard = h('div', { class: 'card' }, h('div', { class: 'card-h' }, 'AI (Gemini) ও OCR'));
  import('./ai.js').then(async ai => {
    const c = await ai.aiConfig();
    aiCard.append(h('button', { class: 'row', type: 'button', onclick: async () => { await ai.aiSetup(); renderMain(); } }, icon('sparkle', 22), h('div', { class: 'rt' }, 'Gemini API কী', h('small', null, c.key ? 'চালু আছে ✓ — বদলাতে চাপুন' : 'বিনামূল্যে কী নিন — AI, ভালো OCR ও স্লাইড/ডকুমেন্ট জেনারেটর চালু হবে'))));
    if (c.key) aiCard.append(h('button', { class: 'row danger', type: 'button', onclick: async () => { await ai.clearKey(); toast('AI কী মুছে ফেলা হয়েছে'); renderMain(); } }, icon('trash', 22), h('div', { class: 'rt' }, 'AI কী মুছুন')));
    aiCard.append(h('div', { class: 'row' }, icon('info', 22), h('div', { class: 'rt' }, 'গোপনীয়তা', h('small', null, 'AI ব্যবহার করলেই শুধু লেখা/ছবি Google-এ যায়। না চাইলে কী দেবেন না — বাকি সব ফিচার অফলাইনে চলে।'))));
  });
  const storeCard = h('div', { class: 'card' }, h('div', { class: 'card-h' }, 'ফোনের স্টোরেজ'));
  const used = h('div', { class: 'rt' }, 'হিসাব করা হচ্ছে…');
  const bar = h('div', { class: 'storebar' }, h('i', { style: { width: '0%' } }));
  storeCard.append(h('div', { class: 'row' }, icon('folder', 22), h('div', { class: 'rt' }, used, bar)));
  db.usage().then(async u => {
    const per = await isPersisted();
    used.firstChild.textContent = `${toBn(u.count)}টি ফাইল · ${toBn(fmtSize(u.total))} ব্যবহৃত` + (u.quota ? ` (ফোনের বরাদ্দ ${toBn(fmtSize(u.quota))})` : '');
    bar.firstChild.style.width = Math.min(100, u.quota ? (u.used || u.total) / u.quota * 100 : 4) + '%';
    if (!per) storeCard.append(h('button', { class: 'row', type: 'button', onclick: async () => { const ok = await requestPersist(); toast(ok ? 'স্থায়ী স্টোরেজ চালু হয়েছে' : 'ব্রাউজার অনুমতি দেয়নি — অ্যাপটি হোম স্ক্রিনে যোগ করুন'); renderMain(); } }, icon('shield', 22), h('div', { class: 'rt' }, 'ফাইল সুরক্ষিত রাখুন', h('small', null, 'ব্রাউজার যেন ফাইল নিজে থেকে মুছে না ফেলে'))));
    else storeCard.append(h('div', { class: 'row' }, icon('check', 22), h('div', { class: 'rt' }, 'স্থায়ী স্টোরেজ চালু', h('small', null, 'ফাইল নিজে থেকে মুছবে না'))));
  });
  storeCard.append(
    h('button', { class: 'row', type: 'button', onclick: backup }, icon('download', 22), h('div', { class: 'rt' }, 'সব ফাইলের ব্যাকআপ', h('small', null, 'একটি ZIP ফাইলে সব সেভ করুন'))),
    h('button', { class: 'row', type: 'button', onclick: restore }, icon('upload', 22), h('div', { class: 'rt' }, 'ব্যাকআপ থেকে ফিরিয়ে আনুন'))
  );
  const aboutCard = h('div', { class: 'card' }, h('div', { class: 'card-h' }, 'সাধারণ'),
    h('div', { class: 'row' }, icon('moon', 22), h('div', { class: 'rt' }, 'থিম'), themeSeg),
    h('button', { class: 'row', type: 'button', onclick: async () => { const v = await promptDlg('লেখকের নাম', { value: s.author, hint: 'নতুন ডকুমেন্টের তথ্যে ব্যবহৃত হবে' }); if (v != null) { await setSetting('author', v.trim()); renderMain(); } } }, icon('pen', 22), h('div', { class: 'rt' }, 'লেখকের নাম', h('small', null, s.author || 'দেওয়া হয়নি'))),
    h('button', { class: 'row danger', type: 'button', onclick: async () => { if (await confirmDlg('ট্র্যাশ খালি করবেন?', 'ট্র্যাশের সব ফাইল স্থায়ীভাবে মুছে যাবে।', { ok: 'খালি করুন', danger: true })) { for (const m of state.metas.filter(x => x.trashed)) await db.remove(m.id); toast('ট্র্যাশ খালি হয়েছে'); refresh(); } } }, icon('trash', 22), h('div', { class: 'rt' }, 'ট্র্যাশ খালি করুন')),
    h('div', { class: 'row' }, icon('info', 22), h('div', { class: 'rt' }, 'Velora', h('small', null, 'সংস্করণ ২.১ · সব ফাইল শুধু আপনার ফোনেই থাকে'))));
  return [top, h('div', { class: 'scroll' }, aiCard, lockCard, storeCard, aboutCard)];
}
async function backup() {
  const metas = state.metas.filter(m => !m.trashed); if (!metas.length) return toast('ব্যাকআপ করার মতো ফাইল নেই');
  await withBusy('ব্যাকআপ হচ্ছে…', async () => {
    const JSZip = await needJSZip(); const z = new JSZip(); const used = new Set();
    for (const m of metas) { let n = m.name, i = 2; while (used.has(n)) n = baseName(m.name) + ` (${i++}).` + m.ext; used.add(n); z.file(n, await db.buf(m.id)); }
    const blob = await z.generateAsync({ type: 'blob', compression: 'STORE' });
    await saveToDevice(blob, `velora-backup-${new Date().toISOString().slice(0, 10)}.zip`);
  });
}
async function restore() {
  const [f] = await pickFiles({ accept: '.zip,application/zip' }); if (!f) return;
  const files = await withBusy('পড়া হচ্ছে…', async () => {
    const JSZip = await needJSZip(); const z = await JSZip.loadAsync(await readBuf(f)); const out = [];
    for (const n of Object.keys(z.files)) { const e = z.files[n]; if (e.dir) continue; out.push(new File([await e.async('arraybuffer')], n.split('/').pop())); }
    return out;
  });
  await importFiles(files);
}

function renderMain() {
  if (state.editor) return;
  const [a, b] = state.tab === 'home' ? renderHome() : state.tab === 'files' ? renderFiles() : state.tab === 'tools' ? renderTools() : renderSettings();
  const tabBtn = (k, t, i) => h('button', { type: 'button', class: state.tab === k ? 'on' : '', onclick: () => { state.tab = k; state.trash = false; renderMain(); } }, icon(i, 22), t);
  const nav = h('nav', { class: 'bottomnav' }, tabBtn('home', 'হোম', 'home'), tabBtn('files', 'ফাইল', 'folder'),
    h('button', { type: 'button', class: 'navscan', 'aria-label': 'স্ক্যান', onclick: () => openScan() }, h('span', null, icon('camera', 26)), 'স্ক্যান'),
    tabBtn('tools', 'টুলস', 'grid'), tabBtn('settings', 'সেটিংস', 'settings'));
  const fab = (state.tab === 'home' || state.tab === 'files') ? h('button', { class: 'fab', type: 'button', onclick: newDialog }, icon('plus', 22), 'নতুন') : null;
  const keep = $('.scroll', root); const st = keep ? keep.scrollTop : 0;
  root.replaceChildren(...[h('div', { class: 'view' }, a, b), nav, fab].filter(Boolean));
  const ns = $('.scroll', root); if (ns) ns.scrollTop = st;
}

/* ---------- routing / boot ---------- */
async function route() {
  const m = /^#\/edit\/(.+)$/.exec(location.hash);
  if (m) { if (!state.editor) await mountEditor(m[1]); }
  else if (state.editor) { await state.editor.finish(); }
}
window.addEventListener('popstate', () => { if (layerCount() === 0) route(); });
window.addEventListener('hashchange', route);

async function sharedFromSW() {
  if (!/[?&]shared=1/.test(location.search)) return;
  try {
    const c = await caches.open('ao-share'); const keys = await c.keys(); const files = [];
    for (const k of keys) { const r = await c.match(k); const b = await r.blob(); files.push(new File([b], decodeURIComponent(r.headers.get('x-name') || 'file'), { type: b.type })); await c.delete(k); }
    history.replaceState(null, '', '/#/');
    await importFiles(files, { open: files.length === 1 });
  } catch (e) { console.warn(e); }
}

async function boot() {
  state.settings = await getSettings(); applyTheme(state.settings.theme);
  state.metas = await db.list();
  // purge trash older than 30 days
  const old = Date.now() - 30 * 864e5; for (const m of state.metas) if (m.trashed && (m.trashedAt || 0) < old) await db.remove(m.id);
  state.metas = await db.list();
  renderMain();
  await initLock(() => { });
  requestPersist();
  if ('launchQueue' in window) window.launchQueue.setConsumer(async p => { if (!p.files || !p.files.length) return; const fs = await Promise.all(p.files.map(x => x.getFile())); importFiles(fs, { open: fs.length === 1 }); });
  await sharedFromSW();
  initIncoming(fs => importFiles(fs, { open: fs.length === 1 })).catch(e => console.warn(e));
  { const q = /[?&]new=(word|excel|ppt)/.exec(location.search); if (q) { history.replaceState(null, '', '/'); createNew(q[1], {}); } }
  if (location.hash.startsWith('#/edit/')) { history.replaceState({ edit: true }, '', location.hash); route(); }
  if ('serviceWorker' in navigator) {
    if (isNative()) navigator.serviceWorker.getRegistrations().then(rs => rs.forEach(r => r.unregister())).catch(() => { }); // app files are local; no cache layer needed
    else if (location.protocol.startsWith('http')) navigator.serviceWorker.register('sw.js').catch(() => { });
  }
}
boot().catch(e => { console.error(e); root.innerHTML = '<div class="empty"><h3>অ্যাপ চালু করা যায়নি</h3><div>' + (e && e.message || e) + '</div></div>'; });
window.__ao = { state, importFiles, createNew, openFile, refresh, db, openScan };
