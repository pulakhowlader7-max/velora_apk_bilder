// Velora — pure image algorithms on {data:Uint8ClampedArray(RGBA), width, height}.
// No DOM here, so everything is unit-testable in Node and safe to run in a worker later.

export const clamp8 = v => (v < 0 ? 0 : v > 255 ? 255 : v);
const clamp01 = v => (v < 0 ? 0 : v > 1 ? 1 : v);

export function lumaOf(img) {
  const { data, width: w, height: h } = img; const g = new Float32Array(w * h);
  for (let i = 0, j = 0; i < g.length; i++, j += 4) g[i] = .299 * data[j] + .587 * data[j + 1] + .114 * data[j + 2];
  return g;
}

// Separable box blur on a float plane (edge clamped, running sums: O(n) regardless of radius).
export function boxBlurPlane(src, w, h, r) {
  r = Math.round(r); if (r < 1) return Float32Array.from(src);
  const tmp = new Float32Array(w * h), out = new Float32Array(w * h), d = 2 * r + 1;
  for (let y = 0; y < h; y++) {
    const o = y * w; let acc = 0;
    for (let k = -r; k <= r; k++) acc += src[o + Math.min(w - 1, Math.max(0, k))];
    for (let x = 0; x < w; x++) { tmp[o + x] = acc / d; acc += src[o + Math.min(w - 1, x + r + 1)] - src[o + Math.max(0, x - r)]; }
  }
  for (let x = 0; x < w; x++) {
    let acc = 0;
    for (let k = -r; k <= r; k++) acc += tmp[Math.min(h - 1, Math.max(0, k)) * w + x];
    for (let y = 0; y < h; y++) { out[y * w + x] = acc / d; acc += tmp[Math.min(h - 1, y + r + 1) * w + x] - tmp[Math.max(0, y - r) * w + x]; }
  }
  return out;
}

export function otsu(gray) {
  const hist = new Float64Array(256); for (let i = 0; i < gray.length; i++) hist[Math.min(255, Math.max(0, gray[i] | 0))]++;
  const total = gray.length; let sum = 0; for (let i = 0; i < 256; i++) sum += i * hist[i];
  let sB = 0, wB = 0, best = 0, thr = 127;
  for (let t = 0; t < 256; t++) {
    wB += hist[t]; if (!wB) continue; const wF = total - wB; if (!wF) break;
    sB += t * hist[t]; const mB = sB / wB, mF = (sum - sB) / wF; const v = wB * wF * (mB - mF) * (mB - mF);
    if (v > best) { best = v; thr = t; }
  }
  return thr;
}

function largestComponent(mask, w, h) {
  const lab = new Int32Array(w * h), stack = new Int32Array(w * h); let id = 0, bestId = 0, bestArea = 0;
  for (let s = 0; s < w * h; s++) {
    if (!mask[s] || lab[s]) continue; id++; let sp = 0, area = 0; stack[sp++] = s; lab[s] = id;
    while (sp) {
      const p = stack[--sp]; area++; const x = p % w;
      if (x > 0 && mask[p - 1] && !lab[p - 1]) { lab[p - 1] = id; stack[sp++] = p - 1; }
      if (x < w - 1 && mask[p + 1] && !lab[p + 1]) { lab[p + 1] = id; stack[sp++] = p + 1; }
      if (p >= w && mask[p - w] && !lab[p - w]) { lab[p - w] = id; stack[sp++] = p - w; }
      if (p < w * (h - 1) && mask[p + w] && !lab[p + w]) { lab[p + w] = id; stack[sp++] = p + w; }
    }
    if (area > bestArea) { bestArea = area; bestId = id; }
  }
  return { lab, id: bestId, area: bestArea };
}
const polyArea = q => { let a = 0; for (let i = 0; i < 4; i++) { const [x1, y1] = q[i], [x2, y2] = q[(i + 1) % 4]; a += x1 * y2 - x2 * y1; } return Math.abs(a) / 2; };

/** Find the paper in a (small) photo. Returns normalised corners TL,TR,BR,BL and whether it was really detected. */
export function findDocumentCorners(img) {
  const { width: w, height: h } = img; const N = w * h;
  const fallback = () => ({ found: false, corners: [[.06, .06], [.94, .06], [.94, .94], [.06, .94]] });
  const g = boxBlurPlane(lumaOf(img), w, h, 2); const t = otsu(g);
  let pick = null;
  for (const bright of [true, false]) {
    const m = new Uint8Array(N); for (let i = 0; i < N; i++) m[i] = (bright ? g[i] > t : g[i] <= t) ? 1 : 0;
    const c = largestComponent(m, w, h);
    if (c.area >= N * .15 && c.area <= N * .97) { pick = c; break; }
  }
  if (!pick) return fallback();
  let tl = [0, 0, 1e9], br = [0, 0, -1e9], tr = [0, 0, -1e9], bl = [0, 0, 1e9];
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    if (pick.lab[y * w + x] !== pick.id) continue;
    const s = x + y, d = x - y;
    if (s < tl[2]) tl = [x, y, s]; if (s > br[2]) br = [x, y, s];
    if (d > tr[2]) tr = [x, y, d]; if (d < bl[2]) bl = [x, y, d];
  }
  const q = [[tl[0], tl[1]], [tr[0], tr[1]], [br[0], br[1]], [bl[0], bl[1]]];
  const area = polyArea(q);
  if (area < pick.area * .55 || area < N * .12) return fallback();
  return { found: true, corners: q.map(([x, y]) => [x / w, y / h]) };
}

/* ---------- perspective ---------- */
function solve8(A, b) {
  const n = 8; for (let i = 0; i < n; i++) A[i].push(b[i]);
  for (let c = 0; c < n; c++) {
    let p = c; for (let r = c + 1; r < n; r++) if (Math.abs(A[r][c]) > Math.abs(A[p][c])) p = r;
    if (Math.abs(A[p][c]) < 1e-12) return null; [A[c], A[p]] = [A[p], A[c]];
    for (let r = 0; r < n; r++) { if (r === c) continue; const f = A[r][c] / A[c][c]; if (!f) continue; for (let k = c; k <= n; k++) A[r][k] -= f * A[c][k]; }
  }
  return A.map((row, i) => row[n] / row[i]);
}
/** Homography mapping destination rectangle (0,0)-(W,H) onto the source quad (TL,TR,BR,BL). */
export function homography(quad, W, H) {
  const dst = [[0, 0], [W, 0], [W, H], [0, H]], A = [], b = [];
  for (let i = 0; i < 4; i++) {
    const [X, Y] = dst[i], [x, y] = quad[i];
    A.push([X, Y, 1, 0, 0, 0, -x * X, -x * Y]); b.push(x);
    A.push([0, 0, 0, X, Y, 1, -y * X, -y * Y]); b.push(y);
  }
  return solve8(A, b);
}
export function quadSize(q, maxSide = 2000) {
  const d = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
  let w = Math.max(d(q[0], q[1]), d(q[3], q[2])), h = Math.max(d(q[0], q[3]), d(q[1], q[2]));
  const sc = Math.min(1, maxSide / Math.max(w, h, 1)); return { w: Math.max(8, Math.round(w * sc)), h: Math.max(8, Math.round(h * sc)) };
}
/** Straighten the quad (pixel coords in src) into a W×H image with bilinear sampling. */
export function warpPerspective(src, quad, W, H) {
  const Hm = homography(quad, W, H); const out = new Uint8ClampedArray(W * H * 4);
  if (!Hm) return { data: out, width: W, height: H };
  const [a, b, c, d, e, f, g, hh] = Hm; const { data, width: sw, height: sh } = src;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const den = g * x + hh * y + 1; let sx = (a * x + b * y + c) / den, sy = (d * x + e * y + f) / den;
    sx = sx < 0 ? 0 : sx > sw - 1 ? sw - 1 : sx; sy = sy < 0 ? 0 : sy > sh - 1 ? sh - 1 : sy;
    const x0 = sx | 0, y0 = sy | 0, x1 = Math.min(sw - 1, x0 + 1), y1 = Math.min(sh - 1, y0 + 1), fx = sx - x0, fy = sy - y0;
    const i00 = (y0 * sw + x0) * 4, i10 = (y0 * sw + x1) * 4, i01 = (y1 * sw + x0) * 4, i11 = (y1 * sw + x1) * 4, o = (y * W + x) * 4;
    for (let k = 0; k < 4; k++) out[o + k] = (data[i00 + k] * (1 - fx) + data[i10 + k] * fx) * (1 - fy) + (data[i01 + k] * (1 - fx) + data[i11 + k] * fx) * fy;
  }
  return { data: out, width: W, height: H };
}

/* ---------- tone / colour ---------- */
export function autoLevels(img, clip = .006) {
  const { data } = img, hist = new Uint32Array(256), n = data.length / 4;
  for (let i = 0; i < data.length; i += 4) hist[(.299 * data[i] + .587 * data[i + 1] + .114 * data[i + 2]) | 0]++;
  let lo = 0, hi = 255, acc = 0; for (; lo < 255; lo++) { acc += hist[lo]; if (acc > n * clip) break; }
  acc = 0; for (; hi > 0; hi--) { acc += hist[hi]; if (acc > n * clip) break; }
  if (hi - lo < 24) return img; const k = 255 / (hi - lo);
  for (let i = 0; i < data.length; i += 4) { data[i] = clamp8((data[i] - lo) * k); data[i + 1] = clamp8((data[i + 1] - lo) * k); data[i + 2] = clamp8((data[i + 2] - lo) * k); }
  return img;
}
export function saturate(img, s) {
  const { data } = img; for (let i = 0; i < data.length; i += 4) { const l = .299 * data[i] + .587 * data[i + 1] + .114 * data[i + 2]; data[i] = clamp8(l + (data[i] - l) * s); data[i + 1] = clamp8(l + (data[i + 1] - l) * s); data[i + 2] = clamp8(l + (data[i + 2] - l) * s); }
  return img;
}
export function brightnessContrast(img, b = 0, c = 0) { // b,c in -100..100
  const { data } = img, k = (100 + c) / 100, kk = k * k, off = b * 2.55;
  const lut = new Uint8ClampedArray(256); for (let v = 0; v < 256; v++) lut[v] = clamp8((v - 128) * kk + 128 + off);
  for (let i = 0; i < data.length; i += 4) { data[i] = lut[data[i]]; data[i + 1] = lut[data[i + 1]]; data[i + 2] = lut[data[i + 2]]; }
  return img;
}
export function grayscale(img) { const { data } = img; for (let i = 0; i < data.length; i += 4) { const l = (.299 * data[i] + .587 * data[i + 1] + .114 * data[i + 2]) | 0; data[i] = data[i + 1] = data[i + 2] = l; } return img; }
export function warmth(img, amt) { // -100 cool .. +100 warm
  const { data } = img, k = amt / 100 * 38; for (let i = 0; i < data.length; i += 4) { data[i] = clamp8(data[i] + k); data[i + 2] = clamp8(data[i + 2] - k); data[i + 1] = clamp8(data[i + 1] + k * .1); } return img;
}
export function vignette(img, amt) { // 0..100
  const { data, width: w, height: h } = img, cx = w / 2, cy = h / 2, md = Math.hypot(cx, cy), k = amt / 100;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const d = Math.hypot(x - cx, y - cy) / md, f = 1 - k * Math.pow(Math.max(0, d - .35) / .65, 1.6); const i = (y * w + x) * 4; data[i] *= f; data[i + 1] *= f; data[i + 2] *= f; }
  return img;
}

/** Unsharp mask — amount 0..2, radius in px. */
export function unsharp(img, amount = .8, radius = 1) {
  const { data, width: w, height: h } = img, n = w * h; const ch = new Float32Array(n);
  for (let c = 0; c < 3; c++) {
    for (let i = 0; i < n; i++) ch[i] = data[i * 4 + c];
    const bl = boxBlurPlane(ch, w, h, radius);
    for (let i = 0; i < n; i++) data[i * 4 + c] = clamp8(ch[i] + amount * (ch[i] - bl[i]));
  }
  return img;
}

/** Light edge-preserving denoise (3×3, weights fall off with colour distance). */
export function denoise(img, strength = 18) {
  const { data, width: w, height: h } = img, src = new Uint8ClampedArray(data), s2 = 2 * strength * strength;
  for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) {
    const i = (y * w + x) * 4; let r = 0, g = 0, b = 0, ws = 0; const r0 = src[i], g0 = src[i + 1], b0 = src[i + 2];
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
      const j = ((y + dy) * w + x + dx) * 4, dr = src[j] - r0, dg = src[j + 1] - g0, db = src[j + 2] - b0;
      const wt = Math.exp(-(dr * dr + dg * dg + db * db) / (3 * s2)); r += src[j] * wt; g += src[j + 1] * wt; b += src[j + 2] * wt; ws += wt;
    }
    data[i] = r / ws; data[i + 1] = g / ws; data[i + 2] = b / ws;
  }
  return img;
}

/* ---------- document looks ---------- */
// Smooth estimate of the paper brightness (text strokes removed by a max filter) — used to flatten shadows.
export function backgroundPlane(luma, w, h) {
  const s = Math.max(1, Math.round(Math.max(w, h) / 220)), sw = Math.ceil(w / s), sh = Math.ceil(h / s);
  let small = new Float32Array(sw * sh), cnt = new Uint16Array(sw * sh);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const k = ((y / s) | 0) * sw + ((x / s) | 0); small[k] += luma[y * w + x]; cnt[k]++; }
  for (let i = 0; i < small.length; i++) small[i] /= cnt[i] || 1;
  for (let pass = 0; pass < 2; pass++) { // dilate (3×3 max) to erase thin dark text
    const nx = new Float32Array(small.length);
    for (let y = 0; y < sh; y++) for (let x = 0; x < sw; x++) { let m = 0; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const xx = x + dx, yy = y + dy; if (xx >= 0 && yy >= 0 && xx < sw && yy < sh) { const v = small[yy * sw + xx]; if (v > m) m = v; } } nx[y * sw + x] = m; }
    small = nx;
  }
  small = boxBlurPlane(small, sw, sh, 3);
  const out = new Float32Array(w * h);
  for (let y = 0; y < h; y++) {
    const fy = Math.min(sh - 1, Math.max(0, (y + .5) / s - .5)), y0 = fy | 0, y1 = Math.min(sh - 1, y0 + 1), ty = fy - y0;
    for (let x = 0; x < w; x++) {
      const fx = Math.min(sw - 1, Math.max(0, (x + .5) / s - .5)), x0 = fx | 0, x1 = Math.min(sw - 1, x0 + 1), tx = fx - x0;
      out[y * w + x] = (small[y0 * sw + x0] * (1 - tx) + small[y0 * sw + x1] * tx) * (1 - ty) + (small[y1 * sw + x0] * (1 - tx) + small[y1 * sw + x1] * tx) * ty;
    }
  }
  return out;
}
/** Colour document: shadows flattened, paper turns white, ink stays vivid. */
export function magicColor(img, gamma = 1.35) {
  const { data, width: w, height: h } = img, B = backgroundPlane(lumaOf(img), w, h);
  const lut = new Uint8ClampedArray(256); for (let v = 0; v < 256; v++) lut[v] = clamp8(255 * Math.pow(v / 255, gamma));
  for (let i = 0, p = 0; p < w * h; p++, i += 4) {
    const k = 255 / Math.max(60, B[p]);
    data[i] = lut[clamp8(data[i] * k) | 0]; data[i + 1] = lut[clamp8(data[i + 1] * k) | 0]; data[i + 2] = lut[clamp8(data[i + 2] * k) | 0];
  }
  return saturate(img, 1.1);
}
/** Crisp black & white (soft threshold relative to local paper brightness). */
export function bwDocument(img, thr = .8, soft = .12) {
  const { data, width: w, height: h } = img, L = lumaOf(img), B = backgroundPlane(L, w, h);
  for (let p = 0, i = 0; p < w * h; p++, i += 4) {
    const v = L[p] / Math.max(60, B[p]); const t = clamp01((v - (thr - soft)) / (2 * soft)); const o = t * t * (3 - 2 * t) * 255;
    data[i] = data[i + 1] = data[i + 2] = o;
  }
  return img;
}

export function enhance(img, { sharp = .7, noise = true } = {}) {
  autoLevels(img, .004); saturate(img, 1.1); if (noise) denoise(img, 14); unsharp(img, sharp, 1); return img;
}

/* ---------- object eraser (inpainting) ---------- */
function dilateMask(mask, w, h, r) {
  let cur = mask;
  for (let pass = 0; pass < r; pass++) {
    const nx = new Uint8Array(cur);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const p = y * w + x; if (cur[p]) continue; if ((x > 0 && cur[p - 1]) || (x < w - 1 && cur[p + 1]) || (y > 0 && cur[p - w]) || (y < h - 1 && cur[p + w])) nx[p] = 1; }
    cur = nx;
  }
  return cur;
}
function gauss() { let u = 0, v = 0; while (!u) u = Math.random(); while (!v) v = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
/**
 * Fill the masked area from its surroundings: the hole is eaten from the outside in, layer by layer,
 * each new pixel being the distance-weighted mean of known neighbours; then matching grain is added so it does not look smeared.
 */
export function inpaint(img, mask0, { grow = 2, radius = 4, grain = true } = {}) {
  const { data, width: w, height: h } = img, N = w * h; const mask = dilateMask(mask0, w, h, grow);
  const known = new Uint8Array(N); let todo = 0; for (let i = 0; i < N; i++) { known[i] = mask[i] ? 0 : 1; if (mask[i]) todo++; }
  if (!todo) return img; if (todo === N) return img;
  // grain level from a ring around the hole
  let ring = [], sum = 0, sum2 = 0, rn = 0;
  const outer = dilateMask(mask, w, h, 8);
  for (let p = 0; p < N && rn < 20000; p += 3) if (outer[p] && !mask[p]) { const l = .299 * data[p * 4] + .587 * data[p * 4 + 1] + .114 * data[p * 4 + 2]; sum += l; sum2 += l * l; rn++; }
  let sd = 0; if (rn > 50) { const m = sum / rn; sd = Math.sqrt(Math.max(0, sum2 / rn - m * m)); } const noiseSd = Math.min(5, sd * .12);
  const R = radius; let guard = 0;
  while (todo > 0 && guard++ < 4000) {
    const layer = [];
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const p = y * w + x; if (known[p]) continue;
      if ((x > 0 && known[p - 1]) || (x < w - 1 && known[p + 1]) || (y > 0 && known[p - w]) || (y < h - 1 && known[p + w])) layer.push(p);
    }
    if (!layer.length) break;
    const vals = new Float32Array(layer.length * 3);
    for (let li = 0; li < layer.length; li++) {
      const p = layer[li], x = p % w, y = (p / w) | 0; let r = 0, g = 0, b = 0, ws = 0;
      for (let dy = -R; dy <= R; dy++) { const yy = y + dy; if (yy < 0 || yy >= h) continue; for (let dx = -R; dx <= R; dx++) { const xx = x + dx; if (xx < 0 || xx >= w) continue; const q = yy * w + xx; if (!known[q]) continue; const wt = 1 / (dx * dx + dy * dy + .5); r += data[q * 4] * wt; g += data[q * 4 + 1] * wt; b += data[q * 4 + 2] * wt; ws += wt; } }
      if (ws) { vals[li * 3] = r / ws; vals[li * 3 + 1] = g / ws; vals[li * 3 + 2] = b / ws; } else { vals[li * 3] = data[p * 4]; vals[li * 3 + 1] = data[p * 4 + 1]; vals[li * 3 + 2] = data[p * 4 + 2]; }
    }
    for (let li = 0; li < layer.length; li++) { const p = layer[li]; data[p * 4] = vals[li * 3]; data[p * 4 + 1] = vals[li * 3 + 1]; data[p * 4 + 2] = vals[li * 3 + 2]; data[p * 4 + 3] = 255; known[p] = 1; todo--; }
  }
  if (grain && noiseSd > .4) for (let p = 0; p < N; p++) if (mask[p]) { const n = gauss() * noiseSd; data[p * 4] = clamp8(data[p * 4] + n); data[p * 4 + 1] = clamp8(data[p * 4 + 1] + n); data[p * 4 + 2] = clamp8(data[p * 4 + 2] + n); }
  return img;
}

/* ---------- background removal ---------- */
function kmeans(samples, k, iters = 10) {
  const n = samples.length / 3; const cent = []; for (let i = 0; i < k; i++) { const s = Math.floor((i + .5) * n / k) * 3; cent.push([samples[s], samples[s + 1], samples[s + 2]]); }
  const cnt = new Array(k).fill(0);
  for (let it = 0; it < iters; it++) {
    const sum = cent.map(() => [0, 0, 0]); cnt.fill(0);
    for (let i = 0; i < n; i++) {
      let best = 0, bd = 1e12; for (let c = 0; c < k; c++) { const dr = samples[i * 3] - cent[c][0], dg = samples[i * 3 + 1] - cent[c][1], db = samples[i * 3 + 2] - cent[c][2], d = dr * dr + dg * dg + db * db; if (d < bd) { bd = d; best = c; } }
      sum[best][0] += samples[i * 3]; sum[best][1] += samples[i * 3 + 1]; sum[best][2] += samples[i * 3 + 2]; cnt[best]++;
    }
    for (let c = 0; c < k; c++) if (cnt[c]) cent[c] = [sum[c][0] / cnt[c], sum[c][1] / cnt[c], sum[c][2] / cnt[c]];
  }
  return cent.map((c, i) => ({ c, share: cnt[i] / n })).filter(x => x.share > .08);
}
/**
 * Remove a fairly uniform background: learn background colours from the picture border, flood from the border,
 * soften the cut edge. Returns a new RGBA image with transparency. (For busy backgrounds use the AI option.)
 */
export function removeBackground(img, { tol = 40, feather = 1 } = {}) {
  const { data, width: w, height: h } = img, N = w * h;
  const bw = Math.max(2, Math.round(Math.min(w, h) * .03)), samples = [];
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (x < bw || y < bw || x >= w - bw || y >= h - bw) { if (((x + y) & 3) === 0) { const i = (y * w + x) * 4; samples.push(data[i], data[i + 1], data[i + 2]); } }
  const bgs = kmeans(Float32Array.from(samples), 3).map(x => x.c); if (!bgs.length) return { data: new Uint8ClampedArray(data), width: w, height: h };
  const D = new Float32Array(N);
  for (let p = 0; p < N; p++) { let m = 1e9; for (const c of bgs) { const dr = data[p * 4] - c[0], dg = data[p * 4 + 1] - c[1], db = data[p * 4 + 2] - c[2]; const d = Math.sqrt(2 * dr * dr + 4 * dg * dg + 3 * db * db) / 3; if (d < m) m = d; } D[p] = m; }
  const cand = new Uint8Array(N); for (let p = 0; p < N; p++) cand[p] = D[p] < tol ? 1 : 0;
  const bg = new Uint8Array(N), stack = new Int32Array(N); let sp = 0;
  const seed = p => { if (cand[p] && !bg[p]) { bg[p] = 1; stack[sp++] = p; } };
  for (let x = 0; x < w; x++) { seed(x); seed((h - 1) * w + x); } for (let y = 0; y < h; y++) { seed(y * w); seed(y * w + w - 1); }
  while (sp) { const p = stack[--sp], x = p % w; if (x > 0) seed(p - 1); if (x < w - 1) seed(p + 1); if (p >= w) seed(p - w); if (p < w * (h - 1)) seed(p + w); }
  // alpha: 0 in background; fade over a 2px band using colour distance so halos disappear
  const near = dilateMask(bg, w, h, 2), alpha = new Float32Array(N);
  for (let p = 0; p < N; p++) alpha[p] = bg[p] ? 0 : (near[p] ? clamp01((D[p] - tol * .55) / (tol * .9)) : 1);
  const soft = feather > 0 ? boxBlurPlane(alpha, w, h, feather) : alpha;
  const out = new Uint8ClampedArray(data);
  for (let p = 0; p < N; p++) out[p * 4 + 3] = Math.round(soft[p] * 255);
  return { data: out, width: w, height: h };
}
/** Turn a flat chroma-key colour (what the AI paints behind the subject) into transparency. */
export function chromaKey(img, key = [0, 255, 0], tol = 70) {
  const { data, width: w, height: h } = img, out = new Uint8ClampedArray(data);
  for (let i = 0; i < data.length; i += 4) {
    const d = Math.hypot(data[i] - key[0], data[i + 1] - key[1], data[i + 2] - key[2]);
    const a = clamp01((d - tol * .6) / (tol * .8)); out[i + 3] = Math.round(a * 255);
    if (a < 1 && a > 0) { // reduce green spill on edges
      const g = Math.min(out[i + 1], Math.max(out[i], out[i + 2])); out[i + 1] = g;
    }
  }
  return { data: out, width: w, height: h };
}
