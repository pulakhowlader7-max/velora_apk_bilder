const { chromium } = require('playwright'); const fs = require('fs');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 420, height: 860 }, deviceScaleFactor: 2 });
  const errs = []; p.on('pageerror', e => errs.push('PAGEERR ' + e.message));
  await p.goto('http://localhost:8765/'); await p.waitForSelector('.create');
  // create CV from template via app API
  await p.evaluate(() => window.__ao.createNew('word', { tpl: 'cv' }));
  await p.waitForSelector('.wd-page'); await p.waitForTimeout(600);
  await p.screenshot({ path: '/tmp/word1.png' });
  // type text, bold via toolbar
  await p.click('.wd-page h1'); await p.keyboard.press('End'); await p.keyboard.type(' টেস্ট');
  await p.waitForTimeout(2200);
  const ids = await p.evaluate(async () => { const l = await window.__ao.db.list(); const m = l[0]; const buf = await window.__ao.db.buf(m.id); return { name: m.name, n: buf.byteLength, b64: btoa(String.fromCharCode(...new Uint8Array(buf))) }; });
  fs.writeFileSync('/tmp/cv.docx', Buffer.from(ids.b64, 'base64')); console.log(ids.name, ids.n);
  // PDF export
  const pdf = await p.evaluate(async () => { const { paginatedPdf } = await import('/js/pdfexport.js'); const { PRINT_CSS } = await import('/js/word.js'); const page = document.querySelector('.wd-page'); const bytes = await paginatedPdf(page, { css: PRINT_CSS, title: 't' }); let s=''; for(let i=0;i<bytes.length;i+=8192) s+=String.fromCharCode(...bytes.subarray(i,i+8192)); return btoa(s); });
  fs.writeFileSync('/tmp/mypdf.pdf', Buffer.from(pdf, 'base64')); console.log('pdf', pdf.length);
  console.log(errs.join('\n') || 'no errors'); await b.close();
})();
