const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 400, height: 820 } });
  const errs = []; p.on('pageerror', e => errs.push('PAGEERR ' + e.message)); p.on('console', m => { if (m.type() === 'error') errs.push('CONSOLE ' + m.text()); });
  await p.goto('http://localhost:8765/'); await p.waitForSelector('.create');
  await p.screenshot({ path: '/tmp/home.png' });
  // roundtrip test via modules
  const res = await p.evaluate(async () => {
    const { htmlToDocx, docxToHtml } = await import('/js/docx.js');
    const d = document.createElement('div');
    d.innerHTML = `<h1>শিরোনাম</h1><p style="text-align:center">হ্যালো <b>বোল্ড</b> <i>italic</i> <span style="color:#d92d20;font-size:24px">লাল</span> <a href="https://example.com">link</a></p><ul><li>এক<ul><li>নেস্টেড</li></ul></li><li>দুই</li></ul><ol><li>one</li><li>two</li></ol><table><tbody><tr><th>A</th><th>B</th></tr><tr><td colspan="2">span</td></tr></tbody></table><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==" width="50"><hr><div class="pagebreak"></div><p>শেষ</p>`;
    const buf = await htmlToDocx(d, { title: 'T', author: 'A' });
    const back = await docxToHtml(buf);
    window.__buf = buf;
    return { size: buf.byteLength, html: back.html };
  });
  console.log(res.size); console.log(res.html);
  console.log(errs.join('\n') || 'no errors');
  await b.close();
})();
