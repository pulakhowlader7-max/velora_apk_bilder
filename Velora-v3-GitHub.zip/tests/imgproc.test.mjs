import * as P from '../public/js/imgproc.js';
import assert from 'node:assert/strict';

const mk = (w, h, fn) => { const d = new Uint8ClampedArray(w * h * 4); for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const [r, g, b] = fn(x, y); const i = (y * w + x) * 4; d[i] = r; d[i + 1] = g; d[i + 2] = b; d[i + 3] = 255; } return { data: d, width: w, height: h }; };

// 1) paper detection: bright rotated-ish quad on dark table
{
  const W = 240, H = 180, quad = [[40, 30], [200, 45], [190, 150], [30, 135]];
  const inside = (x, y) => { // point-in-convex-quad
    let s = 0; for (let i = 0; i < 4; i++) { const [x1, y1] = quad[i], [x2, y2] = quad[(i + 1) % 4]; const c = (x2 - x1) * (y - y1) - (y2 - y1) * (x - x1); if (c !== 0) { if (!s) s = Math.sign(c); else if (s !== Math.sign(c)) return false; } } return true; };
  const img = mk(W, H, (x, y) => inside(x, y) ? [235, 232, 228] : [50, 45, 40]);
  const r = P.findDocumentCorners(img);
  assert.ok(r.found, 'document found');
  r.corners.forEach(([cx, cy], i) => { const dx = Math.abs(cx * W - quad[i][0]), dy = Math.abs(cy * H - quad[i][1]); assert.ok(dx < 5 && dy < 5, `corner ${i} off by ${dx.toFixed(1)},${dy.toFixed(1)}`); });
  console.log('corners ok');
  // 2) warp: straightened output should be (almost) all paper colour, no dark table
  const q = r.corners.map(([x, y]) => [x * W, y * H]); const { w, h } = P.quadSize(q);
  const out = P.warpPerspective(img, q, w, h); let dark = 0; for (let i = 0; i < out.data.length; i += 4) if (out.data[i] < 120) dark++;
  assert.ok(dark / (w * h) < .02, 'warp has no table: ' + dark / (w * h));
  console.log('warp ok', w, h);
}
// 3) no document → fallback
{ const r = P.findDocumentCorners(mk(100, 80, () => [120, 120, 120])); assert.equal(r.found, false); console.log('fallback ok'); }

// 4) magicColor flattens a shadow gradient and keeps dark text
{
  const W = 200, H = 120;
  const img = mk(W, H, (x, y) => { const sh = 255 - x * .5; const text = (y > 50 && y < 56 && x > 30 && x < 170); return text ? [20, 20, 20] : [sh, sh, sh * .98]; });
  const copy = new Uint8ClampedArray(img.data);
  P.magicColor(img);
  const left = img.data[(10 * W + 5) * 4], right = img.data[(10 * W + 195) * 4], text = img.data[(53 * W + 100) * 4];
  assert.ok(left > 235 && right > 235, `paper white both sides ${left} ${right}`);
  assert.ok(text < 90, 'text stays dark ' + text);
  assert.ok(copy[(10 * W + 195) * 4] < 170, 'input really had shadow');
  console.log('magic ok', left, right, text);
}
// 5) bwDocument → only 0/255-ish
{
  const W = 160, H = 100, img = mk(W, H, (x, y) => (y > 40 && y < 46 && x > 20 && x < 140) ? [40, 40, 40] : [200 - x * .3, 200 - x * .3, 200 - x * .3]);
  P.bwDocument(img); const bg = img.data[(10 * W + 100) * 4], tx = img.data[(43 * W + 80) * 4];
  assert.ok(bg > 245 && tx < 10, `bw bg=${bg} text=${tx}`); console.log('bw ok');
}
// 6) inpaint: remove a red square from a smooth gradient; result close to gradient
{
  const W = 120, H = 90, grad = (x, y) => [60 + x, 100 + y * .5, 140];
  const img = mk(W, H, (x, y) => (x > 50 && x < 70 && y > 30 && y < 50) ? [255, 0, 0] : grad(x, y));
  const mask = new Uint8Array(W * H); for (let y = 30; y < 51; y++) for (let x = 50; x < 71; x++) mask[y * W + x] = 1;
  P.inpaint(img, mask, { grain: false });
  let err = 0, n = 0; for (let y = 31; y < 49; y++) for (let x = 51; x < 69; x++) { const i = (y * W + x) * 4, g = grad(x, y); err += Math.abs(img.data[i] - g[0]) + Math.abs(img.data[i + 1] - g[1]) + Math.abs(img.data[i + 2] - g[2]); n += 3; }
  assert.ok(err / n < 8, 'inpaint mean error ' + (err / n).toFixed(2)); console.log('inpaint ok', (err / n).toFixed(2));
}
// 7) removeBackground: blue disc on white
{
  const W = 140, H = 140, img = mk(W, H, (x, y) => Math.hypot(x - 70, y - 70) < 40 ? [30, 60, 200] : [250, 250, 250]);
  const out = P.removeBackground(img, { tol: 40, feather: 1 });
  const corner = out.data[3], center = out.data[(70 * W + 70) * 4 + 3];
  assert.ok(corner === 0 && center === 255, `alpha corner=${corner} center=${center}`);
  // inner hole of a ring must survive (not connected to border)
  const ring = mk(W, H, (x, y) => { const d = Math.hypot(x - 70, y - 70); return d < 40 && d > 20 ? [30, 60, 200] : [250, 250, 250]; });
  const o2 = P.removeBackground(ring, { tol: 40, feather: 0 }); assert.equal(o2.data[(70 * W + 70) * 4 + 3], 255, 'inner hole kept'); console.log('bg remove ok');
}
// 8) chroma key
{ const img = mk(10, 10, (x) => x < 5 ? [0, 255, 0] : [200, 30, 30]); const o = P.chromaKey(img); assert.equal(o.data[3], 0); assert.equal(o.data[(0 * 10 + 8) * 4 + 3], 255); console.log('chroma ok'); }
// 9) perf sanity on a 12MP-ish scaled image
{
  const W = 1600, H = 1200, img = mk(W, H, (x, y) => [x % 255, y % 255, (x + y) % 255]); let t = Date.now();
  P.magicColor(img); const t1 = Date.now() - t; t = Date.now(); P.enhance(img); const t2 = Date.now() - t;
  console.log(`perf 1600x1200: magic ${t1}ms, enhance ${t2}ms`);
}
console.log('ALL OK');
