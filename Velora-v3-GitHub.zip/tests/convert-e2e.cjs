const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 400, height: 820 } }); const errs = [];
  p.on('pageerror', e => errs.push('PAGEERR ' + e.message)); p.on('console', m => { if (m.type() === 'error' && !/ERR_|net::|Failed to load/.test(m.text())) errs.push(m.text()); });
  await p.goto('http://localhost:8765/'); await p.waitForSelector('.quick');
  const r = await p.evaluate(async () => {
    const PL = await (await import('/js/util.js')).needPDFLib(); const pdf = await PL.PDFDocument.create(); const f = await pdf.embedFont(PL.StandardFonts.Helvetica), fb = await pdf.embedFont(PL.StandardFonts.HelveticaBold);
    const pg = pdf.addPage([595, 842]); pg.drawText('Quarterly Report', { x: 160, y: 780, size: 30, font: fb });
    const lines = ['This report summarises the results of the quarter and shows that', 'sales grew steadily across all regions during the period.']; lines.forEach((t, i) => pg.drawText(t, { x: 50, y: 730 - i * 16, size: 12, font: f }));
    pg.drawText('- first point', { x: 50, y: 680, size: 12, font: f }); pg.drawText('- second point', { x: 50, y: 664, size: 12, font: f });
    [['Region', 'Sales', 'Growth'], ['North', '120', '5%'], ['South', '98', '7%']].forEach((row, i) => row.forEach((c, j) => pg.drawText(c, { x: 50 + j * 180, y: 600 - i * 18, size: 12, font: f })));
    const buf = (await pdf.save()).buffer;
    const { pdfToHtml } = await import('/js/convert.js'); const out = await pdfToHtml(buf, { mode: 'text' });
    // docx -> pdf
    const { wordFileToPdf } = await import('/js/convert.js'); const w = await import('/js/word.js'); const d = await w.blank({}); const file = new File([d.buf], 'x.docx');
    const pd = await wordFileToPdf(file); return { html: out.html, pages: out.pages, pdfSize: pd.blob.size };
  });
  console.log(JSON.stringify(r).slice(0, 900)); console.log(errs.length ? errs.join('\n') : 'no errors'); await b.close();
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
