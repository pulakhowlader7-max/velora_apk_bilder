import * as C from '../public/js/convert.js';
import assert from 'node:assert/strict';
const W = 595, H = 842;
const it = (s, x, y, fs = 12, w) => ({ s, x, y, fs, w: w ?? s.length * fs * .5 });
const items = [
  it('Annual Report', 200, 780, 28), // centered heading
  it('This is the first line of a paragraph that goes', 50, 730), it('on to a second line of the same paragraph.', 50, 716),
  it('Next paragraph starts here and is separate.', 50, 690),
  it('• first bullet', 50, 660), it('• second bullet', 50, 646),
  it('Item', 50, 600), it('Qty', 250, 600), it('Price', 400, 600),
  it('Apple', 50, 585), it('3', 250, 585), it('10', 400, 585),
  it('Mango', 50, 570), it('5', 250, 570), it('20', 400, 570),
];
const lines = C.linesFromItems(items, H);
const blocks = C.blocksFromLines(lines, W);
const html = C.blocksToHtml(blocks);
console.log(html);
assert.match(html, /<h[12][^>]*>Annual Report/);
assert.match(html, /<p>This is the first line of a paragraph that goes on to a second line/);
assert.match(html, /<ul><li>first bullet<\/li><li>second bullet<\/li><\/ul>/);
assert.match(html, /<table>.*<th>Item<\/th><th>Qty<\/th><th>Price<\/th>.*<td>Mango<\/td><td>5<\/td><td>20<\/td>/);
assert.equal(C.looksBroken('Avwg evsjv wjwL Avwg ' + 'Ñ¡¢£¤¥¦§¨©ª«¬®¯°±²³'.repeat(3)), true);
assert.equal(C.looksBroken('আমি বাংলায় লিখি, এটি একটি পরীক্ষা বাক্য'), false);
// two columns
const col = []; for (let i = 0; i < 25; i++) { col.push(it('left col text line ' + i, 50, 800 - i * 14, 11, 200)); col.push(it('right col text line ' + i, 320, 800 - i * 14, 11, 200)); }
const cs = C.splitColumns(col, W); assert.equal(cs.length, 2); assert.ok(cs[0].every(i => i.x < 100));
console.log('CONVERT OK');
