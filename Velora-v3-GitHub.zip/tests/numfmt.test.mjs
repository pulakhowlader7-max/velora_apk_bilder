import { formatValue as f, dateToSerial } from '../public/js/numfmt.js';
const T = (v, fmt, exp) => { const r = f(v, fmt).text; console.log(r === exp ? 'ok  ' : 'FAIL', JSON.stringify(fmt), v, '=>', JSON.stringify(r), r === exp ? '' : 'expected ' + JSON.stringify(exp)); };
T(1234.5, 'General', '1234.5'); T(0.1 + 0.2, 'General', '0.3'); T(1234.5, '0.00', '1234.50'); T(1234567.891, '#,##0.00', '1,234,567.89'); T(1234567, '#,##0', '1,234,567');
T(0.256, '0%', '26%'); T(0.2567, '0.00%', '25.67%'); T(-5, '0', '-5'); T(5, '"৳"#,##0.00', '৳5.00'); T(1234, '#,##0;(#,##0)', '1,234'); T(-1234, '#,##0;(#,##0)', '(1,234)');
T(-1234, '#,##0;[Red]-#,##0', '-1,234'); T(0, '0.00', '0.00'); T(0.5, '#.##', '.5'); T(12, '000', '012'); T(1500, '#,##0,"K"', '2K'); T(1234.5678, '0.0', '1234.6');
const d = dateToSerial(2026, 11, 21); T(d, 'dd/mm/yyyy', '21/11/2026'); T(d, 'd mmmm yyyy', '21 November 2026'); T(d, 'ddd, dd-mmm-yy', 'Sat, 21-Nov-26'); T(d + 0.75, 'dd/mm/yyyy h:mm', '21/11/2026 18:00'); T(d + 0.75, 'h:mm AM/PM', '6:00 PM'); T(0.5, 'hh:mm:ss', '12:00:00');
T(1234.5, '0.00E+00', '1.23E+03'); T('abc', '@', 'abc'); T('abc', '"x"@', 'xabc'); T(true, '0', 'TRUE'); T(1e12, 'General', '1E+12'); T(0.000001234, 'General', '1.234E-06'); T(100, 'General', '100'); T(1/3, 'General', '0.3333333333');
console.log(dateToSerial(1900,3,1), dateToSerial(2000,1,1));
