const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 400, height: 820 }, permissions: ['camera'] });
  const p = await ctx.newPage(); const errs = [];
  p.on('pageerror', e => errs.push('PAGEERR ' + e.message)); p.on('console', m => { if (m.type() === 'error' && !/ERR_|Failed to load resource|net::/.test(m.text())) errs.push('CONSOLE ' + m.text()); });
  await p.goto('http://localhost:8765/'); await p.waitForSelector('.quick');
  await p.screenshot({ path: '/tmp/s1_home.png' });
  // tools tab
  await p.click('.bottomnav button:nth-child(4)'); await p.waitForSelector('.toolgrid'); const nTools = await p.locator('.tool').count();
  await p.screenshot({ path: '/tmp/s2_tools.png' });
  // search tool
  await p.click('.bottomnav button:nth-child(1)'); await p.fill('.search input', 'pdf'); await p.waitForTimeout(500);
  const found = await p.locator('#hres .tool').count(); await p.screenshot({ path: '/tmp/s3_search.png' }); await p.fill('.search input', '');
  // settings AI card
  await p.click('.bottomnav button:nth-child(5)'); await p.waitForSelector('.card'); await p.waitForTimeout(300); await p.screenshot({ path: '/tmp/s4_settings.png' });
  await p.click('.bottomnav button:nth-child(1)');
  // scanner opens (fake camera is unavailable -> must degrade gracefully)
  await p.click('.navscan'); await p.waitForSelector('.scanner'); await p.waitForTimeout(600); await p.screenshot({ path: '/tmp/s5_scanner.png' });
  // feed a synthetic paper photo through the scanner via gallery path
  const res = await p.evaluate(async () => {
    const c = document.createElement('canvas'); c.width = 900; c.height = 700; const g = c.getContext('2d'); g.fillStyle = '#3a3330'; g.fillRect(0, 0, 900, 700);
    g.save(); g.translate(450, 350); g.rotate(.08); g.fillStyle = '#efece6'; g.fillRect(-300, -250, 600, 500); g.fillStyle = '#222'; g.font = '28px sans-serif'; for (let i = 0; i < 8; i++) g.fillText('Velora scan test line ' + i, -250, -180 + i * 50); g.restore();
    const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', .9)); window.__testBlob = blob; return blob.size;
  });
  await p.keyboard.press('Escape');
  // photo editor directly
  const ok = await p.evaluate(async () => { const { openPhotoEditor } = await import('/js/photo.js'); await openPhotoEditor(new File([window.__testBlob], 't.jpg', { type: 'image/jpeg' })); return !!document.querySelector('.photo canvas'); });
  await p.waitForTimeout(500); await p.screenshot({ path: '/tmp/s6_photo.png' });
  for (const tab of ['crop', 'filter', 'text', 'erase', 'bg', 'enhance', 'ai']) { const i = ['crop', 'adjust', 'filter', 'text', 'draw', 'erase', 'bg', 'enhance', 'ai'].indexOf(tab); await p.click(`.ph-tab:nth-child(${i + 1})`); await p.waitForTimeout(250); }
  await p.click('.ph-tab:nth-child(7)'); await p.waitForTimeout(200);
  await p.screenshot({ path: '/tmp/s7_photo_bg.png' });
  // run local bg removal + enhance
  await p.click('.ph-act:nth-child(1)'); await p.waitForTimeout(1500);
  await p.click('.ph-tab:nth-child(8)'); await p.click('.ph-act:nth-child(1)'); await p.waitForTimeout(2500);
  await p.screenshot({ path: '/tmp/s8_photo_enh.png' });
  console.log(JSON.stringify({ nTools, found, ok }));
  console.log(errs.length ? errs.join('\n') : 'no errors');
  await b.close();
})().catch(e => { console.error('FAIL', e.message); process.exit(1); });
