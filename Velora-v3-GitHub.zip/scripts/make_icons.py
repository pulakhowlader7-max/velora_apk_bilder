from PIL import Image, ImageDraw
S=1024
def lerp(a,b,t): return tuple(int(a[i]+(b[i]-a[i])*t) for i in range(3))
def base(maskable=False):
    im=Image.new("RGB",(S,S))
    px=im.load()
    c1=(30,52,140); c2=(64,112,255)
    for y in range(S):
        for x in range(S):
            t=(x*0.35+y*0.65)/S
            px[x,y]=lerp(c1,c2,t)
    im=im.convert("RGBA")
    d=ImageDraw.Draw(im)
    k=0.62 if maskable else 1.0
    cx=cy=S/2
    def R(x0,y0,x1,y1):
        return (cx+(x0-cx)*k, cy+(y0-cy)*k, cx+(x1-cx)*k, cy+(y1-cy)*k)
    # back tiles (excel green, ppt orange)
    d.rounded_rectangle(R(520,250,800,720),radius=int(34*k),fill=(46,170,101,255))
    d.rounded_rectangle(R(590,300,860,770),radius=int(34*k),fill=(255,116,64,255))
    # main page
    d.rounded_rectangle(R(240,180,700,860),radius=int(46*k),fill=(255,255,255,255))
    # folded corner
    d.polygon([(cx+(x-cx)*k,cy+(y-cy)*k) for x,y in [(580,180),(700,300),(580,300)]],fill=(206,220,255,255))
    # text lines
    for i,(w) in enumerate([300,360,330,250,340]):
        y=380+i*84
        d.rounded_rectangle(R(310,y,310+w,y+34),radius=int(17*k),fill=(54,96,226,255) if i==0 else (176,192,230,255))
    return im
for name,m,size in [("icon-512.png",False,512),("icon-192.png",False,192),("maskable-512.png",True,512),("apple-touch-icon.png",False,180),("favicon-32.png",False,32)]:
    im=base(m)
    if not m and name!="apple-touch-icon.png":
        # rounded corners for plain icons
        mask=Image.new("L",(S,S),0); ImageDraw.Draw(mask).rounded_rectangle((0,0,S,S),radius=220,fill=255)
        bg=Image.new("RGBA",(S,S),(0,0,0,0)); bg.paste(im,(0,0),mask); im=bg
    im=im.resize((size,size),Image.LANCZOS)
    im.save("public/icons/"+name)
base(False).convert("RGB").save("scripts/icon-1024.png")
print("ok")
