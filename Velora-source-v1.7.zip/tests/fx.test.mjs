import * as F from '../public/js/fx.js';
import * as P from '../public/js/imgproc.js';
const rng = s => { let x = s >>> 0; return () => (x = (x * 1664525 + 1013904223) >>> 0) / 4294967296; };
const mk = (w, h, fn) => { const d = new Uint8ClampedArray(w * h * 4); for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const [r, g, b] = fn(x, y); const i = (y * w + x) * 4; d[i] = r; d[i + 1] = g; d[i + 2] = b; d[i + 3] = 255; } return { data: d, width: w, height: h }; };
const clone = F.cloneImg, mean = (img, ch = -1) => { let s = 0, n = 0; for (let i = 0; i < img.data.length; i += 4) { s += ch < 0 ? (img.data[i] + img.data[i + 1] + img.data[i + 2]) / 3 : img.data[ch + i]; n++; } return s / n; };
const std = img => { const m = mean(img); let s = 0, n = 0; for (let i = 0; i < img.data.length; i += 4) { const v = (img.data[i] + img.data[i + 1] + img.data[i + 2]) / 3; s += (v - m) ** 2; n++; } return Math.sqrt(s / n); };
const med = img => { const a = []; for (let i = 0; i < img.data.length; i += 16) a.push((img.data[i] * .299 + img.data[i + 1] * .587 + img.data[i + 2] * .114)); a.sort((x, y) => x - y); return a[a.length >> 1]; };
const W = 800, H = 600;
// ---- 1. dark, flat photo
const rand = rng(5), dark = mk(W, H, (x, y) => { const v = 35 + 60 * (x / W) + 25 * Math.sin(y / 40); return [v * 1.1 + rand() * 6, v + rand() * 6, v * .9 + rand() * 6]; });
const ap = F.autoParams(dark); console.log('auto on dark photo → kind', ap.kind, JSON.stringify(ap.params));
const fixed = clone(dark); F.applyFx(fixed, ap.params); console.log(`median ${med(dark).toFixed(0)} → ${med(fixed).toFixed(0)} (target≈120) · contrast(std) ${std(dark).toFixed(1)} → ${std(fixed).toFixed(1)}`);
// ---- 2. shadows / highlights are tonal-selective
const grad = mk(W, H, x => { const v = 255 * x / W; return [v, v, v]; });
const sl = clone(grad); F.applyFx(sl, { shadows: 70 }); const left = img => { let s = 0, n = 0; for (let y = 0; y < H; y += 10) for (let x = 0; x < W * .15; x += 5) { s += img.data[(y * W + x) * 4]; n++; } return s / n; }, right = img => { let s = 0, n = 0; for (let y = 0; y < H; y += 10) for (let x = W * .85; x < W; x += 5) { s += img.data[(y * W + x | 0) * 4]; n++; } return s / n; };
console.log(`shadows +70: dark area ${left(grad).toFixed(0)} → ${left(sl).toFixed(0)} (should rise), bright area ${right(grad).toFixed(0)} → ${right(sl).toFixed(0)} (should stay)`);
const hl = clone(grad); F.applyFx(hl, { highlights: -70 }); console.log(`highlights -70: bright area ${right(grad).toFixed(0)} → ${right(hl).toFixed(0)} (should fall), dark area ${left(grad).toFixed(0)} → ${left(hl).toFixed(0)} (should stay)`);
// ---- 3. colour
const col = mk(W, H, () => [160, 120, 90]); const chroma = i => { let s = 0, n = 0; for (let k = 0; k < i.data.length; k += 4) { s += Math.max(i.data[k], i.data[k + 1], i.data[k + 2]) - Math.min(i.data[k], i.data[k + 1], i.data[k + 2]); n++; } return s / n; };
const s1 = clone(col); F.applyFx(s1, { saturation: 50 }); const t1 = clone(col); F.applyFx(t1, { temp: 40 }); const t2 = clone(col); F.applyFx(t2, { temp: -40 });
console.log(`saturation +50: chroma ${chroma(col).toFixed(0)} → ${chroma(s1).toFixed(0)} · temp +40: R-B ${(mean(col, 0) - mean(col, 2)).toFixed(0)} → ${(mean(t1, 0) - mean(t1, 2)).toFixed(0)} · temp -40: → ${(mean(t2, 0) - mean(t2, 2)).toFixed(0)}`);
// ---- 4. denoise + detail
const clean = mk(W, H, (x, y) => { const v = ((x >> 5) + (y >> 5)) % 2 ? 190 : 70; return [v, v * .95, v * .9]; }); const r2 = rng(9), noisy = clone(clean); for (let i = 0; i < noisy.data.length; i += 4) { const n = (r2() + r2() + r2() - 1.5) * 50; for (let c = 0; c < 3; c++) noisy.data[i + c] = Math.max(0, Math.min(255, noisy.data[i + c] + n)); }
const mse = (a, b) => { let s = 0, n = 0; for (let i = 0; i < a.data.length; i += 4) for (let c = 0; c < 3; c++) { s += (a.data[i + c] - b.data[i + c]) ** 2; n++; } return s / n; };
const dn = clone(noisy); F.applyFx(dn, { denoise: 70 }); console.log(`denoise 70: PSNR ${(10 * Math.log10(65025 / mse(noisy, clean))).toFixed(1)} → ${(10 * Math.log10(65025 / mse(dn, clean))).toFixed(1)} dB`);
const soft = clone(clean); const blurred = P.denoise ? (() => { const b = clone(clean); const L = [...Array(3).keys()]; for (const c of L) { const pl = new Float32Array(W * H); for (let i = 0; i < W * H; i++) pl[i] = b.data[i * 4 + c]; const bl = P.boxBlurPlane(pl, W, H, 2); for (let i = 0; i < W * H; i++) b.data[i * 4 + c] = bl[i]; } return b; })() : soft;
const edge = img => { let s = 0, n = 0; for (let y = 1; y < H - 1; y += 3) for (let x = 1; x < W - 1; x += 3) { s += Math.abs(img.data[(y * W + x) * 4] - img.data[(y * W + x - 1) * 4]); n++; } return s / n; };
const sh2 = clone(blurred); F.applyFx(sh2, { sharpen: 60 }); const cl2 = clone(blurred); F.applyFx(cl2, { clarity: 60 }); console.log(`edge energy blurred ${edge(blurred).toFixed(2)} → sharpen ${edge(sh2).toFixed(2)} · clarity ${edge(cl2).toFixed(2)} (original sharp ${edge(clean).toFixed(2)})`);
// ---- 5. every preset: valid, timed
let worst = 0; for (const pr of F.PRESETS) { const t = performance.now(), im = clone(col); F.applyFx(im, pr.p); const ms = performance.now() - t; worst = Math.max(worst, ms); if (!im.data.every(v => v >= 0 && v <= 255)) console.log('BAD', pr.id); }
console.log(`presets ok (${F.PRESETS.length}); slowest at ${W}×${H}: ${worst.toFixed(0)}ms`);
const big = mk(3000, 2000, (x, y) => [x % 255, y % 255, (x + y) % 255]); let t = performance.now(); F.applyFx(big, { exposure: 20, shadows: 30, saturation: 20, clarity: 30, sharpen: 30, denoise: 30 }); console.log(`6 MP full pipeline: ${(performance.now() - t).toFixed(0)}ms`);
// ---- 6. document: strong shadow gradient + ink
const rd = rng(11), inkMask = []; const doc = mk(900, 640, (x, y) => { const ink = ((y % 44) > 14 && (y % 44) < 30) && ((x % 90) < 60) && x > 60 && x < 840 && y > 60 && y < 580; inkMask.push(ink); const shade = .22 + .78 * (x / 900) * (1 - .25 * (y / 640)); const base = ink ? 75 : 235; const v = base * shade + (rd() - .5) * 14; return [v * 1.02, v, v * .86]; });
const score = img => { let inkB = 0, inkN = 0, paperW = 0, paperN = 0; for (let p = 0; p < inkMask.length; p++) { const v = img.data[p * 4]; if (inkMask[p]) { inkN++; if (v < 110) inkB++; } else { paperN++; if (v > 200) paperW++; } } return `ink→dark ${(100 * inkB / inkN).toFixed(1)}% · paper→white ${(100 * paperW / paperN).toFixed(1)}%`; };
console.log('document, uneven light — original   :', score(doc));
const g1 = clone(doc); P.grayscale(g1); const th = P.otsu(P.lumaOf(g1)); for (let i = 0; i < g1.data.length; i += 4) { const v = g1.data[i] > th ? 255 : 0; g1.data[i] = g1.data[i + 1] = g1.data[i + 2] = v; } console.log('document — global Otsu threshold     :', score(g1));
for (const m of ['bw', 'text', 'color', 'gray', 'auto']) { const im = clone(doc); t = performance.now(); const used = F.docClean(im, { mode: m }); console.log(`document — docClean ${m.padEnd(5)}→${used.padEnd(5)} (${(performance.now() - t).toFixed(0)}ms):`, score(im)); }
