import * as P from '../public/js/imgproc.js';
// ---- synthetic "page": white paper, rows of dark word-blobs (deterministic) ----
function rng(seed){ let s=seed>>>0; return ()=> (s = (s*1664525+1013904223)>>>0)/4294967296; }
function page(w,h,tilt=0){
  const data=new Uint8ClampedArray(w*h*4).fill(255); const rand=rng(7);
  const a=tilt*Math.PI/180, cs=Math.cos(a), sn=Math.sin(a), cx=w/2, cy=h/2;
  const set=(x,y,v)=>{ x|=0;y|=0; if(x<0||y<0||x>=w||y>=h)return; const i=(y*w+x)*4; data[i]=data[i+1]=data[i+2]=v; };
  for(let row=0; row<14; row++){
    let x=40; const y0=50+row*28;
    while(x<w-80){ const len=18+rand()*50|0;
      for(let dx=0; dx<len; dx++) for(let dy=0; dy<12; dy++){
        const px=x+dx-cx, py=y0+dy-cy; // rotate clockwise (y-down) by tilt
        set(cx+px*cs-py*sn, cy+px*sn+py*cs, 25);
        set(cx+px*cs-py*sn+1, cy+px*sn+py*cs, 25); }
      x+=len+10+rand()*10; }
  }
  return {data,width:w,height:h};
}
const gauss=r=>{let u=0,v=0;while(!u)u=r();while(!v)v=r();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);};
function addNoise(img,sigma,chroma=true){ const r=rng(99), d=img.data; for(let i=0;i<d.length;i+=4){ const l=gauss(r)*sigma; for(let c=0;c<3;c++) d[i+c]=Math.max(0,Math.min(255,d[i+c]+l+(chroma?gauss(r)*sigma*.8:0))); } return img; }
const clone=i=>({data:new Uint8ClampedArray(i.data),width:i.width,height:i.height});
const mse=(a,b)=>{let s=0,n=0;for(let i=0;i<a.data.length;i+=4){for(let c=0;c<3;c++){const d=a.data[i+c]-b.data[i+c];s+=d*d;n++;}}return s/n;};
const psnr=m=>10*Math.log10(255*255/m);

const W=640,H=480; const clean=page(W,H); const noisy=addNoise(clone(clean),28);
console.log('noisy   PSNR vs clean: ', psnr(mse(noisy,clean)).toFixed(2),'dB');
for (const lv of [30,60,90]) {
  const t0=performance.now(); const out=P.removeNoise(clone(noisy),lv); const ms=performance.now()-t0;
  console.log(`removeNoise(${lv}) PSNR:`, psnr(mse(out,clean)).toFixed(2),'dB', ms.toFixed(0)+'ms');
}
// text must stay dark: mean luma of ink pixels (clean=25) after denoise
{ const out=P.removeNoise(clone(noisy),60); let s=0,c=0; for(let i=0;i<out.data.length;i+=4){ if(clean.data[i]<100){ s+=out.data[i]; c++; } } console.log('ink mean after denoise (want <70):',(s/c).toFixed(1)); }
// textBoost on a dim, shadowed, blurry version
{ const dim=clone(clean); for(let y=0;y<H;y++)for(let x=0;x<W;x++){const i=(y*W+x)*4;const f=.55+.35*x/W; for(let c=0;c<3;c++) dim.data[i+c]=dim.data[i+c]*f*0.9+30;}
  const out=P.textBoost(clone(dim),{strength:.7}); const stat=(img,pred)=>{let s=0,c=0;for(let i=0;i<img.data.length;i+=4){if(pred(i)){s+=img.data[i];c++;}}return s/c;};
  console.log('paper before/after:',stat(dim,i=>clean.data[i]>200).toFixed(0),'→',stat(out,i=>clean.data[i]>200).toFixed(0),' ink before/after:',stat(dim,i=>clean.data[i]<100).toFixed(0),'→',stat(out,i=>clean.data[i]<100).toFixed(0)); }
// deskew
for (const t of [0,-4,2.5,7]) { const im=page(W,H,t); console.log('deskew true tilt',t,'→ detected',P.deskewAngle(im)); }
console.log('blank page deskew:',P.deskewAngle({data:new Uint8ClampedArray(W*H*4).fill(255),width:W,height:H}));
// ---- noise estimation ----
for (const sg of [0, 6, 12, 25]) { const im = sg ? addNoise(clone(clean), sg, false) : clone(clean); console.log('true σ', sg, '→ estimated', P.estimateNoise(im).toFixed(1)); }
