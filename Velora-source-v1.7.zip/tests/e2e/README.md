# E2E tests (Playwright + headless Chromium)
Not part of the app — dev only. They need: Node 20+, `playwright` with Chromium, Python 3 (for the static server), LibreOffice (`soffice`) and
`openpyxl`/`pdftotext` for the file-compatibility checks. Edit the `/opt/npm-tools/...` import path at the top of each script to your Playwright install.
`with-server.sh <script>.mjs` serves `public/` on :8080 while the script runs. Big-file tests expect generated fixtures (see comments in the scripts).
