import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
import fs from 'fs';
const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 390, height: 800 }, deviceScaleFactor: 2, hasTouch: true }); const p = await ctx.newPage(); const errs = [];
p.on('pageerror', e => errs.push('PAGEERR ' + e.message.slice(0, 160))); p.on('console', m => { if (m.type() === 'error') errs.push(m.text().slice(0, 160)); });
await p.goto('http://localhost:8080/'); await p.waitForTimeout(1200);
// a realistic dull, dark, slightly blue, noisy indoor photo
await p.evaluate(async () => { const c = document.createElement('canvas'); c.width = 1400; c.height = 933; const g = c.getContext('2d'); const sky = g.createLinearGradient(0, 0, 0, 933); sky.addColorStop(0, '#5a6a80'); sky.addColorStop(.55, '#3d4a58'); sky.addColorStop(1, '#2a2f2c'); g.fillStyle = sky; g.fillRect(0, 0, 1400, 933);
  g.fillStyle = '#6b7f5a'; g.beginPath(); g.moveTo(0, 650); g.quadraticCurveTo(350, 520, 700, 640); g.quadraticCurveTo(1050, 740, 1400, 600); g.lineTo(1400, 933); g.lineTo(0, 933); g.fill(); g.fillStyle = '#a86b4a'; g.fillRect(560, 420, 280, 230); g.fillStyle = '#d8c9a0'; g.beginPath(); g.moveTo(520, 430); g.lineTo(700, 300); g.lineTo(880, 430); g.fill(); g.fillStyle = '#e8d890'; g.fillRect(640, 500, 70, 90);
  const id = g.getImageData(0, 0, 1400, 933), d = id.data; let s = 4; const r = () => (s = (s * 1664525 + 1013904223) >>> 0) / 4294967296; for (let i = 0; i < d.length; i += 4) { const n = (r() + r() - 1) * 26; d[i] = d[i] * .72 + n; d[i + 1] = d[i + 1] * .74 + n; d[i + 2] = d[i + 2] * .85 + n; } g.putImageData(id, 0, 0);
  const blob = await new Promise(rs => c.toBlob(rs, 'image/jpeg', .92)); await window.__ao.importFiles([new File([blob], 'dull.jpg', { type: 'image/jpeg' })], { open: true }); });
await p.waitForTimeout(1500); await p.locator('.fab.imgedit').click(); await p.waitForSelector('.ph-stage canvas'); await p.waitForTimeout(700);
const shot = async n => { await p.waitForTimeout(500); await p.screenshot({ path: n }); };
await shot('fx_0_before.png');
await p.locator('.ed.photo .ph-gc .chip', { hasText: 'অটো' }).click(); await p.waitForTimeout(200); await p.locator('.ed.photo .ph-auto .btn.primary').click(); await shot('fx_1_auto.png');
console.log('slider values after auto:', JSON.stringify(await p.evaluate(() => [...document.querySelectorAll('.ph-sl')].map(x => x.innerText.replace(/\n/g, ' ')))));
await p.locator('.ed.photo .ph-gc .chip', { hasText: 'লুক' }).click(); await p.waitForTimeout(500); await p.locator('.ed.photo .ph-f', { hasText: 'সিনেমা' }).click(); await shot('fx_2_cine.png');
await p.locator('.ed.photo .ph-ok .btn.primary').click(); await p.waitForTimeout(2500);
console.log('after apply: undo enabled:', !(await p.locator('.ed-top button[aria-label="আনডু"]').isDisabled()));
console.log('errors:', errs); await b.close();
