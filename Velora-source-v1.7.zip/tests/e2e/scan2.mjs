import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
import fs from 'fs';
const b0 = await chromium.launch(); const pg0 = await (await b0.newContext()).newPage(); await pg0.goto('about:blank');
const dataUrl = await pg0.evaluate(() => { const c = document.createElement('canvas'); c.width = 1600; c.height = 1200; const g = c.getContext('2d'); g.fillStyle = '#4b3b2e'; g.fillRect(0, 0, 1600, 1200);
  g.save(); g.translate(800, 600); g.rotate(-2 * Math.PI / 180); const gr = g.createLinearGradient(-560, 0, 560, 0); gr.addColorStop(0, '#6b6355'); gr.addColorStop(.5, '#cbc3ae'); gr.addColorStop(1, '#f1ead2'); g.fillStyle = gr; g.fillRect(-560, -430, 1120, 860);
  g.fillStyle = '#242424'; g.font = '34px sans-serif'; for (let i = 0; i < 16; i++) g.fillText('Velora scanner test line ' + (i + 1) + ' — আমার সোনার বাংলা আমি তোমায় ভালবাসি', -500, -360 + i * 46); g.restore();
  const id = g.getImageData(0, 0, 1600, 1200), d = id.data; let s = 8; const r = () => (s = (s * 1664525 + 1013904223) >>> 0) / 4294967296; for (let i = 0; i < d.length; i += 4) { const n = (r() + r() - 1) * 30; d[i] += n; d[i + 1] += n; d[i + 2] += n; } g.putImageData(id, 0, 0); return c.toDataURL('image/jpeg', .9); });
fs.writeFileSync('scan_doc.jpg', Buffer.from(dataUrl.split(',')[1], 'base64')); await b0.close();
const b = await chromium.launch({ args: ['--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream'] }); const ctx = await b.newContext({ viewport: { width: 390, height: 800 }, deviceScaleFactor: 2, hasTouch: true, permissions: ['camera'] }); const p = await ctx.newPage(); const errs = [];
p.on('pageerror', e => errs.push('PAGEERR ' + e.message.slice(0, 200))); p.on('console', m => { if (m.type() === 'error') errs.push(m.text().slice(0, 200)); });
await p.goto('http://localhost:8080/'); await p.waitForTimeout(1300);
await p.locator('.quick > *', { hasText: 'স্ক্যান' }).first().tap(); await p.waitForTimeout(1800);
const [fc] = await Promise.all([p.waitForEvent('filechooser', { timeout: 5000 }).catch(() => null), p.locator('.livecam button, .scanner button, .ed button', { hasText: /গ্যালারি/ }).first().tap().catch(() => null)]);
console.log('gallery chooser:', !!fc); if (fc) await fc.setFiles('scan_doc.jpg'); await p.waitForSelector('.sc-prev canvas', { timeout: 20000 }); await p.waitForTimeout(800);
const ink = async () => p.evaluate(() => { const c = document.querySelector('.sc-prev canvas'), d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data; let paperWhite = 0, dark = 0, n = 0, tot = 0; for (let i = 0; i < d.length; i += 40) { const v = (d[i] + d[i + 1] + d[i + 2]) / 3; n++; tot += v; if (v > 215) paperWhite++; else if (v < 90) dark++; } return { size: c.width + '×' + c.height, white: Math.round(100 * paperWhite / n) + '%', ink: (100 * dark / n).toFixed(1) + '%', mean: Math.round(tot / n) }; });
console.log('auto   :', JSON.stringify(await ink()), '| chip label:', await p.locator('.sc-chips .chip.on').innerText());
await p.screenshot({ path: 'sc_auto.png' });
for (const m of ['রঙিন', 'লেখা স্পষ্ট', 'গ্রে', 'সাদা-কালো', 'আসল']) { await p.locator('.sc-chips .chip', { hasText: new RegExp('^' + m) }).first().tap(); await p.waitForTimeout(1800); console.log(m.padEnd(10), JSON.stringify(await ink())); if (m === 'সাদা-কালো') await p.screenshot({ path: 'sc_bw.png' }); }
// fine controls
await p.locator('.sc-chips .chip', { hasText: /^অটো/ }).first().tap(); await p.waitForTimeout(1500);
await p.locator('.sc-fine-t').tap(); await p.waitForTimeout(300); const before = await ink();
await p.locator('.sc-fine input').nth(2).evaluate(e => { e.value = 40; e.dispatchEvent(new Event('input', { bubbles: true })); }); await p.waitForTimeout(400); const after = await ink(); console.log('brightness +40 live preview:', before.mean, '→', after.mean, after.size);
await p.waitForTimeout(1600); console.log('after idle → full-res :', JSON.stringify(await ink()));
await p.screenshot({ path: 'sc_fine.png' });
await p.getByRole('button', { name: 'PDF সেভ' }).tap(); await p.waitForTimeout(5000);
console.log('library:', JSON.stringify(await p.evaluate(async () => (await window.__ao.db.list()).map(m => m.name + '|' + m.kind + '|' + m.size)))); console.log('errors:', errs); await b.close();
