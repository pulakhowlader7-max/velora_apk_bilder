import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
import fs from 'fs';
const files = fs.readdirSync('/home/claude/velora/public/js').filter(f => f.endsWith('.js') && f !== 'work.js').map(f => f.replace('.js', ''));
const b = await chromium.launch(); const p = await (await b.newContext()).newPage(); await p.goto('http://localhost:8080/'); await p.waitForTimeout(800);
const bad = await p.evaluate(async files => { const out = []; for (const f of files) { try { await import('/js/' + f + '.js'); } catch (e) { out.push(f + ': ' + e.message); } } return out; }, files);
console.log('modules checked:', files.length, ' failed:', JSON.stringify(bad)); await b.close();
