#!/usr/bin/env python3
"""Checks that the patched Android manifest is valid XML and that Velora shows up in "Open with" / "Share" for the
files people really receive (WhatsApp, Telegram, Gmail, Samsung My Files). Run: python3 -I tests/manifest_test.py"""
import re, sys, importlib.util
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location('patch_android', ROOT / 'scripts/patch_android.py')
pa = importlib.util.module_from_spec(spec); spec.loader.exec_module(pa)

CAP6 = '''<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application android:allowBackup="true" android:icon="@mipmap/ic_launcher" android:label="@string/app_name" android:theme="@style/AppTheme">
        <activity android:configChanges="orientation|keyboardHidden|screenSize" android:name=".MainActivity" android:label="@string/title_activity_main" android:theme="@style/AppTheme.NoActionBarLaunch" android:launchMode="singleTask" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        <provider android:name="androidx.core.content.FileProvider" android:authorities="${applicationId}.fileprovider" android:exported="false" android:grantUriPermissions="true">
            <meta-data android:name="android.support.FILE_PROVIDER_PATHS" android:resource="@xml/file_paths"></meta-data>
        </provider>
    </application>
    <uses-permission android:name="android.permission.INTERNET" />
</manifest>
'''
out = pa.patch_manifest(CAP6)
assert pa.patch_manifest(out) == out, 'patching twice must change nothing'
NS = '{http://schemas.android.com/apk/res/android}'
root = ET.fromstring(out)                       # fails if not well-formed
acts = root.findall('./application/activity')
assert len(acts) == 1
act = acts[0]
assert act.get(NS + 'windowSoftInputMode') == 'adjustResize'
assert root.find('./application').get(NS + 'largeHeap') == 'true'
perms = [p.get(NS + 'name') for p in root.findall('uses-permission')]
assert 'android.permission.CAMERA' in perms and 'android.permission.INTERNET' in perms

filters = []
for f in act.findall('intent-filter'):
    d = {'actions': {a.get(NS + 'name') for a in f.findall('action')}, 'cats': {c.get(NS + 'name') for c in f.findall('category')},
         'schemes': set(), 'hosts': set(), 'paths': [], 'types': []}
    for x in f.findall('data'):
        if x.get(NS + 'scheme'): d['schemes'].add(x.get(NS + 'scheme'))
        if x.get(NS + 'host'): d['hosts'].add(x.get(NS + 'host'))
        if x.get(NS + 'pathPattern'): d['paths'].append(x.get(NS + 'pathPattern'))
        if x.get(NS + 'mimeType'): d['types'].append(x.get(NS + 'mimeType'))
    filters.append(d)
assert any('android.intent.action.MAIN' in f['actions'] for f in filters), 'launcher filter lost'

def type_ok(t, pats):
    if not pats: return t is None
    if t is None: return False
    return any(p == t or p == '*/*' or (p.endswith('/*') and t.startswith(p[:-1])) for p in pats)

def path_ok(path, pats):  # Android pathPattern: simple glob, '.*' = any chars, '\\.' = literal dot
    for p in pats:
        rx = re.escape('').join([])  # placeholder to keep flake quiet
        rx = ''; i = 0
        while i < len(p):
            c = p[i]
            if c == '\\' and i + 1 < len(p): rx += re.escape(p[i + 1]); i += 2; continue
            if c == '.' and i + 1 < len(p) and p[i + 1] == '*': rx += '.*'; i += 2; continue
            rx += re.escape(c); i += 1
        if re.fullmatch(rx, path): return True
    return False

def resolves(action, scheme, mime, path='/x'):
    for f in filters:
        if action not in f['actions'] or 'android.intent.category.DEFAULT' not in f['cats']: continue
        if action.endswith('SEND') or action.endswith('SEND_MULTIPLE'):
            if type_ok(mime, f['types']): return True
            continue
        if f['schemes'] and scheme not in f['schemes']: continue
        if f['hosts'] and not f['paths'] and False: continue
        if f['paths']:
            if not f['hosts'] or not path_ok(path, f['paths']): continue
        if not type_ok(mime, f['types']): continue
        return True
    return False

DOCX = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
XLSX = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
PPTX = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
VIEW, SEND = 'android.intent.action.VIEW', 'android.intent.action.SEND'
cases = [
    ('WhatsApp docx (content://, proper MIME)', VIEW, 'content', DOCX, '/item/12345'),
    ('WhatsApp xlsx', VIEW, 'content', XLSX, '/item/12345'),
    ('WhatsApp pptx', VIEW, 'content', PPTX, '/item/9'),
    ('WhatsApp pdf', VIEW, 'content', 'application/pdf', '/item/9'),
    ('Samsung My Files docx', VIEW, 'content', DOCX, '/external/file/55'),
    ('Telegram doc as octet-stream', VIEW, 'content', 'application/octet-stream', '/files/report.docx'),
    ('file:// docx with generic type', VIEW, 'file', 'application/octet-stream', '/storage/emulated/0/Download/CV.docx'),
    ('Gmail attachment as zip type', VIEW, 'content', 'application/zip', '/attach/1'),
    ('Samsung opens xlsx as legacy ms-excel', VIEW, 'content', 'application/vnd.ms-excel', '/f/1'),
    ('legacy .doc', VIEW, 'content', 'application/msword', '/f/1'),
    ('csv', VIEW, 'content', 'text/csv', '/f/1'),
    ('Gallery image open-with', VIEW, 'content', 'image/jpeg', '/media/1'),
    ('Share a pdf', SEND, 'content', 'application/pdf', '/'),
    ('Share a docx', SEND, 'content', DOCX, '/'),
    ('Share a photo', SEND, 'content', 'image/png', '/'),
    ('Share generic file', SEND, 'content', 'application/octet-stream', '/'),
]
bad = [c[0] for c in cases if not resolves(c[1], c[2], c[3], c[4])]
for c in cases: print(('PASS ' if c[0] not in bad else 'FAIL ') + c[0])
assert not bad, 'Velora would NOT be offered for: ' + ', '.join(bad)
# a video must not make Velora pop up everywhere
assert not resolves(VIEW, 'content', 'video/mp4', '/v/1'), 'video should not match'
print('manifest ok:', len(filters), 'filters,', len(out), 'bytes')
