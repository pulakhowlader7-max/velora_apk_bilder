package com.pulak.velora;

import android.content.Intent;
import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(VeloraIntentPlugin.class);
        super.onCreate(savedInstanceState);
        if (savedInstanceState == null) VeloraIntentPlugin.ingest(this, getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        VeloraIntentPlugin.ingest(this, intent);
    }
}
