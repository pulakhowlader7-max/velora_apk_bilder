package com.pulak.velora;

import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.webkit.MimeTypeMap;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Velora native bridge:
 *  - receives files from other apps ("Open with" / "Share to") and hands them to the web layer
 *  - saves files into Downloads/Velora
 */
@CapacitorPlugin(name = "VeloraIntent")
public class VeloraIntentPlugin extends Plugin {
    private static final List<JSObject> PENDING = new ArrayList<>();
    private static VeloraIntentPlugin instance;

    @Override
    public void load() {
        instance = this;
    }

    /** JS asks for files that arrived while it was not listening. */
    @PluginMethod
    public void getPending(PluginCall call) {
        JSArray arr = new JSArray();
        synchronized (PENDING) {
            for (JSObject o : PENDING) arr.put(o);
            PENDING.clear();
        }
        JSObject ret = new JSObject();
        ret.put("files", arr);
        call.resolve(ret);
    }

    /** Remove a temp copy after JS has read it. */
    @PluginMethod
    public void cleanup(PluginCall call) {
        String path = call.getString("path");
        if (path != null) {
            File f = new File(path);
            File dir = new File(getContext().getCacheDir(), "incoming");
            try {
                if (f.getCanonicalPath().startsWith(dir.getCanonicalPath())) f.delete();
            } catch (Exception ignored) { }
        }
        call.resolve();
    }

    /** Copy a cache file into Downloads/Velora (MediaStore on Android 10+). */
    @PluginMethod
    public void saveToDownloads(PluginCall call) {
        String uriStr = call.getString("uri");
        String name = call.getString("name");
        String mime = call.getString("mime", "application/octet-stream");
        if (uriStr == null || name == null) { call.reject("uri/name missing"); return; }
        try {
            String p = Uri.parse(uriStr).getPath();
            File src = new File(p != null ? p : uriStr);
            if (!src.exists()) { call.reject("source missing"); return; }
            Context ctx = getContext();
            String where;
            if (Build.VERSION.SDK_INT >= 29) {
                ContentResolver cr = ctx.getContentResolver();
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Velora");
                Uri out = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (out == null) { call.reject("insert failed"); return; }
                try (InputStream in = new FileInputStream(src); OutputStream os = cr.openOutputStream(out)) {
                    if (os == null) { call.reject("stream failed"); return; }
                    pipe(in, os);
                }
                where = "Download/Velora/" + name;
            } else {
                File dir = new File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "Velora");
                dir.mkdirs();
                File dst = new File(dir, name);
                try (InputStream in = new FileInputStream(src); OutputStream os = new FileOutputStream(dst)) { pipe(in, os); }
                where = dst.getAbsolutePath();
            }
            JSObject ret = new JSObject();
            ret.put("where", where);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }

    /* ---------------- intent ingestion (called from MainActivity) ---------------- */

    public static void ingest(final Context ctx, final Intent intent) {
        if (intent == null) return;
        final String action = intent.getAction();
        if (action == null) return;
        final List<Uri> uris = new ArrayList<>();
        try {
            if (Intent.ACTION_VIEW.equals(action) || Intent.ACTION_EDIT.equals(action)) {
                if (intent.getData() != null) uris.add(intent.getData());
            } else if (Intent.ACTION_SEND.equals(action)) {
                Uri u = intent.getParcelableExtra(Intent.EXTRA_STREAM);
                if (u != null) uris.add(u);
            } else if (Intent.ACTION_SEND_MULTIPLE.equals(action)) {
                ArrayList<Uri> l = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
                if (l != null) uris.addAll(l);
            } else {
                return;
            }
            if (uris.isEmpty()) {
                ClipData cd = intent.getClipData();
                if (cd != null) for (int i = 0; i < cd.getItemCount(); i++) {
                    Uri u = cd.getItemAt(i).getUri();
                    if (u != null) uris.add(u);
                }
            }
        } catch (Exception e) {
            return;
        }
        if (uris.isEmpty()) return;
        // mark handled so a re-delivery of the same intent is not processed twice
        intent.setAction(Intent.ACTION_MAIN);

        new Thread(new Runnable() {
            @Override
            public void run() {
                for (Uri u : uris) {
                    try {
                        JSObject o = copyToCache(ctx, u);
                        if (o != null) synchronized (PENDING) { PENDING.add(o); }
                    } catch (Exception ignored) { }
                }
                VeloraIntentPlugin p = instance;
                if (p != null) p.notifyListeners("fileOpened", new JSObject(), true);
            }
        }).start();
    }

    private static JSObject copyToCache(Context ctx, Uri uri) throws Exception {
        ContentResolver cr = ctx.getContentResolver();
        String mime = cr.getType(uri);
        String name = null;
        if ("content".equals(uri.getScheme())) {
            Cursor c = null;
            try {
                c = cr.query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
                if (c != null && c.moveToFirst()) name = c.getString(0);
            } catch (Exception ignored) {
            } finally { if (c != null) c.close(); }
        }
        if (name == null || name.isEmpty()) {
            name = uri.getLastPathSegment();
            if (name != null) { int i = name.lastIndexOf('/'); if (i >= 0) name = name.substring(i + 1); }
        }
        if (name == null || name.isEmpty()) name = "file";
        String ext = "";
        int dot = name.lastIndexOf('.');
        if (dot > 0 && dot < name.length() - 1 && name.length() - dot <= 6) ext = name.substring(dot + 1).toLowerCase();
        if (ext.isEmpty() && mime != null) {
            String e = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime);
            if (e != null) { ext = e; name = name + "." + e; }
        }
        ext = ext.replaceAll("[^a-z0-9]", "");
        File dir = new File(ctx.getCacheDir(), "incoming");
        dir.mkdirs();
        // clear copies older than a day
        File[] old = dir.listFiles();
        if (old != null) for (File f : old) if (System.currentTimeMillis() - f.lastModified() > 86400000L) f.delete();
        File out = new File(dir, System.nanoTime() + (ext.isEmpty() ? "" : "." + ext));
        InputStream in = cr.openInputStream(uri);
        if (in == null) return null;
        try (InputStream is = in; OutputStream os = new FileOutputStream(out)) { pipe(is, os); }
        JSObject o = new JSObject();
        o.put("name", name);
        o.put("mime", mime == null ? "" : mime);
        o.put("path", out.getAbsolutePath());
        o.put("size", out.length());
        return o;
    }

    private static void pipe(InputStream in, OutputStream out) throws Exception {
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        out.flush();
    }
}
