// Velora local error log — nothing leaves the phone. Users can view / copy / share it when something misbehaves.
import { db } from './db.js';

const KEY = 'errlog', MAX = 80;
let queue = [], busy = false;
export const APP_VERSION = '1.7';
const short = s => String(s == null ? '' : s).slice(0, 600);
async function flush() {
  if (busy || !queue.length) return; busy = true;
  try { const list = await db.kvGet(KEY, []); list.push(...queue.splice(0)); await db.kvSet(KEY, list.slice(-MAX)); } catch { } finally { busy = false; if (queue.length) setTimeout(flush, 1500); }
}
export function logError(kind, msg, stack, extra) {
  if (/ResizeObserver loop|Script error\.?$/.test(String(msg))) return;
  queue.push({ t: Date.now(), kind, msg: short(msg), stack: short((stack || '').split('\n').slice(0, 5).join('\n')), screen: location.hash || '#/', ...(extra || {}) }); setTimeout(flush, 400);
}
export function initErrorLog() {
  window.addEventListener('error', e => logError('error', e.message, e.error && e.error.stack, { src: (e.filename || '').split('/').pop() + ':' + e.lineno }));
  window.addEventListener('unhandledrejection', e => { const r = e.reason; logError('promise', (r && (r.message || r.name)) || r, r && r.stack); });
  // out-of-memory style problems usually show up as a long freeze — record those too
  try { new PerformanceObserver(l => l.getEntries().forEach(en => { if (en.duration > 1500) logError('freeze', `UI ${Math.round(en.duration)}ms আটকে ছিল`); })).observe({ entryTypes: ['longtask'] }); } catch { }
}
export const readLog = () => db.kvGet(KEY, []);
export const clearLog = () => db.kvSet(KEY, []);
export function deviceLine() {
  const n = navigator, mem = n.deviceMemory ? n.deviceMemory + ' GB' : '?', cores = n.hardwareConcurrency || '?';
  return `Velora ${APP_VERSION} · ${n.userAgent} · RAM≈${mem} · CPU ${cores} · স্ক্রিন ${screen.width}×${screen.height}@${window.devicePixelRatio}`;
}
export const formatLog = list => deviceLine() + '\n\n' + (list.length ? list.map(e => `[${new Date(e.t).toLocaleString('en-GB')}] ${e.kind} ${e.screen}\n${e.msg}${e.src ? ' (' + e.src + ')' : ''}${e.stack ? '\n' + e.stack : ''}`).join('\n\n') : 'কোনো ত্রুটি নেই ✓');
