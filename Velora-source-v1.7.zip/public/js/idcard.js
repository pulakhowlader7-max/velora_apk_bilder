// Velora ID-card sheet — photograph both sides of an NID / ID card and print them on ONE side of ONE page.
import { h, icon, toast, sheet, busy, withBusy, errMsg, toBn } from './util.js';
import { screen } from './screen.js';
import * as P from './imgproc.js';
import { cnv, ctx2, toBlob, fitMax, pdfFromCanvases } from './exportkit.js';
import { openCropper, RATIOS } from './cropper.js';
import { liveCapture, pickPhoto, fileToCanvas } from './camera.js';

export const CARD = { w: 85.6, h: 53.98 };                 // ISO/IEC 7810 ID-1 (NID, driving licence, bank cards)
const CARD_PX = { w: 1011, h: 638 };                        // 300 dpi
export const PAGES = { a4: { w: 210, h: 297 }, letter: { w: 215.9, h: 279.4 } };
const SIZES = { actual: 'আসল মাপ', large: 'বড়', full: 'পুরো প্রস্থ' };

/** Pure layout maths (millimetres). Returns the page size and the front/back boxes. */
export function layoutCards({ page = 'a4', layout = 'stack', size = 'actual', pos = 'top', gap = 12, margin = 12 } = {}) {
  const pg = PAGES[page] || PAGES.a4, ar = CARD.w / CARD.h, availW = pg.w - 2 * margin, availH = pg.h - 2 * margin;
  let cw = size === 'actual' ? CARD.w : size === 'large' ? 105 : Math.min(availW, 150);
  if (layout === 'side') cw = Math.min(cw, (availW - gap) / 2);
  cw = Math.min(cw, availW);
  let ch = cw / ar;
  if (layout === 'stack' && 2 * ch + gap > availH) { ch = (availH - gap) / 2; cw = ch * ar; }
  const totalW = layout === 'side' ? 2 * cw + gap : cw, totalH = layout === 'side' ? ch : 2 * ch + gap;
  const x0 = (pg.w - totalW) / 2, y0 = pos === 'center' ? (pg.h - totalH) / 2 : margin + 6;
  const boxes = layout === 'side' ? [{ x: x0, y: y0, w: cw, h: ch }, { x: x0 + cw + gap, y: y0, w: cw, h: ch }] : [{ x: x0, y: y0, w: cw, h: ch }, { x: x0, y: y0 + ch + gap, w: cw, h: ch }];
  return { page: pg, boxes };
}
const rr = (g, x, y, w, hh, r) => { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + hh, r); g.arcTo(x + w, y + hh, x, y + hh, r); g.arcTo(x, y + hh, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); };
/** Draw the page. `sides` = [frontCanvas|null, backCanvas|null]; dpi 300 for print, ~90 for the on-screen preview. */
export function renderPage(sides, opt = {}, dpi = 300) {
  const L = layoutCards(opt), k = dpi / 25.4, c = cnv(L.page.w * k, L.page.h * k), g = ctx2(c);
  g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.imageSmoothingQuality = 'high';
  L.boxes.forEach((b, i) => {
    const x = b.x * k, y = b.y * k, w = b.w * k, hh = b.h * k, r = (opt.round === false ? 0 : 3.2) * k, img = sides[i];
    if (img) { g.save(); rr(g, x, y, w, hh, r); g.clip(); g.drawImage(img, x, y, w, hh); g.restore(); }
    if (opt.border !== false && img) { g.save(); rr(g, x, y, w, hh, r); g.lineWidth = Math.max(1, .3 * k); g.strokeStyle = '#8a8a8a'; g.stroke(); g.restore(); }
  });
  return c;
}
/** Make a captured/cropped card image canvas into the standard 85.6×54 mm landscape card, cleaned a little. */
export function normalizeCard(src, { clean = true, gray = false } = {}) {
  let c = src;
  if (c.height > c.width * 1.1) { const r = cnv(c.height, c.width), g = ctx2(r); g.translate(r.width / 2, r.height / 2); g.rotate(Math.PI / 2); g.drawImage(c, -c.width / 2, -c.height / 2); c = r; }
  const ratioOff = Math.abs(c.width / c.height - CARD.w / CARD.h) / (CARD.w / CARD.h);
  const out = cnv(CARD_PX.w, CARD_PX.h), g = ctx2(out); g.imageSmoothingQuality = 'high'; g.drawImage(c, 0, 0, out.width, out.height);
  const id = g.getImageData(0, 0, out.width, out.height);
  if (clean) { P.autoLevels(id, .004); P.removeNoise(id, 30); P.unsharp(id, .55, 1); }
  if (gray) { P.grayscale(id); P.autoLevels(id, .01); }
  g.putImageData(id, 0, 0); out.ratioOff = ratioOff; return out;
}

export async function openIdCard({ initial = [] } = {}) {
  const opt = { page: 'a4', layout: 'stack', size: 'actual', pos: 'top', gap: 12, border: true, round: true }, set = { clean: true, gray: false };
  const sides = [null, null], origs = [null, null], NAMES = ['সামনের পাশ', 'পেছনের পাশ'];
  const scr = screen({ title: 'ID কার্ড — দুই পাশ এক পাতায়', cls: 'idcard' });
  scr.setGuard(async () => true);
  const paper = cnv(10, 10); paper.className = 'id-paper'; const slots = h('div', { class: 'id-slots' });
  const pageBox = h('div', { class: 'id-page' }, paper, slots), stageEl = h('div', { class: 'id-stage' }, pageBox);
  const panel = h('div', { class: 'id-panel' }); scr.body.append(stageEl, panel);

  function fitPage() {
    const L = layoutCards(opt), bw = stageEl.clientWidth - 24, bh = stageEl.clientHeight - 24, s = Math.min(bw / L.page.w, bh / L.page.h);
    pageBox.style.width = L.page.w * s + 'px'; pageBox.style.height = L.page.h * s + 'px';
  }
  function draw() {
    const L = layoutCards(opt), pv = renderPage(sides, opt, 110); paper.width = pv.width; paper.height = pv.height; ctx2(paper).drawImage(pv, 0, 0);
    slots.replaceChildren(...L.boxes.map((b, i) => h('button', { type: 'button', class: 'id-slot' + (sides[i] ? ' has' : ''), 'aria-label': NAMES[i],
      style: { left: b.x / L.page.w * 100 + '%', top: b.y / L.page.h * 100 + '%', width: b.w / L.page.w * 100 + '%', height: b.h / L.page.h * 100 + '%' }, onclick: () => slotMenu(i) },
      sides[i] ? null : [icon('camera', 26), h('b', null, NAMES[i]), h('small', null, 'ছবি তুলুন / বাছুন')])));
    fitPage(); drawPanel();
  }
  const seg = (items, cur, on) => h('div', { class: 'seg' }, items.map(([k, t]) => h('button', { type: 'button', class: cur === k ? 'on' : '', onclick: () => on(k) }, t)));
  const row = (label, el) => h('div', { class: 'id-row' }, h('span', null, label), el);
  function drawPanel() {
    const both = sides[0] && sides[1];
    panel.replaceChildren(
      h('div', { class: 'id-pick' }, [0, 1].map(i => h('button', { type: 'button', class: 'id-pk' + (sides[i] ? ' ok' : ''), onclick: () => slotMenu(i) }, sides[i] ? h('img', { src: thumb(sides[i]), alt: '' }) : icon('camera', 22), h('span', null, NAMES[i], h('small', null, sides[i] ? 'বদলাতে চাপুন' : 'ছবি তুলুন'))))),
      row('সাজানো', seg([['stack', 'উপর-নিচ'], ['side', 'পাশাপাশি']], opt.layout, v => { opt.layout = v; draw(); })),
      row('মাপ', seg(Object.entries(SIZES), opt.size, v => { opt.size = v; draw(); })),
      row('অবস্থান', seg([['top', 'উপরে'], ['center', 'মাঝে']], opt.pos, v => { opt.pos = v; draw(); })),
      row('রঙ', seg([['c', 'রঙিন'], ['g', 'সাদা-কালো (ফটোকপি)']], set.gray ? 'g' : 'c', v => { set.gray = v === 'g'; reprocess(); })),
      h('button', { type: 'button', class: 'cl-tg' + (opt.border ? ' on' : ''), onclick: () => { opt.border = !opt.border; draw(); } }, h('span', { class: 'switch' + (opt.border ? ' on' : '') }), h('span', null, 'কার্ডের চারপাশে সরু বর্ডার', h('small', null, 'ফটোকপিতে কিনারা বোঝা যায়'))),
      h('div', { class: 'id-ok' }, h('button', { class: 'btn', type: 'button', disabled: !both, onclick: () => saveMenu('jpg') }, icon('image', 18), 'ছবি'), h('button', { class: 'btn primary', type: 'button', disabled: !both, onclick: () => saveMenu('pdf') }, icon('pdf', 18), 'A4 PDF সেভ')));
  }
  const thumb = c => { const t = cnv(160, 101); ctx2(t).drawImage(c, 0, 0, 160, 101); return t.toDataURL('image/jpeg', .8); };

  async function takeSide(i, how) {
    let src = null;
    try { src = how === 'cam' ? await liveCapture({ title: NAMES[i] + ' তুলুন', ratio: CARD.w / CARD.h, hint: 'কার্ডটি ফ্রেমের ভেতরে সমতলে রাখুন' }) : await pickPhoto(); } catch (e) { return toast('ছবি পড়া যায়নি: ' + errMsg(e), 3500); }
    if (src) await adjust(i, fitMax(src, 3600));
  }
  async function adjust(i, src) {
    const r = await openCropper(src, { title: NAMES[i] + ' — কার্ডের চার কোণা ঠিক করুন', mode: 'quad', ratio: CARD.w / CARD.h });
    if (!r) return; origs[i] = src; sides[i] = normalizeCard(r, set);
    if (sides[i].ratioOff > .14) toast('কার্ডের মাপ আসল কার্ডের সাথে পুরো মেলেনি — দরকারে "ক্রপ ঠিক করুন" দিয়ে আবার কোণা বসান', 4200);
    draw();
  }
  function reprocess() { /* re-run the cleaning on already cropped sides */ for (let i = 0; i < 2; i++) if (origs[i] && sides[i]) { const c = sides[i]; sides[i] = normalizeCard(c, { clean: false, gray: set.gray }); } draw(); }
  function slotMenu(i) {
    const items = [{ title: NAMES[i] }, { icon: 'camera', label: 'ক্যামেরায় তুলুন', sub: 'কার্ড আকারের গাইড ফ্রেম সহ', onClick: () => takeSide(i, 'cam') }, { icon: 'image', label: 'গ্যালারি / ফাইল থেকে', onClick: () => takeSide(i, 'gal') }];
    if (sides[i]) items.push({ sep: true }, { icon: 'crop', label: 'ক্রপ ঠিক করুন', onClick: () => adjust(i, origs[i]) }, { icon: 'rotate', label: 'ঘুরিয়ে দিন (১৮০°)', onClick: () => { const c = sides[i], r = cnv(c.width, c.height), g = ctx2(r); g.translate(r.width / 2, r.height / 2); g.rotate(Math.PI); g.drawImage(c, -c.width / 2, -c.height / 2); sides[i] = r; draw(); } },
      { icon: 'trash', label: 'মুছুন', danger: true, onClick: () => { sides[i] = origs[i] = null; draw(); } });
    sheet('', items);
  }
  async function saveMenu(kind) {
    const nm = 'ID কার্ড ' + new Date().toLocaleDateString('en-GB').replace(/\//g, '-');
    try {
      const f = await withBusy('উচ্চ মানে পাতা তৈরি হচ্ছে…', async () => {
        const page = renderPage(sides, opt, 300);
        if (kind === 'pdf') return new File([await pdfFromCanvases([page], { a4: opt.page === 'a4', quality: .92 })], nm + '.pdf', { type: 'application/pdf' });
        return new File([await toBlob(page, 'image/jpeg', .94)], nm + '.jpg', { type: 'image/jpeg' });
      });
      scr.close(); await window.__ao.importFiles([f], { open: true });
    } catch (e) { console.error(e); toast('সেভ ব্যর্থ: ' + errMsg(e), 4000); }
  }
  requestAnimationFrame(() => { draw(); new ResizeObserver(fitPage).observe(stageEl); initial.forEach((c, i) => { if (c) { origs[i] = c; sides[i] = normalizeCard(c, set); } }); draw(); });
}
