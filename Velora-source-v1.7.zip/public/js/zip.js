// JSZip loader that works on the page and inside a Web Worker.
export async function needJSZip() {
  if (typeof window === 'undefined') { if (!self.JSZip) self.importScripts('/vendor/jszip.min.js'); return self.JSZip; }
  if (!window.JSZip) await new Promise((res, rej) => { const s = document.createElement('script'); s.src = '/vendor/jszip.min.js'; s.onload = res; s.onerror = () => rej(new Error('JSZip লোড করা যায়নি')); document.head.append(s); });
  return window.JSZip;
}
