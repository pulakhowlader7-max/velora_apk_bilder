// Velora Photo Cleanup — remove camera noise, make text crisp, straighten tilted pages. Live before/after preview.
import { h, icon, toast, sheet, busy, withBusy, errMsg, loadImage, baseName, toBn } from './util.js';
import { screen } from './screen.js';
import * as P from './imgproc.js';
import * as FX from './fx.js';
import { cnv, ctx2, toBlob, fitMax, pdfFromCanvases, stampName } from './exportkit.js';
import { openCropper } from './cropper.js';

export const PRESETS = [
  { id: 'auto', label: 'অটো', st: { noise: 45, text: 55, sharp: 35, mono: 'color', deskew: true } },
  { id: 'text', label: 'লেখা স্পষ্ট', st: { noise: 55, text: 85, sharp: 55, mono: 'color', deskew: true } },
  { id: 'hand', label: 'হাতের লেখা', st: { noise: 60, text: 70, sharp: 30, mono: 'gray', deskew: true } },
  { id: 'noise', label: 'শুধু নয়েজ', st: { noise: 75, text: 0, sharp: 20, mono: 'color', deskew: false } },
  { id: 'bw', label: 'সাদা-কালো', st: { noise: 50, text: 100, sharp: 40, mono: 'bw', deskew: true } },
];

/** Rotate about the centre keeping the canvas size; the exposed corners become paper-white. */
function rotateKeep(c, deg) {
  const o = cnv(c.width, c.height), g = ctx2(o); g.fillStyle = '#ffffff'; g.fillRect(0, 0, o.width, o.height);
  g.imageSmoothingQuality = 'high'; g.translate(o.width / 2, o.height / 2); g.rotate(deg * Math.PI / 180); g.drawImage(c, -c.width / 2, -c.height / 2); return o;
}
/** Noise level (0–100) that suits this particular photo, from a measured noise σ. */
export function autoNoiseLevel(c) {
  const s = Math.min(1, 700 / Math.min(c.width, c.height)) < 1 ? 1 : 1, cw = Math.min(c.width, 700), chh = Math.min(c.height, 700);
  const crop = ctx2(c).getImageData(Math.floor((c.width - cw) / 2), Math.floor((c.height - chh) / 2), cw, chh);
  const sg = P.estimateNoise(crop); return Math.max(20, Math.min(95, Math.round(sg * 4.5) + 10));
}

/** The whole pipeline, DOM-free except for canvas plumbing. `tilt` is the angle found by deskewAngle. */
export function processCanvas(src, st, tilt = 0) {
  let c = src;
  if (st.deskew && tilt) c = rotateKeep(c, -tilt);
  const g = ctx2(c), img = g.getImageData(0, 0, c.width, c.height);
  const mode = st.mono === 'bw' ? 'bw' : st.mono === 'gray' ? 'gray' : st.text > 0 ? 'text' : 'color';
  FX.docClean(img, { mode, power: Math.max(20, st.text || 50), shadow: st.text > 0 || mode !== 'color' ? 85 : 25, denoise: st.noise, sharpen: st.sharp * .9, brightness: 0, contrast: 0 });
  const out = cnv(c.width, c.height); ctx2(out).putImageData(new ImageData(img.data, c.width, c.height), 0, 0); return out;
}

export function deskewCanvas(c) { const a = tiltOf(c); return a ? rotateKeep(c, -a) : c; }
export function tiltOf(c) { const s = fitMax(c, 600); return P.deskewAngle(ctx2(s).getImageData(0, 0, s.width, s.height)); }

async function loadSource(src) {
  if (src instanceof HTMLCanvasElement) return src;
  const url = URL.createObjectURL(src);
  try { const img = await loadImage(url), c = cnv(img.naturalWidth, img.naturalHeight); ctx2(c).drawImage(img, 0, 0); return c; } finally { URL.revokeObjectURL(url); }
}

/** opts.onResult(canvas) — when given, the "ব্যবহার করুন" button hands the cleaned canvas back instead of the save menu. */
export async function openCleanup(source, opts = {}) {
  let full;
  try { full = fitMax(await loadSource(source), 3200); } catch (e) { toast(errMsg(e), 3500); return; }
  const name = opts.name || (source && source.name) || stampName('ছবি');
  let st = { ...PRESETS[0].st }, preset = 'auto', tilt = 0, tiltFor = null, autoNoise = 45;
  try { autoNoise = autoNoiseLevel(full); st.noise = autoNoise; } catch (e) { console.warn(e); }
  const scr = screen({ title: 'ছবি পরিষ্কার', cls: 'cleanup' });
  const okB = h('button', { class: 'btn primary', type: 'button' }, icon('check', 18), opts.onResult ? 'ব্যবহার করুন' : 'সেভ');
  const cropB = h('button', { class: 'btn', type: 'button' }, icon('crop', 18) || '', 'ক্রপ');
  const before = h('canvas', { class: 'cl-b' }), after = h('canvas', { class: 'cl-a' });
  const div = h('div', { class: 'cl-div' }, h('i'), h('b', { class: 'l' }, 'আগে'), h('b', { class: 'r' }, 'পরে'));
  const cmp = h('div', { class: 'cl-cmp' }, before, after, div), stageEl = h('div', { class: 'cl-stage' }, cmp);
  const panel = h('div', { class: 'cl-panel' });
  scr.body.append(stageEl, panel);

  let prev = null, pos = 50;
  const setPos = p => { pos = Math.max(0, Math.min(100, p)); cmp.style.setProperty('--p', pos + '%'); };
  function fitStage() {
    if (!prev) return; const bw = stageEl.clientWidth - 16, bh = stageEl.clientHeight - 16, s = Math.min(bw / prev.width, bh / prev.height);
    cmp.style.width = prev.width * s + 'px'; cmp.style.height = prev.height * s + 'px';
  }
  function buildPreview() {
    prev = fitMax(full, 1000); before.width = prev.width; before.height = prev.height; ctx2(before).drawImage(prev, 0, 0);
    if (tiltFor !== full) { tilt = tiltOf(full); tiltFor = full; }
    fitStage(); draw();
  }
  let tm = 0;
  const draw = () => { cancelAnimationFrame(tm); tm = requestAnimationFrame(() => {
    const out = processCanvas(prev, st, tilt); after.width = prev.width; after.height = prev.height; const g = ctx2(after); g.clearRect(0, 0, after.width, after.height); g.drawImage(out, 0, 0, after.width, after.height);
  }); };
  let drag = false; const mv = e => { const r = cmp.getBoundingClientRect(); setPos((e.clientX - r.left) / r.width * 100); };
  cmp.addEventListener('pointerdown', e => { drag = true; cmp.setPointerCapture(e.pointerId); mv(e); }); cmp.addEventListener('pointermove', e => { if (drag) mv(e); }); cmp.addEventListener('pointerup', () => { drag = false; });
  setPos(50);

  function slider(label, key, max = 100, fmt = v => toBn(v)) {
    const out = h('b', null, fmt(st[key])), i = h('input', { type: 'range', min: 0, max, value: st[key], 'aria-label': label });
    i.addEventListener('input', () => { st[key] = +i.value; out.textContent = fmt(st[key]); preset = ''; drawChips(); draw(); }); return h('label', { class: 'ph-sl' }, h('span', null, label), i, out);
  }
  const chips = h('div', { class: 'cl-chips' }); const drawChips = () => chips.replaceChildren(...PRESETS.map(p => h('button', { type: 'button', class: 'chip' + (preset === p.id ? ' on' : ''), onclick: () => { st = { ...p.st }; if (p.id === 'auto' || p.id === 'text' || p.id === 'hand') st.noise = Math.max(p.st.noise * .6, autoNoise); preset = p.id; renderPanel(); draw(); } }, p.label)));
  function renderPanel() {
    drawChips();
    const mono = h('div', { class: 'seg' }, [['color', 'রঙিন'], ['gray', 'গ্রে'], ['bw', 'সাদা-কালো']].map(([k, t]) => h('button', { type: 'button', class: st.mono === k ? 'on' : '', onclick: () => { st.mono = k; preset = ''; renderPanel(); draw(); } }, t)));
    const ds = h('button', { type: 'button', class: 'cl-tg' + (st.deskew ? ' on' : ''), onclick: () => { st.deskew = !st.deskew; preset = ''; renderPanel(); draw(); } },
      h('span', { class: 'switch' + (st.deskew ? ' on' : '') }), h('span', null, 'কাত লেখা সোজা করুন', h('small', null, tilt ? `ছবিটি প্রায় ${toBn(Math.abs(tilt))}° কাত — ঠিক করা হবে` : 'ছবি সোজাই আছে')));
    panel.replaceChildren(chips, slider('নয়েজ কমান', 'noise'), slider('লেখা স্পষ্ট', 'text'), slider('শার্পনেস', 'sharp'), mono, ds, h('div', { class: 'cl-ok' }, cropB, okB));
  }
  cropB.addEventListener('click', async () => {
    const r = await openCropper(full, { title: 'ক্রপ করুন' }); if (!r) return; full = fitMax(r, 3200); tiltFor = null; try { autoNoise = autoNoiseLevel(full); } catch { } buildPreview(); renderPanel();
  });
  okB.addEventListener('click', async () => {
    const b = busy('উচ্চ মানে তৈরি হচ্ছে…'); await new Promise(r => setTimeout(r, 40));
    let res; try { res = processCanvas(full, st, st.deskew ? tilt : 0); } catch (e) { b.done(); return toast(errMsg(e), 4000); } b.done();
    if (opts.onResult) { scr.close(); return opts.onResult(res); }
    saveMenu(res);
  });
  function saveMenu(res) {
    const nm = baseName(name) + ' - পরিষ্কার';
    const add = async (files, open = true) => { await window.__ao.importFiles(files, { open }); };
    sheet('সেভ করুন', [
      { icon: 'image', label: 'ছবি (JPG) হিসেবে', sub: 'গ্যালারির মতো ফাইলে', onClick: async () => { const f = new File([await toBlob(res, 'image/jpeg', .93)], nm + '.jpg', { type: 'image/jpeg' }); scr.close(); await add([f]); } },
      { icon: 'pdf', label: 'PDF হিসেবে', sub: 'A4 পাতায়', onClick: async () => { const buf = await withBusy('PDF তৈরি হচ্ছে…', () => pdfFromCanvases([res], { a4: true })); scr.close(); await add([new File([buf], nm + '.pdf', { type: 'application/pdf' })]); } },
      { icon: 'word', label: 'Word (লেখা বের করে)', sub: 'OCR — বাংলা ও ইংরেজি', onClick: async () => { const { openOcrFlow } = await import('./ocrscreen.js'); scr.close(); openOcrFlow([res], { name: nm, skipClean: true }); } },
    ]);
  }
  requestAnimationFrame(() => { buildPreview(); renderPanel(); new ResizeObserver(fitStage).observe(stageEl); });
}
