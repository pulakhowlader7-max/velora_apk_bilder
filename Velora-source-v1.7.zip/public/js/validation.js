// Excel-style data validation: model, lookup, checking. Pure logic (no DOM) — shared by the grid and the xlsx reader/writer.
//  rule = { sq:'A2:A50', type:'list'|'whole'|'decimal'|'date'|'textLength', op:'between'|..., f1, f2, allowBlank:true, err:'message', title:'' }
const colNum = s => { let n = 0; for (const ch of s.toUpperCase()) n = n * 26 + ch.charCodeAt(0) - 64; return n - 1; };
export const colName = c => { let s = ''; c++; while (c > 0) { const m = (c - 1) % 26; s = String.fromCharCode(65 + m) + s; c = (c - m - 1) / 26 | 0; } return s; };
const CELL = /^\$?([A-Za-z]{1,3})\$?(\d+)$/;
export function parseRef(a) { const m = CELL.exec(a.trim()); return m ? { r: +m[2] - 1, c: colNum(m[1]) } : null; }
export function parseSq(sq) {
  return String(sq || '').split(/\s+/).filter(Boolean).map(p => { const [a, b] = p.split(':'), A = parseRef(a), B = b ? parseRef(b) : A; return A && B ? { r1: Math.min(A.r, B.r), c1: Math.min(A.c, B.c), r2: Math.max(A.r, B.r), c2: Math.max(A.c, B.c) } : null; }).filter(Boolean);
}
export const sqOf = g => `${colName(g.c1)}${g.r1 + 1}` + (g.r1 === g.r2 && g.c1 === g.c2 ? '' : `:${colName(g.c2)}${g.r2 + 1}`);
const cache = new WeakMap();
const rangesOf = rule => { let r = cache.get(rule); if (!r || r.sq !== rule.sq) { r = { sq: rule.sq, g: parseSq(rule.sq) }; cache.set(rule, r); } return r.g; };
export function ruleAt(sh, r, c) { const list = sh && sh.dv; if (!list || !list.length) return null; for (let i = list.length - 1; i >= 0; i--) for (const g of rangesOf(list[i])) if (r >= g.r1 && r <= g.r2 && c >= g.c1 && c <= g.c2) return list[i]; return null; }
export const intersects = (rule, g) => rangesOf(rule).some(x => !(x.r2 < g.r1 || x.r1 > g.r2 || x.c2 < g.c1 || x.c1 > g.c2));

export const TYPE_LABEL = { list: 'তালিকা (ড্রপডাউন)', whole: 'পূর্ণসংখ্যা', decimal: 'দশমিক সংখ্যা', date: 'তারিখ', textLength: 'লেখার দৈর্ঘ্য' };
export const OP_LABEL = { between: 'এর মধ্যে', notBetween: 'এর মধ্যে নয়', equal: 'সমান', notEqual: 'সমান নয়', greaterThan: 'এর চেয়ে বেশি', lessThan: 'এর চেয়ে কম', greaterThanOrEqual: 'বেশি বা সমান', lessThanOrEqual: 'কম বা সমান' };

/** list values: literal "a,b,c" or a range ("$A$1:$A$9" / "Sheet2!$A$1:$A$9"). `read(sheetName|null, r, c)` returns the cell's value. */
export function listItems(rule, read) {
  const f = String(rule.f1 || '').trim(); if (!f) return [];
  if (/^".*"$/.test(f)) return f.slice(1, -1).split(',').map(s => s.trim()).filter(s => s !== '');
  const m = /^(?:'([^']+)'|([^'!]+))?!?(\$?[A-Za-z]{1,3}\$?\d+(?::\$?[A-Za-z]{1,3}\$?\d+)?)$/.exec(f.includes('!') ? f : '!' + f); if (!m) return [];
  const g = parseSq(m[3].replace(/\$/g, ''))[0]; if (!g) return []; const out = [], name = m[1] || m[2] || null, seen = new Set();
  for (let r = g.r1; r <= g.r2 && out.length < 2000; r++) for (let c = g.c1; c <= g.c2; c++) { const v = read(name, r, c); if (v === null || v === undefined || v === '') continue; const s = String(v); if (!seen.has(s)) { seen.add(s); out.push(s); } }
  return out;
}
const num = (v, read) => { if (v === '' || v === undefined || v === null) return NaN; const s = String(v).trim(); if (CELL.test(s)) { const p = parseRef(s), x = read(null, p.r, p.c); return typeof x === 'number' ? x : parseFloat(x); } if (/^\d{4}-\d{2}-\d{2}/.test(s)) return Math.round((Date.UTC(+s.slice(0, 4), +s.slice(5, 7) - 1, +s.slice(8, 10)) - Date.UTC(1899, 11, 30)) / 864e5); return parseFloat(s.replace(/[০-৯]/g, d => '০১২৩৪৫৬৭৮৯'.indexOf(d))); };
const cmp = (op, x, a, b) => op === 'between' ? x >= a && x <= b : op === 'notBetween' ? x < a || x > b : op === 'equal' ? x === a : op === 'notEqual' ? x !== a : op === 'greaterThan' ? x > a : op === 'lessThan' ? x < a : op === 'greaterThanOrEqual' ? x >= a : op === 'lessThanOrEqual' ? x <= a : true;
export function describe(rule, read) {
  if (rule.type === 'list') return 'তালিকা থেকে একটি মান বেছে নিন';
  const t = { whole: 'পূর্ণসংখ্যা', decimal: 'সংখ্যা', date: 'তারিখ', textLength: 'লেখার দৈর্ঘ্য' }[rule.type] || 'মান', o = rule.op || 'between';
  return `${t} ${rule.f1}${o === 'between' || o === 'notBetween' ? ' – ' + rule.f2 : ''} ${OP_LABEL[o]}` .replace(/\s+/g, ' ').trim();
}
/** value = what the user typed. Returns { ok, msg } */
export function check(rule, value, read) {
  const text = String(value ?? '');
  if (text === '') return rule.allowBlank === false ? { ok: false, msg: rule.err || 'এই ঘর ফাঁকা রাখা যাবে না' } : { ok: true };
  const bad = () => ({ ok: false, msg: rule.err || ('অবৈধ মান — ' + describe(rule, read)) });
  if (rule.type === 'list') { const items = listItems(rule, read), t = text.trim(); return items.includes(t) || items.some(i => i.toLowerCase() === t.toLowerCase()) ? { ok: true } : bad(); }
  if (rule.type === 'textLength') return cmp(rule.op || 'between', text.length, num(rule.f1, read), num(rule.f2, read)) ? { ok: true } : bad();
  const x = num(text, read); if (Number.isNaN(x)) return bad();
  if (rule.type === 'whole' && !Number.isInteger(x)) return bad();
  return cmp(rule.op || 'between', x, num(rule.f1, read), num(rule.f2, read)) ? { ok: true } : bad();
}
