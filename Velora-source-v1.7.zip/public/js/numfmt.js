// Excel-style number / date formatting.
const EPOCH = Date.UTC(1899, 11, 30);
export const serialToDate = s => new Date(EPOCH + Math.round(s * 86400000 / 1) );
export function serialParts(s) {
  // handle Excel's 1900 leap-year bug: serial 60 = 29 Feb 1900 (fake)
  let days = Math.floor(s), frac = s - days;
  let ms = Math.round(frac * 86400000); if (ms >= 86400000) { days++; ms -= 86400000; }
  let y, m, d, wd;
  if (days === 60) { y = 1900; m = 2; d = 29; wd = 3; }
  else { const dt = new Date(EPOCH + (days < 60 ? days + 1 : days) * 86400000); y = dt.getUTCFullYear(); m = dt.getUTCMonth() + 1; d = dt.getUTCDate(); wd = dt.getUTCDay(); if (days < 60) { /* 1900-01-01 is serial 1 */ const dt2 = new Date(Date.UTC(1900, 0, days)); y = dt2.getUTCFullYear(); m = dt2.getUTCMonth() + 1; d = dt2.getUTCDate(); wd = dt2.getUTCDay(); } }
  return { y, m, d, wd, hh: Math.floor(ms / 3600000), mi: Math.floor(ms / 60000) % 60, ss: Math.floor(ms / 1000) % 60, ms };
}
export const dateToSerial = (y, m, d) => { const t = Date.UTC(y, m - 1, d); let s = (t - EPOCH) / 86400000; if (s < 60 && y === 1900) s -= 1; return s; };
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export const BUILTIN = { 0: 'General', 1: '0', 2: '0.00', 3: '#,##0', 4: '#,##0.00', 9: '0%', 10: '0.00%', 11: '0.00E+00', 12: '# ?/?', 13: '# ??/??', 14: 'dd/mm/yyyy', 15: 'd-mmm-yy', 16: 'd-mmm', 17: 'mmm-yy', 18: 'h:mm AM/PM', 19: 'h:mm:ss AM/PM', 20: 'h:mm', 21: 'h:mm:ss', 22: 'dd/mm/yyyy h:mm', 37: '#,##0;(#,##0)', 38: '#,##0;[Red](#,##0)', 39: '#,##0.00;(#,##0.00)', 40: '#,##0.00;[Red](#,##0.00)', 45: 'mm:ss', 46: '[h]:mm:ss', 47: 'mm:ss.0', 48: '##0.0E+0', 49: '@' };

const cache = new Map();
function parseSections(fmt) {
  if (cache.has(fmt)) return cache.get(fmt);
  const secs = []; let cur = '', q = false, i = 0;
  for (; i < fmt.length; i++) { const ch = fmt[i]; if (ch === '"') { q = !q; cur += ch; } else if (ch === '\\') { cur += ch + (fmt[++i] || ''); } else if (ch === ';' && !q) { secs.push(cur); cur = ''; } else cur += ch; }
  secs.push(cur);
  const out = secs.map(parseSection); cache.set(fmt, out); return out;
}
function parseSection(s) {
  const sec = { tokens: [], color: null, cond: null, date: false, text: false };
  let i = 0;
  const push = (t, v) => sec.tokens.push({ t, v });
  while (i < s.length) {
    const ch = s[i];
    if (ch === '"') { let j = s.indexOf('"', i + 1); if (j < 0) j = s.length; push('lit', s.slice(i + 1, j)); i = j + 1; continue; }
    if (ch === '\\') { push('lit', s[i + 1] || ''); i += 2; continue; }
    if (ch === '_') { push('lit', ' '); i += 2; continue; }
    if (ch === '*') { i += 2; continue; }
    if (ch === '[') {
      const j = s.indexOf(']', i); const body = s.slice(i + 1, j < 0 ? s.length : j); i = (j < 0 ? s.length : j) + 1;
      if (/^(black|blue|cyan|green|magenta|red|white|yellow)$/i.test(body)) sec.color = body.toLowerCase();
      else if (/^[<>=]/.test(body)) { const m = /^(<=|>=|<>|<|>|=)\s*(-?[\d.]+)/.exec(body); if (m) sec.cond = { op: m[1], v: +m[2] }; }
      else if (/^\$/.test(body)) { const m = /^\$([^-]*)/.exec(body); if (m && m[1]) push('lit', m[1]); }
      else if (/^(h+|m+|s+)$/i.test(body)) { push('elapsed', body.toLowerCase()); sec.date = true; }
      continue;
    }
    const rest = s.slice(i);
    let m;
    if ((m = /^(yyyy|yy)/i.exec(rest))) { push('y', m[1].length); sec.date = true; i += m[1].length; continue; }
    if ((m = /^(mmmmm|mmmm|mmm|mm|m)/i.exec(rest))) { push('m', m[1].length); sec.date = true; i += m[1].length; continue; }
    if ((m = /^(dddd|ddd|dd|d)/i.exec(rest))) { push('d', m[1].length); sec.date = true; i += m[1].length; continue; }
    if ((m = /^(hh|h)/i.exec(rest))) { push('h', m[1].length); sec.date = true; i += m[1].length; continue; }
    if ((m = /^(ss|s)/i.exec(rest))) { push('s', m[1].length); sec.date = true; i += m[1].length; continue; }
    if ((m = /^(AM\/PM|A\/P)/i.exec(rest))) { push('ampm', m[1]); sec.date = true; i += m[1].length; continue; }
    if ((m = /^E[+-]/i.exec(rest))) { push('exp', m[0]); i += 2; continue; }
    if (ch === '@') { push('at'); sec.text = true; i++; continue; }
    if ('0#?'.includes(ch)) { push('dig', ch); i++; continue; }
    if (ch === '.') { push('dot'); i++; continue; }
    if (ch === ',') { push('comma'); i++; continue; }
    if (ch === '%') { push('pct'); i++; continue; }
    if (ch === '/' && sec.tokens.length && sec.tokens[sec.tokens.length - 1].t === 'dig') { push('slash'); i++; continue; }
    push('lit', ch); i++;
  }
  // m after h or before s => minutes
  const t = sec.tokens;
  for (let k = 0; k < t.length; k++) if (t[k].t === 'm') {
    let p = k - 1; while (p >= 0 && t[p].t === 'lit') p--; let n = k + 1; while (n < t.length && t[n].t === 'lit') n++;
    if ((p >= 0 && (t[p].t === 'h' || t[p].t === 'elapsed')) || (n < t.length && t[n].t === 's')) t[k].t = 'min';
  }
  return sec;
}
function groupInt(s) { return s.replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
function fmtNumber(sec, v, neg) {
  const t = sec.tokens;
  let pct = 0, scale = 0; let first = -1, last = -1, dotAt = -1, grouping = false, expTok = null;
  let stop = false;
  for (let k = 0; k < t.length; k++) {
    const x = t[k];
    if (x.t === 'pct') pct++;
    if (x.t === 'exp') { expTok = x; stop = true; }
    if (stop) continue;
    if (x.t === 'dig' || x.t === 'dot' || (x.t === 'comma')) { if (x.t === 'comma') { /* thousands only if between digits */ } if (first < 0 && x.t !== 'comma') first = k; if (x.t !== 'comma') last = k; }
  }
  if (first < 0) { // no digits: only literals
    return t.map(x => x.t === 'lit' ? x.v : '').join('');
  }
  // commas: between digits => grouping; after last digit => scaling
  for (let k = first; k <= last; k++) if (t[k].t === 'comma') grouping = true;
  for (let k = last + 1; k < t.length && t[k].t === 'comma'; k++) scale++;
  let n = Math.abs(v) * Math.pow(100, pct) / Math.pow(1000, scale);
  const digs = t.slice(first, last + 1).filter(x => x.t === 'dig' || x.t === 'dot');
  let di = digs.findIndex(x => x.t === 'dot'); const intP = digs.slice(0, di < 0 ? digs.length : di).map(x => x.v), decP = di < 0 ? [] : digs.slice(di + 1).map(x => x.v);
  let body;
  const fracMode = t.some(x => x.t === 'slash');
  if (expTok) {
    const expDigits = (() => { let c = 0, idx = t.indexOf(expTok) + 1; while (idx < t.length && t[idx].t === 'dig') { c++; idx++; } return c || 2; })();
    const decN = decP.length; let e = n === 0 ? 0 : Math.floor(Math.log10(n)); let mant = n / Math.pow(10, e);
    const intN = Math.max(1, intP.length); if (intN > 1) { e -= intN - 1; mant = n / Math.pow(10, e); }
    let ms = mant.toFixed(decN); if (parseFloat(ms) >= Math.pow(10, intN)) { e++; ms = (n / Math.pow(10, e)).toFixed(decN); }
    body = ms + 'E' + (e < 0 ? '-' : expTok.v[1] === '+' ? '+' : '') + String(Math.abs(e)).padStart(expDigits, '0');
    const out = []; let done = false;
    for (let k = 0; k < t.length; k++) { const x = t[k]; if (k >= first && k <= last + 1 + expDigits) { if (!done) { out.push(body); done = true; } } else if (x.t === 'lit') out.push(x.v); }
    return (neg ? '-' : '') + out.join('');
  }
  const decN = decP.length;
  let s = n.toFixed(Math.min(20, decN)); let [ip, dp = ''] = s.split('.');
  // optional decimals (#) trimmed from the right
  let dArr = dp.split('');
  for (let k = decP.length - 1; k >= 0; k--) { if (decP[k] !== '0' && dArr[k] === '0' && k === dArr.length - 1) dArr.pop(); else if (decP[k] === '?' && dArr[k] === '0' && k === dArr.length - 1) dArr[k] = ' '; else break; }
  dp = dArr.join('');
  const minInt = intP.filter(x => x === '0').length;
  if (ip === '0' && minInt === 0 && intP.length > 0 && !(+n === 0 && decN === 0)) ip = decN > 0 ? '' : '0';
  if (ip.length < minInt) ip = ip.padStart(minInt, '0');
  if (grouping) ip = groupInt(ip);
  body = ip + (decN > 0 && dp.trim() !== '' ? '.' + dp : (decN > 0 && /0|\?/.test(decP.join('')) && dp !== '' ? '.' + dp : ''));
  if (decN > 0 && dp === '' && decP.includes('0')) body = ip + '.' + '0'.repeat(decN);
  if (fracMode) return (neg ? '-' : '') + fmtFraction(n, t, first);
  const out = []; let done = false;
  for (let k = 0; k < t.length; k++) { const x = t[k]; if (k >= first && k <= last) { if (!done) { out.push(body); done = true; } } else if (x.t === 'lit') out.push(x.v); else if (x.t === 'pct') out.push('%'); }
  const outS = out.join('');
  return (neg ? '-' : '') + outS;
}
function fmtFraction(n, t, first) {
  const w = Math.floor(n); let f = n - w; if (f < 1e-9) return String(w);
  let best = [0, 1], err = 1; for (let d = 1; d <= 99; d++) { const nn = Math.round(f * d); const e = Math.abs(f - nn / d); if (e < err - 1e-12) { err = e; best = [nn, d]; } if (e < 1e-9) break; }
  return (w ? w + ' ' : '') + best[0] + '/' + best[1];
}
function fmtDate(sec, v) {
  const p = serialParts(v); const t = sec.tokens; const has12 = t.some(x => x.t === 'ampm');
  let out = '';
  for (const x of t) {
    switch (x.t) {
      case 'y': out += x.v === 2 ? String(p.y % 100).padStart(2, '0') : String(p.y); break;
      case 'm': out += x.v === 1 ? p.m : x.v === 2 ? String(p.m).padStart(2, '0') : x.v === 3 ? MONTHS[p.m - 1].slice(0, 3) : x.v === 5 ? MONTHS[p.m - 1][0] : MONTHS[p.m - 1]; break;
      case 'd': out += x.v === 1 ? p.d : x.v === 2 ? String(p.d).padStart(2, '0') : x.v === 3 ? DAYS[p.wd].slice(0, 3) : DAYS[p.wd]; break;
      case 'h': { let hh = p.hh; if (has12) { hh = hh % 12; if (hh === 0) hh = 12; } out += x.v === 2 ? String(hh).padStart(2, '0') : hh; break; }
      case 'min': out += x.v === 2 ? String(p.mi).padStart(2, '0') : p.mi; break;
      case 's': out += x.v === 2 ? String(p.ss).padStart(2, '0') : p.ss; break;
      case 'ampm': out += x.v.toUpperCase() === 'A/P' ? (p.hh < 12 ? 'A' : 'P') : (p.hh < 12 ? 'AM' : 'PM'); break;
      case 'elapsed': { const tot = v * 24; out += x.v[0] === 'h' ? String(Math.floor(tot)).padStart(x.v.length, '0') : x.v[0] === 'm' ? String(Math.floor(tot * 60)).padStart(x.v.length, '0') : String(Math.floor(tot * 3600)).padStart(x.v.length, '0'); break; }
      case 'lit': out += x.v; break;
      case 'dot': out += '.'; break;
      case 'comma': out += ','; break;
      case 'dig': out += x.v === '0' ? String(Math.floor(p.ms % 1000 / (x.v === '0' ? 100 : 1))) : ''; break;
    }
  }
  return out;
}
export function general(v) {
  if (v === 0) return '0';
  const a = Math.abs(v);
  if (a >= 1e11 || a < 1e-4) { const [m, e] = v.toExponential(5).split('e'); return m.replace(/\.?0+$/, '') + 'E' + (e[0] === '-' ? '-' : '+') + e.replace(/^[+-]/, '').padStart(2, '0'); }
  let s = String(+v.toPrecision(10)); if (/e/i.test(s)) s = (+v).toFixed(10).replace(/\.?0+$/, ''); return s;
}
/** Returns {text, color} */
export function formatValue(v, fmt) {
  if (v === null || v === undefined || v === '') return { text: '' };
  if (typeof v === 'boolean') return { text: v ? 'TRUE' : 'FALSE' };
  if (typeof v === 'object' && v.err) return { text: v.err };
  fmt = fmt || 'General';
  if (typeof v === 'string') {
    if (fmt === 'General' || !/@/.test(fmt)) return { text: v };
    const secs = parseSections(fmt); const sec = secs[secs.length > 3 ? 3 : secs.findIndex(s => s.text)] || secs[0];
    return { text: sec.tokens.map(x => x.t === 'at' ? v : x.t === 'lit' ? x.v : '').join('') };
  }
  if (!isFinite(v)) return { text: '#NUM!' };
  if (fmt === 'General') return { text: general(v) };
  const secs = parseSections(fmt);
  let sec, neg = false;
  if (secs.length === 1) { sec = secs[0]; if (v < 0) neg = true; }
  else {
    const c0 = secs[0].cond, c1 = secs[1] && secs[1].cond;
    if (c0 || c1) { if (c0 && cmp(v, c0)) sec = secs[0]; else if (secs[1] && (!c1 || cmp(v, c1))) { sec = secs[1]; } else sec = secs[2] || secs[0]; neg = false; if (sec !== secs[0] && v < 0 && sec === secs[1] && !c1) neg = false; }
    else if (v > 0) sec = secs[0]; else if (v < 0) { sec = secs[1]; neg = false; } else sec = secs[2] || secs[0];
    if (v < 0 && !(c0 || c1) && !secs[1]) neg = true;
  }
  if (sec.date) { if (v < 0) return { text: '#########' }; return { text: fmtDate(sec, v), color: sec.color }; }
  if (sec.text && !sec.tokens.some(x => x.t === 'dig')) return { text: sec.tokens.map(x => x.t === 'at' ? general(v) : x.t === 'lit' ? x.v : '').join('') };
  return { text: fmtNumber(sec, v, neg || (secs.length > 1 && false)), color: sec.color };
}
const cmp = (v, c) => c.op === '<' ? v < c.v : c.op === '>' ? v > c.v : c.op === '<=' ? v <= c.v : c.op === '>=' ? v >= c.v : c.op === '=' ? v === c.v : v !== c.v;
export const isDateFmt = fmt => !!fmt && fmt !== 'General' && parseSections(fmt).some(s => s.date);
export const PRESETS = [
  ['General', 'সাধারণ'], ['0', 'সংখ্যা (১২৩৪)'], ['0.00', 'দশমিক (১২৩৪.৫০)'], ['#,##0', 'কমা সহ (১,২৩৪)'], ['#,##0.00', 'কমা ও দশমিক'], ['"৳"#,##0.00', 'টাকা (৳)'], ['"$"#,##0.00', 'ডলার ($)'], ['0%', 'শতাংশ (%)'], ['0.00%', 'শতাংশ ০.০০%'],
  ['dd/mm/yyyy', 'তারিখ (০১/০২/২০২৬)'], ['d mmmm yyyy', 'তারিখ (১ জানুয়ারি…)'], ['dd-mmm-yy', 'তারিখ (০১-Jan-26)'], ['h:mm AM/PM', 'সময়'], ['dd/mm/yyyy h:mm', 'তারিখ ও সময়'], ['@', 'টেক্সট'], ['0.00E+00', 'বৈজ্ঞানিক']];
