// PIN lock screen (PBKDF2-hashed PIN, attempt limiting, auto-lock)
import { h, icon, toast, toBn } from './util.js';
import { db, getSettings, setSetting } from './db.js';

const enc = new TextEncoder();
const b64 = a => btoa(String.fromCharCode(...new Uint8Array(a)));
const unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
async function hash(pin, salt) {
  const k = await crypto.subtle.importKey('raw', enc.encode(pin), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: 150000, hash: 'SHA-256' }, k, 256);
  return b64(bits);
}
export async function setPin(pin) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  await db.kvSet('pin', { salt: b64(salt), hash: await hash(pin, salt), len: pin.length });
  await db.kvSet('pinFail', { n: 0, until: 0 });
  await setSetting('lockOn', true);
}
export async function removePin() { await db.kvDel('pin'); await db.kvDel('pinFail'); await setSetting('lockOn', false); }
export async function hasPin() { return !!(await db.kvGet('pin')); }
export async function checkPin(pin) {
  const p = await db.kvGet('pin'); if (!p) return true;
  return (await hash(pin, unb64(p.salt))) === p.hash;
}

let screen = null, locked = false, hiddenAt = 0, onUnlockCb = null;
export const isLocked = () => locked;

export async function lockNow() {
  if (locked) return;
  const p = await db.kvGet('pin'); if (!p) return;
  locked = true; showScreen(p.len || 4);
}

function showScreen(len, opts = {}) {
  closeScreen();
  const { mode = 'unlock', title, onDone, onCancel } = opts;
  let val = '';
  const dots = h('div', { class: 'pin-dots', 'aria-live': 'polite' });
  const msg = h('div', { class: 'pin-msg' });
  const paint = () => { dots.replaceChildren(...Array.from({ length: len }, (_, i) => h('i', { class: i < val.length ? 'on' : '' }))); };
  const keys = [];
  const press = async k => {
    if (busy) return;
    if (k === 'del') { val = val.slice(0, -1); paint(); return; }
    if (val.length >= len) return;
    val += k; paint();
    if (navigator.vibrate) navigator.vibrate(8);
    if (val.length === len) { busy = true; await submit(); busy = false; }
  };
  let busy = false;
  const shake = m => { msg.textContent = m; dots.classList.add('shake'); setTimeout(() => dots.classList.remove('shake'), 400); val = ''; paint(); };
  async function submit() {
    if (mode === 'unlock') {
      const f = await db.kvGet('pinFail', { n: 0, until: 0 });
      if (Date.now() < f.until) { shake(`অনেকবার ভুল। ${toBn(Math.ceil((f.until - Date.now()) / 1000))} সেকেন্ড অপেক্ষা করুন`); return; }
      if (await checkPin(val)) {
        await db.kvSet('pinFail', { n: 0, until: 0 });
        locked = false; closeScreen(); onUnlockCb && onUnlockCb(); onDone && onDone(val);
      } else {
        f.n++; if (f.n >= 5) { f.until = Date.now() + Math.min(300, 15 * 2 ** (f.n - 5)) * 1000; }
        await db.kvSet('pinFail', f);
        shake(f.n >= 5 ? 'অনেকবার ভুল পিন। কিছুক্ষণ পরে চেষ্টা করুন' : 'ভুল পিন, আবার চেষ্টা করুন');
      }
    } else { const v = val; val = ''; paint(); onDone(v); }
  }
  const pad = h('div', { class: 'pin-pad' });
  for (const k of ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', 'del']) {
    if (k === '') { pad.append(h('span')); continue; }
    pad.append(h('button', { type: 'button', class: 'pin-key', 'aria-label': k === 'del' ? 'মুছুন' : k, onclick: () => press(k) },
      k === 'del' ? icon('back', 24) : h('span', null, toBn(k))));
  }
  const ic = h('div', { class: 'pin-ic' }, h('img', { src: '/icons/logo-96.png', alt: '', width: 64, height: 64, style: { borderRadius: '16px' } }));
  screen = h('div', { class: 'pinscreen', role: 'dialog', 'aria-label': 'পিন লক' },
    onCancel ? h('button', { class: 'pin-x', type: 'button', onclick: () => { closeScreen(); onCancel(); }, 'aria-label': 'বাতিল' }, icon('x', 22)) : null,
    ic, h('div', { class: 'pin-title' }, title || 'Velora'), h('div', { class: 'pin-sub' }, mode === 'unlock' ? 'পিন দিয়ে খুলুন' : ''), dots, msg, pad);
  paint(); document.body.append(screen);
  screen._key = e => { if (/^\d$/.test(e.key)) press(e.key); else if (e.key === 'Backspace') press('del'); };
  window.addEventListener('keydown', screen._key);
}
function closeScreen() { if (screen) { window.removeEventListener('keydown', screen._key); screen.remove(); screen = null; } }

// Ask for a new PIN (enter twice). Resolves with the pin or null.
export function askNewPin(len = 4) {
  return new Promise(res => {
    let first = null;
    const step = () => showScreen(len, {
      mode: 'ask', title: first ? 'পিন আবার দিন' : 'নতুন পিন দিন',
      onCancel: () => res(null),
      onDone: v => {
        if (!first) { first = v; step(); return; }
        if (v === first) { closeScreen(); res(v); } else { first = null; toast('পিন মেলেনি, আবার দিন'); step(); }
      }
    });
    step();
  });
}
export function askCurrentPin(title = 'বর্তমান পিন দিন') {
  return new Promise(async res => {
    const p = await db.kvGet('pin'); if (!p) return res(true);
    showScreen(p.len || 4, { mode: 'ask', title, onCancel: () => res(false), onDone: async v => { if (await checkPin(v)) { closeScreen(); res(true); } else { toast('ভুল পিন'); askCurrentPin(title).then(res); } } });
  });
}

export async function initLock(onUnlock) {
  onUnlockCb = onUnlock;
  const s = await getSettings();
  const p = await db.kvGet('pin');
  if (s.lockOn && p) { locked = true; showScreen(p.len || 4); }
  document.addEventListener('visibilitychange', async () => {
    const st = await getSettings(); const has = await db.kvGet('pin');
    if (!st.lockOn || !has) return;
    if (document.hidden) hiddenAt = Date.now();
    else if (hiddenAt && st.autoLock >= 0 && Date.now() - hiddenAt >= st.autoLock * 1000) lockNow();
  });
}
export function locking() { return locked; }
