// Promise API for the background worker. One worker, many calls; progress callbacks supported.
let w = null, seq = 0; const pending = new Map();
function start() {
  w = new Worker('/js/work.js');
  w.onmessage = e => { const { id, progress, result, error } = e.data, p = pending.get(id); if (!p) return; if (progress !== undefined) { p.onProgress && p.onProgress(progress); return; } pending.delete(id); error ? p.rej(new Error(error)) : p.res(result); };
  w.onerror = e => { for (const p of pending.values()) p.rej(new Error(e.message || 'ওয়ার্কার ব্যর্থ')); pending.clear(); try { w.terminate(); } catch { } w = null; };
  return w;
}
export const call = (op, payload = {}, transfer = [], onProgress) => new Promise((res, rej) => { const id = ++seq; pending.set(id, { res, rej, onProgress }); (w || start()).postMessage({ id, op, ...payload }, transfer); });
export const hasWorker = typeof Worker !== 'undefined';
