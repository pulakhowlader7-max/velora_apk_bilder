// Render HTML to paginated PDF (works offline; Bengali shaping done by the browser's own text engine).
import { needPDFLib, loadImage } from './util.js';

const cleanCss = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;');
const ser = n => new XMLSerializer().serializeToString(n).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');

/** Rasterise an HTML fragment (string of well-formed XHTML) to a canvas of w×h CSS px. */
export async function htmlToCanvas(xhtml, css, w, h, scale = 2, bg = '#ffffff') {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w * scale}" height="${h * scale}" viewBox="0 0 ${w} ${h}"><foreignObject x="0" y="0" width="${w}" height="${h}"><div xmlns="http://www.w3.org/1999/xhtml" style="width:${w}px;height:${h}px;overflow:hidden;background:${bg};box-sizing:border-box"><style>${cleanCss(css)}</style>${xhtml}</div></foreignObject></svg>`;
  const img = await loadImage('data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg));
  const c = document.createElement('canvas'); c.width = Math.round(w * scale); c.height = Math.round(h * scale);
  const g = c.getContext('2d'); g.fillStyle = bg; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
  return c;
}
const toJpeg = (c, q = 0.9) => new Promise(r => c.toBlob(b => b.arrayBuffer().then(r), 'image/jpeg', q));

export async function pdfFromCanvases(canvases, { wPt, hPt, title = '' }) {
  const { PDFDocument } = await needPDFLib();
  const pdf = await PDFDocument.create(); pdf.setTitle(title); pdf.setProducer('Velora'); pdf.setCreator('Velora');
  for (const c of canvases) {
    const img = await pdf.embedJpg(await toJpeg(c));
    const pg = pdf.addPage([wPt, hPt]); pg.drawImage(img, { x: 0, y: 0, width: wPt, height: hPt });
  }
  return pdf.save();
}

/**
 * Paginate a content element into pages and export.
 * contentEl: element whose children are laid out at width = pageW - 2*margin.
 * css: stylesheet text that styles the content (must target classes present in the clone).
 */
export async function paginatedPdf(contentEl, { css, title = '', pageW = 794, pageH = 1123, margin = 60, landscape = false, onProgress, wrapClass = 'pdfdoc', cfg = null } = {}) {
  if (landscape) [pageW, pageH] = [pageH, pageW];
  let mt = margin, mr = margin, mb = margin, ml = margin, hf = null;
  if (cfg) {   // Word page setup: real page size, per-side margins, header / footer / page numbers
    const C = await import('./pagecfg.js'), c = C.normalize(cfg), d = C.pageDims(c);
    pageW = Math.round(d.w / 15); pageH = Math.round(d.h / 15); mt = Math.round(c.m.t / 15); mr = Math.round(c.m.r / 15); mb = Math.round(c.m.b / 15); ml = Math.round(c.m.l / 15); hf = c;
  }
  const cw = pageW - ml - mr, ch = pageH - mt - mb;
  const stage = document.createElement('div');
  stage.style.cssText = `position:fixed;left:-20000px;top:0;width:${cw}px;visibility:hidden;pointer-events:none`;
  const sty = document.createElement('style'); sty.textContent = css; stage.append(sty);
  const holder = document.createElement('div'); holder.className = wrapClass; holder.style.width = cw + 'px';
  holder.innerHTML = contentEl.innerHTML; stage.append(holder); document.body.append(stage);
  try {
    // let images decode
    await Promise.all([...holder.querySelectorAll('img')].map(i => i.decode ? i.decode().catch(() => { }) : 0));
    const base = holder.getBoundingClientRect().top;
    const items = [];
    for (const n of holder.children) {
      const r = n.getBoundingClientRect(); const cs = getComputedStyle(n);
      const mt = parseFloat(cs.marginTop) || 0, mb = parseFloat(cs.marginBottom) || 0;
      items.push({ n, top: r.top - base - mt, bottom: r.bottom - base + mb, h: r.height + mt + mb, brk: n.classList.contains('pagebreak') });
    }
    // build pages: arrays of {node, slice}
    const pages = []; let cur = [], curStart = null, curBottom = 0;
    const pushPage = () => { if (cur.length) pages.push(cur); cur = []; curStart = null; };
    for (const it of items) {
      if (it.brk) { pushPage(); continue; }
      if (curStart === null) curStart = it.top;
      if (it.bottom - curStart > ch && cur.length) { pushPage(); curStart = it.top; }
      if (it.h > ch) { // oversize: split table by rows, others by slicing
        if (cur.length) { pushPage(); }
        if (it.n.tagName === 'TABLE') {
          const rows = [...it.n.rows]; let grp = [], gs = null;
          const flushT = () => { if (grp.length) { const t = it.n.cloneNode(false); const tb = document.createElement('tbody'); grp.forEach(r => tb.append(r.cloneNode(true))); t.append(tb); pages.push([{ clone: t }]); grp = []; gs = null; } };
          for (const r of rows) { const rr = r.getBoundingClientRect(); const top = rr.top - base, bot = rr.bottom - base; if (gs === null) gs = top; if (bot - gs > ch && grp.length) { flushT(); gs = top; } grp.push(r); }
          flushT();
        } else { const n = Math.ceil(it.h / ch); for (let k = 0; k < n; k++) pages.push([{ node: it.n, slice: k * ch, h: ch }]); }
        curStart = null; continue;
      }
      cur.push({ node: it.n }); curBottom = it.bottom;
    }
    pushPage(); if (!pages.length) pages.push([]);
    const canvases = [];
    for (let i = 0; i < pages.length; i++) {
      onProgress && onProgress(i + 1, pages.length);
      const parts = pages[i].map(p => {
        if (p.clone) return ser(p.clone);
        if (p.slice !== undefined) return `<div style="height:${p.h}px;overflow:hidden"><div style="margin-top:-${p.slice}px">${ser(p.node)}</div></div>`;
        return ser(p.node);
      }).join('');
      const xhtml = `<div class="${wrapClass}" style="padding:${mt}px ${mr}px ${mb}px ${ml}px;width:${pageW}px;height:${pageH}px;box-sizing:border-box;position:relative;overflow:hidden">${parts}${hf ? hfXhtml(hf, i + 1, pages.length, { mt, mr, mb, ml }) : ''}</div>`;
      canvases.push(await htmlToCanvas(xhtml, css, pageW, pageH, 2));
    }
    const wPt = pageW * 0.75, hPt = pageH * 0.75;
    return await pdfFromCanvases(canvases, { wPt, hPt, title });
  } finally { stage.remove(); }
}

const escX = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
const BN = n => String(n).replace(/\d/g, d => '০১২৩৪৫৬৭৮৯'[d]);
function pnText(fmt, i, n) { return fmt === 'page n' ? 'পাতা ' + BN(i) : fmt === 'n/m' ? `${i} / ${n}` : fmt === 'page n of m' ? `Page ${i} of ${n}` : String(i); }
function hfXhtml(c, i, n, m) {
  const box = (pos, align, lines) => lines.length ? `<div style="position:absolute;left:${m.ml}px;right:${m.mr}px;${pos};text-align:${align === 'justify' ? 'left' : align};font-size:12px;line-height:1.4;color:#555;white-space:pre-line">${lines.map(escX).join('<br/>')}</div>` : '';
  const top = Math.max(6, Math.round(m.mt * .35)), bot = Math.max(6, Math.round(m.mb * .35)), pn = pnText(c.pn.fmt, i, n);
  let h = '', f = '';
  if (c.hdr.text.trim()) h += box(`top:${top}px`, c.hdr.align, c.hdr.text.split('\n')); if (c.pn.pos === 'header') h += box(`top:${top + (c.hdr.text.trim() ? 18 : 0)}px`, c.pn.align, [pn]);
  if (c.pn.pos === 'footer') f += box(`bottom:${bot}px`, c.pn.align, [pn]); if (c.ftr.text.trim()) f += box(`bottom:${bot + (c.pn.pos === 'footer' ? 18 : 0)}px`, c.ftr.align, c.ftr.text.split('\n'));
  return h + f;
}

/** Native browser print (vector, selectable text) for the given element. */
export function printElement(contentEl, css, title = '', cfg = null) {
  let page = '@page{size:A4;margin:16mm}';
  if (cfg) { const m = cfg.m || {}, mm = v => (v / 56.6929).toFixed(1) + 'mm', land = cfg.orient === 'landscape'; page = `@page{size:${cfg.size && cfg.size !== 'Custom' ? cfg.size : 'A4'} ${land ? 'landscape' : 'portrait'};margin:${mm(m.t ?? 1134)} ${mm(m.r ?? 1134)} ${mm(m.b ?? 1134)} ${mm(m.l ?? 1134)}}`; }
  const f = document.createElement('iframe'); f.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0';
  document.body.append(f);
  const d = f.contentDocument; d.open();
  d.write(`<!doctype html><html><head><meta charset="utf-8"><title>${title.replace(/</g, '')}</title><style>${page}body{margin:0}${css}</style></head><body><div class="pdfdoc">${contentEl.innerHTML}</div></body></html>`); d.close();
  const go = () => { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (e) { console.warn(e); } setTimeout(() => f.remove(), 60000); };
  setTimeout(go, 350);
}
