// Velora — readers for formats the editors cannot open natively:
//   .doc / .xls / .ppt / .pps (Office 97-2003 binary), .rtf, .odt / .ods / .odp (OpenDocument).
// Each reader extracts text, tables and basic styling and hands it to the normal Word / Excel / PowerPoint importers.
// Formatting beyond that (fonts, images in binary files, charts, macros) is not carried over — the UI tells the user.
import { needJSZip, readBuf, readText, esc, baseName, extOf } from './util.js';

export const FOREIGN = ['doc', 'xls', 'ppt', 'pps', 'rtf', 'odt', 'ods', 'odp'];
const dec = (u8, label) => new TextDecoder(label).decode(u8);
const cp1252 = u8 => dec(u8, 'windows-1252');
const utf16 = u8 => dec(u8, 'utf-16le');

/* ============================ OLE / Compound File ============================ */
export function readCfb(buf) {
  const u = new Uint8Array(buf), dv = new DataView(buf);
  const SIG = [0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1];
  if (u.length < 512 || SIG.some((b, i) => u[i] !== b)) throw new Error('এটি পুরনো Office ফাইল নয় বা নষ্ট হয়ে গেছে');
  const ss = 1 << dv.getUint16(30, true), ms = 1 << dv.getUint16(32, true);
  const dirStart = dv.getUint32(48, true), cutoff = dv.getUint32(56, true), miniStart = dv.getUint32(60, true), difStart = dv.getUint32(68, true), numDif = dv.getUint32(72, true);
  const secOff = s => (s + 1) * ss, END = 0xFFFFFFFE;
  const fatSecs = []; for (let i = 0; i < 109; i++) { const s = dv.getUint32(76 + i * 4, true); if (s < 0xFFFFFFFA) fatSecs.push(s); }
  let d = difStart; for (let k = 0; k < numDif && d < 0xFFFFFFFA; k++) { const o = secOff(d); for (let i = 0; i < ss / 4 - 1; i++) { const s = dv.getUint32(o + i * 4, true); if (s < 0xFFFFFFFA) fatSecs.push(s); } d = dv.getUint32(o + ss - 4, true); }
  const per = ss / 4, fat = new Uint32Array(fatSecs.length * per);
  fatSecs.forEach((s, k) => { const o = secOff(s); for (let i = 0; i < per; i++) fat[k * per + i] = o + i * 4 + 4 <= u.length ? dv.getUint32(o + i * 4, true) : 0xFFFFFFFF; });
  const chain = (start, table = fat) => { const out = []; let s = start, guard = 0; while (s < 0xFFFFFFFA && guard++ < 5e6) { out.push(s); s = table[s]; if (s === undefined) break; } return out; };
  const readBig = (start, size) => { const out = new Uint8Array(size === null ? chain(start).length * ss : size); let p = 0; for (const s of chain(start)) { const o = secOff(s); const n = Math.min(ss, out.length - p); if (n <= 0) break; out.set(u.subarray(o, o + n), p); p += n; } return out; };
  const dir = readBig(dirStart, null), ents = [];
  for (let o = 0; o + 128 <= dir.length; o += 128) {
    const dd = new DataView(dir.buffer, dir.byteOffset + o, 128), nl = dd.getUint16(64, true); if (!nl) { ents.push(null); continue; }
    ents.push({ name: utf16(dir.subarray(o, o + nl - 2)), type: dd.getUint8(66), start: dd.getUint32(116, true), size: dd.getUint32(120, true) });
  }
  const root = ents.find(e => e && e.type === 5); let miniStream = null, miniFat = null;
  const ensureMini = () => { if (miniStream) return; miniStream = readBig(root.start, root.size); const mf = readBig(miniStart, null); const mdv = new DataView(mf.buffer, mf.byteOffset, mf.byteLength); miniFat = new Uint32Array(mf.length / 4); for (let i = 0; i < miniFat.length; i++) miniFat[i] = mdv.getUint32(i * 4, true); };
  const streams = {};
  for (const e of ents) if (e && e.type === 2) streams[e.name] = () => {
    if (e.size < cutoff) { ensureMini(); const out = new Uint8Array(e.size); let p = 0; for (const s of chain(e.start, miniFat)) { const n = Math.min(ms, out.length - p); if (n <= 0) break; out.set(miniStream.subarray(s * ms, s * ms + n), p); p += n; } return out; }
    return readBig(e.start, e.size);
  };
  return { streams, names: Object.keys(streams) };
}

/* ============================ .doc ============================ */
export function docToHtml(buf) {
  const cfb = readCfb(buf); if (!cfb.streams.WordDocument) throw new Error('Word ডকুমেন্ট পাওয়া যায়নি');
  const wd = cfb.streams.WordDocument(), dv = new DataView(wd.buffer, wd.byteOffset, wd.byteLength);
  if (dv.getUint16(0, true) !== 0xA5EC) throw new Error('এই .doc ফরম্যাট সমর্থিত নয়');
  const flags = dv.getUint16(0x0A, true); if (flags & 0x0100) throw new Error('ফাইলটি পাসওয়ার্ড দিয়ে সুরক্ষিত');
  const tbl = cfb.streams[(flags & 0x0200) ? '1Table' : '0Table']; if (!tbl) throw new Error('টেবিল স্ট্রিম নেই');
  const t = tbl(), tdv = new DataView(t.buffer, t.byteOffset, t.byteLength);
  const ccpText = dv.getInt32(0x4C, true), fcClx = dv.getUint32(0x1A2, true), lcbClx = dv.getUint32(0x1A6, true);
  let p = fcClx, pcd = null; const end = fcClx + lcbClx;
  while (p < end) { const ty = t[p]; if (ty === 1) p += 3 + tdv.getUint16(p + 1, true); else if (ty === 2) { const l = tdv.getUint32(p + 1, true); pcd = [p + 5, l]; break; } else break; }
  if (!pcd) throw new Error('লেখার তথ্য পড়া যায়নি');
  const n = (pcd[1] - 4) / 12 | 0; let text = '';
  for (let i = 0; i < n && text.length < ccpText; i++) {
    const cp0 = tdv.getUint32(pcd[0] + i * 4, true), cp1 = tdv.getUint32(pcd[0] + (i + 1) * 4, true), fcRaw = tdv.getUint32(pcd[0] + (n + 1) * 4 + i * 8 + 2, true);
    const cnt = Math.min(cp1, ccpText) - cp0; if (cnt <= 0) continue;
    if (fcRaw & 0x40000000) { const o = (fcRaw & 0x3FFFFFFF) >> 1; text += cp1252(wd.subarray(o, o + cnt)); } else text += utf16(wd.subarray(fcRaw, fcRaw + cnt * 2));
  }
  // walk the characters: paragraphs, table cells, fields, line breaks
  const blocks = []; let cur = '', row = [], lastCell = false, field = 0, hasTable = false;
  const flushRow = () => { if (row.length) { blocks.push({ row }); row = []; } };
  const para = () => { const s = cur; cur = ''; if (row.length) flushRow(); blocks.push({ p: s }); };
  for (let i = 0; i < text.length; i++) {
    const ch = text[i], c = ch.charCodeAt(0);
    if (c === 0x13) { field++; continue; } if (c === 0x14) { if (field) field = -field; continue; } if (c === 0x15) { field = 0; continue; }
    if (field > 0) continue;                       // field instructions (HYPERLINK …, PAGE …) are not text
    if (c === 7) { if (cur === '' && lastCell) { flushRow(); lastCell = false; } else { row.push(cur); cur = ''; lastCell = true; hasTable = true; } continue; }
    lastCell = false;
    if (c === 13) { para(); continue; } if (c === 11) { cur += '\n'; continue; } if (c === 12) { cur += '\f'; continue; } if (c === 9) { cur += '\t'; continue; }
    if (c === 1 || c === 8 || c < 32) continue; cur += ch;
  }
  if (cur) para(); flushRow();
  const inline = s => esc(s).replace(/\n/g, '<br>').replace(/\t/g, '&emsp;').replace(/\f/g, '');
  let html = '', i = 0;
  while (i < blocks.length) {
    const b = blocks[i];
    if (b.row) { let rows = ''; while (i < blocks.length && blocks[i].row) { rows += '<tr>' + blocks[i].row.map(c => `<td>${inline(c)}</td>`).join('') + '</tr>'; i++; } html += `<table>${rows}</table>`; continue; }
    html += b.p.trim() ? `<p>${inline(b.p)}</p>` : '<p><br></p>'; i++;
  }
  return html.replace(/(<p><br><\/p>){3,}/g, '<p><br></p>') || '<p><br></p>';
}

/* ============================ .xls (BIFF8) ============================ */
const BUILTIN_DATE = new Set([14, 15, 16, 17, 18, 19, 20, 21, 22, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 45, 46, 47, 50, 51, 52, 53, 54, 55, 56, 57, 58]);
const isDateFmt = s => { const t = s.replace(/"[^"]*"/g, '').replace(/\[[^\]]*\]/g, '').replace(/\\./g, ''); return /[dmyhs]/i.test(t) && !/^(general|0|0\.0+|#,##0.*)$/i.test(t); };
const pad = n => String(n).padStart(2, '0');
function serialToText(v, d1904) {
  const ms = Math.round((v - (d1904 ? 0 : (v < 61 ? -1 : 0))) * 864e5), base = d1904 ? Date.UTC(1904, 0, 1) : Date.UTC(1899, 11, 30), d = new Date(base + ms);
  const dt = `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`, tm = `${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`;
  return v < 1 ? tm : (v % 1 ? `${dt} ${tm}` : dt);
}
export function xlsToSheets(buf) {
  const cfb = readCfb(buf), wbS = cfb.streams.Workbook || cfb.streams.Book; if (!wbS) throw new Error('Excel ওয়ার্কবুক পাওয়া যায়নি');
  const u = wbS(), dv = new DataView(u.buffer, u.byteOffset, u.byteLength);
  const recs = []; for (let p = 0; p + 4 <= u.length;) { const id = dv.getUint16(p, true), len = dv.getUint16(p + 2, true); recs.push({ id, s: p + 4, e: p + 4 + len, at: p }); p += 4 + len; }
  const readUStr = (o, cch, grbit) => (grbit & 1) ? [utf16(u.subarray(o, o + cch * 2)), o + cch * 2] : [cp1252(u.subarray(o, o + cch)), o + cch];
  const sst = [], bounds = [], fmts = {}, xfs = []; let d1904 = false;
  // --- globals
  for (let ri = 0; ri < recs.length; ri++) {
    const r = recs[ri];
    if (r.id === 0x0022) d1904 = dv.getUint16(r.s, true) === 1;
    else if (r.id === 0x0085) { const cch = u[r.s + 6], g = u[r.s + 7]; bounds.push({ pos: dv.getUint32(r.s, true), name: readUStr(r.s + 8, cch, g)[0], hidden: u[r.s + 4] }); }
    else if (r.id === 0x041E) { const id = dv.getUint16(r.s, true), cch = dv.getUint16(r.s + 2, true), g = u[r.s + 4]; fmts[id] = readUStr(r.s + 5, cch, g)[0]; }
    else if (r.id === 0x00E0) xfs.push(dv.getUint16(r.s + 2, true));
    else if (r.id === 0x00FC) {
      const chunks = [[r.s, r.e]]; let k = ri + 1; while (k < recs.length && recs[k].id === 0x003C) { chunks.push([recs[k].s, recs[k].e]); k++; }
      let ci = 0, pos = chunks[0][0]; const left = () => chunks[ci][1] - pos; const nextChunk = () => { ci++; pos = chunks[ci][0]; };
      const total = dv.getUint32(r.s + 4, true); pos = r.s + 8;
      for (let n = 0; n < total && ci < chunks.length; n++) {
        if (left() < 3) { if (ci + 1 >= chunks.length) break; nextChunk(); }
        const cch = dv.getUint16(pos, true), g = u[pos + 2]; pos += 3; let runs = 0, ext = 0; if (g & 8) { runs = dv.getUint16(pos, true); pos += 2; } if (g & 4) { ext = dv.getUint32(pos, true); pos += 4; }
        let str = '', remain = cch, wide = g & 1;
        while (remain > 0) {
          const bytes = wide ? 2 : 1, can = Math.min(remain, Math.floor(left() / bytes));
          if (can > 0) { str += wide ? utf16(u.subarray(pos, pos + can * 2)) : cp1252(u.subarray(pos, pos + can)); pos += can * bytes; remain -= can; }
          if (remain > 0) { if (ci + 1 >= chunks.length) break; nextChunk(); wide = u[pos] & 1; pos++; }
        }
        let skip = runs * 4 + ext; while (skip > 0) { const t = Math.min(skip, left()); pos += t; skip -= t; if (skip > 0) { if (ci + 1 >= chunks.length) break; nextChunk(); } }
        sst.push(str);
      }
    }
  }
  const dateXf = xi => { const f = xfs[xi]; if (f === undefined) return false; if (BUILTIN_DATE.has(f)) return true; return fmts[f] ? isDateFmt(fmts[f]) : false; };
  const rk = v => { let x; if (v & 2) x = v >> 2; else { const b = new DataView(new ArrayBuffer(8)); b.setUint32(4, v & 0xFFFFFFFC, true); x = b.getFloat64(0, true); } return (v & 1) ? x / 100 : x; };
  const sheets = [];
  for (const b of bounds) {
    const start = recs.findIndex(r => r.at === b.pos); if (start < 0) continue;
    const cells = new Map(); let depth = 0, maxR = 0, maxC = 0, lastFormula = null;
    const put = (r, c, v) => { if (v === '' || v === null || v === undefined) return; cells.set(r * 16384 + c, v); if (r > maxR) maxR = r; if (c > maxC) maxC = c; };
    const num = (xf, v) => dateXf(xf) ? serialToText(v, d1904) : v;
    for (let ri = start; ri < recs.length; ri++) {
      const r = recs[ri];
      if (r.id === 0x0809) { depth++; continue; } if (r.id === 0x000A) { depth--; if (depth <= 0) break; continue; } if (depth !== 1) continue;
      const row = r.e - r.s >= 4 ? dv.getUint16(r.s, true) : 0, col = r.e - r.s >= 4 ? dv.getUint16(r.s + 2, true) : 0, xf = r.e - r.s >= 6 ? dv.getUint16(r.s + 4, true) : 0;
      if (r.id === 0x00FD) put(row, col, sst[dv.getUint32(r.s + 6, true)]);
      else if (r.id === 0x0203) put(row, col, num(xf, dv.getFloat64(r.s + 6, true)));
      else if (r.id === 0x027E) put(row, col, num(xf, rk(dv.getUint32(r.s + 6, true))));
      else if (r.id === 0x00BD) { const last = dv.getUint16(r.e - 2, true); for (let c = col, o = r.s + 4; c <= last && o + 6 <= r.e - 2; c++, o += 6) put(row, c, num(dv.getUint16(o, true), rk(dv.getUint32(o + 2, true)))); }
      else if (r.id === 0x0204) { const cch = dv.getUint16(r.s + 6, true), g = u[r.s + 8]; put(row, col, readUStr(r.s + 9, cch, g)[0]); }
      else if (r.id === 0x0205) { if (u[r.s + 7] === 0) put(row, col, u[r.s + 6] ? 'TRUE' : 'FALSE'); }
      else if (r.id === 0x0006) { if (dv.getUint16(r.s + 12, true) === 0xFFFF) { const k = u[r.s + 6]; if (k === 0) lastFormula = [row, col]; else if (k === 1) put(row, col, u[r.s + 8] ? 'TRUE' : 'FALSE'); } else put(row, col, num(xf, dv.getFloat64(r.s + 6, true))); }
      else if (r.id === 0x0207 && lastFormula) { const cch = dv.getUint16(r.s, true), g = u[r.s + 2]; put(lastFormula[0], lastFormula[1], readUStr(r.s + 3, cch, g)[0]); lastFormula = null; }
    }
    const rows = []; const R = Math.min(maxR + 1, 20000), C = Math.min(maxC + 1, 500);
    for (let r = 0; r < R; r++) { const line = new Array(C).fill(''); for (let c = 0; c < C; c++) { const v = cells.get(r * 16384 + c); if (v !== undefined) line[c] = v; } rows.push(line); }
    sheets.push({ name: b.name || 'Sheet' + (sheets.length + 1), rows: cells.size ? rows : [['']] });
  }
  if (!sheets.length) throw new Error('কোনো শিট পাওয়া যায়নি');
  return sheets;
}
/** Build a minimal .xlsx (shared strings, numbers) from [{name, rows}] so the normal importer can open it. */
export async function sheetsToXlsx(sheets) {
  const JSZip = await needJSZip(), z = new JSZip(), strs = [], sidx = new Map();
  const si = s => { if (!sidx.has(s)) { sidx.set(s, strs.length); strs.push(s); } return sidx.get(s); };
  const colName = c => { let s = ''; c++; while (c > 0) { const m = (c - 1) % 26; s = String.fromCharCode(65 + m) + s; c = (c - m - 1) / 26 | 0; } return s; };
  const nm = sheets.map((s, i) => (String(s.name).replace(/[\\/?*[\]:]/g, ' ').slice(0, 31).trim() || 'Sheet' + (i + 1)));
  z.file('[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>${sheets.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`);
  z.file('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
  z.file('xl/workbook.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${nm.map((n, i) => `<sheet name="${esc(n)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets></workbook>`);
  z.file('xl/_rels/workbook.xml.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/></Relationships>`);
  sheets.forEach((s, i) => {
    let body = '';
    s.rows.forEach((row, r) => { let cs = ''; row.forEach((v, c) => { if (v === '' || v === null || v === undefined) return; const ref = colName(c) + (r + 1); cs += typeof v === 'number' && isFinite(v) ? `<c r="${ref}"><v>${v}</v></c>` : `<c r="${ref}" t="s"><v>${si(String(v))}</v></c>`; }); if (cs) body += `<row r="${r + 1}">${cs}</row>`; });
    z.file(`xl/worksheets/sheet${i + 1}.xml`, `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${body}</sheetData></worksheet>`);
  });
  z.file('xl/sharedStrings.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="${strs.length}" uniqueCount="${strs.length}">${strs.map(s => `<si><t xml:space="preserve">${esc(s)}</t></si>`).join('')}</sst>`);
  return z.generateAsync({ type: 'arraybuffer', compression: 'DEFLATE' });
}

/* ============================ .ppt ============================ */
export function pptToOutline(buf) {
  const cfb = readCfb(buf), ps = cfb.streams['PowerPoint Document']; if (!ps) throw new Error('PowerPoint ডকুমেন্ট পাওয়া যায়নি');
  const u = ps(), dv = new DataView(u.buffer, u.byteOffset, u.byteLength);
  const slwt = [], persist = [], containers = [], texts = [];   // text atoms in document order
  let pendingType = 1;
  const walk = (s, e) => {
    let p = s;
    while (p + 8 <= e) {
      const vi = dv.getUint16(p, true), type = dv.getUint16(p + 2, true), len = dv.getUint32(p + 4, true), ver = vi & 0xF, inst = vi >> 4, bs = p + 8, be = Math.min(e, bs + len);
      if (type === 4080 && inst === 0) slwt.push([bs, be]); if (type === 1006) containers.push([bs, be]);
      if (type === 1011) persist.push(bs);
      if (type === 3999) pendingType = dv.getUint32(bs, true);
      if (type === 4000 || type === 4008) texts.push({ at: bs, type: pendingType, text: type === 4000 ? utf16(u.subarray(bs, be)) : cp1252(u.subarray(bs, be)) });
      if (ver === 0xF) walk(bs, be); p = be;
    }
  };
  walk(0, u.length);
  const inR = (at, r) => at >= r[0] && at < r[1];
  const slides = persist.map(() => ({ title: '', body: [], extra: [] }));
  let si = -1;
  // slide text lives in SlideListWithText: a SlidePersistAtom starts each slide, text atoms follow it
  const events = [...persist.map(at => ({ at, k: 'slide' })), ...texts.filter(t => slwt.some(r => inR(t.at, r))).map(t => ({ at: t.at, k: 'text', t }))].sort((a, b) => a.at - b.at);
  for (const ev of events) {
    if (ev.k === 'slide') { si++; continue; } if (si < 0 || !slides[si]) continue;
    const lines = ev.t.text.split(/[\r\v\n]+/).map(s => s.trim()).filter(Boolean);
    if ((ev.t.type === 0 || ev.t.type === 6) && !slides[si].title) slides[si].title = lines.join(' '); else slides[si].body.push(...lines);
  }
  // text boxes drawn on the slide itself (not placeholders)
  containers.forEach((r, i) => { const s = slides[i]; if (!s) return; for (const t of texts) if (inR(t.at, r)) for (const l of t.text.split(/[\r\v\n]+/).map(x => x.trim()).filter(Boolean)) if (!s.body.includes(l) && s.title !== l) s.extra.push(l); });
  return slides.map(s => { const all = [...s.body, ...s.extra]; let title = s.title; if (!title && all.length) title = all.shift(); return { title, bullets: all }; }).filter(s => s.title || s.bullets.length);
}

/* ============================ .rtf ============================ */
export function rtfToHtml(rtf) {
  const SKIP = new Set(['fonttbl', 'colortbl', 'stylesheet', 'info', 'header', 'footer', 'headerl', 'headerr', 'footerl', 'footerr', 'pict', 'object', 'listtable', 'listoverridetable', 'generator', 'themedata', 'colorschememapping', 'datastore', 'latentstyles', 'xmlnstbl', 'revtbl', 'rsidtbl', 'fldinst', 'bkmkstart', 'bkmkend', 'shpinst', 'private']);
  let i = 0; const n = rtf.length, stack = []; let st = { b: 0, i: 0, u: 0, skip: 0 }, uc = 1, skipChars = 0;
  const blocks = []; let runs = [], row = [], tbl = [];
  const html = () => runs.map(r => { let t = esc(r.t).replace(/\t/g, '&emsp;'); if (r.b) t = `<b>${t}</b>`; if (r.i) t = `<i>${t}</i>`; if (r.u) t = `<u>${t}</u>`; return t; }).join('');
  const addText = s => { if (!s || st.skip) return; const l = runs[runs.length - 1]; if (l && l.b === st.b && l.i === st.i && l.u === st.u) l.t += s; else runs.push({ t: s, b: st.b, i: st.i, u: st.u }); };
  const flushTbl = () => { if (tbl.length) { blocks.push('<table>' + tbl.map(r => '<tr>' + r.map(c => `<td>${c}</td>`).join('') + '</tr>').join('') + '</table>'); tbl = []; } };
  const endPara = () => { const h = html(); runs = []; if (tbl.length && !row.length && !h.trim()) { flushTbl(); return; } flushTbl(); blocks.push(h.trim() ? `<p>${h}</p>` : '<p><br></p>'); };
  let first = true;
  while (i < n) {
    const c = rtf[i];
    if (c === '{') { stack.push({ ...st }); i++; first = true; continue; }
    if (c === '}') { st = stack.pop() || st; i++; first = false; continue; }
    if (c === '\r' || c === '\n') { i++; continue; }
    if (c === '\\') {
      const d = rtf[i + 1];
      if (d === '\\' || d === '{' || d === '}') { if (skipChars) skipChars--; else addText(d); i += 2; first = false; continue; }
      if (d === '*') { st.skip = 1; i += 2; continue; }
      if (d === "'") { const v = parseInt(rtf.substr(i + 2, 2), 16); if (skipChars) skipChars--; else addText(cp1252(new Uint8Array([v]))); i += 4; first = false; continue; }
      if (d === '~') { addText('\u00a0'); i += 2; continue; } if (d === '_') { addText('-'); i += 2; continue; }
      const m = /^\\([a-zA-Z]+)(-?\d+)? ?/.exec(rtf.substr(i, 40)); if (!m) { i += 2; continue; }
      const w = m[1], v = m[2] === undefined ? null : +m[2]; i += m[0].length;
      if (first && SKIP.has(w)) st.skip = 1; first = false;
      if (w === 'uc') uc = v; else if (w === 'u') { let cc = v < 0 ? v + 65536 : v; if (!st.skip) addText(String.fromCharCode(cc)); skipChars = uc; }
      else if (w === 'par' || w === 'sect') { if (!st.skip) endPara(); } else if (w === 'line') addText('\n'.replace('\n', ' ')); else if (w === 'tab') addText('\t');
      else if (w === 'b') st.b = v === 0 ? 0 : 1; else if (w === 'i') st.i = v === 0 ? 0 : 1; else if (w === 'ul') st.u = v === 0 ? 0 : 1; else if (w === 'ulnone') st.u = 0; else if (w === 'plain') { st.b = st.i = st.u = 0; }
      else if (w === 'cell') { row.push(html()); runs = []; } else if (w === 'row') { tbl.push(row); row = []; }
      else if (w === 'emdash') addText('—'); else if (w === 'endash') addText('–'); else if (w === 'bullet') addText('•'); else if (w === 'lquote') addText('‘'); else if (w === 'rquote') addText('’'); else if (w === 'ldblquote') addText('“'); else if (w === 'rdblquote') addText('”');
      continue;
    }
    // plain text run
    let j = i; while (j < n && rtf[j] !== '\\' && rtf[j] !== '{' && rtf[j] !== '}' && rtf[j] !== '\r' && rtf[j] !== '\n') j++;
    let seg = rtf.slice(i, j); i = j; first = false;
    if (skipChars) { const k = Math.min(skipChars, seg.length); seg = seg.slice(k); skipChars -= k; }
    addText(seg);
  }
  if (runs.length) endPara(); flushTbl();
  return blocks.join('').replace(/(<p><br><\/p>){3,}/g, '<p><br></p>') || '<p><br></p>';
}

/* ============================ OpenDocument ============================ */
const parseXml = s => new DOMParser().parseFromString(s, 'application/xml');
const kids = el => [...el.childNodes];
async function odfZip(file) { const JSZip = await needJSZip(), z = await JSZip.loadAsync(await readBuf(file)); const c = z.file('content.xml'); if (!c) throw new Error('content.xml নেই'); return { z, doc: parseXml(await c.async('string')) }; }
function odfStyles(doc) {
  const map = {}, ord = new Set();
  for (const s of doc.getElementsByTagName('style:style')) { const tp = s.getElementsByTagName('style:text-properties')[0]; if (!tp) continue; map[s.getAttribute('style:name')] = { b: /bold/.test(tp.getAttribute('fo:font-weight') || ''), i: /italic/.test(tp.getAttribute('fo:font-style') || ''), u: (tp.getAttribute('style:text-underline-style') || 'none') !== 'none' }; }
  for (const s of doc.getElementsByTagName('text:list-style')) if (s.getElementsByTagName('text:list-level-style-number').length) ord.add(s.getAttribute('style:name'));
  return { map, ord };
}
export async function odtToHtml(file) {
  const { z, doc } = await odfZip(file), { map, ord } = odfStyles(doc), body = doc.getElementsByTagName('office:text')[0]; if (!body) throw new Error('লেখা পাওয়া যায়নি');
  const imgs = {}; for (const name of Object.keys(z.files)) if (/^Pictures\/.+\.(png|jpe?g|gif|webp)$/i.test(name)) { const ext = extOf(name); imgs[name] = `data:image/${ext === 'jpg' ? 'jpeg' : ext};base64,` + await z.file(name).async('base64'); }
  const inl = el => kids(el).map(k => {
    if (k.nodeType === 3) return esc(k.nodeValue); if (k.nodeType !== 1) return '';
    const t = k.nodeName;
    if (t === 'text:span' || t === 'text:a') { let s = inl(k); const f = map[k.getAttribute('text:style-name')]; if (f) { if (f.b) s = `<b>${s}</b>`; if (f.i) s = `<i>${s}</i>`; if (f.u) s = `<u>${s}</u>`; } if (t === 'text:a' && /^https?:/.test(k.getAttribute('xlink:href') || '')) s = `<a href="${esc(k.getAttribute('xlink:href'))}">${s}</a>`; return s; }
    if (t === 'text:line-break') return '<br>'; if (t === 'text:tab') return '&emsp;'; if (t === 'text:s') return '&nbsp;'.repeat(+k.getAttribute('text:c') || 1);
    if (t === 'draw:frame') { const im = k.getElementsByTagName('draw:image')[0]; const src = im && imgs[im.getAttribute('xlink:href')]; return src ? `<img src="${src}">` : ''; }
    return inl(k);
  }).join('');
  const blk = el => kids(el).map(k => {
    if (k.nodeType !== 1) return ''; const t = k.nodeName;
    if (t === 'text:p') { const f = map[k.getAttribute('text:style-name')]; let s = inl(k); if (f && f.b && s) s = `<b>${s}</b>`; return s.trim() ? `<p>${s}</p>` : '<p><br></p>'; }
    if (t === 'text:h') return `<h${Math.min(6, +k.getAttribute('text:outline-level') || 1)}>${inl(k)}</h${Math.min(6, +k.getAttribute('text:outline-level') || 1)}>`;
    if (t === 'text:list') { const tag = ord.has(k.getAttribute('text:style-name')) ? 'ol' : 'ul'; return `<${tag}>${kids(k).filter(x => x.nodeName === 'text:list-item').map(li => `<li>${blk(li).replace(/^<p>|<\/p>$/g, '')}</li>`).join('')}</${tag}>`; }
    if (t === 'table:table') return '<table>' + kids(k).filter(r => r.nodeName === 'table:table-row' || r.nodeName === 'table:table-header-rows').flatMap(r => r.nodeName === 'table:table-row' ? [r] : kids(r)).filter(r => r.nodeName === 'table:table-row').map(r => '<tr>' + kids(r).filter(c => c.nodeName === 'table:table-cell').map(c => `<td>${blk(c).replace(/^<p>|<\/p>$/g, '')}</td>`).join('') + '</tr>').join('') + '</table>';
    if (t === 'text:section') return blk(k); return '';
  }).join('');
  return blk(body) || '<p><br></p>';
}
export async function odsToSheets(file) {
  const { doc } = await odfZip(file), out = [];
  for (const tb of doc.getElementsByTagName('table:table')) {
    const rows = []; let maxC = 0;
    for (const tr of tb.getElementsByTagName('table:table-row')) {
      const rep = Math.min(+tr.getAttribute('table:number-rows-repeated') || 1, 200), line = [];
      for (const c of kids(tr)) {
        if (c.nodeName !== 'table:table-cell' && c.nodeName !== 'table:covered-table-cell') continue;
        const cr = Math.min(+c.getAttribute('table:number-columns-repeated') || 1, 200), vt = c.getAttribute('office:value-type'); let v = '';
        if (vt === 'float' || vt === 'percentage' || vt === 'currency') v = +c.getAttribute('office:value'); else if (vt === 'date') v = (c.getAttribute('office:date-value') || '').replace('T', ' ').replace(/:\d\d(\.\d+)?$/, ''); else if (vt === 'boolean') v = c.getAttribute('office:boolean-value') === 'true' ? 'TRUE' : 'FALSE';
        else v = [...c.getElementsByTagName('text:p')].map(p => p.textContent).join('\n');
        for (let k = 0; k < cr; k++) line.push(v);
      }
      while (line.length && line[line.length - 1] === '') line.pop(); if (line.length > maxC) maxC = line.length;
      for (let k = 0; k < rep; k++) rows.push(line);
    }
    while (rows.length && !rows[rows.length - 1].length) rows.pop();
    out.push({ name: tb.getAttribute('table:name') || 'Sheet' + (out.length + 1), rows: rows.length ? rows.map(r => r.concat(new Array(Math.max(0, maxC - r.length)).fill(''))) : [['']] });
  }
  if (!out.length) throw new Error('কোনো শিট পাওয়া যায়নি'); return out;
}
export async function odpToOutline(file) {
  const { doc } = await odfZip(file), slides = [], SKIP = new Set(['page-number', 'footer', 'date-time', 'header']);
  for (const pg of doc.getElementsByTagName('draw:page')) {
    let title = '', bullets = [];
    for (const el of kids(pg)) {
      if (el.nodeType !== 1 || !/^draw:(frame|custom-shape|g|rect|ellipse)$/.test(el.nodeName)) continue;
      const cls = el.getAttribute('presentation:class') || ''; if (SKIP.has(cls)) continue;
      const lines = [...el.getElementsByTagName('text:p')].map(p => p.textContent.trim()).filter(l => l && !/^<(number|date\/time|footer|header)>$/.test(l));
      if (!lines.length) continue; if (!title && cls === 'title') title = lines.join(' '); else bullets.push(...lines);
    }
    if (!title && bullets.length) title = bullets.shift(); if (title || bullets.length) slides.push({ title, bullets });
  }
  if (!slides.length) throw new Error('কোনো স্লাইড পাওয়া যায়নি'); return slides;
}

/* ============================ entry point ============================ */
const asOutline = (slides, name) => ({ theme: 'clean', title: slides[0].title || name, subtitle: slides[0].bullets.slice(0, 2).join(' · '), slides: slides.slice(1) });
/**
 * Converts a foreign file into the app's own format. Resolves null when the extension is not handled,
 * else { kind, name, buf, snap, note }.
 */
export async function convertForeign(file) {
  const ext = extOf(file.name), base = baseName(file.name);
  if (!FOREIGN.includes(ext)) return null;
  const word = async html => { const m = await import('./word.js'); return { kind: 'word', ...(await m.importFile(new File([`<html><body>${html}</body></html>`], base + '.html', { type: 'text/html' }))) }; };
  const excel = async sheets => { const m = await import('./sheet.js'); return { kind: 'excel', ...(await m.importFile(new File([await sheetsToXlsx(sheets)], base + '.xlsx'))) }; };
  const ppt = async slides => { const m = await import('./slides.js'); return { kind: 'ppt', ...(await m.fromOutline(asOutline(slides, base))), name: base + '.pptx' }; };
  const NOTE = 'পুরনো ফরম্যাট থেকে লেখা ও টেবিল আনা হয়েছে — ফন্ট/ছবি/চার্ট বাদ যেতে পারে';
  let r;
  if (ext === 'doc') r = await word(docToHtml(await readBuf(file)));
  else if (ext === 'rtf') r = await word(rtfToHtml(await readText(file)));
  else if (ext === 'odt') r = await word(await odtToHtml(file));
  else if (ext === 'xls') r = await excel(xlsToSheets(await readBuf(file)));
  else if (ext === 'ods') r = await excel(await odsToSheets(file));
  else if (ext === 'ppt' || ext === 'pps') { const s = pptToOutline(await readBuf(file)); if (!s.length) throw new Error('স্লাইডে কোনো লেখা পাওয়া যায়নি'); r = await ppt(s); }
  else if (ext === 'odp') r = await ppt(await odpToOutline(file));
  r.note = NOTE; return r;
}
