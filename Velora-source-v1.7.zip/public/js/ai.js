// Velora AI — Google Gemini (free API key from Google AI Studio). Key stays on the phone.
import { h, icon, modal, sheet, toast, errMsg, withBusy, busy, blobToB64, pickFiles, loadImage } from './util.js';
import { db, uniqueName } from './db.js';
import { screen } from './screen.js';

const BASE = 'https://generativelanguage.googleapis.com/v1beta';
let cfg = null;
const load = async () => cfg ||= { key: '', model: '', good: '', ...(await db.kvGet('ai', {})) };
const persist = () => db.kvSet('ai', cfg);
export async function hasKey() { return !!(await load()).key; }
export async function aiConfig() { return load(); }
export async function clearKey() { const c = await load(); c.key = ''; c.models = null; c.good = ''; await persist(); }

const SYSTEM = 'You are Velora AI, an assistant inside an office app (Word, Excel, PowerPoint, PDF). Reply in the same language the user writes in (Bangla by default). Be practical and concise. When asked to write a document, produce clean, ready-to-use text with no extra commentary.';

/* ---------- key setup ---------- */
function onRemoved(el, cb) { const o = new MutationObserver(() => { if (!document.body.contains(el)) { o.disconnect(); cb(); } }); o.observe(document.body, { childList: true }); }
export function aiSetup() {
  return new Promise(async res => {
    const c = await load(); let ok = false;
    const inp = h('input', { class: 'inp', type: 'password', placeholder: 'AIza…', value: c.key || '', autocomplete: 'off', spellcheck: 'false' });
    const body = h('div', null,
      h('p', { class: 'modal-p' }, 'Gemini AI ব্যবহার করতে একটি বিনামূল্যের API কী লাগে (ক্রেডিট কার্ড লাগে না):'),
      h('ol', { class: 'ai-steps' }, h('li', null, 'Google AI Studio খুলুন → লগইন করুন'), h('li', null, '"Create API key" চাপুন'), h('li', null, 'কী-টি কপি করে নিচে বসান')),
      h('a', { class: 'ai-link', href: 'https://aistudio.google.com/apikey', target: '_blank', rel: 'noopener' }, 'aistudio.google.com/apikey ↗'),
      inp, h('div', { class: 'hint' }, 'কী শুধু আপনার ফোনে থাকে। AI ব্যবহার করলে আপনার লেখা/ছবি Google-এ যায় — গোপন তথ্য পাঠাবেন না।'));
    const ov = modal({
      title: 'AI চালু করুন', body, actions: [
        { label: 'বাতিল', ghost: true },
        {
          label: 'পরীক্ষা ও সেভ', primary: true, onClick: async () => {
            const k = inp.value.trim(); if (!k) { toast('কী বসান'); return false; }
            try { const models = await fetchModels(k); c.key = k; c.models = models; c.modelsAt = Date.now(); c.good = ''; await persist(); ok = true; toast('AI চালু হয়েছে ✓'); }
            catch (e) { toast(errMsg(e), 4200); return false; }
          }
        }]
    });
    onRemoved(ov.el, () => res(ok));
  });
}
export async function ensureKey() { return (await hasKey()) || aiSetup(); }

/* ---------- Gemini REST ---------- */
class AiError extends Error { constructor(msg, status) { super(msg); this.status = status; } }
function friendly(status, j) {
  const m = (j && j.error && j.error.message) || ''; 
  if (status === 400 && /api key/i.test(m)) return new AiError('API কী ঠিক নয় — সেটিংসে আবার বসান', status);
  if (status === 403) return new AiError('এই কী দিয়ে অনুমতি নেই — নতুন কী বানিয়ে দেখুন', status);
  if (status === 429) return new AiError('ফ্রি লিমিট শেষ — এক মিনিট পরে আবার চেষ্টা করুন', status);
  if (status === 404) return new AiError('মডেল পাওয়া যায়নি', status);
  if (status === 503 || status === 500) return new AiError('Google-এর সার্ভার এখন ব্যস্ত', status);
  return new AiError(m ? m.slice(0, 140) : 'AI-তে সমস্যা (' + status + ')', status);
}
async function fetchModels(key) {
  let r; try { r = await fetch(`${BASE}/models?pageSize=200`, { headers: { 'x-goog-api-key': key } }); } catch { throw new AiError('ইন্টারনেট সংযোগ নেই', 0); }
  const j = await r.json().catch(() => ({})); if (!r.ok) throw friendly(r.status, j);
  return (j.models || []).filter(m => (m.supportedGenerationMethods || []).includes('generateContent')).map(m => m.name.replace(/^models\//, ''));
}
const verOf = n => { const m = /gemini-(\d+(?:\.\d+)?)/.exec(n); return m ? parseFloat(m[1]) : 0; };
export function rankModels(models, kind) {
  let ok;
  if (kind === 'image') ok = models.filter(n => /^gemini-/.test(n) && /image/.test(n) && !/tts|live|audio/.test(n));
  else ok = models.filter(n => /^gemini-/.test(n) && /flash/.test(n) && !/image|tts|live|audio|embedding|robotics|computer|native|exp|thinking|8b/i.test(n));
  const rank = n => verOf(n) * 10 + (/lite/.test(n) ? 0 : 1) + (/preview/.test(n) ? -100 : 0);
  return ok.sort((a, b) => rank(b) - rank(a));
}
async function candidates(kind) {
  const c = await load(); let models = c.models; if (!models || !models.length || Date.now() - (c.modelsAt || 0) > 864e5) { models = await fetchModels(c.key); c.models = models; c.modelsAt = Date.now(); await persist(); }
  const list = rankModels(models, kind); const first = kind === 'text' ? [c.model, c.good].filter(Boolean) : [];
  return [...new Set([...first, ...list])].filter(n => models.includes(n) || n === c.model).slice(0, 6);
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

/**
 * generate({prompt, parts, contents, system, json, kind:'text'|'image', temperature, signal})
 * → text kind: string; image kind: {text, image:{mime,data(base64)}}
 */
export async function generate({ prompt, parts = [], contents, system = SYSTEM, json = false, kind = 'text', temperature = .5, signal } = {}) {
  if (!(await ensureKey())) throw new AiError('AI চালু করা হয়নি', 0);
  const c = await load(); const list = await candidates(kind);
  if (!list.length) throw new AiError(kind === 'image' ? 'এই কী-তে ছবি-AI মডেল পাওয়া যায়নি' : 'কোনো উপযুক্ত মডেল পাওয়া যায়নি', 404);
  const body = { contents: contents || [{ role: 'user', parts: [...parts, ...(prompt ? [{ text: prompt }] : [])] }], generationConfig: { temperature } };
  if (system && kind === 'text') body.systemInstruction = { parts: [{ text: system }] };
  if (json) body.generationConfig.responseMimeType = 'application/json';
  if (kind === 'image') body.generationConfig.responseModalities = ['TEXT', 'IMAGE'];
  let last = null;
  for (const model of list) {
    for (let attempt = 0; attempt < 2; attempt++) {
      let r, j;
      try {
        const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 110000); if (signal) signal.addEventListener('abort', () => ctl.abort());
        r = await fetch(`${BASE}/models/${model}:generateContent`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': c.key }, body: JSON.stringify(body), signal: ctl.signal });
        clearTimeout(to); j = await r.json().catch(() => ({}));
      } catch (e) { if (e.name === 'AbortError') throw new AiError('সময় শেষ — আবার চেষ্টা করুন', 0); last = new AiError('ইন্টারনেট সংযোগ নেই', 0); break; }
      if (r.ok) {
        const cand = j.candidates && j.candidates[0];
        if (!cand || !cand.content) { const why = (j.promptFeedback && j.promptFeedback.blockReason) || (cand && cand.finishReason); throw new AiError(why ? 'AI উত্তর দিতে পারেনি (' + why + ')' : 'AI খালি উত্তর দিয়েছে', 200); }
        const ps = cand.content.parts || []; const text = ps.filter(p => p.text && !p.thought).map(p => p.text).join('').trim();
        if (kind === 'image') { const im = ps.find(p => p.inlineData || p.inline_data); const d = im && (im.inlineData || im.inline_data); if (!d) throw new AiError(text ? text.slice(0, 140) : 'AI ছবি বানাতে পারেনি', 200); return { text, image: { mime: d.mimeType || d.mime_type || 'image/png', data: d.data } }; }
        if (!text) throw new AiError('AI খালি উত্তর দিয়েছে', 200);
        if (kind === 'text' && model !== c.good) { c.good = model; persist(); }
        return text;
      }
      last = friendly(r.status, j);
      if (r.status === 400 || r.status === 403) throw last;
      if (r.status === 429) {
        const m = /retry in ([\d.]+)s/i.exec((j.error && j.error.message) || ''); const wait = m ? Math.ceil(parseFloat(m[1])) : 0;
        if (/limit:\s*0/.test((j.error && j.error.message) || '')) { break; } // no free quota for this model at all
        if (attempt === 0 && wait > 0 && wait <= 25) { await sleep(wait * 1000 + 300); continue; }
      }
      break; // next model
    }
  }
  throw last || new AiError('AI-তে সমস্যা', 0);
}
export const stripFences = t => t.replace(/^```[a-z]*\s*/i, '').replace(/```\s*$/i, '').trim();
export const parseJSON = t => { try { return JSON.parse(stripFences(t)); } catch { const m = /[\[{][\s\S]*[\]}]/.exec(t); if (m) return JSON.parse(m[0]); throw new Error('AI-এর উত্তর বোঝা যায়নি, আবার চেষ্টা করুন'); } };
export async function fileToPart(file, maxSide = 1600, q = .85) {
  const url = URL.createObjectURL(file); try {
    const img = await loadImage(url); const sc = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight)); const c = document.createElement('canvas'); c.width = Math.round(img.naturalWidth * sc); c.height = Math.round(img.naturalHeight * sc);
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
    return canvasToPart(c, q);
  } finally { URL.revokeObjectURL(url); }
}
export async function canvasToPart(canvas, q = .85, maxSide = 1700) {
  let c = canvas; const sc = Math.min(1, maxSide / Math.max(canvas.width, canvas.height));
  if (sc < 1) { c = document.createElement('canvas'); c.width = Math.round(canvas.width * sc); c.height = Math.round(canvas.height * sc); c.getContext('2d').drawImage(canvas, 0, 0, c.width, c.height); }
  const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', q)); return { inlineData: { mimeType: 'image/jpeg', data: await blobToB64(blob) } };
}
/** AI call wrapped in a progress dialog and friendly error toast. Returns undefined on failure. */
export async function aiBusy(msg, fn) {
  try { return await withBusy(msg, fn); } catch (e) { console.warn(e); toast(errMsg(e), 4500); }
}

/* ---------- markdown → html (shared with Word) ---------- */
async function mdHtml(md) { const w = await import('./word.js'); return w.sanitize(w.mdToHtml(md)); }
const asFile = (html, name) => new File([`<html><body>${html}</body></html>`], name, { type: 'text/html' });
async function openAsWord(html, name = 'AI ডকুমেন্ট.html') { await window.__ao.importFiles([asFile(html, name)], { open: true }); }

/* ---------- chat ---------- */
const CHIPS = ['একটি চাকরির আবেদনপত্র লিখে দাও', 'এই লেখাটি সংক্ষেপ করো', 'ইংরেজি থেকে বাংলা অনুবাদ করো', 'একটি ব্যবসায়িক ইমেইল লিখে দাও', 'Excel-এ VLOOKUP কীভাবে কাজ করে?', 'আমার CV-র জন্য সামারি লিখে দাও'];
export async function aiChat({ title = 'AI সহায়ক', system = SYSTEM, context = '', contextParts = [], chips = CHIPS, intro } = {}) {
  if (!(await ensureKey())) return;
  const scr = screen({ title, cls: 'aichat' });
  const list = h('div', { class: 'chat-list' });
  const ta = h('textarea', { class: 'chat-in', rows: 1, placeholder: 'কিছু লিখুন বা জিজ্ঞাসা করুন…', 'aria-label': 'বার্তা' });
  let pendingImg = null; const imgTag = h('div', { class: 'chat-img', hidden: true });
  const attach = h('button', { class: 'iconbtn', type: 'button', 'aria-label': 'ছবি যোগ', onclick: async () => { const [f] = await pickFiles({ accept: 'image/*' }); if (!f) return; pendingImg = await fileToPart(f); imgTag.hidden = false; imgTag.replaceChildren(icon('image', 16), ' ছবি যোগ হয়েছে ', h('button', { type: 'button', onclick: () => { pendingImg = null; imgTag.hidden = true; } }, '✕')); } }, icon('image', 22));
  const send = h('button', { class: 'chat-send', type: 'button', 'aria-label': 'পাঠান' }, icon('arrowUp', 20));
  scr.body.append(list, h('div', { class: 'chat-bar' }, imgTag, h('div', { class: 'chat-row' }, attach, ta, send)));
  const history = []; let working = false;
  const sys = context ? system + '\n\nDocument the user is asking about (may be truncated):\n"""\n' + context.slice(0, 90000) + '\n"""' : system;
  const bubble = (role, node) => { const b = h('div', { class: 'msg ' + role }, node); list.append(b); list.scrollTop = list.scrollHeight; return b; };
  if (intro) bubble('ai', h('div', { class: 'md' }, intro));
  const chipRow = h('div', { class: 'chat-chips' }, chips.map(t => h('button', { type: 'button', class: 'chip', onclick: () => { ta.value = t; ask(); } }, t)));
  list.append(chipRow);
  ta.addEventListener('input', () => { ta.style.height = 'auto'; ta.style.height = Math.min(140, ta.scrollHeight) + 'px'; });
  async function ask() {
    const text = ta.value.trim(); if ((!text && !pendingImg) || working) return; working = true; chipRow.remove();
    const parts = []; if (!history.length && contextParts.length) parts.push(...contextParts); if (pendingImg) parts.push(pendingImg); parts.push({ text: text || 'এই ছবিটি সম্পর্কে বলুন' });
    history.push({ role: 'user', parts }); bubble('me', h('div', null, text, pendingImg ? h('div', { class: 'hint' }, '[ছবি সহ]') : null));
    ta.value = ''; ta.style.height = 'auto'; pendingImg = null; imgTag.hidden = true;
    const wait = bubble('ai', h('div', { class: 'typing' }, h('i'), h('i'), h('i')));
    try {
      const out = await generate({ contents: history, system: sys, temperature: .6 });
      history.push({ role: 'model', parts: [{ text: out }] });
      const md = h('div', { class: 'md' }); md.innerHTML = await mdHtml(out);
      const acts = h('div', { class: 'msg-acts' },
        h('button', { type: 'button', onclick: () => { navigator.clipboard && navigator.clipboard.writeText(out).then(() => toast('কপি হয়েছে')).catch(() => toast('কপি করা যায়নি')); } }, icon('copy', 16), ' কপি'),
        h('button', { type: 'button', onclick: async () => { scr.close(); await openAsWord(md.innerHTML, 'AI উত্তর.html'); } }, icon('word', 16), ' Word-এ নিন'));
      wait.replaceChildren(md, acts);
    } catch (e) { history.pop(); wait.replaceChildren(h('div', { class: 'err' }, errMsg(e))); }
    working = false; list.scrollTop = list.scrollHeight;
  }
  send.onclick = ask; ta.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey && !('ontouchstart' in window)) { e.preventDefault(); ask(); } });
  setTimeout(() => ta.focus(), 250);
}

/* ---------- generators: Word / PowerPoint / Excel ---------- */
const HTML_RULES = 'Output ONLY clean semantic HTML for the body (no <html>/<head>, no markdown fences, no CSS). Use h1/h2/h3, p, ul/ol/li, table/tr/th/td, b, i. Use a right-aligned date line with style="text-align:right" where natural.';
function askDialog({ title, label, placeholder, chips = [], extra, ok = 'তৈরি করুন' }) {
  return new Promise(res => {
    let out = null; const ta = h('textarea', { class: 'inp', rows: 4, placeholder }); const ex = extra ? extra() : null;
    const body = h('div', null, h('div', { class: 'hint', style: { margin: '0 0 6px' } }, label), ta, chips.length ? h('div', { class: 'chat-chips tight' }, chips.map(t => h('button', { type: 'button', class: 'chip', onclick: () => { ta.value = t; ta.focus(); } }, t))) : null, ex ? ex.el : null);
    const ov = modal({ title, body, actions: [{ label: 'বাতিল', ghost: true }, { label: ok, primary: true, onClick: () => { if (!ta.value.trim()) { toast('কী বানাতে হবে লিখুন'); return false; } out = { text: ta.value.trim(), extra: ex && ex.get() }; } }] });
    setTimeout(() => ta.focus(), 120); onRemoved(ov.el, () => res(out));
  });
}
export async function aiDocument() {
  if (!(await ensureKey())) return;
  const r = await askDialog({ title: 'AI দিয়ে ডকুমেন্ট', label: 'কী ধরনের ডকুমেন্ট লাগবে? বিস্তারিত লিখুন (নাম, তারিখ, বিষয়…)', placeholder: 'যেমন: ছুটির আবেদন — ৩ দিন, জ্বরের কারণে, স্কুলের প্রধান শিক্ষককে', chips: ['ছুটির আবেদনপত্র', 'চাকরির আবেদন ও CV', 'ব্যবসায়িক চিঠি', 'মিটিং কার্যবিবরণী', 'প্রজেক্ট রিপোর্ট', 'নোটিশ'] });
  if (!r) return;
  const html = await aiBusy('AI লিখছে…', async () => stripFences(await generate({ prompt: `Write this document in Bangla unless the request is in another language:\n${r.text}\n\n${HTML_RULES}`, temperature: .5 })));
  if (html) await openAsWord(await mdHtmlOrHtml(html), 'AI ডকুমেন্ট.html');
}
async function mdHtmlOrHtml(t) { const w = await import('./word.js'); return /<(p|h1|h2|h3|ul|ol|table)\b/i.test(t) ? w.sanitize(t) : w.sanitize(w.mdToHtml(t)); }

export async function aiPresentation() {
  if (!(await ensureKey())) return;
  const r = await askDialog({
    title: 'AI দিয়ে প্রেজেন্টেশন', label: 'প্রেজেন্টেশনের বিষয় কী?', placeholder: 'যেমন: ডিজিটাল বাংলাদেশ — সুযোগ ও চ্যালেঞ্জ', chips: ['স্টার্টআপ পিচ', 'স্বাস্থ্য সচেতনতা', 'প্রজেক্ট আপডেট', 'আমার বিদ্যালয়'],
    extra: () => { let n = 8, th = 'clean'; const nums = h('div', { class: 'seg' }, [5, 8, 10, 12].map(v => h('button', { type: 'button', class: v === n ? 'on' : '', onclick: e => { n = v; [...nums.children].forEach(b => b.classList.toggle('on', b === e.currentTarget)); } }, v + ' স্লাইড')));
      const ths = h('div', { class: 'seg' }, [['clean', 'নীল'], ['dark', 'ডার্ক'], ['warm', 'উষ্ণ'], ['green', 'সবুজ']].map(([v, t]) => h('button', { type: 'button', class: v === th ? 'on' : '', onclick: e => { th = v; [...ths.children].forEach(b => b.classList.toggle('on', b === e.currentTarget)); } }, t)));
      return { el: h('div', { style: { marginTop: '10px', display: 'grid', gap: '8px' } }, nums, ths), get: () => ({ n, th }) }; }
  });
  if (!r) return; const { n, th } = r.extra;
  const data = await aiBusy('স্লাইড বানাচ্ছে…', async () => parseJSON(await generate({
    json: true, temperature: .6, prompt: `Create a presentation outline about: ${r.text}\nLanguage: Bangla unless the topic is written in another language.\nReturn JSON only: {"title":string,"subtitle":string,"slides":[{"title":string,"bullets":[string,...],"notes":string}]}\nExactly ${n - 1} content slides (the title slide is added separately). Each slide has 3-5 short bullets (max 12 words each). Last slide is a summary / thank-you.`
  })));
  if (!data || !Array.isArray(data.slides)) return;
  const { fromOutline } = await import('./slides.js'); const f = await fromOutline({ theme: th, title: data.title || r.text.slice(0, 40), subtitle: data.subtitle || '', slides: data.slides });
  const meta = await db.create({ name: await uniqueName(f.name), buf: f.buf, snap: f.snap, kind: 'ppt' });
  await window.__ao.refresh(); window.__ao.openFile(meta.id);
}
export async function aiSheet() {
  if (!(await ensureKey())) return;
  const r = await askDialog({ title: 'AI দিয়ে Excel টেবিল', label: 'কী ধরনের টেবিল/হিসাব লাগবে?', placeholder: 'যেমন: মাসিক বাজেট — আয়, খরচ ও সঞ্চয় সহ, মোট ও গড় হিসাব করা', chips: ['মাসিক বাজেট', 'ছাত্রদের নম্বরের তালিকা (গ্রেড সহ)', 'দোকানের বিক্রয় হিসাব', 'উপস্থিতি রেজিস্টার'] });
  if (!r) return;
  const csv = await aiBusy('টেবিল বানাচ্ছে…', async () => stripFences(await generate({ temperature: .4, prompt: `Create a spreadsheet for: ${r.text}\nOutput ONLY valid CSV (comma separated, quote cells containing commas). First row = headers (Bangla unless requested otherwise). Add 8-15 realistic sample rows. Use Excel formulas where useful, written like =SUM(B2:B10) or =B2*C2 (cell references must be correct), e.g. a totals row. No explanation, no markdown fences.` })));
  if (csv) await window.__ao.importFiles([new File(['\ufeff' + csv], 'AI টেবিল.csv', { type: 'text/csv' })], { open: true });
}

/* ---------- Word editor assistant ---------- */
const TEXT_ACTIONS = [
  ['ভুল ঠিক করুন', 'বানান ও ব্যাকরণ', 'Fix spelling, grammar and punctuation. Keep the meaning, tone and language. Return only the corrected text.'],
  ['সংক্ষেপ করুন', 'ছোট করে লিখুন', 'Summarise this concisely, keeping the key points. Same language. Return only the summary.'],
  ['বিস্তারিত করুন', 'আরও পূর্ণাঙ্গ লিখুন', 'Expand this with more detail and better flow, same language and tone. Return only the new text.'],
  ['আরও পেশাদার করুন', 'ফরমাল ভাষায়', 'Rewrite in a professional, formal tone. Same language. Return only the rewritten text.'],
  ['সহজ ভাষায় লিখুন', 'সহজ ও পরিষ্কার', 'Rewrite in simple, clear language anyone can understand. Same language. Return only the rewritten text.'],
  ['ইংরেজিতে অনুবাদ', 'Bangla → English', 'Translate to natural English. Return only the translation.'],
  ['বাংলায় অনুবাদ', 'English → বাংলা', 'Translate to natural Bangla. Return only the translation.'],
];
/** api: { getSelected():string, getAll():string, replaceSelected(html), replaceAll(html), insertHtml(html) } */
export async function wordAssistant(api) {
  if (!(await ensureKey())) return;
  const sel = api.getSelected().trim(); const target = sel || api.getAll().trim(); const scope = sel ? 'নির্বাচিত লেখা' : 'পুরো ডকুমেন্ট';
  const run = async (instruction, text, mode) => {
    const out = await aiBusy('AI কাজ করছে…', async () => stripFences(await generate({ prompt: `${instruction}\n\nTEXT:\n"""\n${text.slice(0, 60000)}\n"""`, temperature: .4 })));
    if (!out) return; const html = await mdHtmlOrHtml(out); const prev = h('div', { class: 'md ai-prev' }); prev.innerHTML = html;
    modal({
      title: 'AI-এর উত্তর', body: prev, wide: true, actions: [
        { label: 'বাতিল', ghost: true },
        { label: 'নিচে যোগ করুন', ghost: true, onClick: () => { api.insertHtml(html); } },
        ...(mode === 'edit' ? [{ label: sel ? 'বদলে দিন' : 'সব বদলান', primary: true, onClick: () => { sel ? api.replaceSelected(html) : api.replaceAll(html); } }] : [{ label: 'ঠিক আছে', primary: true }])]
    });
  };
  const items = [{ title: 'AI সহায়ক — ' + scope }];
  if (target) for (const [t, sub, ins] of TEXT_ACTIONS) items.push({ icon: 'sparkle', label: t, sub, onClick: () => run(ins, target, 'edit') });
  items.push({ sep: true },
    { icon: 'pen', label: 'নিজের নির্দেশ দিন', sub: 'যেমন: "এটি আরও আকর্ষণীয় করো"', onClick: async () => { const r = await askDialog({ title: 'নির্দেশ', label: 'AI-কে কী করতে হবে?', placeholder: 'যেমন: প্রথম অনুচ্ছেদে একটি ভূমিকা যোগ করো', ok: 'করুন' }); if (r) run(r.text + '\nReturn only the resulting text.', target || '(খালি ডকুমেন্ট)', 'edit'); } },
    { icon: 'word', label: 'নতুন লেখা লেখান', sub: 'বিষয় দিলে AI লিখবে', onClick: async () => { const r = await askDialog({ title: 'AI দিয়ে লিখুন', label: 'কী লিখতে হবে?', placeholder: 'যেমন: পরিবেশ দূষণ নিয়ে ৩ অনুচ্ছেদের রচনা' }); if (r) run('Write the following in Bangla unless requested otherwise. ' + HTML_RULES + '\nRequest: ' + r.text, '(none)', 'insert'); } },
    { icon: 'sparkle', label: 'AI চ্যাট খুলুন', onClick: () => aiChat({ context: target }) });
  sheet('', items);
}
