// Spreadsheet formula engine: parser + evaluator + ~170 Excel functions.
import { formatValue, general, serialParts, dateToSerial } from './numfmt.js';

export const MAXR = 1048575, MAXC = 16383;
export const colName = c => { let s = ''; c++; while (c > 0) { const m = (c - 1) % 26; s = String.fromCharCode(65 + m) + s; c = Math.floor((c - 1) / 26); } return s; };
export const colIndex = s => { let n = 0; for (const ch of s.toUpperCase()) n = n * 26 + ch.charCodeAt(0) - 64; return n - 1; };
export const addr = (r, c) => colName(c) + (r + 1);
export function parseAddr(s) { const m = /^\$?([A-Za-z]{1,3})\$?(\d+)$/.exec(s.trim()); return m ? { r: +m[2] - 1, c: colIndex(m[1]) } : null; }
export function parseRange(s) {
  s = s.trim(); const [a, b] = s.split(':'); const p = parseAddr(a); if (!p) return null; const q = b ? parseAddr(b) : p; if (!q) return null;
  return { r1: Math.min(p.r, q.r), c1: Math.min(p.c, q.c), r2: Math.max(p.r, q.r), c2: Math.max(p.c, q.c) };
}
export const rangeStr = g => g.r1 === g.r2 && g.c1 === g.c2 ? addr(g.r1, g.c1) : addr(g.r1, g.c1) + ':' + addr(g.r2, g.c2);
const E = code => ({ err: code });
export const isErr = v => v !== null && typeof v === 'object' && v.err !== undefined;
const ERRS = ['#DIV/0!', '#N/A', '#NAME?', '#NULL!', '#NUM!', '#REF!', '#VALUE!'];

/* ---------------- tokenizer ---------------- */
function tokenize(src) {
  const t = []; let i = 0; const n = src.length;
  while (i < n) {
    const ch = src[i];
    if (/\s/.test(ch)) { i++; continue; }
    const rest = src.slice(i); let m;
    if (ch === '"') { let j = i + 1, s = ''; for (; j < n; j++) { if (src[j] === '"') { if (src[j + 1] === '"') { s += '"'; j++; } else break; } else s += src[j]; } t.push({ k: 'str', v: s, p: i, e: j + 1 }); i = j + 1; continue; }
    if ((m = /^#(DIV\/0!|N\/A|NAME\?|NULL!|NUM!|REF!|VALUE!)/i.exec(rest))) { t.push({ k: 'err', v: m[0].toUpperCase(), p: i, e: i + m[0].length }); i += m[0].length; continue; }
    let sheet = null, sp = i;
    if ((m = /^(?:'((?:[^']|'')+)'|([A-Za-z_\u0080-\uFFFF][\w.\u0080-\uFFFF]*))!/.exec(rest))) { sheet = (m[1] !== undefined ? m[1].replace(/''/g, "'") : m[2]); i += m[0].length; }
    const r2 = src.slice(i);
    if ((m = /^(\$?)([A-Za-z]{1,3})(\$?)(\d+)(?![\w(.])/.exec(r2))) { t.push({ k: 'ref', sheet, ac: !!m[1], c: colIndex(m[2]), ar: !!m[3], r: +m[4] - 1, p: sp, e: i + m[0].length }); i += m[0].length; continue; }
    if ((m = /^(\$?)([A-Za-z]{1,3}):(\$?)([A-Za-z]{1,3})(?![\w(])/.exec(r2))) { t.push({ k: 'colrange', sheet, ac1: !!m[1], c1: colIndex(m[2]), ac2: !!m[3], c2: colIndex(m[4]), p: sp, e: i + m[0].length }); i += m[0].length; continue; }
    if ((m = /^(\$?)(\d+):(\$?)(\d+)(?![\w(])/.exec(r2))) { t.push({ k: 'rowrange', sheet, ar1: !!m[1], r1: +m[2] - 1, ar2: !!m[3], r2: +m[4] - 1, p: sp, e: i + m[0].length }); i += m[0].length; continue; }
    if (sheet !== null) { t.push({ k: 'err', v: '#REF!', p: sp, e: i }); continue; }
    if ((m = /^(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?/.exec(rest))) { t.push({ k: 'num', v: parseFloat(m[0]), p: i, e: i + m[0].length }); i += m[0].length; continue; }
    if ((m = /^[A-Za-z_\u0080-\uFFFF][\w.\u0080-\uFFFF]*/.exec(rest))) { const nx = rest[m[0].length]; if (nx === '(') t.push({ k: 'fn', v: m[0].toUpperCase(), p: i, e: i + m[0].length }); else t.push({ k: 'id', v: m[0], p: i, e: i + m[0].length }); i += m[0].length; continue; }
    if ((m = /^(<=|>=|<>)/.exec(rest))) { t.push({ k: 'op', v: m[0], p: i, e: i + 2 }); i += 2; continue; }
    if ('+-*/^&=<>%(),;:{}'.includes(ch)) { t.push({ k: 'op', v: ch, p: i, e: i + 1 }); i++; continue; }
    throw new Error('Unexpected ' + ch);
  }
  return t;
}

/* ---------------- parser ---------------- */
const astCache = new Map();
export function parse(src) {
  if (astCache.has(src)) return astCache.get(src);
  let ast;
  try { const toks = tokenize(src); let p = 0; ast = parseExpr(); if (p < toks.length) throw new Error('trailing'); function peek() { return toks[p]; } function eat(v) { const x = toks[p]; if (x && x.k === 'op' && x.v === v) { p++; return true; } return false; }
    function parseExpr() { return parseCmp(); }
    function parseCmp() { let a = parseCat(); for (;;) { const x = peek(); if (x && x.k === 'op' && ['=', '<>', '<', '>', '<=', '>='].includes(x.v)) { p++; a = { t: 'bin', op: x.v, a, b: parseCat() }; } else return a; } }
    function parseCat() { let a = parseAdd(); while (peek() && peek().k === 'op' && peek().v === '&') { p++; a = { t: 'bin', op: '&', a, b: parseAdd() }; } return a; }
    function parseAdd() { let a = parseMul(); for (;;) { const x = peek(); if (x && x.k === 'op' && (x.v === '+' || x.v === '-')) { p++; a = { t: 'bin', op: x.v, a, b: parseMul() }; } else return a; } }
    function parseMul() { let a = parsePow(); for (;;) { const x = peek(); if (x && x.k === 'op' && (x.v === '*' || x.v === '/')) { p++; a = { t: 'bin', op: x.v, a, b: parsePow() }; } else return a; } }
    function parsePow() { let a = parseUn(); while (peek() && peek().k === 'op' && peek().v === '^') { p++; a = { t: 'bin', op: '^', a, b: parseUn() }; } return a; }
    function parseUn() { const x = peek(); if (x && x.k === 'op' && (x.v === '-' || x.v === '+')) { p++; const a = parseUn(); return x.v === '-' ? { t: 'un', a } : a; } return parsePost(); }
    function parsePost() { let a = parsePrim(); while (peek() && peek().k === 'op' && peek().v === '%') { p++; a = { t: 'pct', a }; } return a; }
    function parsePrim() {
      const x = toks[p++]; if (!x) throw new Error('eof');
      if (x.k === 'num') return { t: 'num', v: x.v };
      if (x.k === 'str') return { t: 'str', v: x.v };
      if (x.k === 'err') return { t: 'err', v: x.v };
      if (x.k === 'ref') {
        const nx = peek();
        if (nx && nx.k === 'op' && nx.v === ':' && toks[p + 1] && toks[p + 1].k === 'ref') { p += 2; const y = toks[p - 1]; return { t: 'range', sheet: x.sheet, r1: Math.min(x.r, y.r), c1: Math.min(x.c, y.c), r2: Math.max(x.r, y.r), c2: Math.max(x.c, y.c) }; }
        return { t: 'ref', sheet: x.sheet, r: x.r, c: x.c };
      }
      if (x.k === 'colrange') return { t: 'range', sheet: x.sheet, r1: 0, c1: Math.min(x.c1, x.c2), r2: MAXR, c2: Math.max(x.c1, x.c2) };
      if (x.k === 'rowrange') return { t: 'range', sheet: x.sheet, r1: Math.min(x.r1, x.r2), c1: 0, r2: Math.max(x.r1, x.r2), c2: MAXC };
      if (x.k === 'fn') {
        eat('('); const args = [];
        if (!eat(')')) { for (;;) { const nx = peek(); if (nx && nx.k === 'op' && (nx.v === ',' || nx.v === ';')) { args.push({ t: 'empty' }); p++; continue; } if (nx && nx.k === 'op' && nx.v === ')') { args.push({ t: 'empty' }); p++; break; } args.push(parseExpr()); if (eat(',') || eat(';')) { const n2 = peek(); if (n2 && n2.k === 'op' && n2.v === ')') { args.push({ t: 'empty' }); p++; break; } continue; } if (eat(')')) break; throw new Error('expected )'); } }
        return { t: 'fn', name: x.v, args };
      }
      if (x.k === 'id') { const u = x.v.toUpperCase(); if (u === 'TRUE') return { t: 'bool', v: true }; if (u === 'FALSE') return { t: 'bool', v: false }; return { t: 'name', v: x.v }; }
      if (x.k === 'op' && x.v === '(') { const e = parseExpr(); if (!eat(')')) throw new Error('expected )'); return e; }
      if (x.k === 'op' && x.v === '{') { const rows = [[]]; for (;;) { rows[rows.length - 1].push(parseExpr()); if (eat(',')) continue; if (eat(';')) { rows.push([]); continue; } if (eat('}')) break; throw new Error('array'); } return { t: 'arr', rows }; }
      throw new Error('unexpected token');
    }
  } catch (e) { ast = { t: 'err', v: '#NAME?', syntax: true }; }
  astCache.set(src, ast); return ast;
}

/* rewrite references in a formula string (copy/fill/insert/delete) */
export function transformRefs(src, fn) {
  let toks; try { toks = tokenize(src); } catch { return src; }
  let out = '', last = 0;
  const pre = t => (t.sheet != null ? (/^[A-Za-z_][\w.]*$/.test(t.sheet) ? t.sheet : "'" + t.sheet.replace(/'/g, "''") + "'") + '!' : '');
  for (let i = 0; i < toks.length; i++) {
    const t = toks[i];
    if (t.k === 'ref') {
      const nx = toks[i + 1], ny = toks[i + 2];
      if (nx && nx.k === 'op' && nx.v === ':' && ny && ny.k === 'ref') {
        const a = fn({ ...t }, t.sheet, 'start'), b = fn({ ...ny }, t.sheet, 'end');
        const rep = (a === null || b === null || a.r > b.r || a.c > b.c) ? '#REF!' : pre(t) + (t.ac ? '$' : '') + colName(a.c) + (t.ar ? '$' : '') + (a.r + 1) + ':' + (ny.ac ? '$' : '') + colName(b.c) + (ny.ar ? '$' : '') + (b.r + 1);
        out += src.slice(last, t.p) + rep; last = ny.e; i += 2; continue;
      }
      const a = fn({ ...t }, t.sheet, 'single');
      const rep = a === null ? '#REF!' : pre(t) + (t.ac ? '$' : '') + colName(a.c) + (t.ar ? '$' : '') + (a.r + 1);
      out += src.slice(last, t.p) + rep; last = t.e;
    }
  }
  return out + src.slice(last);
}
export function shiftFormula(src, dr, dc) {
  return transformRefs(src, t => ({ r: t.ar ? t.r : t.r + dr, c: t.ac ? t.c : t.c + dc })).replace(/([A-Za-z]{1,3})(\$?)(-\d+)/g, '#REF!');
}

/* ---------------- value helpers ---------------- */
const toNum = v => { if (isErr(v)) return v; if (v === null || v === undefined || v === '') return 0; if (typeof v === 'number') return v; if (typeof v === 'boolean') return v ? 1 : 0; if (typeof v === 'string') { const s = v.trim().replace(/,/g, ''); if (s === '') return E('#VALUE!'); if (/^[-+]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?%?$/.test(s)) return s.endsWith('%') ? parseFloat(s) / 100 : parseFloat(s); const d = parseDateStr(v); if (d !== null) return d; return E('#VALUE!'); } if (v.rows) return toNum(v.a[0][0]); return E('#VALUE!'); };
const toStr = v => { if (isErr(v)) return v; if (v === null || v === undefined) return ''; if (typeof v === 'number') return general(v); if (typeof v === 'boolean') return v ? 'TRUE' : 'FALSE'; return String(v); };
const toBool = v => { if (isErr(v)) return v; if (typeof v === 'boolean') return v; if (typeof v === 'number') return v !== 0; if (v === null || v === undefined || v === '') return false; if (typeof v === 'string') { const u = v.toUpperCase(); if (u === 'TRUE') return true; if (u === 'FALSE') return false; return E('#VALUE!'); } return false; };
export function parseDateStr(s) {
  s = String(s).trim(); let m;
  if ((m = /^(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?$/.exec(s))) return dateToSerial(+m[1], +m[2], +m[3]) + (m[4] ? (+m[4] * 3600 + +m[5] * 60 + (+m[6] || 0)) / 86400 : 0);
  if ((m = /^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4}|\d{2})$/.exec(s))) { let y = +m[3]; if (y < 100) y += y < 30 ? 2000 : 1900; const d = +m[1], mo = +m[2]; if (mo < 1 || mo > 12 || d < 1 || d > 31) return null; return dateToSerial(y, mo, d); }
  if ((m = /^(\d{1,2}):(\d{2})(?::(\d{2}))?$/.exec(s))) return (+m[1] * 3600 + +m[2] * 60 + (+m[3] || 0)) / 86400;
  return null;
}
const typeRank = v => typeof v === 'number' ? 0 : typeof v === 'string' ? 1 : typeof v === 'boolean' ? 2 : 3;
function compare(a, b) {
  if (a === null || a === undefined) a = typeof b === 'string' ? '' : typeof b === 'boolean' ? false : 0;
  if (b === null || b === undefined) b = typeof a === 'string' ? '' : typeof a === 'boolean' ? false : 0;
  const ra = typeRank(a), rb = typeRank(b); if (ra !== rb) return ra - rb;
  if (typeof a === 'string') { const x = a.toLowerCase(), y = b.toLowerCase(); return x < y ? -1 : x > y ? 1 : 0; }
  return a < b ? -1 : a > b ? 1 : 0;
}
function matcher(crit) {
  if (typeof crit === 'string') {
    const m = /^(<=|>=|<>|<|>|=)?(.*)$/s.exec(crit); const op = m[1] || '='; let val = m[2];
    const num = val !== '' && !isNaN(+val) ? +val : (val !== '' && parseDateStr(val) !== null ? parseDateStr(val) : null);
    if (num !== null && /^[-+\d.eE%/: ]+$/.test(val)) return x => { if (typeof x !== 'number') return op === '<>' ; const c = x - num; return op === '=' ? c === 0 : op === '<>' ? c !== 0 : op === '<' ? c < 0 : op === '>' ? c > 0 : op === '<=' ? c <= 0 : c >= 0; };
    if (val.toUpperCase() === 'TRUE' || val.toUpperCase() === 'FALSE') { const b = val.toUpperCase() === 'TRUE'; return x => op === '<>' ? x !== b : x === b; }
    if (/[*?]/.test(val) && (op === '=' || op === '<>')) { const re = new RegExp('^' + val.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/~\*/g, '\u0001').replace(/\*/g, '.*').replace(/\?/g, '.').replace(/\u0001/g, '\\*') + '$', 'i'); return x => (typeof x === 'string' ? re.test(x) : false) === (op === '='); }
    const lv = val.toLowerCase();
    return x => { if (op === '=') return val === '' ? (x === null || x === '' || x === undefined) : typeof x === 'string' && x.toLowerCase() === lv; if (op === '<>') return !(typeof x === 'string' && x.toLowerCase() === lv); if (typeof x !== 'string') return false; const c = x.toLowerCase() < lv ? -1 : x.toLowerCase() > lv ? 1 : 0; return op === '<' ? c < 0 : op === '>' ? c > 0 : op === '<=' ? c <= 0 : c >= 0; };
  }
  if (typeof crit === 'number') return x => typeof x === 'number' && x === crit;
  if (typeof crit === 'boolean') return x => x === crit;
  return x => x === null || x === undefined || x === '';
}

/* ---------------- engine ---------------- */
export class Engine {
  constructor(wb) { this.wb = wb; this.memo = new Map(); this.visiting = new Set(); this.now = Date.now(); }
  invalidate() { this.memo.clear(); this.now = Date.now(); }
  sheetIndex(name, cur) { if (name == null) return cur; const l = name.toLowerCase(); const i = this.wb.sheets.findIndex(s => s.name.toLowerCase() === l); return i; }
  raw(si, r, c) { const sh = this.wb.sheets[si]; return sh ? sh.cells[r + ',' + c] : undefined; }
  value(si, r, c) {
    const cell = this.raw(si, r, c); if (!cell) return null;
    if (cell.f === undefined || cell.f === null || cell.f === '') return cell.v === undefined ? null : cell.v;
    const key = si + ':' + r + ',' + c;
    if (this.memo.has(key)) return this.memo.get(key);
    if (this.visiting.has(key)) return E('#REF!');
    this.visiting.add(key);
    let v; try { v = this.evalNode(parse(cell.f), { si, r, c }); if (v && v.rows) v = v.a[0][0]; if (v === undefined) v = null; if (v && v.range) v = this.cellOf(v, 0, 0); } catch (e) { v = E('#VALUE!'); }
    this.visiting.delete(key); this.memo.set(key, v); return v;
  }
  cellOf(rg, dr, dc) { return this.value(rg.si, rg.r1 + dr, rg.c1 + dc); }
  /** Bounding box of the filled cells. Cached; the editor keeps it up to date incrementally (see noteUsed) and only sets _usedDirty when a boundary cell was removed. */
  used(si) { const sh = this.wb.sheets[si]; if (sh._used && !sh._usedDirty) return sh._used; let mr = -1, mc = -1; for (const k in sh.cells) { const i = k.indexOf(','); const r = +k.slice(0, i), c = +k.slice(i + 1); if (r > mr) mr = r; if (c > mc) mc = c; } sh._used = { r: mr, c: mc }; sh._usedDirty = false; return sh._used; }
  clampRange(rg) { const u = this.used(rg.si); return { ...rg, r2: Math.min(rg.r2, Math.max(u.r, rg.r1)), c2: Math.min(rg.c2, Math.max(u.c, rg.c1)) }; }
  /** iterate range cell values (clamped to used area) */
  each(rg, cb) { const g = this.clampRange(rg); for (let r = g.r1; r <= g.r2; r++) for (let c = g.c1; c <= g.c2; c++) cb(this.value(g.si, r, c), r, c); }
  toArr(x) { if (x && x.range) { const g = this.clampRange(x); const a = []; for (let r = g.r1; r <= g.r2; r++) { const row = []; for (let c = g.c1; c <= g.c2; c++) row.push(this.value(g.si, r, c)); a.push(row); } return a; } if (x && x.rows) return x.a; return [[x]]; }
  scalar(x) { if (x && x.range) return this.value(x.si, x.r1, x.c1); if (x && x.rows) return x.a[0][0]; return x; }
  evalNode(n, cx) {
    switch (n.t) {
      case 'num': case 'str': case 'bool': return n.v;
      case 'empty': return null;
      case 'err': return E(n.v);
      case 'name': return E('#NAME?');
      case 'ref': { const si = this.sheetIndex(n.sheet, cx.si); if (si < 0) return E('#REF!'); return this.value(si, n.r, n.c); }
      case 'range': { const si = this.sheetIndex(n.sheet, cx.si); if (si < 0) return E('#REF!'); return { range: true, si, r1: n.r1, c1: n.c1, r2: n.r2, c2: n.c2 }; }
      case 'arr': return { rows: true, a: n.rows.map(r => r.map(x => this.scalar(this.evalNode(x, cx)))) };
      case 'un': return this.unary(this.evalNode(n.a, cx), v => { const x = toNum(v); return isErr(x) ? x : -x; });
      case 'pct': return this.unary(this.evalNode(n.a, cx), v => { const x = toNum(v); return isErr(x) ? x : x / 100; });
      case 'bin': return this.binary(n.op, this.evalNode(n.a, cx), this.evalNode(n.b, cx));
      case 'fn': return this.call(n, cx);
    }
    return E('#VALUE!');
  }
  unary(v, f) { if (v && (v.range || v.rows)) return { rows: true, a: this.toArr(v).map(r => r.map(f)) }; return f(v); }
  binary(op, a, b) {
    if ((a && (a.range || a.rows)) || (b && (b.range || b.rows))) {
      const A = this.toArr(a), B = this.toArr(b); const R = Math.max(A.length, B.length), C = Math.max(A[0].length, B[0].length); const out = [];
      for (let i = 0; i < R; i++) { const row = []; for (let j = 0; j < C; j++) { const x = A[A.length === 1 ? 0 : i] && A[A.length === 1 ? 0 : i][A[0].length === 1 ? 0 : j], y = B[B.length === 1 ? 0 : i] && B[B.length === 1 ? 0 : i][B[0].length === 1 ? 0 : j]; row.push(x === undefined || y === undefined ? E('#N/A') : this.binary(op, x, y)); } out.push(row); }
      return { rows: true, a: out };
    }
    if (isErr(a)) return a; if (isErr(b)) return b;
    switch (op) {
      case '+': case '-': case '*': case '/': case '^': {
        const x = toNum(a), y = toNum(b); if (isErr(x)) return x; if (isErr(y)) return y;
        if (op === '+') return x + y; if (op === '-') return x - y; if (op === '*') return x * y;
        if (op === '/') return y === 0 ? E('#DIV/0!') : x / y;
        const r = Math.pow(x, y); return isNaN(r) ? E('#NUM!') : r;
      }
      case '&': return toStr(a) + toStr(b);
      default: { const c = compare(a, b); return op === '=' ? c === 0 : op === '<>' ? c !== 0 : op === '<' ? c < 0 : op === '>' ? c > 0 : op === '<=' ? c <= 0 : c >= 0; }
    }
  }
  call(n, cx) {
    const name = n.name, A = n.args;
    // lazy functions
    if (name === 'IF') { const c = toBool(this.scalar(this.evalNode(A[0], cx))); if (isErr(c)) return c; if (c) return A[1] ? this.scalar(this.evalNode(A[1], cx)) : true; return A[2] ? this.scalar(this.evalNode(A[2], cx)) : false; }
    if (name === 'IFERROR') { const v = this.scalar(this.evalNode(A[0], cx)); return isErr(v) ? this.scalar(this.evalNode(A[1], cx)) : v; }
    if (name === 'IFNA') { const v = this.scalar(this.evalNode(A[0], cx)); return isErr(v) && v.err === '#N/A' ? this.scalar(this.evalNode(A[1], cx)) : v; }
    if (name === 'IFS') { for (let i = 0; i + 1 < A.length; i += 2) { const c = toBool(this.scalar(this.evalNode(A[i], cx))); if (isErr(c)) return c; if (c) return this.scalar(this.evalNode(A[i + 1], cx)); } return E('#N/A'); }
    if (name === 'SWITCH') { const v = this.scalar(this.evalNode(A[0], cx)); let i = 1; for (; i + 1 < A.length; i += 2) { if (compare(v, this.scalar(this.evalNode(A[i], cx))) === 0) return this.scalar(this.evalNode(A[i + 1], cx)); } return i < A.length ? this.scalar(this.evalNode(A[i], cx)) : E('#N/A'); }
    if (name === 'CHOOSE') { const k = toNum(this.scalar(this.evalNode(A[0], cx))); if (isErr(k)) return k; const i = Math.floor(k); return i >= 1 && i < A.length ? this.evalNode(A[i], cx) : E('#VALUE!'); }
    if (name === 'ROW' || name === 'COLUMN') { if (!A.length) return name === 'ROW' ? cx.r + 1 : cx.c + 1; const v = this.evalNode(A[0], cx); if (v && v.range) return name === 'ROW' ? v.r1 + 1 : v.c1 + 1; return E('#VALUE!'); }
    if (name === 'ROWS' || name === 'COLUMNS') { const v = this.evalNode(A[0], cx); if (v && v.range) { const g = this.clampRangeFull(v); return name === 'ROWS' ? g.r2 - g.r1 + 1 : g.c2 - g.c1 + 1; } const a = this.toArr(v); return name === 'ROWS' ? a.length : a[0].length; }
    if (name === 'INDIRECT') { const s = toStr(this.scalar(this.evalNode(A[0], cx))); if (isErr(s)) return s; const m = /^(?:'?([^'!]+)'?!)?(.+)$/.exec(s); const rg = m && parseRange(m[2]); if (!rg) return E('#REF!'); const si = this.sheetIndex(m[1] || null, cx.si); if (si < 0) return E('#REF!'); return { range: true, si, ...rg }; }
    if (name === 'ISERROR' || name === 'ISERR' || name === 'ISNA') { const v = this.scalar(this.evalNode(A[0], cx)); return name === 'ISNA' ? isErr(v) && v.err === '#N/A' : name === 'ISERR' ? isErr(v) && v.err !== '#N/A' : isErr(v); }
    const fn = FN[name]; if (!fn) return E('#NAME?');
    const args = A.map(a => this.evalNode(a, cx));
    try { return fn.call(this, args, cx); } catch (e) { return E('#VALUE!'); }
  }
  clampRangeFull(g) { return this.clampRange(g); }
  /* helpers for functions */
  nums(args, strict = false) { // collect numbers from args; direct args coerced, range cells only numbers
    const out = []; let err = null;
    const add = (v, direct) => { if (err) return; if (isErr(v)) { err = v; return; } if (typeof v === 'number') out.push(v); else if (direct) { if (typeof v === 'boolean') out.push(v ? 1 : 0); else if (typeof v === 'string') { const x = toNum(v); if (isErr(x)) { if (v.trim() !== '') err = x; } else out.push(x); } } };
    for (const a of args) { if (a && a.range) this.each(a, v => add(v, false)); else if (a && a.rows) a.a.forEach(r => r.forEach(v => add(v, false))); else if (a === null && !strict) { /* empty */ } else add(a, true); }
    return err ? err : out;
  }
  flat(args) { const out = []; for (const a of args) { if (a && (a.range || a.rows)) { for (const r of this.toArr(a)) for (const v of r) out.push(v); } else out.push(a); } return out; }
}

/* ---------------- functions ---------------- */
const N = (v) => { const x = toNum(v); return x; };
const FN = {};
const def = (names, f) => { for (const n of names.split(' ')) FN[n] = f; };
const num1 = fn => function (args) { if (!args.length) return E('#VALUE!'); const x = N(this.scalar(args[0])); return isErr(x) ? x : fn(x); };
const withNums = fn => function (args) { const v = this.nums(args); return isErr(v) ? v : fn(v); };

def('SUM', withNums(v => v.reduce((a, b) => a + b, 0)));
def('PRODUCT', withNums(v => v.reduce((a, b) => a * b, 1)));
def('AVERAGE', withNums(v => v.length ? v.reduce((a, b) => a + b, 0) / v.length : E('#DIV/0!')));
def('MIN', withNums(v => v.length ? Math.min(...v) : 0));
def('MAX', withNums(v => v.length ? Math.max(...v) : 0));
def('SUMSQ', withNums(v => v.reduce((a, b) => a + b * b, 0)));
def('MEDIAN', withNums(v => { if (!v.length) return E('#NUM!'); v.sort((a, b) => a - b); const m = v.length >> 1; return v.length % 2 ? v[m] : (v[m - 1] + v[m]) / 2; }));
def('MODE MODE.SNGL', withNums(v => { const c = new Map(); let best = null, bc = 1; for (const x of v) { const k = (c.get(x) || 0) + 1; c.set(x, k); if (k > bc) { bc = k; best = x; } } return best === null ? E('#N/A') : best; }));
const variance = (v, sample) => { const n = v.length; if (n < (sample ? 2 : 1)) return E('#DIV/0!'); const m = v.reduce((a, b) => a + b, 0) / n; return v.reduce((a, b) => a + (b - m) ** 2, 0) / (sample ? n - 1 : n); };
def('VAR VAR.S', withNums(v => variance(v, true))); def('VAR.P VARP', withNums(v => variance(v, false)));
def('STDEV STDEV.S', withNums(v => { const x = variance(v, true); return isErr(x) ? x : Math.sqrt(x); })); def('STDEV.P STDEVP', withNums(v => { const x = variance(v, false); return isErr(x) ? x : Math.sqrt(x); }));
def('COUNT', function (args) { let n = 0; for (const a of args) { if (a && a.range) this.each(a, v => { if (typeof v === 'number') n++; }); else if (a && a.rows) a.a.flat().forEach(v => { if (typeof v === 'number') n++; }); else if (typeof a === 'number' || (typeof a === 'string' && !isErr(toNum(a)) && a.trim() !== '') || typeof a === 'boolean') n++; } return n; });
def('COUNTA', function (args) { let n = 0; for (const a of args) { if (a && a.range) this.each(a, v => { if (v !== null && v !== '') n++; }); else if (a && a.rows) a.a.flat().forEach(v => { if (v !== null && v !== '') n++; }); else if (a !== null) n++; } return n; });
def('COUNTBLANK', function (args) { const a = args[0]; if (!a.range) return 0; const g = a; const total = (Math.min(g.r2, 1048575) - g.r1 + 1) * (g.c2 - g.c1 + 1); let filled = 0; this.each(g, v => { if (v !== null && v !== '') filled++; }); return total - filled; });
def('LARGE', function (args) { const v = this.nums([args[0]]); if (isErr(v)) return v; const k = N(this.scalar(args[1])); v.sort((a, b) => b - a); return k >= 1 && k <= v.length ? v[k - 1] : E('#NUM!'); });
def('SMALL', function (args) { const v = this.nums([args[0]]); if (isErr(v)) return v; const k = N(this.scalar(args[1])); v.sort((a, b) => a - b); return k >= 1 && k <= v.length ? v[k - 1] : E('#NUM!'); });
def('RANK RANK.EQ', function (args) { const x = N(this.scalar(args[0])); const v = this.nums([args[1]]); const asc = args[2] ? N(this.scalar(args[2])) !== 0 : false; if (!v.includes(x)) return E('#N/A'); return 1 + v.filter(y => asc ? y < x : y > x).length; });
def('PERCENTILE PERCENTILE.INC', function (args) { const v = this.nums([args[0]]); const k = N(this.scalar(args[1])); if (isErr(v)) return v; v.sort((a, b) => a - b); if (!v.length || k < 0 || k > 1) return E('#NUM!'); const p = k * (v.length - 1), lo = Math.floor(p), hi = Math.ceil(p); return v[lo] + (v[hi] - v[lo]) * (p - lo); });
def('SUMPRODUCT', function (args) { const arrs = args.map(a => this.toArr(a).flat()); const n = arrs[0].length; let s = 0; for (let i = 0; i < n; i++) { let p = 1; for (const a of arrs) { if (a.length !== n) return E('#VALUE!'); const x = a[i]; if (isErr(x)) return x; p *= typeof x === 'number' ? x : typeof x === 'boolean' ? 0 : 0; } s += p; } return s; });
// conditional aggregates
function condIter(eng, pairs, cb) { // pairs: [[rangeArg, crit]...]
  const arrs = pairs.map(([r]) => eng.toArr(r)); const ms = pairs.map(([, c]) => matcher(c));
  const R = arrs[0].length, C = arrs[0][0].length;
  for (let i = 0; i < R; i++) for (let j = 0; j < C; j++) { let ok = true; for (let k = 0; k < arrs.length; k++) { const row = arrs[k][i]; if (!row || !ms[k](row[j])) { ok = false; break; } } if (ok) cb(i, j); }
}
function critArgs(eng, args, start) { const p = []; for (let i = start; i + 1 < args.length; i += 2) p.push([args[i], eng.scalar(args[i + 1])]); return p; }
const sumRangeAt = (eng, sumArg, i, j) => { const a = eng.toArr(sumArg); const row = a[i]; return row ? row[j] : null; };
def('COUNTIF', function (args) { let n = 0; condIter(this, [[args[0], this.scalar(args[1])]], () => n++); return n; });
def('COUNTIFS', function (args) { let n = 0; condIter(this, critArgs(this, args, 0), () => n++); return n; });
def('SUMIF', function (args) { const sr = args[2] || args[0]; const sa = this.toArr(sr); let s = 0; condIter(this, [[args[0], this.scalar(args[1])]], (i, j) => { const v = sa[i] && sa[i][j]; if (typeof v === 'number') s += v; }); return s; });
def('SUMIFS', function (args) { const sa = this.toArr(args[0]); let s = 0; condIter(this, critArgs(this, args, 1), (i, j) => { const v = sa[i] && sa[i][j]; if (typeof v === 'number') s += v; }); return s; });
def('AVERAGEIF', function (args) { const sa = this.toArr(args[2] || args[0]); let s = 0, n = 0; condIter(this, [[args[0], this.scalar(args[1])]], (i, j) => { const v = sa[i] && sa[i][j]; if (typeof v === 'number') { s += v; n++; } }); return n ? s / n : E('#DIV/0!'); });
def('AVERAGEIFS', function (args) { const sa = this.toArr(args[0]); let s = 0, n = 0; condIter(this, critArgs(this, args, 1), (i, j) => { const v = sa[i] && sa[i][j]; if (typeof v === 'number') { s += v; n++; } }); return n ? s / n : E('#DIV/0!'); });
def('MAXIFS', function (args) { const sa = this.toArr(args[0]); let m = null; condIter(this, critArgs(this, args, 1), (i, j) => { const v = sa[i] && sa[i][j]; if (typeof v === 'number' && (m === null || v > m)) m = v; }); return m === null ? 0 : m; });
def('MINIFS', function (args) { const sa = this.toArr(args[0]); let m = null; condIter(this, critArgs(this, args, 1), (i, j) => { const v = sa[i] && sa[i][j]; if (typeof v === 'number' && (m === null || v < m)) m = v; }); return m === null ? 0 : m; });
// math
def('ABS', num1(Math.abs)); def('SQRT', num1(x => x < 0 ? E('#NUM!') : Math.sqrt(x))); def('EXP', num1(Math.exp)); def('LN', num1(x => x <= 0 ? E('#NUM!') : Math.log(x))); def('LOG10', num1(x => x <= 0 ? E('#NUM!') : Math.log10(x)));
def('LOG', function (args) { const x = N(this.scalar(args[0])); const b = args[1] ? N(this.scalar(args[1])) : 10; if (isErr(x)) return x; return x <= 0 || b <= 0 || b === 1 ? E('#NUM!') : Math.log(x) / Math.log(b); });
def('SIN', num1(Math.sin)); def('COS', num1(Math.cos)); def('TAN', num1(Math.tan)); def('ASIN', num1(x => Math.abs(x) > 1 ? E('#NUM!') : Math.asin(x))); def('ACOS', num1(x => Math.abs(x) > 1 ? E('#NUM!') : Math.acos(x))); def('ATAN', num1(Math.atan));
def('DEGREES', num1(x => x * 180 / Math.PI)); def('RADIANS', num1(x => x * Math.PI / 180)); def('SIGN', num1(Math.sign)); def('INT', num1(Math.floor)); def('PI', () => Math.PI);
def('FACT', num1(x => { if (x < 0 || x > 170) return E('#NUM!'); let r = 1; for (let i = 2; i <= Math.floor(x); i++) r *= i; return r; }));
def('EVEN', num1(x => { const s = Math.sign(x) || 1; return s * 2 * Math.ceil(Math.abs(x) / 2); })); def('ODD', num1(x => { const s = Math.sign(x) || 1; const a = Math.ceil(Math.abs(x)); return s * (a % 2 ? a : a + 1); }));
const rnd = (x, d, mode) => { const p = Math.pow(10, d); const y = Math.abs(x) * p; const eps = 1e-9; let r; if (mode === 0) r = Math.round(y + eps * (y > 0 ? 1 : 0)); else if (mode === 1) r = Math.ceil(y - eps); else r = Math.floor(y + eps); return Math.sign(x) * r / p; };
const roundF = mode => function (args) { const x = N(this.scalar(args[0])), d = args[1] ? N(this.scalar(args[1])) : 0; if (isErr(x)) return x; if (isErr(d)) return d; return rnd(x, Math.trunc(d), mode); };
def('ROUND', roundF(0)); def('ROUNDUP', roundF(1)); def('ROUNDDOWN', roundF(2));
def('TRUNC', function (args) { const x = N(this.scalar(args[0])), d = args[1] ? N(this.scalar(args[1])) : 0; if (isErr(x)) return x; const p = Math.pow(10, d); return Math.trunc(x * p) / p; });
def('MOD', function (args) { const a = N(this.scalar(args[0])), b = N(this.scalar(args[1])); if (isErr(a)) return a; if (isErr(b)) return b; return b === 0 ? E('#DIV/0!') : a - b * Math.floor(a / b); });
def('QUOTIENT', function (args) { const a = N(this.scalar(args[0])), b = N(this.scalar(args[1])); return b === 0 ? E('#DIV/0!') : Math.trunc(a / b); });
def('POWER', function (args) { const a = N(this.scalar(args[0])), b = N(this.scalar(args[1])); if (isErr(a)) return a; if (isErr(b)) return b; const r = Math.pow(a, b); return isNaN(r) ? E('#NUM!') : r; });
def('CEILING CEILING.MATH', function (args) { const x = N(this.scalar(args[0])), s = args[1] ? N(this.scalar(args[1])) : 1; return s === 0 ? 0 : Math.ceil(x / s - 1e-12) * s; });
def('FLOOR FLOOR.MATH', function (args) { const x = N(this.scalar(args[0])), s = args[1] ? N(this.scalar(args[1])) : 1; return s === 0 ? 0 : Math.floor(x / s + 1e-12) * s; });
def('MROUND', function (args) { const x = N(this.scalar(args[0])), s = N(this.scalar(args[1])); return s === 0 ? 0 : Math.round(x / s) * s; });
def('RAND', () => Math.random()); def('RANDBETWEEN', function (args) { const a = Math.ceil(N(this.scalar(args[0]))), b = Math.floor(N(this.scalar(args[1]))); return a + Math.floor(Math.random() * (b - a + 1)); });
const gcd = (a, b) => b ? gcd(b, a % b) : Math.abs(a);
def('GCD', withNums(v => v.reduce(gcd))); def('LCM', withNums(v => v.reduce((a, b) => Math.abs(a * b) / gcd(a, b))));
def('COMBIN', function (args) { const n = N(this.scalar(args[0])), k = N(this.scalar(args[1])); if (k > n || k < 0) return E('#NUM!'); let r = 1; for (let i = 1; i <= k; i++) r = r * (n - k + i) / i; return Math.round(r); });
// logical
def('AND', function (args) { const v = this.flat(args).filter(x => x !== null && typeof x !== 'string'); if (!v.length) return E('#VALUE!'); for (const x of v) { const b = toBool(x); if (isErr(b)) return b; if (!b) return false; } return true; });
def('OR', function (args) { const v = this.flat(args).filter(x => x !== null && typeof x !== 'string'); if (!v.length) return E('#VALUE!'); for (const x of v) { const b = toBool(x); if (isErr(b)) return b; if (b) return true; } return false; });
def('XOR', function (args) { let c = 0; for (const x of this.flat(args)) { const b = toBool(x); if (isErr(b)) return b; if (b) c++; } return c % 2 === 1; });
def('NOT', function (args) { const b = toBool(this.scalar(args[0])); return isErr(b) ? b : !b; });
def('TRUE', () => true); def('FALSE', () => false); def('NA', () => E('#N/A'));
// info
def('ISBLANK', function (args) { const v = this.scalar(args[0]); return v === null || v === undefined; }); def('ISNUMBER', function (args) { return typeof this.scalar(args[0]) === 'number'; }); def('ISTEXT', function (args) { return typeof this.scalar(args[0]) === 'string'; }); def('ISLOGICAL', function (args) { return typeof this.scalar(args[0]) === 'boolean'; });
def('ISEVEN', function (args) { const x = N(this.scalar(args[0])); return isErr(x) ? x : Math.floor(Math.abs(x)) % 2 === 0; }); def('ISODD', function (args) { const x = N(this.scalar(args[0])); return isErr(x) ? x : Math.floor(Math.abs(x)) % 2 === 1; });
def('N', function (args) { const v = this.scalar(args[0]); return typeof v === 'number' ? v : typeof v === 'boolean' ? +v : 0; }); def('T', function (args) { const v = this.scalar(args[0]); return typeof v === 'string' ? v : ''; });
// text
const S1 = fn => function (args) { const s = toStr(this.scalar(args[0])); return isErr(s) ? s : fn(s, args, this); };
def('LEN', S1(s => s.length)); def('UPPER', S1(s => s.toUpperCase())); def('LOWER', S1(s => s.toLowerCase())); def('TRIM', S1(s => s.trim().replace(/ +/g, ' '))); def('CLEAN', S1(s => s.replace(/[\u0000-\u001f]/g, '')));
def('PROPER', S1(s => s.toLowerCase().replace(/(^|[^A-Za-z\u00C0-\u024F])([a-z\u00E0-\u024F])/g, (m, a, b) => a + b.toUpperCase())));
def('LEFT', S1((s, a, e) => { const n = a[1] ? N(e.scalar(a[1])) : 1; return isErr(n) ? n : n < 0 ? E('#VALUE!') : [...s].slice(0, n).join(''); }));
def('RIGHT', S1((s, a, e) => { const n = a[1] ? N(e.scalar(a[1])) : 1; return isErr(n) ? n : n < 0 ? E('#VALUE!') : n === 0 ? '' : [...s].slice(-n).join(''); }));
def('MID', S1((s, a, e) => { const st = N(e.scalar(a[1])), n = N(e.scalar(a[2])); if (isErr(st)) return st; if (isErr(n)) return n; return st < 1 || n < 0 ? E('#VALUE!') : [...s].slice(st - 1, st - 1 + n).join(''); }));
def('REPT', S1((s, a, e) => { const n = N(e.scalar(a[1])); return isErr(n) ? n : n < 0 ? E('#VALUE!') : s.repeat(n); }));
def('CONCATENATE CONCAT', function (args) { let o = ''; for (const v of this.flat(args)) { const s = toStr(v); if (isErr(s)) return s; o += s; } return o; });
def('TEXTJOIN', function (args) { const d = toStr(this.scalar(args[0])), ig = toBool(this.scalar(args[1])); const parts = this.flat(args.slice(2)).map(toStr).filter(s => !(ig && s === '')); return parts.join(d); });
def('SUBSTITUTE', function (args) { const s = toStr(this.scalar(args[0])), a = toStr(this.scalar(args[1])), b = toStr(this.scalar(args[2])); if (isErr(s)) return s; if (!a) return s; if (args[3]) { let k = N(this.scalar(args[3])), idx = -1; while (k-- > 0) { idx = s.indexOf(a, idx + 1); if (idx < 0) return s; } return s.slice(0, idx) + b + s.slice(idx + a.length); } return s.split(a).join(b); });
def('REPLACE', function (args) { const s = toStr(this.scalar(args[0])), st = N(this.scalar(args[1])), n = N(this.scalar(args[2])), t = toStr(this.scalar(args[3])); return s.slice(0, st - 1) + t + s.slice(st - 1 + n); });
def('FIND', function (args) { const f = toStr(this.scalar(args[0])), s = toStr(this.scalar(args[1])), st = args[2] ? N(this.scalar(args[2])) : 1; const i = s.indexOf(f, st - 1); return i < 0 ? E('#VALUE!') : i + 1; });
def('SEARCH', function (args) { const f = toStr(this.scalar(args[0])).toLowerCase(), s = toStr(this.scalar(args[1])).toLowerCase(), st = args[2] ? N(this.scalar(args[2])) : 1; let i; if (/[*?]/.test(f)) { const re = new RegExp(f.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/\?/g, '.')); const m = re.exec(s.slice(st - 1)); i = m ? m.index + st - 1 : -1; } else i = s.indexOf(f, st - 1); return i < 0 ? E('#VALUE!') : i + 1; });
def('EXACT', function (args) { return toStr(this.scalar(args[0])) === toStr(this.scalar(args[1])); });
def('CHAR', num1(x => String.fromCharCode(x))); def('CODE', S1(s => s.charCodeAt(0))); def('UNICHAR', num1(x => String.fromCodePoint(x))); def('UNICODE', S1(s => s.codePointAt(0)));
def('VALUE NUMBERVALUE', function (args) { const v = this.scalar(args[0]); const x = toNum(v); return isErr(x) ? E('#VALUE!') : x; });
def('TEXT', function (args) { const v = this.scalar(args[0]); const f = toStr(this.scalar(args[1])); if (isErr(v)) return v; const x = typeof v === 'string' && !isErr(toNum(v)) && v.trim() !== '' ? toNum(v) : v; return formatValue(x, f).text; });
def('FIXED', function (args) { const x = N(this.scalar(args[0])), d = args[1] ? N(this.scalar(args[1])) : 2; const nc = args[2] ? toBool(this.scalar(args[2])) : false; return formatValue(x, (nc ? '0' : '#,##0') + (d > 0 ? '.' + '0'.repeat(d) : '')).text; });
// date & time
const nowSerial = e => { const d = new Date(e.now); return dateToSerial(d.getFullYear(), d.getMonth() + 1, d.getDate()) + (d.getHours() * 3600 + d.getMinutes() * 60 + d.getSeconds()) / 86400; };
def('TODAY', function () { return Math.floor(nowSerial(this)); }); def('NOW', function () { return nowSerial(this); });
def('DATE', function (args) { let y = N(this.scalar(args[0])), m = N(this.scalar(args[1])), d = N(this.scalar(args[2])); if (isErr(y)) return y; if (isErr(m)) return m; if (isErr(d)) return d; if (y < 1900) y += 1900; const t = new Date(Date.UTC(y, m - 1, d)); return dateToSerial(t.getUTCFullYear(), t.getUTCMonth() + 1, t.getUTCDate()); });
def('TIME', function (args) { const h = N(this.scalar(args[0])), m = N(this.scalar(args[1])), s = N(this.scalar(args[2])); return ((h * 3600 + m * 60 + s) / 86400) % 1; });
def('DATEVALUE', function (args) { const s = toStr(this.scalar(args[0])); const d = parseDateStr(s); return d === null ? E('#VALUE!') : Math.floor(d); }); def('TIMEVALUE', function (args) { const d = parseDateStr(toStr(this.scalar(args[0]))); return d === null ? E('#VALUE!') : d % 1; });
const dp = (name, f) => def(name, function (args) { const x = N(this.scalar(args[0])); return isErr(x) ? x : f(serialParts(x), x, args, this); });
dp('YEAR', p => p.y); dp('MONTH', p => p.m); dp('DAY', p => p.d); dp('HOUR', p => p.hh); dp('MINUTE', p => p.mi); dp('SECOND', p => p.ss);
dp('WEEKDAY', (p, x, a, e) => { const t = a[1] ? N(e.scalar(a[1])) : 1; return t === 2 ? (p.wd + 6) % 7 + 1 : t === 3 ? (p.wd + 6) % 7 : p.wd + 1; });
dp('WEEKNUM', p => { const d = new Date(Date.UTC(p.y, p.m - 1, p.d)); const j = new Date(Date.UTC(p.y, 0, 1)); return Math.floor(((d - j) / 864e5 + j.getUTCDay()) / 7) + 1; });
def('DAYS', function (args) { return N(this.scalar(args[0])) - N(this.scalar(args[1])); });
def('EDATE', function (args) { const p = serialParts(N(this.scalar(args[0]))), k = N(this.scalar(args[1])); const t = new Date(Date.UTC(p.y, p.m - 1 + k, p.d)); return dateToSerial(t.getUTCFullYear(), t.getUTCMonth() + 1, t.getUTCDate()); });
def('EOMONTH', function (args) { const p = serialParts(N(this.scalar(args[0]))), k = N(this.scalar(args[1])); const t = new Date(Date.UTC(p.y, p.m + k, 0)); return dateToSerial(t.getUTCFullYear(), t.getUTCMonth() + 1, t.getUTCDate()); });
def('DATEDIF', function (args) { const a = N(this.scalar(args[0])), b = N(this.scalar(args[1])), u = toStr(this.scalar(args[2])).toUpperCase(); if (a > b) return E('#NUM!'); const p = serialParts(a), q = serialParts(b); let y = q.y - p.y, m = q.m - p.m, d = q.d - p.d; if (d < 0) { m--; d += new Date(Date.UTC(q.y, q.m - 1, 0)).getUTCDate(); } if (m < 0) { y--; m += 12; } return u === 'Y' ? y : u === 'M' ? y * 12 + m : u === 'D' ? Math.floor(b - a) : u === 'MD' ? d : u === 'YM' ? m : u === 'YD' ? Math.floor(b - dateToSerial(q.m < p.m || (q.m === p.m && q.d < p.d) ? q.y - 1 + 1 : q.y, p.m, p.d)) : E('#NUM!'); });
def('NETWORKDAYS', function (args) { let a = Math.floor(N(this.scalar(args[0]))), b = Math.floor(N(this.scalar(args[1]))); let n = 0; const s = a <= b ? 1 : -1; for (let x = a; s > 0 ? x <= b : x >= b; x += s) { const wd = serialParts(x).wd; if (wd !== 0 && wd !== 6) n += s; } return n; });
// lookup
function lookupVals(eng, a) { return eng.toArr(a); }
def('VLOOKUP', function (args) { const key = this.scalar(args[0]); if (isErr(key)) return key; const t = lookupVals(this, args[1]); const ci = N(this.scalar(args[2])); const approx = args[3] ? toBool(this.scalar(args[3])) : true; if (ci < 1 || ci > t[0].length) return E('#REF!'); if (!approx) { const m = typeof key === 'string' && /[*?]/.test(key) ? matcher(key) : null; for (const row of t) if (m ? m(row[0]) : compare(row[0], key) === 0 && typeRank(row[0]) === typeRank(key)) return row[ci - 1]; return E('#N/A'); } let best = -1; for (let i = 0; i < t.length; i++) { if (t[i][0] === null) continue; if (typeRank(t[i][0]) !== typeRank(key)) continue; if (compare(t[i][0], key) <= 0) best = i; else break; } return best < 0 ? E('#N/A') : t[best][ci - 1]; });
def('HLOOKUP', function (args) { const key = this.scalar(args[0]); const t = lookupVals(this, args[1]); const ri = N(this.scalar(args[2])); const approx = args[3] ? toBool(this.scalar(args[3])) : true; if (ri < 1 || ri > t.length) return E('#REF!'); const row0 = t[0]; if (!approx) { for (let j = 0; j < row0.length; j++) if (compare(row0[j], key) === 0 && typeRank(row0[j]) === typeRank(key)) return t[ri - 1][j]; return E('#N/A'); } let best = -1; for (let j = 0; j < row0.length; j++) { if (typeRank(row0[j]) === typeRank(key) && compare(row0[j], key) <= 0) best = j; } return best < 0 ? E('#N/A') : t[ri - 1][best]; });
def('MATCH', function (args) { const key = this.scalar(args[0]); const v = lookupVals(this, args[1]).flat(); const mt = args[2] ? N(this.scalar(args[2])) : 1; if (mt === 0) { const m = typeof key === 'string' && /[*?]/.test(key) ? matcher(key) : null; for (let i = 0; i < v.length; i++) if (m ? m(v[i]) : (compare(v[i], key) === 0 && typeRank(v[i]) === typeRank(key))) return i + 1; return E('#N/A'); } let best = -1; for (let i = 0; i < v.length; i++) { if (typeRank(v[i]) !== typeRank(key)) continue; const c = compare(v[i], key); if (mt > 0 ? c <= 0 : c >= 0) best = i; else break; } return best < 0 ? E('#N/A') : best + 1; });
def('INDEX', function (args) { const t = lookupVals(this, args[0]); let r = args[1] ? N(this.scalar(args[1])) : 0, c = args[2] ? N(this.scalar(args[2])) : 0; if (isErr(r)) return r; if (isErr(c)) return c; if (t.length === 1 && !args[2] && r > 0) { c = r; r = 1; } if (r === 0 && c > 0 && t.length > 1) return { rows: true, a: t.map(x => [x[c - 1]]) }; if (r < 0 || c < 0 || r > t.length || c > t[0].length) return E('#REF!'); if (r === 0) r = 1; if (c === 0) c = 1; return t[r - 1][c - 1]; });
def('LOOKUP', function (args) { const key = this.scalar(args[0]); const v = lookupVals(this, args[1]).flat(); const res = args[2] ? lookupVals(this, args[2]).flat() : v; let best = -1; for (let i = 0; i < v.length; i++) { if (typeRank(v[i]) !== typeRank(key)) continue; if (compare(v[i], key) <= 0) best = i; else break; } return best < 0 ? E('#N/A') : res[best]; });
def('XLOOKUP', function (args) { const key = this.scalar(args[0]); const lv = lookupVals(this, args[1]); const rv = lookupVals(this, args[2]); const mode = args[4] ? N(this.scalar(args[4])) : 0; const vert = lv[0].length === 1 || lv.length > 1; const flat = lv.flat(); let idx = -1; if (mode === 0) { const m = typeof key === 'string' && /[*?]/.test(key) && N(this.scalar(args[4] || 0)) === 2 ? matcher(key) : null; for (let i = 0; i < flat.length; i++) if (compare(flat[i], key) === 0 && typeRank(flat[i]) === typeRank(key)) { idx = i; break; } } else { let bv = null; for (let i = 0; i < flat.length; i++) { if (typeRank(flat[i]) !== typeRank(key)) continue; const c = compare(flat[i], key); if (c === 0) { idx = i; break; } if (mode < 0 ? c < 0 : c > 0) if (bv === null || (mode < 0 ? compare(flat[i], bv) > 0 : compare(flat[i], bv) < 0)) { bv = flat[i]; idx = i; } } } if (idx < 0) return args[3] ? this.scalar(args[3]) : E('#N/A'); return lv.length > 1 || (lv.length === 1 && lv[0].length === 1) ? (rv.length > 1 ? (rv[0].length > 1 ? { rows: true, a: [rv[idx]] } : rv[idx][0]) : rv[0][idx]) : rv[0][idx]; });
// finance
def('PMT', function (args) { const r = N(this.scalar(args[0])), n = N(this.scalar(args[1])), pv = N(this.scalar(args[2])), fv = args[3] ? N(this.scalar(args[3])) : 0, ty = args[4] ? N(this.scalar(args[4])) : 0; if (r === 0) return -(pv + fv) / n; const f = Math.pow(1 + r, n); return -(r * (pv * f + fv)) / ((1 + r * ty) * (f - 1)); });
def('FV', function (args) { const r = N(this.scalar(args[0])), n = N(this.scalar(args[1])), p = N(this.scalar(args[2])), pv = args[3] ? N(this.scalar(args[3])) : 0, ty = args[4] ? N(this.scalar(args[4])) : 0; if (r === 0) return -(pv + p * n); const f = Math.pow(1 + r, n); return -(pv * f + p * (1 + r * ty) * (f - 1) / r); });
def('PV', function (args) { const r = N(this.scalar(args[0])), n = N(this.scalar(args[1])), p = N(this.scalar(args[2])), fv = args[3] ? N(this.scalar(args[3])) : 0, ty = args[4] ? N(this.scalar(args[4])) : 0; if (r === 0) return -(fv + p * n); const f = Math.pow(1 + r, n); return -(fv + p * (1 + r * ty) * (f - 1) / r) / f; });
def('NPV', function (args) { const r = N(this.scalar(args[0])); const v = this.nums(args.slice(1)); return v.reduce((a, x, i) => a + x / Math.pow(1 + r, i + 1), 0); });
def('IRR', function (args) { const v = this.nums([args[0]]); let r = 0.1; for (let k = 0; k < 100; k++) { let f = 0, d = 0; v.forEach((x, i) => { f += x / Math.pow(1 + r, i); d -= i * x / Math.pow(1 + r, i + 1); }); const nr = r - f / d; if (!isFinite(nr)) return E('#NUM!'); if (Math.abs(nr - r) < 1e-10) return nr; r = nr; } return E('#NUM!'); });
def('TRANSPOSE', function (args) { const a = this.toArr(args[0]); return { rows: true, a: a[0].map((_, j) => a.map(r => r[j])) }; });
def('UNIQUE', function (args) { const a = this.toArr(args[0]); const seen = new Set(), out = []; for (const r of a) { const k = JSON.stringify(r); if (!seen.has(k)) { seen.add(k); out.push(r); } } return { rows: true, a: out }; });
def('SORT', function (args) { const a = this.toArr(args[0]).map(r => r.slice()); const ci = args[1] ? N(this.scalar(args[1])) - 1 : 0, o = args[2] ? N(this.scalar(args[2])) : 1; a.sort((x, y) => compare(x[ci], y[ci]) * o); return { rows: true, a }; });

// ---- statistics / lookup additions (v1.6) ----
const numsOf = (eng, node) => eng.toArr(node).flat().filter(x => typeof x === 'number' && isFinite(x));
const pairsOf = (eng, ny, nx) => { const y = eng.toArr(ny).flat(), x = eng.toArr(nx).flat(), P = []; for (let i = 0; i < Math.min(x.length, y.length); i++) if (typeof x[i] === 'number' && typeof y[i] === 'number') P.push([x[i], y[i]]); return P; };
const regress = P => { const n = P.length; if (n < 2) return null; const mx = P.reduce((a, p) => a + p[0], 0) / n, my = P.reduce((a, p) => a + p[1], 0) / n; let sxy = 0, sxx = 0, syy = 0; for (const [x, y] of P) { sxy += (x - mx) * (y - my); sxx += (x - mx) ** 2; syy += (y - my) ** 2; } return { mx, my, sxy, sxx, syy, slope: sxx ? sxy / sxx : NaN }; };
def('QUARTILE', function (args) { const v = numsOf(this, args[0]).sort((a, b) => a - b), q = N(this.scalar(args[1])); if (!v.length || q < 0 || q > 4 || !Number.isInteger(q)) return E('#NUM!'); const k = (v.length - 1) * q / 4, lo = Math.floor(k), hi = Math.ceil(k); return v[lo] + (v[hi] - v[lo]) * (k - lo); });
def('CORREL', function (args) { const r = regress(pairsOf(this, args[0], args[1])); return !r || !r.sxx || !r.syy ? E('#DIV/0!') : r.sxy / Math.sqrt(r.sxx * r.syy); });
def('RSQ', function (args) { const r = regress(pairsOf(this, args[0], args[1])); return !r || !r.sxx || !r.syy ? E('#DIV/0!') : (r.sxy * r.sxy) / (r.sxx * r.syy); });
def('SLOPE', function (args) { const r = regress(pairsOf(this, args[0], args[1])); return !r || !r.sxx ? E('#DIV/0!') : r.slope; });
def('INTERCEPT', function (args) { const r = regress(pairsOf(this, args[0], args[1])); return !r || !r.sxx ? E('#DIV/0!') : r.my - r.slope * r.mx; });
def('FORECAST', function (args) { const x = N(this.scalar(args[0])), r = regress(pairsOf(this, args[1], args[2])); return !r || !r.sxx ? E('#DIV/0!') : r.my + r.slope * (x - r.mx); });
def('RATE', function (args) {
  const n = N(this.scalar(args[0])), pmt = N(this.scalar(args[1])), pv = N(this.scalar(args[2])), fv = args[3] ? N(this.scalar(args[3])) : 0, ty = args[4] ? N(this.scalar(args[4])) : 0; let r = args[5] ? N(this.scalar(args[5])) : 0.1;
  const f = x => x === 0 ? pv + pmt * n + fv : pv * Math.pow(1 + x, n) + pmt * (1 + x * ty) * (Math.pow(1 + x, n) - 1) / x + fv;
  for (let i = 0; i < 100; i++) { const d = 1e-7, y = f(r), dy = (f(r + d) - y) / d; if (!isFinite(dy) || dy === 0) break; const nr = r - y / dy; if (Math.abs(nr - r) < 1e-10) return nr; r = nr; }
  return E('#NUM!');
});
def('XMATCH', function (args) { const key = this.scalar(args[0]), v = this.toArr(args[1]).flat(), mode = args[2] ? N(this.scalar(args[2])) : 0;
  if (mode === 0 || mode === 2) { const m = mode === 2 && typeof key === 'string' ? matcher(key) : null; for (let i = 0; i < v.length; i++) if (m ? m(v[i]) : (compare(v[i], key) === 0 && typeRank(v[i]) === typeRank(key))) return i + 1; return E('#N/A'); }
  let best = -1; for (let i = 0; i < v.length; i++) { if (typeRank(v[i]) !== typeRank(key)) continue; const c = compare(v[i], key); if (c === 0) return i + 1; if (mode < 0 ? c < 0 : c > 0) { if (best < 0 || (mode < 0 ? compare(v[i], v[best]) > 0 : compare(v[i], v[best]) < 0)) best = i; } } return best < 0 ? E('#N/A') : best + 1; });
def('SEQUENCE', function (args) { const r = N(this.scalar(args[0])), c = args[1] ? N(this.scalar(args[1])) : 1, s = args[2] ? N(this.scalar(args[2])) : 1, st = args[3] ? N(this.scalar(args[3])) : 1; if (!(r > 0 && c > 0) || r * c > 100000) return E('#VALUE!'); const a = []; let x = s; for (let i = 0; i < r; i++) { const row = []; for (let j = 0; j < c; j++) { row.push(x); x += st; } a.push(row); } return { rows: true, a }; });
def('FILTER', function (args) { const a = this.toArr(args[0]), inc = this.toArr(args[1]); let out;
  if (inc.length === a.length && inc[0].length === 1) out = a.filter((_, i) => { const x = inc[i][0]; return x === true || (typeof x === 'number' && x !== 0); });
  else if (inc.length === 1 && inc[0].length === a[0].length) { const keep = inc[0].map(x => x === true || (typeof x === 'number' && x !== 0)); out = a.map(row => row.filter((_, j) => keep[j])); if (out[0] && !out[0].length) out = []; }
  else return E('#VALUE!');
  if (!out.length) return args[2] ? this.scalar(args[2]) : E('#CALC!'); return { rows: true, a: out }; });
export const FUNCTIONS = Object.keys(FN).sort().concat(['IF', 'IFERROR', 'IFNA', 'IFS', 'SWITCH', 'CHOOSE', 'ROW', 'COLUMN', 'ROWS', 'COLUMNS', 'INDIRECT', 'ISERROR', 'ISERR', 'ISNA']).sort();
export function formatCellValue(v, fmt) { return formatValue(v, fmt); }
