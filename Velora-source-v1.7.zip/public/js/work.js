// Velora background worker — heavy file work off the UI thread (classic worker so importScripts/JSZip work everywhere).
importScripts('/vendor/jszip.min.js', '/vendor/pdf-lib.min.js');
const mods = {}; const need = async n => (mods[n] ||= await import('/js/' + n + '.js'));
const attr = (tag, name) => { const m = new RegExp('\\s' + name + '="([^"]*)"').exec(tag); return m ? m[1] : null; };
const post = (id, msg, tr) => self.postMessage({ id, ...msg }, tr || []);

const OPS = {
  async xlsxParse({ buf }, id) {
    const S = await need('xlsxscan'), z = await JSZip.loadAsync(buf);
    const text = async n => { const f = z.file(n); return f ? f.async('string') : ''; };
    const wbx = await text('xl/workbook.xml'); if (!wbx) throw new Error('এটি বৈধ .xlsx ফাইল নয়');
    const rels = {}; for (const m of (await text('xl/_rels/workbook.xml.rels')).matchAll(/<Relationship\b[^>]*>/g)) rels[attr(m[0], 'Id')] = attr(m[0], 'Target');
    post(id, { progress: .05 }); const sst = S.scanSharedStrings(await text('xl/sharedStrings.xml')); post(id, { progress: .15 });
    const styles = await text('xl/styles.xml'), sheetTags = [...wbx.matchAll(/<sheet\b[^>]*>/g)].map(m => m[0]), sheets = [], tr = [];
    for (let i = 0; i < sheetTags.length; i++) {
      const tg = sheetTags[i], rid = attr(tg, 'r:id') || attr(tg, 'id'); let t = rels[rid] || ''; t = t.startsWith('/') ? t.slice(1) : 'xl/' + t; const name = S.unent(attr(tg, 'name') || 'Sheet' + (i + 1));
      const f = z.file(t); if (!f) { sheets.push({ name }); continue; }
      const sc = S.scanSheetData(await f.async('string')); if (!sc.ok) return { fallback: true };
      const head = sc.head; delete sc.head; for (const k of ['r', 'c', 'k', 'x', 'ref', 'fi', 'num']) tr.push(sc[k].buffer);
      sheets.push({ name, scan: sc, head }); post(id, { progress: .15 + .85 * (i + 1) / sheetTags.length });
    }
    return { result: { sst, styles, sheets }, transfer: tr };
  },
  async pdfFlatten({ bytes, list, imgs }, id) {
    const { PDFDocument, rgb, LineCapStyle } = PDFLib, mapPt = (rot, W, Hh, vx, vy) => rot === 90 ? [vy, vx] : rot === 180 ? [W - vx, vy] : rot === 270 ? [W - vy, Hh - vx] : [vx, Hh - vy];
    const hexRgb = c => { const x = c.replace('#', ''); return [parseInt(x.slice(0, 2), 16) / 255, parseInt(x.slice(2, 4), 16) / 255, parseInt(x.slice(4, 6), 16) / 255]; };
    const pdf = await PDFDocument.load(bytes, { updateMetadata: false }), n0 = pdf.getPageCount(), pgs = pdf.getPages(); post(id, { progress: .3 });
    for (const a of list) {
      const pg = pgs[a.p]; if (!pg) continue; const { width: W, height: Hh } = pg.getSize(), rot = ((pg.getRotation().angle % 360) + 360) % 360, mp = (vx, vy) => mapPt(rot, W, Hh, vx, vy);
      if (a.t === 'note') { const im = imgs[a.id]; if (!im) continue; const img = await pdf.embedPng(im.bytes), p1 = mp(a.x, a.y), p2 = mp(a.x + im.vw, a.y + im.vh); pg.drawImage(img, { x: Math.min(p1[0], p2[0]), y: Math.min(p1[1], p2[1]), width: Math.abs(p2[0] - p1[0]), height: Math.abs(p2[1] - p1[1]) }); }
      else { const [r, g, b] = hexRgb(a.c), col = rgb(r, g, b); for (let i = 1; i < a.pts.length; i++) { const s = mp(...a.pts[i - 1]), e = mp(...a.pts[i]); pg.drawLine({ start: { x: s[0], y: s[1] }, end: { x: e[0], y: e[1] }, thickness: a.w, color: col, opacity: a.t === 'hl' ? .4 : 1, lineCap: LineCapStyle.Round }); } }
    }
    post(id, { progress: .7 }); const out = await pdf.save();
    // integrity gate: a damaged result must never replace the user's file
    const head = String.fromCharCode(...out.subarray(0, 5)), tail = String.fromCharCode(...out.subarray(Math.max(0, out.length - 1100)));
    if (head !== '%PDF-' || !tail.includes('%%EOF')) throw new Error('PDF সংরক্ষণ যাচাই ব্যর্থ — আসল ফাইল অক্ষত আছে');
    if (out.length < 80 * 1048576) { const chk = await PDFDocument.load(out, { updateMetadata: false }); if (chk.getPageCount() !== n0) throw new Error('পাতার সংখ্যা মেলেনি — আসল ফাইল অক্ষত আছে'); }
    const buf = out.buffer.slice(out.byteOffset, out.byteOffset + out.byteLength); return { result: buf, transfer: [buf] };
  },
  async xlsxPack({ snap, title, author }, id) {
    const X = await need('xlsx'), F = await need('formula'); post(id, { progress: .1 });
    const wb = X.loadWb(snap), eng = new F.Engine(wb); post(id, { progress: .3 });
    const buf = await X.wbToXlsx(wb, (si, r, c) => eng.value(si, r, c), { title, author }); return { result: buf, transfer: [buf] };
  },
};
self.onmessage = async e => {
  const { id, op } = e.data;
  try { const r = await OPS[op](e.data, id); if (r && r.fallback) post(id, { result: r }); else post(id, { result: r.result }, r.transfer); }
  catch (err) { post(id, { error: String((err && err.message) || err) }); }
};
