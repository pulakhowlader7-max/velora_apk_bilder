// Velora cropper — one modern, full-screen crop used everywhere (photo editor, scanner, ID card, cleanup, OCR).
//  • pinch / wheel zoom + pan   • 8 handles with rule-of-thirds grid   • ratio presets (A4, ID card, passport…)
//  • straighten slider (±45°) + rotate 90° + flip   • 4-point "paper" mode (perspective fix) with a loupe
//  openCropper(canvas|File, opts) → Promise<canvas | null>
import { h, icon, toast, loadImage, errMsg } from './util.js';
import { screen } from './screen.js';
import * as P from './imgproc.js';

const cnv = (w, hh) => { const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(hh)); return c; };
const g2 = c => c.getContext('2d', { willReadFrequently: true });
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const PREVIEW = 1400, MIN = .04;
export const RATIOS = [[0, 'ফ্রি'], [1, '১:১'], [4 / 3, '৪:৩'], [3 / 4, '৩:৪'], [16 / 9, '১৬:৯'], [210 / 297, 'A4'], [85.6 / 54, 'ID কার্ড'], [35 / 45, 'পাসপোর্ট']];

/** Largest axis-aligned rectangle that fits inside a w×h rectangle rotated by `rad` (both centred). */
export function insetRect(w, hh, rad) {
  const a = Math.abs(rad) % Math.PI, s = Math.sin(Math.min(a, Math.PI - a)), c = Math.cos(Math.min(a, Math.PI - a));
  if (s < 1e-9) return { w, h: hh };
  const long = w >= hh, L = long ? w : hh, S = long ? hh : w;
  if (S <= 2 * s * c * L || Math.abs(s - c) < 1e-9) { const x = .5 * S; return long ? { w: x / s, h: x / c } : { w: x / c, h: x / s }; }
  const c2 = c * c - s * s; return { w: (w * c - hh * s) / c2, h: (hh * c - w * s) / c2 };
}
/** rotate by quarter turns (+ optional mirror), then by a fine angle (degrees); canvas grows so nothing is lost. */
export function transformCanvas(src, rot = 0, flip = false, fine = 0, fill = '#ffffff') {
  const sw = src.width, sh = src.height, odd = rot % 2 !== 0;
  let a = src;
  if (rot || flip) { a = cnv(odd ? sh : sw, odd ? sw : sh); const g = g2(a); g.translate(a.width / 2, a.height / 2); g.rotate(rot * Math.PI / 2); if (flip) g.scale(-1, 1); g.drawImage(src, -sw / 2, -sh / 2); }
  if (!fine) return a;
  const rad = fine * Math.PI / 180, c = Math.abs(Math.cos(rad)), s = Math.abs(Math.sin(rad));
  const W = Math.ceil(a.width * c + a.height * s), H = Math.ceil(a.width * s + a.height * c), b = cnv(W, H), g = g2(b);
  if (fill) { g.fillStyle = fill; g.fillRect(0, 0, W, H); }
  g.imageSmoothingQuality = 'high'; g.translate(W / 2, H / 2); g.rotate(rad); g.drawImage(a, -a.width / 2, -a.height / 2);
  return b;
}
function detectQuad(c) {
  const sc = 300 / Math.max(c.width, c.height), s = cnv(Math.max(8, c.width * sc), Math.max(8, c.height * sc));
  g2(s).drawImage(c, 0, 0, s.width, s.height);
  return P.findDocumentCorners(g2(s).getImageData(0, 0, s.width, s.height));
}
async function toCanvas(src) {
  if (src instanceof HTMLCanvasElement) return src;
  const url = URL.createObjectURL(src);
  try {
    const img = await loadImage(url), sc = Math.min(1, 4096 / Math.max(img.naturalWidth, img.naturalHeight));
    const c = cnv(img.naturalWidth * sc, img.naturalHeight * sc); g2(c).drawImage(img, 0, 0, c.width, c.height); return c;
  } finally { URL.revokeObjectURL(url); }
}

/**
 * opts: title, ratio (0 = free), ratios (list of [value,label]; [] hides the chips), mode ('rect' | 'quad'), allowQuad (default true),
 *       quad (initial normalised corners TL,TR,BR,BL), fill (colour for corners exposed by straightening), okLabel
 */
export async function openCropper(source, opts = {}) {
  let full;
  try { full = await toCanvas(source); } catch (e) { toast(errMsg(e), 3500); return null; }
  const o = { title: 'ক্রপ', ratio: 0, ratios: RATIOS, mode: 'rect', allowQuad: true, fill: '#ffffff', okLabel: 'ঠিক আছে', cornersOnly: false, ...opts };
  if (o.cornersOnly) { o.mode = 'quad'; o.allowQuad = false; o.ratios = []; }
  const ps = Math.min(1, PREVIEW / Math.max(full.width, full.height));
  const small = ps < 1 ? (() => { const c = cnv(full.width * ps, full.height * ps); const g = g2(c); g.imageSmoothingQuality = 'high'; g.drawImage(full, 0, 0, c.width, c.height); return c; })() : full;

  return new Promise(resolve => {
    let settled = false, mode = o.mode, ratio = o.ratio, rot = 0, flip = false, fine = 0, work = null;
    let rect = { x: .05, y: .05, w: .9, h: .9 }, quad = null, z = 1, tx = 0, ty = 0, fw = 100, fh = 100;
    const done = v => { if (settled) return; settled = true; resolve(v); };
    const okB = h('button', { class: 'btn primary', type: 'button' }, icon('check', 18), o.okLabel);
    const scr = screen({ title: o.title, cls: 'cropper', onClose: () => done(null) });

    /* ---------- stage ---------- */
    const stage = h('div', { class: 'cr-stage' }), zoomEl = h('div', { class: 'cr-zoom' }), view = document.createElement('canvas'); view.className = 'cr-img';
    const ov = h('div', { class: 'cr-ov' });
    const rectEl = h('div', { class: 'cr-rect' }, ...['nw', 'n', 'ne', 'e', 'se', 's', 'sw', 'w'].map(k => h('i', { 'data-k': k, class: k.length === 2 ? 'c' : 'e' })));
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); svg.setAttribute('class', 'cr-svg'); svg.setAttribute('viewBox', '0 0 1 1'); svg.setAttribute('preserveAspectRatio', 'none');
    const poly = document.createElementNS('http://www.w3.org/2000/svg', 'path'); poly.setAttribute('fill-rule', 'evenodd'); poly.setAttribute('class', 'dim');
    const line = document.createElementNS('http://www.w3.org/2000/svg', 'polygon'); line.setAttribute('class', 'ln'); svg.append(poly, line);
    const qh = [0, 1, 2, 3].map(i => h('div', { class: 'cr-q', 'data-q': i }));
    const loupe = h('div', { class: 'cr-loupe', hidden: true }, h('canvas', { width: 104, height: 104 }));
    zoomEl.append(view, ov); ov.append(rectEl, svg, ...qh); stage.append(zoomEl, loupe);

    /* ---------- controls ---------- */
    const chipsEl = h('div', { class: 'cr-chips' }), modeEl = h('div', { class: 'seg cr-seg' });
    const slVal = h('b', null, '০°'), sl = h('input', { type: 'range', min: -45, max: 45, step: .1, value: 0, 'aria-label': 'সোজা করুন' });
    const slRow = h('div', { class: 'cr-sl' }, h('span', null, 'সোজা'), sl, slVal, h('button', { class: 'cr-reset', type: 'button', onclick: () => { sl.value = 0; fine = 0; rebuild(true); } }, 'রিসেট'));
    const tool = (ic, label, fn, mirror) => h('button', { class: 'cr-tool' + (mirror ? ' mir' : ''), type: 'button', onclick: fn, 'aria-label': label }, icon(ic, 20), h('span', null, label));
    const toolsEl = h('div', { class: 'cr-tools' + (o.cornersOnly ? ' co' : '') },
      tool('rotate', 'বাঁয়ে', () => { rot = (rot + 3) % 4; rebuild(true); }, true), tool('rotate', 'ডানে', () => { rot = (rot + 1) % 4; rebuild(true); }),
      tool('left', 'আয়না', () => { flip = !flip; rebuild(true); }), tool('sparkle', 'অটো', () => autoFit()), tool('maximize', 'পুরো', () => fullArea()));
    const bar = h('div', { class: 'cr-bar' }, chipsEl, slRow, toolsEl,
      h('div', { class: 'cr-ok' }, h('button', { class: 'btn', type: 'button', onclick: () => scr.tryClose() }, 'বাতিল'), okB));
    scr.body.append(stage, bar);
    scr.body.classList.add('cr-body');

    /* ---------- model helpers ---------- */
    const W = () => work.width, H = () => work.height;
    function rebuild(reset) {
      work = transformCanvas(small, rot, flip, mode === 'rect' ? fine : 0, o.fill);
      view.width = work.width; view.height = work.height; g2(view).drawImage(work, 0, 0);
      slVal.textContent = (fine ? (fine > 0 ? '+' : '') + fine.toFixed(1) : '0') + '°';
      if (mode === 'rect') { if (reset) resetRect(); } else if (reset || !quad) initQuad();
      layout(); draw();
    }
    function resetRect() {
      const odd = rot % 2 !== 0, bw = odd ? small.height : small.width, bh = odd ? small.width : small.height;
      const ins = fine ? insetRect(bw, bh, fine * Math.PI / 180) : { w: W(), h: H() };
      let rw = clamp(ins.w / W(), .05, 1), rh = clamp(ins.h / H(), .05, 1);
      if (!fine) { rw = .92; rh = .92; }
      rect = { x: (1 - rw) / 2, y: (1 - rh) / 2, w: rw, h: rh }; if (ratio) fitRatio();
    }
    function fitRatio() {
      if (!ratio) return; const R = ratio * H() / W(); const cx = rect.x + rect.w / 2, cy = rect.y + rect.h / 2;
      let nw = rect.w, nh = nw / R; if (nh > rect.h) { nh = rect.h; nw = nh * R; }
      nw = Math.min(nw, 1); nh = nw / R; if (nh > 1) { nh = 1; nw = nh * R; }
      rect = { x: clamp(cx - nw / 2, 0, 1 - nw), y: clamp(cy - nh / 2, 0, 1 - nh), w: nw, h: nh };
    }
    function initQuad() {
      const found = o.quad ? { corners: o.quad, found: true } : detectQuad(work);
      quad = (found.corners || [[.06, .06], [.94, .06], [.94, .94], [.06, .94]]).map(a => [...a]);
      if (!found.found && !o.quad) toast('কিনারা নিজে ঠিক করুন — ৪টি বিন্দু টেনে কাগজের কোণে বসান', 3200);
    }
    function autoFit() {
      if (mode === 'quad') { const d = detectQuad(work); quad = d.corners.map(a => [...a]); draw(); if (!d.found) toast('কাগজ খুঁজে পাওয়া যায়নি — হাতে ঠিক করুন', 2600); return; }
      const d = detectQuad(work); if (!d.found) return toast('কাগজ/কার্ড খুঁজে পাওয়া যায়নি', 2400);
      const xs = d.corners.map(a => a[0]), ys = d.corners.map(a => a[1]); const x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
      rect = { x: x0, y: y0, w: x1 - x0, h: y1 - y0 }; if (ratio) fitRatio(); draw();
    }
    function fullArea() { if (mode === 'quad') { quad = [[0, 0], [1, 0], [1, 1], [0, 1]]; } else { rect = { x: 0, y: 0, w: 1, h: 1 }; if (ratio) fitRatio(); } draw(); }

    /* ---------- layout / zoom ---------- */
    function layout() {
      const bw = stage.clientWidth || 360, bh = stage.clientHeight || 420, pad = 14;
      const s = Math.min((bw - pad * 2) / work.width, (bh - pad * 2) / work.height); fw = Math.max(40, work.width * s); fh = Math.max(40, work.height * s);
      zoomEl.style.width = fw + 'px'; zoomEl.style.height = fh + 'px'; clampPan(); applyZ();
    }
    function clampPan() {
      const bw = stage.clientWidth, bh = stage.clientHeight, W2 = fw * z, H2 = fh * z;
      tx = W2 <= bw ? (bw - W2) / 2 : clamp(tx, bw - W2 - 20, 20); ty = H2 <= bh ? (bh - H2) / 2 : clamp(ty, bh - H2 - 20, 20);
    }
    function applyZ() { zoomEl.style.transform = `translate(${tx}px,${ty}px) scale(${z})`; stage.style.setProperty('--z', z); }
    function zoomAt(cx, cy, nz) { nz = clamp(nz, 1, 8); tx = cx - (cx - tx) * (nz / z); ty = cy - (cy - ty) * (nz / z); z = nz; clampPan(); applyZ(); }
    const ptr = new Map(); let pinch0 = null;
    stage.addEventListener('pointerdown', e => {
      if (e.target.closest('.cr-rect,.cr-q')) return;
      stage.setPointerCapture(e.pointerId); ptr.set(e.pointerId, { x: e.clientX, y: e.clientY });
      pinch0 = ptr.size === 2 ? { d: dist(), z, tx, ty, c: mid() } : null;
    });
    stage.addEventListener('pointermove', e => {
      const p = ptr.get(e.pointerId); if (!p) return;
      const r = stage.getBoundingClientRect();
      if (ptr.size === 2 && pinch0) { p.x = e.clientX; p.y = e.clientY; const c = mid(); const nz = clamp(pinch0.z * dist() / pinch0.d, 1, 8); const cx = pinch0.c.x - r.left, cy = pinch0.c.y - r.top; tx = pinch0.tx; ty = pinch0.ty; z = pinch0.z; zoomAt(cx, cy, nz); tx += c.x - pinch0.c.x; ty += c.y - pinch0.c.y; clampPan(); applyZ(); }
      else if (ptr.size === 1 && z > 1) { tx += e.clientX - p.x; ty += e.clientY - p.y; p.x = e.clientX; p.y = e.clientY; clampPan(); applyZ(); }
    });
    const up = e => { ptr.delete(e.pointerId); pinch0 = null; if (ptr.size === 1) { /* continue as pan */ } };
    stage.addEventListener('pointerup', up); stage.addEventListener('pointercancel', up);
    stage.addEventListener('wheel', e => { e.preventDefault(); const r = stage.getBoundingClientRect(); zoomAt(e.clientX - r.left, e.clientY - r.top, z * (e.deltaY < 0 ? 1.15 : .87)); }, { passive: false });
    stage.addEventListener('dblclick', e => { const r = stage.getBoundingClientRect(); if (z > 1.05) { z = 1; tx = ty = 0; clampPan(); applyZ(); } else zoomAt(e.clientX - r.left, e.clientY - r.top, 2.6); });
    function dist() { const a = [...ptr.values()]; return Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y) || 1; }
    function mid() { const a = [...ptr.values()]; return { x: (a[0].x + a[1].x) / 2, y: (a[0].y + a[1].y) / 2 }; }

    /* ---------- drawing the overlay ---------- */
    function draw() {
      const rm = mode === 'rect';
      rectEl.hidden = !rm; svg.style.display = rm ? 'none' : ''; qh.forEach(q => { q.hidden = rm; });
      rectEl.classList.toggle('lock', !!ratio);
      if (rm) {
        rectEl.style.left = rect.x * 100 + '%'; rectEl.style.top = rect.y * 100 + '%'; rectEl.style.width = rect.w * 100 + '%'; rectEl.style.height = rect.h * 100 + '%';
        const px = Math.round(rect.w * W() / ps), py = Math.round(rect.h * H() / ps); rectEl.dataset.size = `${px}×${py}`;
      } else {
        poly.setAttribute('d', 'M0 0H1V1H0Z M' + quad.map(a => a.join(' ')).join(' L') + 'Z'); line.setAttribute('points', quad.map(a => a.join(',')).join(' '));
        qh.forEach((q, i) => { q.style.left = quad[i][0] * 100 + '%'; q.style.top = quad[i][1] * 100 + '%'; });
      }
      drawChips();
    }
    function drawChips() {
      chipsEl.replaceChildren();
      if (o.allowQuad) {
        modeEl.replaceChildren(...[['rect', 'সাধারণ ক্রপ'], ['quad', 'কাগজ সোজা (৪ কোণা)']].map(([k, t]) => h('button', { type: 'button', class: mode === k ? 'on' : '', onclick: () => { if (mode === k) return; mode = k; if (k === 'quad') { fine = 0; sl.value = 0; } rebuild(true); } }, t)));
        chipsEl.append(modeEl);
      }
      if (mode === 'rect' && o.ratios.length) chipsEl.append(h('div', { class: 'cr-ratios' }, o.ratios.map(([v, t]) => h('button', { type: 'button', class: 'chip' + (Math.abs(ratio - v) < 1e-6 ? ' on' : ''), onclick: () => { ratio = v; fitRatio(); draw(); } }, t))));
      slRow.hidden = mode !== 'rect';
    }

    /* ---------- pointer → normalised coords of the (possibly zoomed) overlay ---------- */
    const norm = e => { const r = ov.getBoundingClientRect(); return { x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height }; };
    function showLoupe(nx, ny) {
      const c = loupe.firstChild, g = c.getContext('2d'), S = 34; loupe.hidden = false; loupe.classList.toggle('r', nx < .5 && ny < .35);
      g.imageSmoothingEnabled = true; g.fillStyle = '#000'; g.fillRect(0, 0, 104, 104);
      g.drawImage(view, nx * view.width - S / 2, ny * view.height - S / 2, S, S, 0, 0, 104, 104);
      g.strokeStyle = 'rgba(255,255,255,.95)'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(52, 38); g.lineTo(52, 66); g.moveTo(38, 52); g.lineTo(66, 52); g.stroke();
    }
    // rect drag
    rectEl.addEventListener('pointerdown', e => {
      e.preventDefault(); e.stopPropagation(); const k = e.target.dataset.k || '', p0 = norm(e), s = { ...rect }; rectEl.setPointerCapture(e.pointerId); rectEl.classList.add('drag');
      rectEl.onpointermove = ev => {
        const p = norm(ev), dx = p.x - p0.x, dy = p.y - p0.y;
        if (!k) rect = { x: clamp(s.x + dx, 0, 1 - s.w), y: clamp(s.y + dy, 0, 1 - s.h), w: s.w, h: s.h };
        else {
          let x0 = s.x, y0 = s.y, x1 = s.x + s.w, y1 = s.y + s.h;
          if (k.includes('w')) x0 = clamp(s.x + dx, 0, x1 - MIN); if (k.includes('e')) x1 = clamp(x1 + dx, x0 + MIN, 1);
          if (k.includes('n')) y0 = clamp(s.y + dy, 0, y1 - MIN); if (k.includes('s')) y1 = clamp(y1 + dy, y0 + MIN, 1);
          if (ratio) {
            const R = ratio * H() / W(), ax = k.includes('w') ? s.x + s.w : s.x, ay = k.includes('n') ? s.y + s.h : s.y;
            let nw = Math.abs((k.includes('w') ? s.x + dx : s.x + s.w + dx) - ax); const maxW = k.includes('w') ? ax : 1 - ax, maxH = k.includes('n') ? ay : 1 - ay;
            let nh = nw / R; if (nw > maxW) { nw = maxW; nh = nw / R; } if (nh > maxH) { nh = maxH; nw = nh * R; } nw = Math.max(nw, MIN); nh = nw / R;
            x0 = k.includes('w') ? ax - nw : ax; y0 = k.includes('n') ? ay - nh : ay; x1 = x0 + nw; y1 = y0 + nh;
          }
          rect = { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
          if (k.length === 2) showLoupe(k.includes('w') ? rect.x : rect.x + rect.w, k.includes('n') ? rect.y : rect.y + rect.h);
        }
        draw();
      };
      const end = () => { rectEl.onpointermove = null; rectEl.classList.remove('drag'); loupe.hidden = true; };
      rectEl.onpointerup = end; rectEl.onpointercancel = end;
    });
    // quad drag
    qh.forEach((q, i) => q.addEventListener('pointerdown', e => {
      e.preventDefault(); e.stopPropagation(); q.setPointerCapture(e.pointerId); q.classList.add('drag');
      q.onpointermove = ev => { const p = norm(ev); quad[i] = [clamp(p.x, 0, 1), clamp(p.y, 0, 1)]; draw(); showLoupe(quad[i][0], quad[i][1]); };
      const end = () => { q.onpointermove = null; q.classList.remove('drag'); loupe.hidden = true; }; q.onpointerup = end; q.onpointercancel = end;
    }));
    sl.addEventListener('input', () => { fine = +sl.value; rebuild(true); });

    /* ---------- export at full resolution ---------- */
    okB.addEventListener('click', async () => {
      okB.disabled = true; await new Promise(r => setTimeout(r, 30));
      if (o.cornersOnly) { done({ corners: quad.map(a => [...a]) }); scr.close(); return; }
      try {
        const big = transformCanvas(full, rot, flip, mode === 'rect' ? fine : 0, o.fill);
        let out;
        if (mode === 'rect') {
          out = cnv(rect.w * big.width, rect.h * big.height); g2(out).drawImage(big, rect.x * big.width, rect.y * big.height, rect.w * big.width, rect.h * big.height, 0, 0, out.width, out.height);
        } else {
          const id = g2(big).getImageData(0, 0, big.width, big.height), q = quad.map(([x, y]) => [x * big.width, y * big.height]), { w, h: hh } = P.quadSize(q, 2600);
          const r = P.warpPerspective(id, q, w, hh); out = cnv(w, hh); g2(out).putImageData(new ImageData(r.data, w, hh), 0, 0);
        }
        done(out); scr.close();
      } catch (e) { console.error(e); toast('ক্রপ করা যায়নি: ' + errMsg(e), 4000); okB.disabled = false; }
    });

    requestAnimationFrame(() => { rebuild(true); requestAnimationFrame(layout); });
    new ResizeObserver(() => { if (work) layout(); }).observe(stage);
  });
}
