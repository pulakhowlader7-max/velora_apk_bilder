// Velora — Android bridge: files arriving from other apps ("Open with" / "Share to"), native detection.
import { toast, errMsg, plugin } from './util.js';

export const isNative = () => !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());

const b64ToBlob = (b64, type = '') => { const bin = atob(b64), a = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i); return new Blob([a], { type }); };

async function readIncoming(f) {
  const uri = 'file://' + f.path; let blob;
  try {
    const r = await fetch(window.Capacitor.convertFileSrc(uri)); if (!r.ok) throw new Error('http ' + r.status);
    blob = await r.blob();
  } catch (e) {
    const FS = plugin('Filesystem'); const r = await FS.readFile({ path: uri }); blob = b64ToBlob(r.data);
  }
  return new File([blob], f.name || 'file', { type: f.mime && f.mime !== 'application/octet-stream' ? f.mime : '' });
}

/** Calls handler(files[]) for every batch of files other apps send to Velora (also those that opened the app). */
export async function initIncoming(handler) {
  if (!isNative()) return;
  const P = plugin('VeloraIntent'); if (!P) return;
  let running = false, again = false;
  const drain = async () => {
    if (running) { again = true; return; } running = true;
    try {
      do {
        again = false; const res = await P.getPending(); const list = (res && res.files) || [];
        if (!list.length) continue;
        const out = [];
        for (const f of list) {
          try { out.push(await readIncoming(f)); } catch (e) { console.warn(e); toast('"' + (f.name || 'ফাইল') + '" পড়া যায়নি: ' + errMsg(e), 4000); }
          finally { P.cleanup({ path: f.path }).catch(() => { }); }
        }
        if (out.length) await handler(out);
      } while (again);
    } finally { running = false; }
  };
  try { await P.addListener('fileOpened', drain); } catch (e) { console.warn(e); }
  await drain();
}
