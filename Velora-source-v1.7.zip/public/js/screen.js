// Full-screen sub-pages (scanner, photo editor, AI chat…) that cooperate with the phone's Back button.
import { h, btn, pushLayer, leave } from './util.js';

export function screen({ title = '', actions = [], onClose, cls = '' } = {}) {
  const body = h('div', { class: 'scr-body' });
  const titleEl = h('div', { class: 'scr-title' }, title);
  const back = btn('back', 'ফিরুন', () => { api.tryClose(); }, { keepFocus: false });
  const top = h('div', { class: 'ed-top scr-top' }, back, titleEl, ...actions);
  const el = h('div', { class: 'ed scr ' + cls }, top, body);
  document.body.append(el);
  let closed = false, release, guard = null;
  const api = {
    el, body, top, titleEl,
    setTitle(t) { titleEl.textContent = t; },
    // guard: async () => true to allow closing (e.g. ask "discard changes?")
    setGuard(fn) { guard = fn; },
    async tryClose() { if (guard && !(await guard())) return false; api.close(); return true; },
    close(fromPop) {
      if (closed) return; closed = true; leave(el);
      if (!fromPop) release();
      onClose && onClose();
    },
  };
  const onPop = () => {
    if (!guard) return api.close(true);
    guard().then(ok => { if (ok) api.close(true); else release = pushLayer(onPop); });
  };
  release = pushLayer(onPop);
  return api;
}
