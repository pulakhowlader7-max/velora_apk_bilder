// Presentation editor: JSON slide model, drag/resize, present mode, PPTX import/export, PDF export.
import { h, icon, btn, sheet as actionSheet, modal, promptDlg, confirmDlg, pickColor, pickFiles, toast, busy, toBn, esc, baseName, extOf, readBuf, errMsg, clamp, uid, imageToDataURL, pushLayer, needJSZip, needPptx, saveToDevice } from './util.js';
import { getSettings } from './db.js';
import { SLIDE_THEMES } from './templates.js';

const W = 1280, H = 720;
const FONT_TAIL = '"Noto Sans Bengali","Kalpurush","Nirmala UI",system-ui,sans-serif';
const themeOf = id => SLIDE_THEMES.find(t => t.id === id) || SLIDE_THEMES[0];
const TOKENS = { '@title': t => t.title, '@body': t => t.body, '@accent': t => t.accent, '@bg': t => t.bg };
const col = (c, t) => (c && TOKENS[c]) ? TOKENS[c](t) : c;
const hex = c => { let x = String(c || '').replace('#', '').toUpperCase(); if (x.length === 3) x = x.replace(/./g, d => d + d); return x.padEnd(6, '0').slice(0, 6); };
const hasBn = s => /[ঀ-৿]/.test(s);

/* ---------- model helpers ---------- */
const shape = (x, y, w, h2, o = {}) => ({ id: uid(), type: 'shape', geo: 'rect', x, y, w, h: h2, text: '', fs: 28, color: '@body', ha: 'left', va: 'top', ...o });
const txt = (x, y, w, h2, text, o = {}) => shape(x, y, w, h2, { text, ...o });
function layoutSlide(kind, t) {
  const bar = (x, y, w = 110) => shape(x, y, w, 8, { fill: '@accent', fs: 10 });
  switch (kind) {
    case 'title': return { els: [bar(100, 250), txt(100, 275, 1080, 150, 'শিরোনাম লিখুন', { fs: 66, b: 1, color: '@title', va: 'top' }), txt(100, 440, 1080, 90, 'উপশিরোনাম', { fs: 32, color: '@body' })] };
    case 'section': return { els: [shape(0, 0, 1280, 720, { fill: '@accent', fs: 10 }), txt(100, 270, 1080, 160, 'বিভাগের নাম', { fs: 64, b: 1, color: '#ffffff', va: 'middle' })] };
    case 'two': return { els: [txt(80, 46, 1120, 90, 'শিরোনাম', { fs: 46, b: 1, color: '@title', va: 'middle' }), bar(80, 140, 90), txt(80, 180, 540, 480, '• প্রথম পয়েন্ট\n• দ্বিতীয় পয়েন্ট\n• তৃতীয় পয়েন্ট', { fs: 28 }), txt(660, 180, 540, 480, '• প্রথম পয়েন্ট\n• দ্বিতীয় পয়েন্ট\n• তৃতীয় পয়েন্ট', { fs: 28 })] };
    case 'blank': return { els: [] };
    case 'titleonly': return { els: [txt(80, 46, 1120, 90, 'শিরোনাম', { fs: 46, b: 1, color: '@title', va: 'middle' }), bar(80, 140, 90)] };
    default: return { els: [txt(80, 46, 1120, 90, 'শিরোনাম', { fs: 46, b: 1, color: '@title', va: 'middle' }), bar(80, 140, 90), txt(80, 180, 1120, 480, '• প্রথম পয়েন্ট\n• দ্বিতীয় পয়েন্ট\n• তৃতীয় পয়েন্ট', { fs: 30 })] };
  }
}
const LAYOUTS = [['title', 'টাইটেল'], ['content', 'শিরোনাম ও বিষয়বস্তু'], ['two', 'দুই কলাম'], ['titleonly', 'শুধু শিরোনাম'], ['section', 'বিভাগ'], ['blank', 'ফাঁকা']];
const newSlide = (kind, t) => ({ id: uid(), els: layoutSlide(kind, t).els, notes: '' });
const clone = o => JSON.parse(JSON.stringify(o));
function defaultModel(themeId) {
  const t = themeOf(themeId); const s1 = newSlide('title', t), s2 = newSlide('content', t);
  return { v: 1, theme: t.id, slides: [s1, s2] };
}

/* ---------- rendering ---------- */
function elNode(e, t, o = {}) {
  const d = document.createElement('div'); d.className = 'sl-el'; d.dataset.id = e.id;
  const st = d.style; st.left = e.x + 'px'; st.top = e.y + 'px'; st.width = e.w + 'px'; st.height = e.h + 'px';
  if (e.rot) st.transform = `rotate(${e.rot}deg)`; if (e.op != null && e.op < 1) st.opacity = e.op;
  if (e.type === 'image') { const i = document.createElement('img'); i.src = e.src; i.draggable = false; i.style.cssText = 'width:100%;height:100%;object-fit:fill;display:block;pointer-events:none'; d.append(i); return d; }
  const fill = col(e.fill, t), stroke = col(e.stroke, t);
  if (fill) st.background = fill; if (stroke) st.border = `${e.sw || 2}px solid ${stroke}`;
  st.borderRadius = e.geo === 'ellipse' ? '50%' : e.geo === 'round' ? Math.min(e.w, e.h) * .15 + 'px' : '0';
  const tx = document.createElement('div'); tx.className = 'tx';
  tx.style.cssText = `width:100%;height:100%;box-sizing:border-box;padding:6px 10px;display:flex;flex-direction:column;justify-content:${e.va === 'middle' ? 'center' : e.va === 'bottom' ? 'flex-end' : 'flex-start'};overflow:hidden;font-family:"${e.font || t.font}",${FONT_TAIL};font-size:${e.fs || 28}px;line-height:1.25;color:${col(e.color, t) || '#000'};text-align:${e.ha || 'left'};font-weight:${e.b ? 700 : 400};font-style:${e.i ? 'italic' : 'normal'};text-decoration:${e.u ? 'underline' : 'none'};white-space:pre-wrap;word-break:break-word`;
  tx.textContent = e.text || ''; d.append(tx); return d;
}
function slideNode(s, t, o = {}) {
  const d = document.createElement('div'); d.className = 'sl-slide'; d.style.cssText = `width:${W}px;height:${H}px;background:${col(s.bg, t) || t.bg}`;
  for (const e of s.els) d.append(elNode(e, t, o)); return d;
}
const SL_CSS = '.sl-slide{position:relative;overflow:hidden}.sl-el{position:absolute;box-sizing:border-box}';

/* ---------- PPTX export ---------- */
async function modelToPptx(m, { title, author }) {
  const P = await needPptx(); const pp = new P(); pp.layout = 'LAYOUT_WIDE'; pp.title = title || ''; pp.author = author || ''; const t = themeOf(m.theme); const k = 1 / 96;
  for (const s of m.slides) {
    const sl = pp.addSlide(); sl.background = { color: hex(col(s.bg, t) || t.bg) };
    for (const e of s.els) {
      const pos = { x: e.x * k, y: e.y * k, w: e.w * k, h: e.h * k };
      if (e.rot) pos.rotate = e.rot;
      if (e.type === 'image') { try { sl.addImage({ data: e.src, ...pos }); } catch (x) { console.warn(x); } continue; }
      const fill = col(e.fill, t), stroke = col(e.stroke, t);
      const gt = e.geo === 'ellipse' ? pp.ShapeType.ellipse : e.geo === 'round' ? pp.ShapeType.roundRect : pp.ShapeType.rect;
      const common = { ...pos, shape: gt, ...(fill ? { fill: { color: hex(fill), transparency: e.op != null && e.op < 1 ? Math.round((1 - e.op) * 100) : 0 } } : {}), ...(stroke ? { line: { color: hex(stroke), width: (e.sw || 2) * .75 } } : {}), ...(e.geo === 'round' ? { rectRadius: .15 } : {}) };
      if (e.text) {
        const bn = hasBn(e.text);
        sl.addText(e.text.split('\n').map((ln, i, a) => ({ text: ln, options: { breakLine: i < a.length - 1 } })), { ...common, fontSize: (e.fs || 28) * .75, bold: !!e.b, italic: !!e.i, underline: e.u ? { style: 'sng' } : undefined, color: hex(col(e.color, t) || '#000'), fontFace: e.font || (bn ? 'Nirmala UI' : t.font), align: e.ha || 'left', valign: e.va === 'middle' ? 'middle' : e.va === 'bottom' ? 'bottom' : 'top', margin: [4, 7, 4, 7], fit: 'none', wrap: true });
      } else if (fill || stroke) sl.addShape(gt, { ...pos, ...(common.fill ? { fill: common.fill } : { fill: { type: 'none' } }), line: common.line || { type: 'none' }, ...(e.geo === 'round' ? { rectRadius: .15 } : {}), ...(e.rot ? { rotate: e.rot } : {}) });
    }
    if (s.notes) sl.addNotes(s.notes);
  }
  return pp.write({ outputType: 'arraybuffer' });
}

/* ---------- PPTX import ---------- */
const NS = { a: 'http://schemas.openxmlformats.org/drawingml/2006/main', p: 'http://schemas.openxmlformats.org/presentationml/2006/main', r: 'http://schemas.openxmlformats.org/officeDocument/2006/relationships' };
const ln = (el, name) => el ? [...el.children].filter(c => c.localName === name) : [];
const l1 = (el, name) => ln(el, name)[0] || null;
const path = (el, ...names) => { let c = el; for (const n of names) { c = l1(c, n); if (!c) return null; } return c; };
const dp = s => new DOMParser().parseFromString(s, 'application/xml');
async function pptxToModel(buf) {
  const JSZip = await needJSZip(); const zip = await JSZip.loadAsync(buf);
  const read = async p => { const f = zip.file(p); return f ? dp(await f.async('string')) : null; };
  const pres = await read('ppt/presentation.xml'); if (!pres) throw new Error('এটি বৈধ PPTX ফাইল নয়');
  const sz = pres.getElementsByTagNameNS(NS.p, 'sldSz')[0]; const cx = +(sz && sz.getAttribute('cx')) || 9144000, cy = +(sz && sz.getAttribute('cy')) || 6858000;
  const sc = W / cx; const hh = cy * sc; const vs = H / hh; // fit to 16:9 vertically if different
  const relsOf = async p => { const d = await read(p.replace(/([^/]+)$/, '_rels/$1.rels')); const m = {}; if (d) for (const r of d.getElementsByTagName('Relationship')) { let tg = r.getAttribute('Target'); const base = p.split('/').slice(0, -1).join('/'); if (!tg.startsWith('/')) { const parts = (base + '/' + tg).split('/'); const o = []; for (const q of parts) { if (q === '..') o.pop(); else if (q !== '.') o.push(q); } tg = o.join('/'); } else tg = tg.slice(1); m[r.getAttribute('Id')] = { target: tg, type: r.getAttribute('Type') }; } return m; };
  const prels = await relsOf('ppt/presentation.xml'); const ids = [...pres.getElementsByTagNameNS(NS.p, 'sldId')].map(x => x.getAttributeNS(NS.r, 'id'));
  // theme colours
  const themeRel = Object.values(prels).find(r => /theme$/.test(r.type)); const thDoc = themeRel ? await read(themeRel.target) : null; const clr = {};
  if (thDoc) { const cs = thDoc.getElementsByTagNameNS(NS.a, 'clrScheme')[0]; if (cs) for (const c of cs.children) { const v = c.firstElementChild; clr[c.localName] = v ? (v.getAttribute('val') === 'windowText' ? '000000' : v.getAttribute('val') === 'window' ? 'FFFFFF' : v.getAttribute('lastClr') || v.getAttribute('val')) : '000000'; } }
  const mapC = { tx1: 'dk1', bg1: 'lt1', tx2: 'dk2', bg2: 'lt2' };
  const colorOf = el => { if (!el) return null; const sf = l1(el, 'solidFill') || el; const c = [...sf.children].find(x => ['srgbClr', 'schemeClr', 'sysClr', 'prstClr'].includes(x.localName)); if (!c) return null; let v; if (c.localName === 'srgbClr') v = c.getAttribute('val'); else if (c.localName === 'sysClr') v = c.getAttribute('lastClr') || '000000'; else if (c.localName === 'prstClr') v = ({ black: '000000', white: 'FFFFFF', red: 'FF0000', blue: '0000FF', green: '00FF00' })[c.getAttribute('val')] || '000000'; else { const n = c.getAttribute('val'); v = clr[mapC[n] || n] || '000000'; } return '#' + v; };
  const media = async p => { const f = zip.file(p); if (!f) return null; const e = extOf(p); const mime = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', svg: 'image/svg+xml', webp: 'image/webp' }[e]; if (!mime) return null; return `data:${mime};base64,` + await f.async('base64'); };
  const slides = []; let skipped = 0;
  for (const rid of ids) {
    const rel = prels[rid]; if (!rel) continue; const doc = await read(rel.target); if (!doc) continue; const srels = await relsOf(rel.target);
    const layRel = Object.values(srels).find(r => /slideLayout$/.test(r.type)); const layDoc = layRel ? await read(layRel.target) : null; let masDoc = null;
    if (layRel) { const lr = await relsOf(layRel.target); const mr = Object.values(lr).find(r => /slideMaster$/.test(r.type)); if (mr) masDoc = await read(mr.target); }
    const phXfrm = ph => { for (const d of [layDoc, masDoc]) { if (!d) continue; for (const sp of d.getElementsByTagNameNS(NS.p, 'sp')) { const p2 = sp.getElementsByTagNameNS(NS.p, 'ph')[0]; if (!p2) continue; const same = (ph.getAttribute('idx') && p2.getAttribute('idx') === ph.getAttribute('idx')) || (!ph.getAttribute('idx') && (p2.getAttribute('type') || 'body') === (ph.getAttribute('type') || 'body')) || (p2.getAttribute('type') && p2.getAttribute('type') === ph.getAttribute('type')); if (!same) continue; const x = path(sp, 'spPr', 'xfrm'); if (x) return x; } } return null; };
    const out = { id: uid(), els: [], notes: '' };
    const bgc = colorOf(path(doc.documentElement, 'cSld', 'bg', 'bgPr')) || colorOf(path(layDoc && layDoc.documentElement, 'cSld', 'bg', 'bgPr')) || colorOf(path(masDoc && masDoc.documentElement, 'cSld', 'bg', 'bgPr')); if (bgc) out.bg = bgc;
    const walk = async (tree, T) => {
      for (const n of tree.children) {
        const nm = n.localName;
        if (nm === 'grpSp') { const x = path(n, 'grpSpPr', 'xfrm'); let T2 = T; if (x) { const off = l1(x, 'off'), ext = l1(x, 'ext'), co = l1(x, 'chOff'), ce = l1(x, 'chExt'); if (off && ext && co && ce) { const sx = +ext.getAttribute('cx') / (+ce.getAttribute('cx') || 1), sy = +ext.getAttribute('cy') / (+ce.getAttribute('cy') || 1); T2 = { sx: T.sx * sx, sy: T.sy * sy, tx: T.tx + T.sx * (+off.getAttribute('x') - +co.getAttribute('x') * sx), ty: T.ty + T.sy * (+off.getAttribute('y') - +co.getAttribute('y') * sy) }; } } await walk(n, T2); continue; }
        if (!['sp', 'pic', 'graphicFrame', 'cxnSp'].includes(nm)) continue;
        const spPr = l1(n, 'spPr'); let xf = spPr && l1(spPr, 'xfrm'); if (nm === 'graphicFrame') xf = l1(n, 'xfrm');
        const phEl = n.getElementsByTagNameNS(NS.p, 'ph')[0]; if (!xf && phEl) xf = phXfrm(phEl); if (!xf) { skipped++; continue; }
        const off = l1(xf, 'off'), ext = l1(xf, 'ext'); if (!off || !ext) continue;
        const X = (T.tx + T.sx * +off.getAttribute('x')) * sc, Y = (T.ty + T.sy * +off.getAttribute('y')) * sc * vs, Wd = T.sx * +ext.getAttribute('cx') * sc, Ht = T.sy * +ext.getAttribute('cy') * sc * vs;
        const rot = (+xf.getAttribute('rot') || 0) / 60000;
        if (nm === 'pic') { const bl = n.getElementsByTagNameNS(NS.a, 'blip')[0]; const id = bl && bl.getAttributeNS(NS.r, 'embed'); const r = id && srels[id]; const src = r ? await media(r.target) : null; if (src) out.els.push({ id: uid(), type: 'image', src, x: X, y: Y, w: Wd, h: Ht, rot }); else skipped++; continue; }
        if (nm === 'graphicFrame') {
          const tbl = n.getElementsByTagNameNS(NS.a, 'tbl')[0]; if (!tbl) { skipped++; continue; }
          const gw = ln(l1(tbl, 'tblGrid'), 'gridCol').map(g => +g.getAttribute('w') * T.sx * sc); let y = Y;
          for (const tr of ln(tbl, 'tr')) { const rh = +tr.getAttribute('h') * T.sy * sc * vs; let x = X; ln(tr, 'tc').forEach((tc, ci) => { const w = gw[ci] || Wd / 3; const p = ln(l1(tc, 'txBody'), 'p'); const text = p.map(pp => ln(pp, 'r').map(r => (l1(r, 't') || {}).textContent || '').join('')).join('\n'); const rp = p[0] && l1(ln(p[0], 'r')[0], 'rPr'); const fillC = colorOf(path(tc, 'tcPr')) ; out.els.push(shape(x, y, w, rh, { text, fs: rp && rp.getAttribute('sz') ? +rp.getAttribute('sz') / 100 * 12700 * sc / 1 * (1) : 20, color: (rp && colorOf(rp)) || '#000000', b: rp && rp.getAttribute('b') === '1' ? 1 : 0, fill: fillC || undefined, stroke: '#9aa1b5', sw: 1, va: 'middle' })); x += w; }); y += rh; }
          continue;
        }
        const geoEl = spPr && l1(spPr, 'prstGeom'); const prst = geoEl ? geoEl.getAttribute('prst') : 'rect';
        const isLine = nm === 'cxnSp' || prst === 'line' || prst === 'straightConnector1';
        let fill = spPr && !l1(spPr, 'noFill') ? colorOf(l1(spPr, 'solidFill') ? spPr : null) : null; const lnE = spPr && l1(spPr, 'ln'); let stroke = lnE && !l1(lnE, 'noFill') ? colorOf(l1(lnE, 'solidFill') ? lnE : null) : null; const sw = lnE && lnE.getAttribute('w') ? Math.max(1, +lnE.getAttribute('w') * sc) : 2;
        if (isLine) { out.els.push(shape(X, Y, Math.max(Wd, 3), Math.max(Ht, 3), { fill: stroke || '#333333', fs: 10 })); continue; }
        const tb = l1(n, 'txBody'); const paras = tb ? ln(tb, 'p') : []; let text = '', fs = 0, color = null, b = 0, i = 0, u = 0, ha = 'left', font;
        paras.forEach((p, pi) => { const pPr = l1(p, 'pPr'); if (pi === 0 && pPr && pPr.getAttribute('algn')) ha = ({ l: 'left', ctr: 'center', r: 'right', just: 'left' })[pPr.getAttribute('algn')] || 'left'; let line = ''; for (const r of p.children) { if (r.localName === 'r' || r.localName === 'fld') { line += (l1(r, 't') || {}).textContent || ''; const rp = l1(r, 'rPr'); if (rp && !fs) { if (rp.getAttribute('sz')) fs = +rp.getAttribute('sz') / 100 * 12700 * sc; color = colorOf(rp) || color; b = rp.getAttribute('b') === '1' ? 1 : 0; i = rp.getAttribute('i') === '1' ? 1 : 0; u = rp.getAttribute('u') && rp.getAttribute('u') !== 'none' ? 1 : 0; const lat = l1(rp, 'latin'); if (lat && !/^\+/.test(lat.getAttribute('typeface'))) font = lat.getAttribute('typeface'); } } else if (r.localName === 'br') line += '\n'; } const bu = pPr && l1(pPr, 'buChar'); if (bu && line) line = '• ' + line; text += (pi ? '\n' : '') + line; });
        if (!fs) { const ty = phEl && phEl.getAttribute('type'); fs = (ty === 'title' || ty === 'ctrTitle' ? 44 : ty === 'subTitle' ? 24 : 18) * 12700 * sc; }
        const bp = tb && l1(tb, 'bodyPr'); const va = bp && bp.getAttribute('anchor') === 'ctr' ? 'middle' : bp && bp.getAttribute('anchor') === 'b' ? 'bottom' : 'top';
        if (!text.trim() && !fill && !stroke) continue;
        out.els.push({ id: uid(), type: 'shape', geo: prst === 'ellipse' ? 'ellipse' : prst === 'roundRect' ? 'round' : 'rect', x: X, y: Y, w: Wd, h: Ht, rot, text, fs: Math.round(fs * vs), color: color || '#000000', b, i, u, ha, va, fill: fill || undefined, stroke: stroke || undefined, sw, font });
      }
    };
    const tree = path(doc.documentElement, 'cSld', 'spTree'); if (tree) await walk(tree, { sx: 1, sy: 1, tx: 0, ty: 0 });
    // notes
    const nr = Object.values(srels).find(r => /notesSlide$/.test(r.type)); if (nr) { const nd = await read(nr.target); if (nd) { const parts = []; for (const sp of nd.getElementsByTagNameNS(NS.p, 'sp')) { const ph = sp.getElementsByTagNameNS(NS.p, 'ph')[0]; if (ph && ph.getAttribute('type') === 'body') parts.push([...sp.getElementsByTagNameNS(NS.a, 'p')].map(p => p.textContent).join('\n')); } out.notes = parts.join('\n'); } }
    slides.push(out);
  }
  if (!slides.length) slides.push(newSlide('blank', themeOf('clean')));
  return { m: { v: 1, theme: 'clean', slides }, skipped };
}

/* ---------- create / import ---------- */
async function pack(m, name) { const s = await getSettings(); return { buf: await modelToPptx(m, { title: baseName(name), author: s.author || '' }), snap: JSON.stringify(m) }; }
export async function blank({ theme } = {}) { const t = theme && theme.id ? theme : themeOf(theme); const m = defaultModel(t.id); return { name: 'নতুন প্রেজেন্টেশন.pptx', ...(await pack(m, 'প্রেজেন্টেশন')) }; }
export async function fromOutline({ theme = 'clean', title, subtitle = '', slides = [] }) {
  const t = themeOf(theme); const m = { v: 1, theme: t.id, slides: [] };
  const s0 = newSlide('title', t); s0.els[1].text = String(title || 'প্রেজেন্টেশন'); s0.els[2].text = String(subtitle || ''); m.slides.push(s0);
  for (const s of slides.slice(0, 30)) {
    const ns = newSlide('content', t); const bl = (Array.isArray(s.bullets) ? s.bullets : []).slice(0, 8).map(String);
    ns.els[0].text = String(s.title || ''); ns.els[2].text = bl.map(b => '• ' + b).join('\n'); ns.els[2].fs = bl.length > 5 || bl.join('').length > 260 ? 24 : 30; ns.notes = String(s.notes || ''); m.slides.push(ns);
  }
  const nm = String(title || 'প্রেজেন্টেশন').replace(/[\\/:*?"<>|]/g, '').slice(0, 60) + '.pptx';
  return { name: nm, ...(await pack(m, nm)) };
}
export async function importFile(file) { const { m, skipped } = await pptxToModel(await readBuf(file)); if (skipped) toast(`${toBn(skipped)}টি উপাদান (চার্ট/স্মার্টআর্ট ইত্যাদি) দেখানো যায়নি`, 4500); const name = baseName(file.name) + '.pptx'; return { name, ...(await pack(m, name)) }; }

/* ---------- editor ---------- */
export async function mount(ctx) {
  let m;
  if (typeof ctx.snap === 'string') m = JSON.parse(ctx.snap); else { const r = await pptxToModel(ctx.buf); m = r.m; if (r.skipped) toast(`${toBn(r.skipped)}টি উপাদান দেখানো যায়নি`, 4500); }
  let cur = 0, selId = null, Z = 1, editingId = null; let hdr, as;
  const T = () => themeOf(m.theme); const S = () => m.slides[cur]; const E = id => S().els.find(e => e.id === id);

  const stage = h('div', { class: 'sl-stage' }); const wrap = h('div', { style: { position: 'relative', flex: 'none' } }); stage.append(wrap);
  const strip = h('div', { class: 'sl-strip' });
  let slideEl = null, selBox = null;

  /* history */
  const hist = []; let hi = -1; let last = JSON.stringify(m);
  function commit(skipMark) { const now = JSON.stringify(m); if (now === last) return; hist.length = hi + 1; hist.push(last); if (hist.length > 60) hist.shift(); hi = hist.length - 1; last = now; hdr && hdr.setUndo(true, false); if (!skipMark) as && as.mark(); }
  function restore(js) { m = JSON.parse(js); last = js; cur = clamp(cur, 0, m.slides.length - 1); if (selId && !E(selId)) selId = null; fit(); renderAll(); as && as.mark(); }
  let redoStack = [];
  function undo() { if (editingId) { finishEdit(true); return; } if (hi < 0) return; redoStack.push(last); restore(hist[hi]); hist.length = hi; hi--; hdr.setUndo(hi >= 0, true); }
  function redo() { if (!redoStack.length) return; hist.push(last); hi = hist.length - 1; restore(redoStack.pop()); hdr.setUndo(true, redoStack.length > 0); }
  const origCommit = commit; commit = (s) => { const before = last; origCommit(s); if (last !== before) redoStack = []; };

  /* layout */
  function fit() { const w = stage.clientWidth - 24, hh = stage.clientHeight - 24; if (w <= 0 || hh <= 0) return; Z = Math.min(w / W, hh / H); wrap.style.width = W * Z + 'px'; wrap.style.height = H * Z + 'px'; if (slideEl) slideEl.style.transform = `scale(${Z})`; }
  function renderStage() {
    wrap.replaceChildren(); slideEl = slideNode(S(), T()); slideEl.style.transformOrigin = 'top left'; slideEl.style.boxShadow = 'var(--shadow)'; wrap.append(slideEl); fit();
    slideEl.querySelectorAll('.sl-el').forEach(n => { n.style.cursor = 'move'; });
    drawSel();
  }
  function drawSel() {
    if (selBox) { selBox.remove(); selBox = null; } const e = selId && E(selId); if (!e || !slideEl || editingId === selId) return;
    selBox = h('div', { class: 'sl-sel', style: { left: e.x + 'px', top: e.y + 'px', width: e.w + 'px', height: e.h + 'px', borderWidth: 2 / Z + 'px', transform: e.rot ? `rotate(${e.rot}deg)` : '' } });
    const hs = 18 / Z; for (const [k, l, t] of [['nw', 0, 0], ['ne', 100, 0], ['sw', 0, 100], ['se', 100, 100], ['n', 50, 0], ['s', 50, 100], ['w', 0, 50], ['e', 100, 50]]) { const d = h('div', { class: 'sl-h', style: { left: l + '%', top: t + '%', width: hs + 'px', height: hs + 'px', margin: `${-hs / 2}px 0 0 ${-hs / 2}px`, borderWidth: 2 / Z + 'px', pointerEvents: 'auto', cursor: k + '-resize' } }); d.dataset.h = k; selBox.append(d); }
    selBox.style.pointerEvents = 'none'; slideEl.append(selBox);
  }
  function renderThumbs() {
    strip.replaceChildren(...m.slides.map((s, i) => { const inner = slideNode(s, T()); inner.style.transform = 'scale(.1)'; inner.style.transformOrigin = 'top left'; const b = h('button', { class: 'sl-th' + (i === cur ? ' on' : ''), type: 'button', style: { width: '132px', height: '77px' }, onclick: () => goto(i) }, h('span', { class: 'num' }, toBn(i + 1)), h('div', { class: 'inner', style: { width: W + 'px', height: H + 'px', transform: 'scale(.1)' } }, inner)); inner.style.transform = ''; inner.style.boxShadow = 'none'; b.querySelector('.inner').style.transform = `scale(${128 / W})`; return b; }), h('button', { class: 'sl-addth', type: 'button', onclick: addSlideDlg }, icon('plus', 22)));
    const on = strip.querySelector('.on'); if (on) on.scrollIntoView({ block: 'nearest', inline: 'center' });
  }
  function renderAll() { renderStage(); renderThumbs(); syncTb(); }
  function goto(i) { finishEdit(); cur = clamp(i, 0, m.slides.length - 1); selId = null; renderAll(); }

  /* interaction */
  let drag = null;
  stage.addEventListener('pointerdown', ev => {
    if (!slideEl) return; const hnd = ev.target.closest('.sl-h'); const node = ev.target.closest('.sl-el'); const pt = p => { const r = slideEl.getBoundingClientRect(); return { x: (p.clientX - r.left) / Z, y: (p.clientY - r.top) / Z }; };
    if (editingId) { if (node && node.dataset.id === editingId) return; finishEdit(); }
    if (hnd && selId) { const e = E(selId); drag = { kind: 'resize', k: hnd.dataset.h, e, start: pt(ev), o: { x: e.x, y: e.y, w: e.w, h: e.h }, id: ev.pointerId }; stage.setPointerCapture(ev.pointerId); ev.preventDefault(); return; }
    if (node) { const e = E(node.dataset.id); const was = selId === e.id; selId = e.id; drag = { kind: 'move', e, start: pt(ev), o: { x: e.x, y: e.y }, moved: false, was, id: ev.pointerId, t: Date.now() }; stage.setPointerCapture(ev.pointerId); ev.preventDefault(); drawSel(); syncTb(); return; }
    if (selId) { selId = null; drawSel(); syncTb(); }
  });
  stage.addEventListener('pointermove', ev => {
    if (!drag || ev.pointerId !== drag.id) return; const r = slideEl.getBoundingClientRect(); const p = { x: (ev.clientX - r.left) / Z, y: (ev.clientY - r.top) / Z }; const dx = p.x - drag.start.x, dy = p.y - drag.start.y; const e = drag.e;
    if (drag.kind === 'move') { if (!drag.moved && Math.abs(dx) + Math.abs(dy) < 4 / Z) return; drag.moved = true; let nx = drag.o.x + dx, ny = drag.o.y + dy; const cx = nx + e.w / 2, cy = ny + e.h / 2; if (Math.abs(cx - W / 2) < 8) nx = W / 2 - e.w / 2; if (Math.abs(cy - H / 2) < 8) ny = H / 2 - e.h / 2; e.x = Math.round(nx); e.y = Math.round(ny); }
    else { const k = drag.k, o = drag.o; let x = o.x, y = o.y, w = o.w, hh = o.h; if (k.includes('e')) w = o.w + dx; if (k.includes('s')) hh = o.h + dy; if (k.includes('w')) { w = o.w - dx; x = o.x + dx; } if (k.includes('n')) { hh = o.h - dy; y = o.y + dy; } if (e.type === 'image' && k.length === 2) { const ar = o.w / o.h; if (Math.abs(dx) > Math.abs(dy)) hh = w / ar; else w = hh * ar; if (k.includes('w')) x = o.x + o.w - w; if (k.includes('n')) y = o.y + o.h - hh; } if (w < 24) { if (k.includes('w')) x -= 24 - w; w = 24; } if (hh < 16) { if (k.includes('n')) y -= 16 - hh; hh = 16; } Object.assign(e, { x: Math.round(x), y: Math.round(y), w: Math.round(w), h: Math.round(hh) }); }
    const n = slideEl.querySelector(`.sl-el[data-id="${e.id}"]`); if (n) { n.style.left = e.x + 'px'; n.style.top = e.y + 'px'; n.style.width = e.w + 'px'; n.style.height = e.h + 'px'; } drawSel();
  });
  const endDrag = ev => { if (!drag) return; const d = drag; drag = null; if (d.kind === 'move' && !d.moved && d.was && d.e.type !== 'image') { startEdit(d.e.id); return; } if (d.moved || d.kind === 'resize') { commit(); renderThumbs(); } syncTb(); };
  stage.addEventListener('pointerup', endDrag); stage.addEventListener('pointercancel', endDrag);
  stage.addEventListener('dblclick', ev => { const n = ev.target.closest('.sl-el'); if (n && E(n.dataset.id).type !== 'image') startEdit(n.dataset.id); });
  function startEdit(id) {
    const e = E(id); if (!e) return; editingId = id; selId = id; drawSel(); const n = slideEl.querySelector(`.sl-el[data-id="${id}"] .tx`); if (!n) return; n.contentEditable = 'plaintext-only'; if (n.contentEditable !== 'plaintext-only') n.contentEditable = 'true'; n.style.outline = '2px dashed var(--brand)'; n.style.userSelect = 'text'; n.style.webkitUserSelect = 'text'; n.style.overflow = 'visible'; n.focus();
    const r = document.createRange(); r.selectNodeContents(n); const s = getSelection(); s.removeAllRanges(); s.addRange(r); s.collapseToEnd();
    n.addEventListener('keydown', ev => { if (ev.key === 'Escape') { ev.preventDefault(); finishEdit(); } });
  }
  function finishEdit(cancel) {
    if (!editingId) return; const id = editingId; editingId = null; const e = E(id); const n = slideEl && slideEl.querySelector(`.sl-el[data-id="${id}"] .tx`);
    if (e && n) { if (!cancel) { const t = n.innerText.replace(/ /g, ' ').replace(/\n$/, ''); e.text = t; } n.contentEditable = 'false'; }
    commit(); renderAll();
  }
  addEventListener('keydown', onKey);
  function onKey(ev) {
    if (!ctx.root.isConnected || editingId || document.querySelector('.present') || document.querySelector('.ov.in')) return; const t = ev.target; if (t && /INPUT|TEXTAREA|SELECT/.test(t.tagName)) return;
    const mod = ev.ctrlKey || ev.metaKey, k = ev.key;
    if (mod && k.toLowerCase() === 'z') { ev.preventDefault(); ev.shiftKey ? redo() : undo(); } else if (mod && k.toLowerCase() === 'y') { ev.preventDefault(); redo(); } else if (mod && k.toLowerCase() === 'd') { ev.preventDefault(); dupEl(); } else if (mod && k.toLowerCase() === 's') { ev.preventDefault(); as.now(true); }
    else if ((k === 'Delete' || k === 'Backspace') && selId) { ev.preventDefault(); delEl(); } else if (selId && k.startsWith('Arrow')) { ev.preventDefault(); const e = E(selId), st = ev.shiftKey ? 20 : 4; if (k === 'ArrowLeft') e.x -= st; if (k === 'ArrowRight') e.x += st; if (k === 'ArrowUp') e.y -= st; if (k === 'ArrowDown') e.y += st; commit(); renderStage(); renderThumbs(); } else if (k === 'Enter' && selId) { ev.preventDefault(); startEdit(selId); } else if (k === 'PageDown' || (k === 'ArrowRight' && !selId)) goto(cur + 1); else if (k === 'PageUp' || (k === 'ArrowLeft' && !selId)) goto(cur - 1); else if (k === 'F5') { ev.preventDefault(); present(0); }
  }
  new ResizeObserver(() => fit() || drawSel()).observe(stage);

  /* operations */
  const change = (fn, rerender = true) => { fn(); commit(); if (rerender) renderAll(); };
  function addEl(e) { finishEdit(); change(() => { S().els.push(e); selId = e.id; }); }
  function delEl() { if (!selId) return; change(() => { S().els = S().els.filter(e => e.id !== selId); selId = null; }); }
  function dupEl() { const e = selId && E(selId); if (!e) return; const c = { ...clone(e), id: uid(), x: e.x + 30, y: e.y + 30 }; change(() => { S().els.push(c); selId = c.id; }); }
  function order(dir) { const e = selId && E(selId); if (!e) return; change(() => { const a = S().els, i = a.indexOf(e); a.splice(i, 1); if (dir === 'front') a.push(e); else if (dir === 'back') a.unshift(e); else if (dir === 'up') a.splice(Math.min(a.length, i + 1), 0, e); else a.splice(Math.max(0, i - 1), 0, e); }); }
  function setP(patch) { const e = selId && E(selId); if (!e) return toast('আগে একটি বক্স/ছবি সিলেক্ট করুন'); finishEdit(); change(() => { for (const k in patch) { if (patch[k] === undefined) delete e[k]; else e[k] = patch[k]; } }); }
  function alignEl(k) { const e = selId && E(selId); if (!e) return toast('আগে সিলেক্ট করুন'); change(() => { if (k === 'ch') e.x = Math.round((W - e.w) / 2); if (k === 'cv') e.y = Math.round((H - e.h) / 2); if (k === 'l') e.x = 40; if (k === 'r') e.x = W - e.w - 40; if (k === 't') e.y = 40; if (k === 'b') e.y = H - e.h - 40; }); }
  function addSlideDlg() { actionSheet('নতুন স্লাইড', LAYOUTS.map(([k, t]) => ({ icon: 'pages', label: t, onClick: () => { finishEdit(); change(() => { m.slides.splice(cur + 1, 0, newSlide(k, T())); cur++; selId = null; }); } }))); }
  function dupSlide() { change(() => { const c = clone(S()); c.id = uid(); c.els.forEach(e => e.id = uid()); m.slides.splice(cur + 1, 0, c); cur++; selId = null; }); }
  async function delSlide() { if (m.slides.length < 2) return toast('শেষ স্লাইড মোছা যাবে না'); if (!(await confirmDlg('স্লাইড মুছবেন?', `স্লাইড ${toBn(cur + 1)} মুছে যাবে।`, { ok: 'মুছুন', danger: true }))) return; change(() => { m.slides.splice(cur, 1); cur = Math.min(cur, m.slides.length - 1); selId = null; }); }
  function moveSlide(d) { const j = cur + d; if (j < 0 || j >= m.slides.length) return; change(() => { const [s] = m.slides.splice(cur, 1); m.slides.splice(j, 0, s); cur = j; }); }
  function slideMenu() { actionSheet(`স্লাইড ${toBn(cur + 1)}`, [{ icon: 'copy', label: 'স্লাইড কপি', onClick: dupSlide }, { icon: 'left', label: 'আগে সরান', disabled: cur === 0, onClick: () => moveSlide(-1) }, { icon: 'right', label: 'পরে সরান', disabled: cur === m.slides.length - 1, onClick: () => moveSlide(1) }, { icon: 'fill', label: 'ব্যাকগ্রাউন্ড রঙ', onClick: async () => { const c = await pickColor({ title: 'ব্যাকগ্রাউন্ড', current: col(S().bg, T()) || T().bg, none: true, noneLabel: 'থিমের রঙ' }); if (c === undefined) return; change(() => { if (c === null) delete S().bg; else S().bg = c; }); } }, { icon: 'pen', label: 'স্পিকার নোট', onClick: notesDlg }, { icon: 'trash', label: 'স্লাইড মুছুন', danger: true, onClick: delSlide }]); }
  function notesDlg() { const ta = h('textarea', { class: 'inp', rows: 6, placeholder: 'উপস্থাপনার সময় মনে রাখার কথা…' }); ta.value = S().notes || ''; modal({ title: 'স্পিকার নোট', body: ta, actions: [{ label: 'বাতিল', ghost: true }, { label: 'সংরক্ষণ', primary: true, onClick: () => change(() => { S().notes = ta.value; }, false) }] }); }
  async function addImage(file) { if (!file) return; const b = busy('ছবি যোগ হচ্ছে…'); try { const { url, w, h: hh } = await imageToDataURL(file); const sc = Math.min(1, 800 / (w || 800), 500 / (hh || 500)); const ww = Math.round((w || 800) * sc), h2 = Math.round((hh || 500) * sc); addEl({ id: uid(), type: 'image', src: url, x: Math.round((W - ww) / 2), y: Math.round((H - h2) / 2), w: ww, h: h2 }); } catch (e) { toast('ছবি যোগ করা যায়নি: ' + errMsg(e)); } finally { b.done(); } }
  async function pickImage() { const f = await pickFiles({ accept: 'image/*' }); if (f && f[0]) addImage(f[0]); }
  async function camImage() { const f = await pickFiles({ accept: 'image/*', capture: 'environment' }); if (f && f[0]) addImage(f[0]); }

  /* toolbar */
  const tabsEl = h('div', { class: 'tabs' }), toolsEl = h('div', { class: 'tools' }); const TB = {}; const cache = {};
  const mk = (id, ic, label, fn, o) => (TB[id] = btn(ic, label, fn, o));
  const colorBtn = (ic, label, key, def, none) => { const sw = h('i', { style: { background: def } }); const b = h('button', { class: 'tb colorbtn', type: 'button', 'aria-label': label, title: label, onmousedown: e => e.preventDefault() }, icon(ic, 20), sw); b.addEventListener('click', async () => { const e = selId && E(selId); if (!e) return toast('আগে একটি বক্স সিলেক্ট করুন'); const c = await pickColor({ title: label, current: col(e[key], T()) || def, none, noneLabel: 'কোনো রঙ নয়' }); if (c === undefined) return; setP({ [key]: c === null ? undefined : c }); sw.style.background = c || def; }); return b; };
  const sizeLab = h('span', { class: 'tb-t' }, '২৮');
  const addShape = geo => addEl(shape(480, 260, 320, 200, { geo, fill: '@accent', color: '#ffffff', ha: 'center', va: 'middle', text: '' }));
  const tabsDef = {
    home: () => [btn('plus', 'নতুন স্লাইড', addSlideDlg, { text: 'নতুন স্লাইড' }), btn('more', 'স্লাইড মেনু', slideMenu, { text: 'স্লাইড ⋯' }), h('span', { class: 'tsep' }), btn('play', 'উপস্থাপন', () => present(0), { text: 'উপস্থাপন' }), btn('play', 'বর্তমান স্লাইড থেকে', () => present(cur), { text: 'এখান থেকে' }), h('span', { class: 'tsep' }),
      mk('b', 'bold', 'বোল্ড', () => { const e = selId && E(selId); setP({ b: e && e.b ? 0 : 1 }); }), mk('i', 'italic', 'ইটালিক', () => { const e = selId && E(selId); setP({ i: e && e.i ? 0 : 1 }); }), mk('u', 'underline', 'আন্ডারলাইন', () => { const e = selId && E(selId); setP({ u: e && e.u ? 0 : 1 }); }),
      btn('minus', 'ছোট', () => { const e = selId && E(selId); setP({ fs: Math.max(8, ((e && e.fs) || 28) - 2) }); }), h('button', { class: 'tb', type: 'button', style: { minWidth: '38px' }, onmousedown: e => e.preventDefault(), onclick: () => actionSheet('ফন্টের মাপ', [14, 18, 20, 24, 28, 32, 36, 44, 54, 64, 80, 96].map(n => ({ icon: 'type', label: toBn(n), onClick: () => setP({ fs: n }) }))) }, sizeLab), btn('plus', 'বড়', () => { const e = selId && E(selId); setP({ fs: Math.min(200, ((e && e.fs) || 28) + 2) }); }),
      colorBtn('fontColor', 'লেখার রঙ', 'color', '#222222', false), colorBtn('fill', 'বক্সের রঙ', 'fill', '#3157e0', true), colorBtn('borders', 'বর্ডারের রঙ', 'stroke', '#222222', true), h('span', { class: 'tsep' }),
      mk('aL', 'alignL', 'বামে', () => setP({ ha: 'left' })), mk('aC', 'alignC', 'মাঝে', () => setP({ ha: 'center' })), mk('aR', 'alignR', 'ডানে', () => setP({ ha: 'right' })), btn('arrowUp', 'উপরে', () => setP({ va: 'top' })), btn('hr', 'মাঝখানে', () => setP({ va: 'middle' })), btn('arrowDown', 'নিচে', () => setP({ va: 'bottom' }))],
    insert: () => [btn('text', 'লেখা', () => addEl(txt(400, 280, 480, 100, 'এখানে লিখুন', { fs: 36 })), { text: 'লেখা' }), btn('square', 'আয়তক্ষেত্র', () => addShape('rect'), { text: 'আয়তক্ষেত্র' }), btn('square', 'গোলকোণ', () => addShape('round'), { text: 'গোলকোণ' }), btn('circle', 'বৃত্ত', () => addShape('ellipse'), { text: 'বৃত্ত' }), btn('hr', 'রেখা', () => addEl(shape(300, 360, 680, 5, { fill: '@accent', fs: 10 })), { text: 'রেখা' }), h('span', { class: 'tsep' }), btn('image', 'ছবি', pickImage, { text: 'ছবি' }), btn('camera', 'ক্যামেরা', camImage, { text: 'ক্যামেরা' }), h('span', { class: 'tsep' }), btn('table', 'টেবিল', tableDlg, { text: 'টেবিল' })],
    format: () => [btn('copy', 'কপি', dupEl, { text: 'কপি' }), btn('trash', 'মুছুন', delEl, { text: 'মুছুন' }), h('span', { class: 'tsep' }), btn('up', 'সামনে আনুন', () => order('front'), { text: 'সামনে' }), btn('down', 'পিছনে দিন', () => order('back'), { text: 'পিছনে' }), btn('arrowUp', 'এক ধাপ সামনে', () => order('up'), { text: '↑ ধাপ' }), btn('arrowDown', 'এক ধাপ পিছনে', () => order('down'), { text: '↓ ধাপ' }), h('span', { class: 'tsep' }),
      btn('alignC', 'অনুভূমিক মাঝে', () => alignEl('ch'), { text: 'মাঝে ↔' }), btn('alignC', 'উলম্ব মাঝে', () => alignEl('cv'), { text: 'মাঝে ↕' }), btn('alignL', 'বামে', () => alignEl('l'), { text: 'বাম' }), btn('alignR', 'ডানে', () => alignEl('r'), { text: 'ডান' }), h('span', { class: 'tsep' }),
      btn('rotate', 'ঘোরান', () => { const e = selId && E(selId); setP({ rot: ((e && e.rot || 0) + 15) % 360 }); }, { text: 'ঘোরান' }), btn('drop', 'স্বচ্ছতা', async () => { const e = selId && E(selId); if (!e) return toast('আগে সিলেক্ট করুন'); actionSheet('স্বচ্ছতা', [1, .8, .6, .4, .2].map(v => ({ icon: 'drop', label: toBn(Math.round(v * 100)) + '%', onClick: () => setP({ op: v === 1 ? undefined : v }) }))); }, { text: 'স্বচ্ছতা' })],
    design: () => [btn('tpl', 'থিম', themeDlg, { text: 'থিম বদলান' }), btn('fill', 'ব্যাকগ্রাউন্ড', async () => { const c = await pickColor({ title: 'ব্যাকগ্রাউন্ড', current: col(S().bg, T()) || T().bg, none: true, noneLabel: 'থিমের রঙ' }); if (c === undefined) return; change(() => { if (c === null) delete S().bg; else S().bg = c; }); }, { text: 'ব্যাকগ্রাউন্ড' }), btn('pen', 'নোট', notesDlg, { text: 'স্পিকার নোট' })],
  };
  const TABS = [['home', 'হোম'], ['insert', 'ঢোকান'], ['format', 'সাজান'], ['design', 'ডিজাইন']];
  const showTab = k => { [...tabsEl.children].forEach((b, i) => b.classList.toggle('on', TABS[i][0] === k)); toolsEl.replaceChildren(...(cache[k] ||= tabsDef[k]().filter(Boolean))); syncTb(); };
  TABS.forEach(([k, t]) => tabsEl.append(h('button', { class: 'tab', type: 'button', onclick: () => showTab(k) }, t)));
  function syncTb() { const e = selId && E(selId) || {}; const set = (id, on) => TB[id] && TB[id].classList.toggle('on', !!on); set('b', e.b); set('i', e.i); set('u', e.u); set('aL', e.ha === 'left'); set('aC', e.ha === 'center'); set('aR', e.ha === 'right'); sizeLab.textContent = toBn(Math.round(e.fs || 28)); }
  function themeDlg() { actionSheet('থিম', SLIDE_THEMES.map(t => ({ icon: 'tpl', label: t.name, active: t.id === m.theme, onClick: () => change(() => { m.theme = t.id; }) }))); }
  async function tableDlg() { const v = await promptDlg('টেবিল (সারি × কলাম)', { value: '3x3', placeholder: '3x4', hint: 'যেমন 4x3 = ৪ সারি, ৩ কলাম' }); if (!v) return; const mm = /(\d+)\s*[x×*]\s*(\d+)/i.exec(v); if (!mm) return toast('এভাবে লিখুন: 3x4'); const R = clamp(+mm[1], 1, 12), C = clamp(+mm[2], 1, 8); finishEdit(); const w = Math.min(1100, C * 220), cw = w / C, rh = Math.min(70, 440 / R), x0 = (W - w) / 2, y0 = 200; change(() => { for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) S().els.push(shape(Math.round(x0 + c * cw), Math.round(y0 + r * rh), Math.round(cw), Math.round(rh), { stroke: '#9aa1b5', sw: 1, fs: 22, va: 'middle', ha: 'center', fill: r === 0 ? '@accent' : undefined, color: r === 0 ? '#ffffff' : '@body', b: r === 0 ? 1 : 0, text: r === 0 ? 'শিরোনাম' : '' })); }); }

  /* present */
  function present(from) {
    finishEdit(); let i = from; const ov = h('div', { class: 'present show' }); const box = h('div', { style: { position: 'absolute', left: 0, top: 0, width: W + 'px', height: H + 'px', transformOrigin: 'top left' } }); ov.append(box);
    const cnt = h('span', { style: { color: '#fff', alignSelf: 'center', padding: '0 8px', fontSize: '14px' } }); let closeLayer;
    const close = () => { removeEventListener('keydown', key); removeEventListener('resize', place); ov.remove(); closeLayer && closeLayer(); try { document.exitFullscreen && document.fullscreenElement && document.exitFullscreen(); } catch { } };
    const show = n => { i = clamp(n, 0, m.slides.length - 1); box.replaceChildren(slideNode(m.slides[i], T())); box.firstChild.style.animation = 'fadeIn .25s'; cnt.textContent = toBn(i + 1) + ' / ' + toBn(m.slides.length); };
    const place = () => { const z = Math.min(innerWidth / W, innerHeight / H); box.style.transform = `scale(${z})`; box.style.left = (innerWidth - W * z) / 2 + 'px'; box.style.top = (innerHeight - H * z) / 2 + 'px'; };
    const key = e => { if (e.key === 'Escape') close(); else if (['ArrowRight', 'ArrowDown', 'PageDown', ' ', 'Enter'].includes(e.key)) { e.preventDefault(); i < m.slides.length - 1 ? show(i + 1) : close(); } else if (['ArrowLeft', 'ArrowUp', 'PageUp', 'Backspace'].includes(e.key)) show(i - 1); };
    ov.addEventListener('click', e => { if (e.target.closest('.pc')) return; const x = e.clientX / innerWidth; if (x < .3) show(i - 1); else if (i < m.slides.length - 1) show(i + 1); else close(); });
    let sx = 0; ov.addEventListener('touchstart', e => { sx = e.touches[0].clientX; }, { passive: true }); ov.addEventListener('touchend', e => { const dx = e.changedTouches[0].clientX - sx; if (Math.abs(dx) > 60) { e.preventDefault(); dx < 0 ? (i < m.slides.length - 1 ? show(i + 1) : 0) : show(i - 1); ov._sw = Date.now(); } }, { passive: false });
    ov.addEventListener('click', e => { if (ov._sw && Date.now() - ov._sw < 400) e.stopImmediatePropagation(); }, true);
    ov.append(h('div', { class: 'pc' }, h('button', { type: 'button', onclick: () => show(i - 1), 'aria-label': 'আগের' }, icon('left', 22)), cnt, h('button', { type: 'button', onclick: () => show(i + 1), 'aria-label': 'পরের' }, icon('right', 22)), h('button', { type: 'button', onclick: close, 'aria-label': 'বন্ধ' }, icon('x', 22))));
    document.body.append(ov); addEventListener('keydown', key); addEventListener('resize', place); closeLayer = pushLayer(close); place(); show(from); setTimeout(() => ov.classList.remove('show'), 2500); ov.addEventListener('pointermove', () => { ov.classList.add('show'); clearTimeout(ov._t); ov._t = setTimeout(() => ov.classList.remove('show'), 2500); });
    try { ov.requestFullscreen && ov.requestFullscreen().catch(() => { }); } catch { }
  }

  /* exports */
  async function slidesToCanvases(onProg) { const { htmlToCanvas } = await import('./pdfexport.js'); const out = []; for (let i = 0; i < m.slides.length; i++) { onProg && onProg(i + 1, m.slides.length); const n = slideNode(m.slides[i], T()); const xml = new XMLSerializer().serializeToString(n); out.push(await htmlToCanvas(xml, SL_CSS, W, H, 1.5, '#ffffff')); } return out; }
  const exportsList = [
    { icon: 'pdf', label: 'PDF করুন', sub: 'সব স্লাইড, প্রতি পাতায় একটি', async run() { const b = busy('PDF তৈরি হচ্ছে…'); try { const cs = await slidesToCanvases((i, n) => b.set(`স্লাইড ${toBn(i)}/${toBn(n)}`)); const { pdfFromCanvases } = await import('./pdfexport.js'); const bytes = await pdfFromCanvases(cs, { wPt: 960, hPt: 540, title: ctx.meta.name }); return { blob: new Blob([bytes], { type: 'application/pdf' }), name: baseName(ctx.meta.name) + '.pdf', kind: 'pdf' }; } finally { b.done(); } } },
    { icon: 'image', label: 'বর্তমান স্লাইড ছবি (PNG)', async run() { const cs = await (async () => { const { htmlToCanvas } = await import('./pdfexport.js'); return htmlToCanvas(new XMLSerializer().serializeToString(slideNode(S(), T())), SL_CSS, W, H, 2, '#fff'); })(); const blob = await new Promise(r => cs.toBlob(r, 'image/png')); return { blob, name: baseName(ctx.meta.name) + ` স্লাইড ${cur + 1}.png`, kind: 'image' }; } },
  ];
  ctx.afterExport = async r => { const { offerOutput } = await import('./edkit.js'); return offerOutput(ctx, r); };
  async function serialize() { const s = await getSettings(); return { buf: await modelToPptx(m, { title: baseName(ctx.meta.name), author: s.author || '' }), snap: JSON.stringify(m) }; }

  const r0 = ctx.setup({ serialize, undo, redo, exports: exportsList, extraMenu: [{ icon: 'play', label: 'উপস্থাপন', onClick: () => present(0) }] }); hdr = r0.hdr; as = r0.as; hdr.setUndo(false, false);
  ctx.root.replaceChildren(hdr.el, h('div', { class: 'ed-body' }, tabsEl, toolsEl, h('div', { class: 'sl-main' }, stage, strip)));
  showTab('home'); requestAnimationFrame(() => { fit(); renderAll(); }); setTimeout(() => { fit(); renderStage(); }, 200);
  window.__sl = { get m() { return m; }, goto, addEl, setP, present, undo, redo, get sel() { return selId; }, select: id => { selId = id; drawSel(); }, startEdit, finishEdit, serialize };
  return { destroy() { removeEventListener('keydown', onKey); } };
}
