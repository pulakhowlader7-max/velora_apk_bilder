// Velora conversions: PDF → Word (text, tables, pictures, scanned pages via OCR) and Word → PDF.
// The layout analysis (linesFromItems / blocksFromLines / blocksToHtml) is pure so it can be unit-tested.

const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const BULLET = /^[\u2022\u25CF\u25AA\u25E6\u00B7\u2023\u25CB\u2013\u2014*-]\s+/;
const NUM = /^(\(?[0-9\u09E6-\u09EF]{1,3}[.)]|[a-zA-Z][.)])\s+/;
const SENT_END = /[.!?\u0964:;)"\u201D']\s*$/;

/** Text that came out as symbols (legacy Bijoy/ANSI Bangla fonts, symbol fonts) instead of real letters. */
export function looksBroken(text) {
  const t = text.replace(/\s/g, ''); if (t.length < 20) return false;
  let weird = 0; for (const ch of t) { const c = ch.codePointAt(0); if ((c >= 0x80 && c <= 0x24F && !/[\u00A0\u00AB\u00BB\u00B0\u00A9\u00AE]/.test(ch)) || (c >= 0xE000 && c <= 0xF8FF) || c === 0xFFFD || (c >= 0x2190 && c <= 0x2BFF && c !== 0x2022)) weird++; }
  return weird / t.length > .18;
}

/** items: [{s,x,y,w,fs}] in PDF space (y grows upwards). Returns lines top→bottom, each {text,x,x2,top,fs,items}. */
export function linesFromItems(items, pageH) {
  const its = items.filter(i => i.s && i.s.trim().length).map(i => ({ ...i })).sort((a, b) => b.y - a.y || a.x - b.x);
  const lines = [];
  for (const it of its) {
    const ln = lines.find(l => Math.abs(l.y - it.y) <= .5 * Math.min(l.fs, it.fs) + .5);
    if (ln) ln.items.push(it); else lines.push({ y: it.y, fs: it.fs, items: [it] });
  }
  for (const l of lines) {
    l.items.sort((a, b) => a.x - b.x); let text = '', prev = null, big = l.items[0];
    for (const it of l.items) {
      if (it.s.length * it.fs > big.s.length * big.fs) big = it;
      if (prev) { const gap = it.x - (prev.x + prev.w); if (gap > .18 * it.fs && !/\s$/.test(text) && !/^\s/.test(it.s)) text += ' '; }
      text += it.s; prev = it;
    }
    l.fs = big.fs; l.text = text.replace(/\s+$/, ''); l.x = l.items[0].x; l.x2 = Math.max(...l.items.map(i => i.x + i.w)); l.top = pageH - l.y;
  }
  return lines.filter(l => l.text.trim()).sort((a, b) => a.top - b.top);
}

/** Split into one or two columns when there is a clear empty vertical gutter. */
export function splitColumns(items, pageW) {
  const narrow = items.filter(i => i.w < pageW * .45 && i.s.trim()); if (narrow.length < 40) return [items];
  const bins = new Uint16Array(Math.ceil(pageW) + 2); for (const i of narrow) for (let x = Math.max(0, Math.floor(i.x)); x <= Math.min(bins.length - 1, Math.ceil(i.x + i.w)); x++) bins[x]++;
  let bestS = -1, bestL = 0, s = -1;
  for (let x = Math.floor(pageW * .3); x <= Math.ceil(pageW * .7); x++) { if (!bins[x]) { if (s < 0) s = x; } else if (s >= 0) { if (x - s > bestL) { bestL = x - s; bestS = s; } s = -1; } }
  if (s >= 0 && Math.ceil(pageW * .7) - s > bestL) { bestL = Math.ceil(pageW * .7) - s; bestS = s; }
  if (bestL < pageW * .02) return [items];
  const mid = bestS + bestL / 2, L = [], R = [];
  for (const i of items) (i.x + i.w / 2 < mid ? L : R).push(i);
  if (L.length < items.length * .25 || R.length < items.length * .25) return [items];
  return [L, R];
}

function cellsOf(line, minGapEm = 1.6) {
  const out = []; let cur = null;
  for (const it of line.items) {
    if (cur && it.x - cur.x2 <= minGapEm * line.fs) { cur.text += (it.x - cur.x2 > .18 * line.fs && !/\s$/.test(cur.text) ? ' ' : '') + it.s; cur.x2 = it.x + it.w; }
    else { cur = { text: it.s, x: it.x, x2: it.x + it.w }; out.push(cur); }
  }
  return out.map(c => ({ ...c, text: c.text.trim() }));
}

/** lines → blocks [{t:'h',level,text,align}|{t:'p',...}|{t:'li',ol,text}|{t:'table',rows}] */
export function blocksFromLines(lines, pageW) {
  if (!lines.length) return [];
  const freq = new Map(); for (const l of lines) { const k = Math.round(l.fs); freq.set(k, (freq.get(k) || 0) + l.text.length); }
  const body = [...freq.entries()].sort((a, b) => b[1] - a[1])[0][0];
  const gaps = []; for (let i = 1; i < lines.length; i++) { const g = lines[i].top - lines[i - 1].top; if (g > 0 && g < body * 3) gaps.push(g); }
  gaps.sort((a, b) => a - b); const pitch = gaps.length ? gaps[Math.floor(gaps.length / 2)] : body * 1.3;
  const maxW = Math.max(...lines.map(l => l.x2 - l.x)); const leftMin = Math.min(...lines.map(l => l.x));
  const blocks = []; let i = 0;
  const alignOf = l => { const cx = (l.x + l.x2) / 2, w = l.x2 - l.x; if (w < maxW * .8 && Math.abs(cx - pageW / 2) < pageW * .04 && l.x - leftMin > pageW * .08) return 'center'; if (l.x2 > pageW * .9 && l.x - leftMin > pageW * .35 && w < maxW * .5) return 'right'; return ''; };
  while (i < lines.length) {
    const l = lines[i];
    // table: ≥2 consecutive lines split into the same number (≥2) of well separated cells
    const c0 = cellsOf(l);
    if (c0.length >= 2 && c0.length <= 12) {
      let j = i, rows = [];
      while (j < lines.length) { const cj = cellsOf(lines[j]); if (cj.length === c0.length && (j === i || lines[j].top - lines[j - 1].top < pitch * 2.2)) { rows.push(cj.map(c => c.text)); j++; } else break; }
      if (rows.length >= 2) { blocks.push({ t: 'table', rows }); i = j; continue; }
    }
    const ratio = l.fs / body;
    if (ratio >= 1.18 && l.text.length <= 150) { blocks.push({ t: 'h', level: ratio >= 1.8 ? 1 : ratio >= 1.4 ? 2 : 3, text: l.text, align: alignOf(l), top: l.top }); i++; continue; }
    let m;
    if ((m = BULLET.exec(l.text))) { blocks.push({ t: 'li', ol: false, text: l.text.slice(m[0].length), top: l.top }); i++; continue; }
    if ((m = NUM.exec(l.text))) { blocks.push({ t: 'li', ol: true, text: l.text.slice(m[0].length), top: l.top }); i++; continue; }
    const prev = blocks[blocks.length - 1], pl = lines[i - 1];
    const al = alignOf(l);
    if (prev && prev.t === 'p' && !al && !prev.align && pl) {
      const gap = l.top - pl.top, prevShort = (pl.x2 - pl.x) < maxW * .72, indent = l.x - pl.x > body * 1.2;
      if (gap <= pitch * 1.55 && !(SENT_END.test(prev.text) && (prevShort || indent)) && Math.abs(l.x - pl.x) < body * 3) {
        prev.text = /-$/.test(prev.text) && /^[a-z]/.test(l.text) ? prev.text.slice(0, -1) + l.text : prev.text + ' ' + l.text; i++; continue;
      }
    }
    blocks.push({ t: 'p', text: l.text, align: al, top: l.top }); i++;
  }
  return blocks;
}

const inline = s => esc(s);
export function blocksToHtml(blocks) {
  let out = '', list = null;
  const close = () => { if (list) { out += `</${list}>`; list = null; } };
  for (const b of blocks) {
    if (b.t === 'li') { const tag = b.ol ? 'ol' : 'ul'; if (list !== tag) { close(); out += `<${tag}>`; list = tag; } out += `<li>${inline(b.text)}</li>`; continue; }
    close();
    const st = b.align ? ` style="text-align:${b.align}"` : '';
    if (b.t === 'h') out += `<h${b.level}${st}>${inline(b.text)}</h${b.level}>`;
    else if (b.t === 'p') out += `<p${st}>${inline(b.text)}</p>`;
    else if (b.t === 'table') out += '<table><tbody>' + b.rows.map((r, ri) => '<tr>' + r.map(c => `<${ri === 0 ? 'th' : 'td'}>${inline(c)}</${ri === 0 ? 'th' : 'td'}>`).join('') + '</tr>').join('') + '</tbody></table><p><br></p>';
    else if (b.t === 'img') out += `<p><img src="${b.src}" style="width:${Math.round(b.w)}px" alt=""></p>`;
    else if (b.t === 'html') out += b.html;
  }
  close(); return out;
}

/* ---------- PDF → Word ---------- */
const mul = (m, n) => [m[0] * n[0] + m[2] * n[1], m[1] * n[0] + m[3] * n[1], m[0] * n[2] + m[2] * n[3], m[1] * n[2] + m[3] * n[3], m[0] * n[4] + m[2] * n[5] + m[4], m[1] * n[4] + m[3] * n[5] + m[5]];
async function imageBoxes(page, pdfjs, vp) {
  const { OPS } = pdfjs, ops = await page.getOperatorList(), out = [], stack = []; let ctm = [1, 0, 0, 1, 0, 0];
  for (let k = 0; k < ops.fnArray.length; k++) {
    const fn = ops.fnArray[k], a = ops.argsArray[k];
    if (fn === OPS.save) stack.push(ctm);
    else if (fn === OPS.restore) ctm = stack.pop() || ctm;
    else if (fn === OPS.transform) ctm = mul(ctm, a);
    else if (OPS.paintFormXObjectBegin !== undefined && fn === OPS.paintFormXObjectBegin) { stack.push(ctm); if (a && a[0]) ctm = mul(ctm, a[0]); }
    else if (OPS.paintFormXObjectEnd !== undefined && fn === OPS.paintFormXObjectEnd) ctm = stack.pop() || ctm;
    else if (fn === OPS.paintImageXObject || fn === OPS.paintInlineImageXObject || fn === OPS.paintImageMaskXObject) {
      const pts = [[0, 0], [1, 0], [1, 1], [0, 1]].map(([x, y]) => { const ux = ctm[0] * x + ctm[2] * y + ctm[4], uy = ctm[1] * x + ctm[3] * y + ctm[5]; return [vp.transform[0] * ux + vp.transform[2] * uy + vp.transform[4], vp.transform[1] * ux + vp.transform[3] * uy + vp.transform[5]]; });
      const xs = pts.map(p => p[0]), ys = pts.map(p => p[1]); out.push({ x0: Math.min(...xs), y0: Math.min(...ys), x1: Math.max(...xs), y1: Math.max(...ys) });
    }
  }
  return out;
}
async function renderPage(page, scale) { const vp = page.getViewport({ scale }); const c = document.createElement('canvas'); c.width = Math.round(vp.width); c.height = Math.round(vp.height); const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); await page.render({ canvasContext: g, viewport: vp }).promise; return c; }

/**
 * mode: 'auto' (text where real text exists, OCR for scanned/broken pages) | 'text' | 'ocr' (every page through OCR)
 * Returns { html, pages, ocrPages, images, warnings[] }
 */
export async function pdfToHtml(buf, { mode = 'auto', password, onProgress = () => { }, ocrEngine = 'auto', signal } = {}) {
  const { needPdfJs } = await import('./util.js'); const pdfjs = await needPdfJs();
  const task = pdfjs.getDocument({ data: new Uint8Array(buf.slice ? buf.slice(0) : buf), cMapUrl: '/vendor/pdfjs/cmaps/', cMapPacked: true, standardFontDataUrl: '/vendor/pdfjs/standard_fonts/', password });
  const doc = await task.promise; const warnings = []; let ocrPages = 0, images = 0; let sess = null; const parts = [];
  try {
    for (let pn = 1; pn <= doc.numPages; pn++) {
      if (signal && signal.aborted) throw new Error('বাতিল করা হয়েছে');
      onProgress(pn, doc.numPages, 'পাতা ' + pn + ' পড়া হচ্ছে…');
      const page = await doc.getPage(pn); const vp = page.getViewport({ scale: 1 }); let html = '', needOcr = mode === 'ocr';
      if (!needOcr) {
        const tc = await page.getTextContent(); const items = [];
        for (const it of tc.items) { if (!it.str) continue; const [a, b, , , e, f] = it.transform; items.push({ s: it.str, x: e, y: f, w: it.width || 0, fs: Math.hypot(a, b) || it.height || 10 }); }
        const joined = items.map(i => i.s).join(' '); const chars = joined.replace(/\s/g, '').length;
        if (mode === 'auto' && (chars < 25 || looksBroken(joined))) needOcr = true;
        else {
          let blocks = []; const cols = splitColumns(items, vp.width);
          for (const col of cols) blocks.push(...blocksFromLines(linesFromItems(col, vp.height), vp.width));
          // pictures
          try {
            const boxes = (await imageBoxes(page, pdfjs, vp)).filter(b => b.x1 - b.x0 > 36 && b.y1 - b.y0 > 36 && (b.x1 - b.x0) * (b.y1 - b.y0) < vp.width * vp.height * .8);
            if (boxes.length) {
              const S = 1.6, cv = await renderPage(page, S);
              for (const b of boxes.slice(0, 12)) {
                const x = Math.max(0, b.x0 * S), y = Math.max(0, b.y0 * S), w = Math.min(cv.width - x, (b.x1 - b.x0) * S), h = Math.min(cv.height - y, (b.y1 - b.y0) * S); if (w < 20 || h < 20) continue;
                const c = document.createElement('canvas'); c.width = Math.round(w); c.height = Math.round(h); c.getContext('2d').drawImage(cv, x, y, w, h, 0, 0, c.width, c.height);
                blocks.push({ t: 'img', src: c.toDataURL('image/jpeg', .85), w: Math.min(560, b.x1 - b.x0), top: b.y0 - .01 }); images++;
              }
              blocks = blocks.map((b, idx) => ({ b, idx })).sort((p, q) => (p.b.top ?? 0) - (q.b.top ?? 0) || p.idx - q.idx).map(x => x.b);
            }
          } catch (e) { console.warn('images', e); }
          html = blocksToHtml(blocks);
        }
      }
      if (needOcr) {
        onProgress(pn, doc.numPages, 'পাতা ' + pn + ' — OCR চলছে…');
        const cv = await renderPage(page, Math.min(2.2, 1900 / Math.max(vp.width, vp.height)));
        try {
          const { ocrSession } = await import('./ocr.js'); sess ||= await ocrSession({ engine: ocrEngine, onStatus: m => onProgress(pn, doc.numPages, m) });
          html = (await sess.run(cv)).html; ocrPages++;
        } catch (e) {
          console.warn(e); warnings.push('পাতা ' + pn + ': ' + (e.message || 'OCR ব্যর্থ') + ' — পাতাটি ছবি হিসেবে রাখা হয়েছে');
          html = `<p><img src="${cv.toDataURL('image/jpeg', .8)}" style="width:560px" alt=""></p>`; images++;
        }
      }
      parts.push(html || '<p><br></p>'); page.cleanup();
    }
  } finally { if (sess) await sess.close(); try { doc.destroy(); } catch { } }
  return { html: parts.join('<div class="pagebreak" contenteditable="false"></div>'), pages: doc.numPages, ocrPages, images, warnings };
}

/* ---------- Word / text → PDF (no editor needed) ---------- */
export async function wordFileToPdf(file, { onProgress } = {}) {
  const { extOf, baseName, readBuf, readText } = await import('./util.js');
  const w = await import('./word.js'); const ext = extOf(file.name); let html;
  if (ext === 'docx' || ext === 'dotx') html = (await (await import('./docx.js')).docxToHtml(await readBuf(file))).html;
  else if (ext === 'md' || ext === 'markdown') html = w.mdToHtml(await readText(file));
  else if (ext === 'html' || ext === 'htm') { const t = await readText(file); const m = /<body[^>]*>([\s\S]*)<\/body>/i.exec(t); html = m ? m[1] : t; }
  else html = (await readText(file)).replace(/\r/g, '').split('\n').map(l => `<p>${l ? esc(l) : '<br>'}</p>`).join('');
  const el = document.createElement('div'); el.innerHTML = w.sanitize(html);
  const { paginatedPdf } = await import('./pdfexport.js'); const bytes = await paginatedPdf(el, { css: w.PRINT_CSS, title: baseName(file.name), onProgress });
  return { blob: new Blob([bytes], { type: 'application/pdf' }), name: baseName(file.name) + '.pdf' };
}
