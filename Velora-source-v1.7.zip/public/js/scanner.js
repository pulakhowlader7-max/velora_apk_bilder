// Velora Scanner — camera/gallery → auto edge detection → straighten → clean filters → PDF / Word (OCR) / images.
import { h, icon, btn, toast, confirmDlg, sheet, pickFiles, withBusy, busy, loadImage, errMsg, toBn, baseName } from './util.js';
import { screen } from './screen.js';
import * as P from './imgproc.js';
import { db, uniqueName } from './db.js';
import { openCropper } from './cropper.js';
import * as FX from './fx.js';

const MAXSIDE = 2000;
const FILTERS = FX.DOC_MODES;   // অটো · রঙিন · লেখা স্পষ্ট · গ্রে · সাদা-কালো · আসল
const defaultFxo = () => ({ mode: 'auto', power: 70, shadow: 80, denoise: 'auto', brightness: 0, contrast: 0, sharpen: 30 });
const cnv = (w, hh) => { const c = document.createElement('canvas'); c.width = w; c.height = hh; return c; };
const ctx2 = c => c.getContext('2d', { willReadFrequently: true });

async function fileToCanvas(file) {
  const url = URL.createObjectURL(file);
  try {
    const img = await loadImage(url); const sc = Math.min(1, MAXSIDE / Math.max(img.naturalWidth, img.naturalHeight));
    const c = cnv(Math.round(img.naturalWidth * sc), Math.round(img.naturalHeight * sc)); ctx2(c).drawImage(img, 0, 0, c.width, c.height); return c;
  } finally { URL.revokeObjectURL(url); }
}
function detect(src) {
  const sc = 300 / Math.max(src.width, src.height), s = cnv(Math.max(8, Math.round(src.width * sc)), Math.max(8, Math.round(src.height * sc)));
  ctx2(s).drawImage(src, 0, 0, s.width, s.height); return P.findDocumentCorners(ctx2(s).getImageData(0, 0, s.width, s.height));
}
/** warp the paper flat, clean it with the image engine (docClean) and rotate. `max` = longest side of the result. */
function renderTo(page, max = MAXSIDE, fxo = page.fxo) {
  const { src, corners, rot } = page, g = ctx2(src), img = g.getImageData(0, 0, src.width, src.height);
  const q = corners.map(([x, y]) => [x * src.width, y * src.height]); const { w, h: hh } = P.quadSize(q, max);
  let out = P.warpPerspective(img, q, w, hh);
  const used = FX.docClean(out, fxo); if (fxo === page.fxo) page.usedMode = used;
  let c = cnv(w, hh); ctx2(c).putImageData(new ImageData(out.data, w, hh), 0, 0);
  const r = ((rot % 4) + 4) % 4;
  if (r) { const rc = r % 2 ? cnv(hh, w) : cnv(w, hh), rg = ctx2(rc); rg.translate(rc.width / 2, rc.height / 2); rg.rotate(r * Math.PI / 2); rg.drawImage(c, -w / 2, -hh / 2); c = rc; }
  return c;
}
function render(page, max = MAXSIDE) { page.out = renderTo(page, max); page.low = max < MAXSIDE; }

export async function openScanner({ start = 'camera' } = {}) {
  const pages = []; let cur = 0, stream = null, mode = 'cam';
  const scr = screen({ title: 'স্ক্যানার', cls: 'scanner', onClose: stopCam });
  scr.setGuard(async () => !pages.length || confirmDlg('স্ক্যান বাতিল করবেন?', `${toBn(pages.length)}টি পাতা সংরক্ষণ করা হয়নি।`, { ok: 'বাতিল করুন', cancel: 'থাকুন', danger: true }));
  const stage = h('div', { class: 'sc-stage' }), strip = h('div', { class: 'sc-strip' }), bar = h('div', { class: 'sc-bar' });
  scr.body.append(stage, strip, bar);

  function stopCam() { if (stream) { stream.getTracks().forEach(t => t.stop()); stream = null; } }
  async function addCanvas(c) {
    const page = { src: c, corners: detect(c).corners, fxo: defaultFxo(), rot: 0 }; render(page); pages.push(page); cur = pages.length - 1;
  }
  async function addFiles(files) {
    if (!files.length) return; const b = busy('ছবি প্রসেস হচ্ছে…');
    try { for (const f of files) { b.set(f.name); await new Promise(r => setTimeout(r)); await addCanvas(await fileToCanvas(f)); } } catch (e) { toast(errMsg(e), 3500); } finally { b.done(); }
  }

  /* ---- live camera ---- */
  async function showCam() {
    mode = 'cam'; stage.replaceChildren(); bar.replaceChildren(); drawStrip();
    const video = h('video', { class: 'sc-video', autoplay: true, playsinline: true, muted: true });
    const hint = h('div', { class: 'sc-hint' }, 'কাগজটি ফ্রেমের ভেতরে রাখুন');
    stage.append(video, h('div', { class: 'sc-frame' }), hint);
    try {
      stopCam(); stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 2560 }, height: { ideal: 1440 } }, audio: false });
      video.srcObject = stream; await video.play().catch(() => { });
    } catch (e) { console.warn(e); stopCam(); hint.textContent = 'ক্যামেরা চালু হয়নি — নিচের বোতাম দিয়ে ছবি তুলুন'; }
    const shot = h('button', { class: 'sc-shot', type: 'button', 'aria-label': 'ছবি তুলুন', onclick: async () => {
      if (stream && video.videoWidth) { const c = cnv(video.videoWidth, video.videoHeight); ctx2(c).drawImage(video, 0, 0); const sc = Math.min(1, MAXSIDE / Math.max(c.width, c.height)); let cc = c; if (sc < 1) { cc = cnv(Math.round(c.width * sc), Math.round(c.height * sc)); ctx2(cc).drawImage(c, 0, 0, cc.width, cc.height); } const b = busy('প্রসেস হচ্ছে…'); await new Promise(r => setTimeout(r)); try { await addCanvas(cc); } finally { b.done(); } toast(`পাতা ${toBn(pages.length)} যোগ হয়েছে`, 1200); drawStrip(); doneBtn.hidden = false; doneBtn.firstChild.textContent = toBn(pages.length); }
      else { await addFiles(await pickFiles({ accept: 'image/*', capture: 'environment' })); if (pages.length) showReview(); }
    } });
    const doneBtn = h('button', { class: 'sc-done', type: 'button', hidden: !pages.length, onclick: () => { stopCam(); showReview(); } }, h('b', null, toBn(pages.length)), ' ✓ শেষ');
    bar.append(btn('image', 'গ্যালারি', async () => { const fs = await pickFiles({ accept: 'image/*', multiple: true }); if (fs.length) { await addFiles(fs); stopCam(); showReview(); } }, { text: 'গ্যালারি', keepFocus: false, class: 'sc-side' }), shot, doneBtn);
  }

  /* ---- review ---- */
  function drawStrip() {
    strip.replaceChildren(); if (mode === 'cam' && !pages.length) return;
    pages.forEach((p, i) => { const t = cnv(60, 80); const g = ctx2(t); const s = Math.min(60 / p.out.width, 80 / p.out.height); g.drawImage(p.out, (60 - p.out.width * s) / 2, (80 - p.out.height * s) / 2, p.out.width * s, p.out.height * s); t.className = 'sc-th' + (i === cur && mode === 'rev' ? ' on' : ''); t.onclick = () => { if (mode === 'rev') { cur = i; showReview(); } }; strip.append(t); });
  }
  function showReview() {
    stopCam(); mode = 'rev'; if (!pages.length) return showCam(); cur = Math.min(cur, pages.length - 1); const p = pages[cur];
    stage.replaceChildren(h('div', { class: 'sc-prev' }, p.out)); p.out.style.maxWidth = '100%'; p.out.style.maxHeight = '100%'; scr.setTitle(`পাতা ${toBn(cur + 1)}/${toBn(pages.length)}`); drawStrip();
    const fchips = h('div', { class: 'sc-chips' }, FILTERS.map(([k, tt]) => h('button', { type: 'button', class: 'chip' + (p.fxo.mode === k ? ' on' : ''), onclick: async () => { p.fxo.mode = k; await redo(); } }, tt + (k === 'auto' && p.fxo.mode === 'auto' && p.usedMode ? ' · ' + (FILTERS.find(f => f[0] === p.usedMode) || [0, ''])[1] : ''))));
    const fine = fineControls(p);
    const tools = h('div', { class: 'sc-tools' },
      btn('plus', 'আরও পাতা', () => { showCam(); }, { text: 'যোগ', keepFocus: false }),
      btn('crop', 'কাটুন', async () => { const r = await openCropper(p.src, { title: 'কাগজের চার কোণা ঠিক করুন', quad: p.corners, cornersOnly: true }); if (r) { p.corners = r.corners; await redo(); } }, { text: 'ক্রপ', keepFocus: false }),
      btn('rotate', 'ঘোরান', async () => { p.rot++; await redo(); }, { text: 'ঘোরান', keepFocus: false }),
      btn('left', 'আগে', () => { if (cur > 0) { [pages[cur - 1], pages[cur]] = [pages[cur], pages[cur - 1]]; cur--; showReview(); } }, { keepFocus: false }),
      btn('right', 'পরে', () => { if (cur < pages.length - 1) { [pages[cur + 1], pages[cur]] = [pages[cur], pages[cur + 1]]; cur++; showReview(); } }, { keepFocus: false }),
      btn('trash', 'মুছুন', () => { pages.splice(cur, 1); cur = Math.max(0, cur - 1); pages.length ? showReview() : showCam(); }, { text: 'মুছুন', keepFocus: false }));
    const save = h('div', { class: 'sc-save' },
      h('button', { class: 'btn primary', type: 'button', onclick: () => savePdf() }, icon('pdf', 18), 'PDF সেভ'),
      h('button', { class: 'btn', type: 'button', onclick: () => saveWord() }, icon('word', 18), 'Word (লেখা)'),
      h('button', { class: 'btn', type: 'button', onclick: () => saveMore() }, icon('more', 18)));
    bar.replaceChildren(h('div', { class: 'sc-col' }, fchips, fine, tools, save));
  }
  /* fine-tuning: every slider re-renders a small preview straight away; the full-size page is rebuilt when you stop (or on save) */
  let fastRaf = 0, fullTimer = 0;
  function liveRender(p) {
    cancelAnimationFrame(fastRaf); fastRaf = requestAnimationFrame(() => { render(p, 800); const el = stage.querySelector('.sc-prev'); if (el) { p.out.style.maxWidth = '100%'; p.out.style.maxHeight = '100%'; el.replaceChildren(p.out); } });
    clearTimeout(fullTimer); fullTimer = setTimeout(() => { render(p); const el = stage.querySelector('.sc-prev'); if (el && pages[cur] === p) { p.out.style.maxWidth = '100%'; p.out.style.maxHeight = '100%'; el.replaceChildren(p.out); } drawStrip(); }, 900);
  }
  async function fullAll() { clearTimeout(fullTimer); const todo = pages.filter(x => x.low); if (!todo.length) return; const b = busy('উচ্চ মানে তৈরি হচ্ছে…'); await new Promise(r => setTimeout(r, 30)); try { for (const x of todo) render(x); } finally { b.done(); } }
  function fineControls(p) {
    const row = (label, key, min, max, fmt = v => toBn(v)) => { const val = h('b', null, fmt(p.fxo[key])), i = h('input', { type: 'range', min, max, value: typeof p.fxo[key] === 'number' ? p.fxo[key] : 0, 'aria-label': label }); i.addEventListener('input', () => { p.fxo[key] = +i.value; val.textContent = fmt(+i.value); liveRender(p); }); return h('label', { class: 'ph-sl' }, h('span', null, label), i, val); };
    const box = h('div', { class: 'sc-fine', hidden: true }, row('তীব্রতা', 'power', 0, 100), row('ছায়া সরান', 'shadow', 0, 100), row('উজ্জ্বলতা', 'brightness', -50, 50), row('কনট্রাস্ট', 'contrast', -50, 50), row('শার্পনেস', 'sharpen', 0, 100),
      row('নয়েজ কমান', 'denoise', 0, 100, v => v === 'auto' ? 'অটো' : toBn(v)));
    const cmp = h('button', { class: 'btn sc-cmp', type: 'button' }, icon('eye', 16), 'ধরে রেখে আসল দেখুন');
    const showOrig = on => { const el = stage.querySelector('.sc-prev'); if (!el) return; if (on) { const c = renderTo(p, 800, { ...p.fxo, mode: 'orig', brightness: 0, contrast: 0 }); c.style.maxWidth = '100%'; c.style.maxHeight = '100%'; el.replaceChildren(c); } else { p.out.style.maxWidth = '100%'; p.out.style.maxHeight = '100%'; el.replaceChildren(p.out); } };
    cmp.addEventListener('pointerdown', e => { cmp.setPointerCapture(e.pointerId); showOrig(true); }); cmp.addEventListener('pointerup', () => showOrig(false)); cmp.addEventListener('pointercancel', () => showOrig(false));
    const toggle = h('button', { class: 'btn sc-fine-t', type: 'button', onclick: () => { box.hidden = !box.hidden; toggle.classList.toggle('on', !box.hidden); } }, icon('settings', 16), 'সূক্ষ্ম সেটিং');
    return h('div', { class: 'sc-fx' }, h('div', { class: 'sc-fx-row' }, toggle, cmp), box);
  }
  async function redo() { const b = busy('প্রসেস হচ্ছে…'); await new Promise(r => setTimeout(r)); try { render(pages[cur]); } finally { b.done(); } showReview(); }

  /* ---- crop with 4 handles ---- */
  function cropEdit(p) {
    const box = h('div', { class: 'crop-box' }); const c = cnv(p.src.width, p.src.height); ctx2(c).drawImage(p.src, 0, 0); c.className = 'crop-img';
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); svg.setAttribute('class', 'crop-svg'); svg.setAttribute('viewBox', '0 0 1 1'); svg.setAttribute('preserveAspectRatio', 'none');
    const poly = document.createElementNS('http://www.w3.org/2000/svg', 'polygon'); svg.append(poly); const pts = p.corners.map(a => [...a]);
    const handles = pts.map((pt, i) => { const hd = h('div', { class: 'crop-h' }); hd.addEventListener('pointerdown', e => { hd.setPointerCapture(e.pointerId); hd.onpointermove = ev => { const r = c.getBoundingClientRect(); pts[i] = [Math.min(1, Math.max(0, (ev.clientX - r.left) / r.width)), Math.min(1, Math.max(0, (ev.clientY - r.top) / r.height))]; upd(); }; hd.onpointerup = () => { hd.onpointermove = null; }; e.preventDefault(); }); return hd; });
    const wrap = h('div', { class: 'crop-wrap' }, c, svg, ...handles); box.append(wrap);
    function upd() { poly.setAttribute('points', pts.map(a => a.join(',')).join(' ')); handles.forEach((hd, i) => { hd.style.left = pts[i][0] * 100 + '%'; hd.style.top = pts[i][1] * 100 + '%'; }); }
    const sizeIt = () => { const bw = box.clientWidth, bh = box.clientHeight, s = Math.min(bw / c.width, bh / c.height); wrap.style.width = c.width * s + 'px'; wrap.style.height = c.height * s + 'px'; };
    stage.replaceChildren(box); bar.replaceChildren(h('div', { class: 'sc-save' },
      h('button', { class: 'btn', type: 'button', onclick: () => { const d = detect(p.src); pts.splice(0, 4, ...d.corners.map(a => [...a])); upd(); if (!d.found) toast('কাগজ খুঁজে পাওয়া যায়নি — হাতে ঠিক করুন'); } }, 'অটো'),
      h('button', { class: 'btn', type: 'button', onclick: () => { pts.splice(0, 4, [0, 0], [1, 0], [1, 1], [0, 1]); upd(); } }, 'পুরো ছবি'),
      h('button', { class: 'btn primary', type: 'button', onclick: async () => { p.corners = pts; await redo(); } }, 'ঠিক আছে')));
    requestAnimationFrame(() => { sizeIt(); upd(); });
  }

  /* ---- outputs ---- */
  const jpeg = (c, q = .86) => new Promise(r => c.toBlob(r, 'image/jpeg', q));
  async function finish(meta) { stopCam(); scr.close(); await window.__ao.refresh(); window.__ao.openFile(meta.id); }
  const stamp = () => 'স্ক্যান ' + new Date().toLocaleDateString('en-GB').replace(/\//g, '-');
  async function savePdf() {
    await fullAll();
    try {
      const meta = await withBusy('PDF তৈরি হচ্ছে…', async b => {
        const { PDFDocument } = await (await import('./util.js')).needPDFLib(); const pdf = await PDFDocument.create(); pdf.setProducer('Velora');
        for (let i = 0; i < pages.length; i++) { b.set(`পাতা ${toBn(i + 1)}/${toBn(pages.length)}`); const c = pages[i].out; const img = await pdf.embedJpg(new Uint8Array(await (await jpeg(c)).arrayBuffer())); const k = 595 / Math.max(c.width, 1); const w = c.width > c.height ? 842 : 595, sc = Math.min(w / c.width, (c.width > c.height ? 595 : 842) / c.height); const pw = c.width * sc, ph = c.height * sc; pdf.addPage([pw, ph]).drawImage(img, { x: 0, y: 0, width: pw, height: ph }); void k; }
        return db.create({ name: await uniqueName(stamp() + '.pdf'), buf: (await pdf.save()).buffer, kind: 'pdf' });
      }); await finish(meta);
    } catch (e) { console.error(e); toast('PDF তৈরি ব্যর্থ: ' + errMsg(e), 4000); }
  }
  async function ocrAll(msg) {
    const { ocrSession } = await import('./ocr.js'); const b = busy(msg); const s = await ocrSession({ onStatus: m => b.set(m) }); const res = [];
    try { for (let i = 0; i < pages.length; i++) { b.set(`পাতা ${toBn(i + 1)}/${toBn(pages.length)} পড়া হচ্ছে…`); res.push(await s.run(pages[i].out)); } } finally { await s.close(); b.done(); }
    return res;
  }
  async function saveWord() {
    await fullAll();
    const { openOcrFlow } = await import('./ocrscreen.js'); const imgs = pages.map(p => p.out); stopCam(); scr.close(); return openOcrFlow(imgs, { name: stamp(), mode: 'print' });
    try {
      const res = await ocrAll('লেখা চেনা হচ্ছে…'); const html = res.map(r => r.html).join('<div class="pagebreak" contenteditable="false"></div>');
      scr.close(); await window.__ao.importFiles([new File([`<html><body>${html}</body></html>`], stamp() + '.html', { type: 'text/html' })], { open: true });
    } catch (e) { console.error(e); toast(errMsg(e), 5000); }
  }
  function saveMore() {
    fullAll();
    sheet('আরও', [
      { icon: 'image', label: 'ছবি হিসেবে সেভ (JPG)', onClick: async () => { const files = []; for (let i = 0; i < pages.length; i++) files.push(new File([await jpeg(pages[i].out, .9)], `${stamp()} (${i + 1}).jpg`, { type: 'image/jpeg' })); scr.close(); await window.__ao.importFiles(files); toast('ছবি ফাইলে যোগ হয়েছে'); } },
      { icon: 'text', label: 'শুধু লেখা বের করুন (কপি)', onClick: async () => { try { const res = await ocrAll('লেখা চেনা হচ্ছে…'); const text = res.map(r => r.text).join('\n\n'); const { modal } = await import('./util.js'); const ta = h('textarea', { class: 'inp', rows: 12 }); ta.value = text; modal({ title: 'বের করা লেখা', body: ta, wide: true, actions: [{ label: 'বন্ধ', ghost: true }, { label: 'কপি', primary: true, onClick: () => { navigator.clipboard && navigator.clipboard.writeText(ta.value).then(() => toast('কপি হয়েছে')); } }] }); } catch (e) { toast(errMsg(e), 5000); } } },
      { icon: 'clean', label: 'ছবি পরিষ্কার (নয়েজ কমান, লেখা স্পষ্ট)', onClick: async () => { const { openCleanup } = await import('./cleanup.js'); openCleanup(pages[cur].src, { name: stamp() }); } },
      { icon: 'sparkle', label: 'ছবি এডিটরে খুলুন', onClick: async () => { const b = await jpeg(pages[cur].out, .95); const { openPhotoEditor } = await import('./photo.js'); openPhotoEditor(new File([b], stamp() + '.jpg', { type: 'image/jpeg' })); } },
    ]);
  }

  if (start === 'gallery') { const fs = await pickFiles({ accept: 'image/*', multiple: true }); if (fs.length) { await addFiles(fs); return showReview(); } }
  showCam();
}
