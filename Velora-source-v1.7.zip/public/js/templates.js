// Ready-made templates: letters, CV, application, sheets, slide themes.
import { h, icon, sheet, modal } from './util.js';

const L = (s) => s; // marker for editable text
export const WORD_TPLS = [
  { id: 'blank', name: 'ফাঁকা ডকুমেন্ট', sub: 'শুরু থেকে লিখুন', file: 'নতুন ডকুমেন্ট', html: '<p><br></p>', lines: [60, 80, 50] },
  {
    id: 'application', name: 'আবেদনপত্র', sub: 'চাকরি / ছুটি / অন্যান্য', file: 'আবেদনপত্র',
    html: `<p style="text-align:right">তারিখ: ০১ জানুয়ারি ২০২৬</p>
<p>বরাবর,<br>ব্যবস্থাপনা পরিচালক / প্রধান শিক্ষক<br>প্রতিষ্ঠানের নাম<br>ঠিকানা</p>
<p><b>বিষয়: ........................ জন্য আবেদন।</b></p>
<p>জনাব,</p>
<p>সবিনয় নিবেদন এই যে, আমি আপনার প্রতিষ্ঠানের একজন ........................। আমি ........................ কারণে ........................ তারিখ থেকে ........................ তারিখ পর্যন্ত মোট .... দিনের ছুটি / চাকরির জন্য আবেদন করছি।</p>
<p>অতএব, মহোদয়ের নিকট বিনীত প্রার্থনা, আমার আবেদনটি সদয় বিবেচনা করে মঞ্জুর করতে আপনার মর্জি হয়।</p>
<p><br></p><p>বিনীত নিবেদক,<br><br>(স্বাক্ষর)<br>নাম: ........................<br>পদবি: ........................<br>মোবাইল: ........................</p>`, lines: [40, 90, 70, 90, 90, 60]
  },
  {
    id: 'letter', name: 'অফিসিয়াল চিঠি (English)', sub: 'Formal business letter', file: 'Official Letter',
    html: `<p><b>Your Name</b><br>Your Address<br>City, Postcode<br>Email · Phone</p>
<p>Date: 1 January 2026</p>
<p>Recipient Name<br>Designation<br>Company Name<br>Company Address</p>
<p><b>Subject: Write the subject of your letter here</b></p>
<p>Dear Sir/Madam,</p>
<p>I am writing to … State the purpose of the letter in the first paragraph. Keep it short and clear.</p>
<p>In the second paragraph, give the details, reasons, or supporting information the reader needs.</p>
<p>Thank you for your time and consideration. I look forward to your reply.</p>
<p>Yours sincerely,<br><br><br>Your Name<br>Designation</p>`, lines: [50, 40, 60, 90, 80, 90]
  },
  {
    id: 'cv', name: 'CV / Resume', sub: 'পরিচ্ছন্ন প্রফেশনাল CV', file: 'CV',
    html: `<h1 style="text-align:center;color:#1f3a93">আপনার নাম</h1>
<p style="text-align:center">পদবি / পেশা · ফোন · ইমেইল · শহর</p>
<hr>
<h2 style="color:#1f3a93">ক্যারিয়ার উদ্দেশ্য</h2>
<p>আপনার দক্ষতা ও লক্ষ্য সম্পর্কে ২–৩ লাইনের সংক্ষিপ্ত বিবরণ লিখুন।</p>
<h2 style="color:#1f3a93">কর্ম অভিজ্ঞতা</h2>
<p><b>পদবি</b> — প্রতিষ্ঠান, স্থান <span style="color:#666">(২০২০ – বর্তমান)</span></p>
<ul><li>প্রধান দায়িত্ব বা অর্জন</li><li>পরিমাপযোগ্য ফলাফল (যেমন: উৎপাদন ১০% বৃদ্ধি)</li></ul>
<h2 style="color:#1f3a93">শিক্ষাগত যোগ্যতা</h2>
<table><tr><th>পরীক্ষা</th><th>প্রতিষ্ঠান</th><th>সাল</th><th>ফলাফল</th></tr><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr></table>
<h2 style="color:#1f3a93">দক্ষতা</h2>
<ul><li>দক্ষতা ১</li><li>দক্ষতা ২</li><li>দক্ষতা ৩</li></ul>
<h2 style="color:#1f3a93">ব্যক্তিগত তথ্য</h2>
<p>পিতার নাম: ........ · জন্ম তারিখ: ........ · জাতীয়তা: বাংলাদেশি · ঠিকানা: ........</p>
<h2 style="color:#1f3a93">রেফারেন্স</h2><p>অনুরোধে সরবরাহ করা হবে।</p>`, lines: [70, 50, 90, 60, 90, 70]
  },
  {
    id: 'meeting', name: 'মিটিং মিনিটস', sub: 'সভার কার্যবিবরণী', file: 'মিটিং মিনিটস',
    html: `<h1>সভার কার্যবিবরণী</h1>
<table><tr><td><b>তারিখ</b></td><td>&nbsp;</td><td><b>সময়</b></td><td>&nbsp;</td></tr><tr><td><b>স্থান</b></td><td>&nbsp;</td><td><b>সভাপতি</b></td><td>&nbsp;</td></tr></table>
<h2>উপস্থিত সদস্য</h2><ol><li>&nbsp;</li><li>&nbsp;</li></ol>
<h2>আলোচ্যসূচি ও সিদ্ধান্ত</h2>
<table><tr><th>ক্রম</th><th>আলোচনা</th><th>সিদ্ধান্ত</th><th>দায়িত্বপ্রাপ্ত</th><th>সময়সীমা</th></tr><tr><td>১</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>২</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr></table>
<p><br></p><p>স্বাক্ষর: ......................</p>`, lines: [70, 90, 60, 90]
  },
  {
    id: 'report', name: 'রিপোর্ট', sub: 'শিরোনাম, সারসংক্ষেপ, বিভাগ', file: 'রিপোর্ট',
    html: `<h1 style="text-align:center">রিপোর্টের শিরোনাম</h1>
<p style="text-align:center;color:#555">প্রস্তুতকারক: ........ · তারিখ: ........</p>
<h2>১. সারসংক্ষেপ</h2><p>রিপোর্টের মূল বিষয় এখানে লিখুন।</p>
<h2>২. পটভূমি</h2><p>&nbsp;</p>
<h2>৩. বিশ্লেষণ</h2><p>&nbsp;</p>
<h2>৪. সুপারিশ</h2><ul><li>&nbsp;</li><li>&nbsp;</li></ul>
<h2>৫. উপসংহার</h2><p>&nbsp;</p>`, lines: [60, 90, 70, 90]
  },
  {
    id: 'invoice', name: 'ইনভয়েস / বিল', sub: 'পণ্য, দাম, মোট', file: 'ইনভয়েস',
    html: `<h1>ইনভয়েস</h1><p>ইনভয়েস নং: ........ &nbsp; তারিখ: ........</p>
<p><b>প্রাপক:</b> ........<br><b>ঠিকানা:</b> ........</p>
<table><tr><th>ক্রম</th><th>বিবরণ</th><th>পরিমাণ</th><th>দর</th><th>মোট</th></tr><tr><td>১</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>২</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>৩</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td colspan="4" style="text-align:right"><b>সর্বমোট</b></td><td>&nbsp;</td></tr></table>
<p><br></p><p>ধন্যবাদান্তে,<br>.........</p>`, lines: [50, 60, 90, 90]
  },
];

// rows: strings starting with "=" are formulas. {v,s} for styled cells.
const H = (v) => ({ v, s: { b: 1, bg: '#3157e0', color: '#ffffff', ha: 'center' } });
export const SHEET_TPLS = [
  { id: 'blank', name: 'ফাঁকা শিট', sub: '', file: 'নতুন স্প্রেডশিট', sheets: [{ name: 'Sheet1', rows: [] }] },
  {
    id: 'expense', name: 'দৈনিক আয়-ব্যয়', sub: 'আয়, ব্যয়, ব্যালান্স', file: 'আয়-ব্যয়',
    sheets: [{
      name: 'হিসাব', colW: [90, 200, 100, 100, 110], freeze: { r: 1, c: 0 },
      rows: [[H('তারিখ'), H('বিবরণ'), H('আয়'), H('ব্যয়'), H('ব্যালান্স')],
      ['01/01/2026', 'প্রারম্ভিক জমা', 5000, '', '=C2-D2'], ['02/01/2026', 'বাজার', '', 850, '=E2+C3-D3'], ['03/01/2026', 'যাতায়াত', '', 120, '=E3+C4-D4'],
      [{ v: 'মোট', s: { b: 1 } }, '', { v: '=SUM(C2:C100)', s: { b: 1 } }, { v: '=SUM(D2:D100)', s: { b: 1 } }, { v: '=C102-D102', s: { b: 1 } }]]
    }]
  },
  {
    id: 'attendance', name: 'উপস্থিতি শিট', sub: 'মাসিক হাজিরা', file: 'উপস্থিতি',
    sheets: [{
      name: 'হাজিরা', colW: [50, 160, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 70], freeze: { r: 1, c: 2 },
      rows: [[H('ক্রম'), H('নাম'), ...Array.from({ length: 10 }, (_, i) => H(String(i + 1))), H('মোট')],
      [1, 'নাম ১', 'P', 'P', 'A', 'P', 'P', 'P', 'A', 'P', 'P', 'P', '=COUNTIF(C2:L2,"P")'], [2, 'নাম ২', 'P', 'P', 'P', 'P', 'A', 'P', 'P', 'P', 'P', 'P', '=COUNTIF(C3:L3,"P")'], [3, 'নাম ৩', '', '', '', '', '', '', '', '', '', '', '=COUNTIF(C4:L4,"P")']]
    }]
  },
  {
    id: 'budget', name: 'মাসিক বাজেট', sub: 'পরিকল্পনা বনাম বাস্তব', file: 'বাজেট',
    sheets: [{
      name: 'বাজেট', colW: [170, 110, 110, 110], freeze: { r: 1, c: 0 },
      rows: [[H('খাত'), H('পরিকল্পনা'), H('বাস্তব'), H('পার্থক্য')],
      ['বাসা ভাড়া', 8000, 8000, '=B2-C2'], ['খাবার', 6000, 6400, '=B3-C3'], ['যাতায়াত', 2000, 1800, '=B4-C4'], ['বিদ্যুৎ ও গ্যাস', 1200, 1350, '=B5-C5'], ['অন্যান্য', 1500, 900, '=B6-C6'],
      [{ v: 'মোট', s: { b: 1 } }, { v: '=SUM(B2:B6)', s: { b: 1 } }, { v: '=SUM(C2:C6)', s: { b: 1 } }, { v: '=SUM(D2:D6)', s: { b: 1 } }]]
    }]
  },
  {
    id: 'marks', name: 'ফলাফল / নম্বর শিট', sub: 'যোগফল, গড়, গ্রেড', file: 'ফলাফল',
    sheets: [{
      name: 'ফলাফল', colW: [50, 150, 70, 70, 70, 80, 80, 70], freeze: { r: 1, c: 2 },
      rows: [[H('রোল'), H('নাম'), H('বাংলা'), H('ইংরেজি'), H('গণিত'), H('মোট'), H('গড়'), H('গ্রেড')],
      [1, 'শিক্ষার্থী ১', 78, 65, 90, '=SUM(C2:E2)', '=AVERAGE(C2:E2)', '=IF(G2>=80,"A+",IF(G2>=70,"A",IF(G2>=60,"A-",IF(G2>=33,"B","F"))))'],
      [2, 'শিক্ষার্থী ২', 55, 48, 62, '=SUM(C3:E3)', '=AVERAGE(C3:E3)', '=IF(G3>=80,"A+",IF(G3>=70,"A",IF(G3>=60,"A-",IF(G3>=33,"B","F"))))']]
    }]
  },
  {
    id: 'invoice', name: 'বিল / ইনভয়েস', sub: 'স্বয়ংক্রিয় মোট ও ভ্যাট', file: 'বিল',
    sheets: [{
      name: 'বিল', colW: [50, 220, 80, 90, 110],
      rows: [[{ v: 'ইনভয়েস', s: { b: 1, fs: 20 } }], [], [H('ক্রম'), H('বিবরণ'), H('পরিমাণ'), H('দর'), H('মোট')],
      [1, 'পণ্য ক', 2, 500, '=C4*D4'], [2, 'পণ্য খ', 1, 1200, '=C5*D5'], [3, '', '', '', ''],
      ['', '', '', { v: 'উপমোট', s: { b: 1 } }, '=SUM(E4:E20)'], ['', '', '', 'ভ্যাট ৫%', '=E21*0.05'], ['', '', '', { v: 'সর্বমোট', s: { b: 1 } }, { v: '=E21+E22', s: { b: 1 } }]]
    }]
  },
];

export const SLIDE_THEMES = [
  { id: 'clean', name: 'ক্লিন নীল', bg: '#ffffff', title: '#1f3a93', body: '#2b2f45', accent: '#3157e0', band: '#3157e0', font: 'Calibri' },
  { id: 'dark', name: 'ডার্ক', bg: '#14182b', title: '#ffffff', body: '#c9cfee', accent: '#6f8cff', band: '#6f8cff', font: 'Calibri' },
  { id: 'warm', name: 'উষ্ণ', bg: '#fff7ed', title: '#9a3412', body: '#431407', accent: '#ea580c', band: '#ea580c', font: 'Georgia' },
  { id: 'green', name: 'সবুজ', bg: '#f0fdf4', title: '#14532d', body: '#1f2d25', accent: '#16a34a', band: '#16a34a', font: 'Calibri' },
  { id: 'mono', name: 'সাদা-কালো', bg: '#ffffff', title: '#111111', body: '#333333', accent: '#111111', band: '#111111', font: 'Arial' },
  { id: 'plum', name: 'বেগুনি', bg: '#faf5ff', title: '#581c87', body: '#2e1065', accent: '#9333ea', band: '#9333ea', font: 'Calibri' },
];

function grid(items, onPick, render) {
  const g = h('div', { class: 'tplgrid' });
  items.forEach(t => g.append(h('button', { class: 'tpl', type: 'button', onclick: () => onPick(t) }, render(t), h('b', null, t.name), t.sub ? h('small', null, t.sub) : null)));
  return g;
}
function pick(title, items, cb, render) {
  let ov; const g = grid(items, t => { ov.close(); setTimeout(() => cb(t.id), 80); }, render);
  ov = modal({ title, body: g, wide: true, actions: [{ label: 'বন্ধ', ghost: true }] });
}
const lines = (t) => h('div', { class: 'tp' }, (t.lines || [70, 90, 60, 80]).map((w, i) => h('i', { style: { top: 12 + i * 14 + 'px', width: w + '%', right: 'auto' } })));
export const pickWordTemplate = cb => pick('টেমপ্লেট বাছাই করুন', WORD_TPLS, cb, lines);
export const pickSheetTemplate = cb => pick('Excel টেমপ্লেট', SHEET_TPLS, cb, t => h('div', { class: 'tp' }, [0, 1, 2, 3].map(i => h('i', { style: { top: 10 + i * 17 + 'px', height: '10px', right: '10px', left: '10px', background: i ? 'var(--line)' : 'var(--excel)' } }))));
export const pickSlideTheme = cb => pick('থিম বাছাই করুন', SLIDE_THEMES, cb, t => h('div', { class: 'tp', style: { background: t.bg, border: '1px solid var(--line)' } },
  h('i', { style: { top: '16px', left: '12px', width: '55%', height: '9px', background: t.title } }), h('i', { style: { top: '34px', left: '12px', width: '75%', background: t.body, opacity: .5 } }), h('i', { style: { top: '46px', left: '12px', width: '60%', background: t.body, opacity: .5 } }), h('i', { style: { bottom: '0', top: 'auto', left: '0', right: '0', height: '8px', background: t.band, borderRadius: 0 } })));
