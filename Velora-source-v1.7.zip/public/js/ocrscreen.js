// Velora Text from Photo — handwritten notes or printed pages → editable text / Word.
//  pick or shoot pages → (crop · clean) → OCR (Gemini for handwriting, Tesseract fallback) → edit → copy / TXT / Word
import { h, icon, toast, sheet, busy, errMsg, toBn, baseName, shareFile, saveToDevice, esc } from './util.js';
import { screen } from './screen.js';
import * as P from './imgproc.js';
import { cnv, ctx2, fitMax, stampName } from './exportkit.js';
import { openCropper } from './cropper.js';
import { liveCapture, pickPhoto, fileToCanvas } from './camera.js';
import { deskewCanvas, openCleanup } from './cleanup.js';

const MODES = [['hand', 'হাতের লেখা', 'খাতা, নোট, চিঠি'], ['print', 'ছাপা লেখা', 'বই, কাগজ, নোটিশ'], ['form', 'ফর্ম / টেবিল', 'রসিদ, সনদ, তালিকা']];
const LANGS = [['ben+eng', 'বাংলা + English'], ['ben', 'শুধু বাংলা'], ['eng', 'শুধু English']];

/** Make a page easier to read for any OCR engine: right size, shadows flattened, noise gone, tilt fixed. */
export function prepForOcr(src, { mode = 'print', clean = true } = {}) {
  let c = src; const long = Math.max(c.width, c.height);
  if (long < 1500) { const s = Math.min(2, 1800 / long), n = cnv(c.width * s, c.height * s), g = ctx2(n); g.imageSmoothingQuality = 'high'; g.drawImage(c, 0, 0, n.width, n.height); c = n; }
  else c = fitMax(c, 2600);
  if (!clean) return c;
  try { c = deskewCanvas(c); } catch (e) { console.warn(e); }
  const id = ctx2(c).getImageData(0, 0, c.width, c.height);
  P.removeNoise(id, mode === 'hand' ? 55 : 40); P.textBoost(id, { strength: mode === 'hand' ? .55 : .6, color: false });
  const out = cnv(c.width, c.height); ctx2(out).putImageData(new ImageData(id.data, c.width, c.height), 0, 0); return out;
}
const wordCount = t => (t.trim().match(/\S+/g) || []).length;

export async function openOcrFlow(images = [], { name, skipClean = false, mode = 'hand' } = {}) {
  const pages = images.map(c => ({ src: c })); let cur = 0, opt = { mode, lang: 'ben+eng', clean: !skipClean };
  const scr = screen({ title: 'ছবি থেকে লেখা', cls: 'ocrs' });
  scr.setGuard(async () => true);
  const body = scr.body; body.classList.add('oc-body');

  /* ---------- step 1: pages + options ---------- */
  async function addFrom(how) {
    try {
      if (how === 'cam') { const c = await liveCapture({ title: 'লেখার ছবি তুলুন', hint: 'আলো পড়ছে এমন জায়গায়, লেখা ফ্রেমে ভরে তুলুন' }); if (c) { pages.push({ src: c }); cur = pages.length - 1; } }
      else if (how === 'gal') { const b = busy('ছবি আনা হচ্ছে…'); try { const { pickFiles } = await import('./util.js'); const fs = await pickFiles({ accept: 'image/*', multiple: true }); for (const f of fs) { b.set(f.name); pages.push({ src: await fileToCanvas(f) }); } if (fs.length) cur = pages.length - 1; } finally { b.done(); } }
      else if (how === 'lib') { const { pickInput } = await import('./tools.js'); const fs = await pickInput({ kind: 'image', accept: 'image/*', multiple: true, title: 'ছবি বেছে নিন' }); if (fs) for (const f of (Array.isArray(fs) ? fs : [fs])) { pages.push({ src: await fileToCanvas(f) }); cur = pages.length - 1; } }
    } catch (e) { toast('ছবি পড়া যায়নি: ' + errMsg(e), 3500); }
    drawSetup();
  }
  const addMenu = () => sheet('পাতা যোগ করুন', [
    { icon: 'camera', label: 'ক্যামেরায় তুলুন', onClick: () => addFrom('cam') }, { icon: 'image', label: 'গ্যালারি থেকে (একাধিক)', onClick: () => addFrom('gal') }, { icon: 'folder', label: 'আমার ফাইল থেকে', onClick: () => addFrom('lib') }]);

  function pageMenu(i) {
    sheet(`পাতা ${toBn(i + 1)}`, [
      { icon: 'crop', label: 'ক্রপ / কাগজ সোজা করুন', onClick: async () => { const r = await openCropper(pages[i].src, { title: 'লেখার অংশ বেছে নিন' }); if (r) { pages[i].src = r; drawSetup(); } } },
      { icon: 'clean', label: 'ছবি পরিষ্কার করুন', sub: 'নয়েজ কমান, লেখা স্পষ্ট', onClick: () => openCleanup(pages[i].src, { onResult: r => { pages[i].src = r; drawSetup(); } }) },
      { icon: 'rotate', label: 'ডানে ঘোরান', onClick: () => { const c = pages[i].src, r = cnv(c.height, c.width), g = ctx2(r); g.translate(r.width / 2, r.height / 2); g.rotate(Math.PI / 2); g.drawImage(c, -c.width / 2, -c.height / 2); pages[i].src = r; drawSetup(); } },
      { icon: 'trash', label: 'মুছুন', danger: true, onClick: () => { pages.splice(i, 1); cur = Math.max(0, Math.min(cur, pages.length - 1)); drawSetup(); } }]);
  }
  const seg = (items, curv, on) => h('div', { class: 'seg' }, items.map(([k, t]) => h('button', { type: 'button', class: curv === k ? 'on' : '', onclick: () => on(k) }, t)));
  async function engineNote() {
    const { hasKey, aiSetup } = await import('./ai.js'); const ok = await hasKey();
    const el = h('div', { class: 'oc-eng' + (ok ? ' ok' : '') }, icon(ok ? 'sparkle' : 'info', 20),
      h('div', null, h('b', null, ok ? 'AI (Gemini) চালু — হাতের লেখায় সেরা ফল' : 'AI কী নেই — শুধু ছাপা লেখা ভালো পড়বে'),
        h('small', null, ok ? 'ছবি শুধু লেখা পড়ার জন্য Google-এ যায়।' : 'হাতের লেখা, বিশেষ করে বাংলা, ঠিকমতো পড়তে বিনামূল্যের Gemini কী দিন। কী ছাড়া অফলাইন-ধাঁচের ইঞ্জিন চলবে (প্রথমবার ইন্টারনেট লাগে)।')),
      ok ? null : h('button', { class: 'btn', type: 'button', onclick: async () => { if (await aiSetup()) drawSetup(); } }, 'AI চালু'));
    return el;
  }
  async function drawSetup() {
    scr.setTitle('ছবি থেকে লেখা');
    const strip = h('div', { class: 'oc-strip' }, pages.map((p, i) => { const t = cnv(84, 112), g = ctx2(t), s = Math.min(84 / p.src.width, 112 / p.src.height); g.fillStyle = '#fff'; g.fillRect(0, 0, 84, 112); g.drawImage(p.src, (84 - p.src.width * s) / 2, (112 - p.src.height * s) / 2, p.src.width * s, p.src.height * s);
      return h('button', { type: 'button', class: 'oc-th' + (i === cur ? ' on' : ''), onclick: () => { if (i === cur) pageMenu(i); else { cur = i; drawSetup(); } }, 'aria-label': 'পাতা ' + (i + 1) }, t, h('i', null, toBn(i + 1))); }),
      h('button', { type: 'button', class: 'oc-th add', onclick: addMenu, 'aria-label': 'পাতা যোগ' }, icon('plus', 26), h('small', null, 'যোগ')));
    const big = h('div', { class: 'oc-prev' });
    if (pages[cur]) { const v = fitMax(pages[cur].src, 900); v.className = 'oc-img'; big.append(v, h('button', { class: 'oc-edit', type: 'button', onclick: () => pageMenu(cur) }, icon('pen', 16), 'এডিট')); }
    else big.append(h('div', { class: 'oc-empty' }, icon('handwrite', 44), h('b', null, 'লেখার ছবি যোগ করুন'), h('small', null, 'হাতে লেখা খাতা, নোট, বই বা কাগজের ছবি'),
      h('div', { class: 'oc-empty-b' }, h('button', { class: 'btn primary', type: 'button', onclick: () => addFrom('cam') }, icon('camera', 18), 'ক্যামেরা'), h('button', { class: 'btn', type: 'button', onclick: () => addFrom('gal') }, icon('image', 18), 'গ্যালারি'))));
    const goB = h('button', { class: 'btn primary oc-go', type: 'button', disabled: !pages.length, onclick: run }, icon('scantext', 20), pages.length ? `লেখা বের করুন (${toBn(pages.length)}টি পাতা)` : 'আগে ছবি যোগ করুন');
    const tg = h('button', { type: 'button', class: 'cl-tg' + (opt.clean ? ' on' : ''), onclick: () => { opt.clean = !opt.clean; drawSetup(); } }, h('span', { class: 'switch' + (opt.clean ? ' on' : '') }), h('span', null, 'পড়ার আগে ছবি পরিষ্কার করা', h('small', null, 'ছায়া, নয়েজ ও কাত ঠিক করে — ফল ভালো হয়')));
    const opts = h('div', { class: 'oc-opts' },
      h('div', { class: 'oc-modes' }, MODES.map(([k, t, s]) => h('button', { type: 'button', class: 'oc-mode' + (opt.mode === k ? ' on' : ''), onclick: () => { opt.mode = k; drawSetup(); } }, h('b', null, t), h('small', null, s)))),
      seg(LANGS, opt.lang, v => { opt.lang = v; drawSetup(); }), tg, await engineNote(), goB);
    body.replaceChildren(strip, big, opts);
  }

  /* ---------- step 2: run OCR ---------- */
  async function run() {
    const { ocrSession, htmlToText, textToHtml } = await import('./ocr.js'); const b = busy('শুরু হচ্ছে…'); let s = null, res = [];
    try {
      s = await ocrSession({ engine: 'auto', lang: opt.lang, mode: opt.mode, onStatus: m => b.set(m) });
      for (let i = 0; i < pages.length; i++) {
        b.set(`পাতা ${toBn(i + 1)}/${toBn(pages.length)} — ছবি তৈরি হচ্ছে…`); await new Promise(r => setTimeout(r, 20));
        const img = prepForOcr(pages[i].src, { mode: opt.mode, clean: opt.clean });
        b.set(`পাতা ${toBn(i + 1)}/${toBn(pages.length)} — লেখা পড়া হচ্ছে…`); res.push(await s.run(img));
      }
    } catch (e) { b.done(); if (s) s.close(); console.error(e); return toast(errMsg(e), 5500); }
    b.done(); await s.close(); const usedAI = res.some(r => r.engine === 'ai');
    showResult(res, usedAI, { htmlToText, textToHtml });
  }

  /* ---------- step 3: result — edit, copy, save ---------- */
  function showResult(res, usedAI, { textToHtml }) {
    scr.setTitle('পাওয়া লেখা');
    const sep = '\n\n──────── পাতা {n} ────────\n\n';
    const text0 = res.length > 1 ? res.map((r, i) => (i ? sep.replace('{n}', toBn(i + 1)) : '') + r.text).join('') : res[0].text;
    const ta = h('textarea', { class: 'oc-ta', spellcheck: 'false', 'aria-label': 'পাওয়া লেখা' }); ta.value = text0;
    const wc = h('span', null); const upd = () => { wc.textContent = `${toBn(wordCount(ta.value))}টি শব্দ · ${toBn(ta.value.length)}টি অক্ষর`; }; ta.addEventListener('input', upd); upd();
    const info = h('div', { class: 'oc-info' }, icon(usedAI ? 'sparkle' : 'info', 16), h('span', null, usedAI ? 'AI দিয়ে পড়া হয়েছে — নিচে ভুল থাকলে শুধরে নিন' : 'লোকাল ইঞ্জিনে পড়া — ভুল থাকলে শুধরে নিন (হাতের লেখায় AI কী দিলে অনেক ভালো)'), wc);
    const sheetHtml = () => ta.value === text0 ? res.map(r => r.html).join('<div class="pagebreak" contenteditable="false"></div>') : ta.value.split(/\n?─{4,}[^\n]*─{4,}\n?/).map(t => textToHtml(t)).join('<div class="pagebreak" contenteditable="false"></div>');
    const nm = name ? baseName(name) : stampName('লেখা');
    const toWord = async () => { scr.close(); await window.__ao.importFiles([new File([`<html><body>${sheetHtml()}</body></html>`], nm + '.html', { type: 'text/html' })], { open: true }); };
    const copy = async () => { try { await navigator.clipboard.writeText(ta.value); toast('কপি হয়েছে'); } catch { ta.select(); document.execCommand('copy'); toast('কপি হয়েছে'); } };
    const txtBlob = () => new Blob(['\ufeff' + ta.value], { type: 'text/plain;charset=utf-8' });
    const bar = h('div', { class: 'oc-bar' },
      h('button', { class: 'btn', type: 'button', onclick: copy }, icon('copy', 18), 'কপি'),
      h('button', { class: 'btn', type: 'button', onclick: () => sheet('টেক্সট ফাইল', [{ icon: 'download', label: 'ফোনে সেভ (.txt)', onClick: () => saveToDevice(txtBlob(), nm + '.txt') }, { icon: 'share', label: 'শেয়ার', onClick: () => shareFile(txtBlob(), nm + '.txt') }, { icon: 'file', label: 'লাইব্রেরিতে রাখুন (.txt)', onClick: async () => { await window.__ao.importFiles([new File([txtBlob()], nm + '.txt', { type: 'text/plain' })]); } }]) }, icon('file', 18), '.txt'),
      h('button', { class: 'btn primary', type: 'button', onclick: toWord }, icon('word', 18), 'Word-এ খুলুন'));
    const back = h('button', { class: 'oc-back', type: 'button', onclick: drawSetup }, icon('back', 16), 'ছবিতে ফিরুন / আবার পড়ুন');
    body.replaceChildren(info, ta, h('div', { class: 'oc-bottom' }, back, bar));
  }
  drawSetup();
}
