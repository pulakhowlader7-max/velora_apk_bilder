// IndexedDB storage — files live in the phone's own app storage.
import { uid, extOf, kindOf, baseName } from './util.js';

const DB_NAME = 'amar-office', VER = 2;
const VERSION_GAP = 10 * 60 * 1000, VERSION_MAX = 5, VERSION_FILE_MAX = 40 * 1048576;
let dbp;
function open() {
  return dbp ||= new Promise((res, rej) => {
    const r = indexedDB.open(DB_NAME, VER);
    r.onupgradeneeded = () => {
      const d = r.result;
      if (!d.objectStoreNames.contains('meta')) d.createObjectStore('meta', { keyPath: 'id' });
      if (!d.objectStoreNames.contains('data')) d.createObjectStore('data');
      if (!d.objectStoreNames.contains('snap')) d.createObjectStore('snap');
      if (!d.objectStoreNames.contains('kv')) d.createObjectStore('kv');
      if (!d.objectStoreNames.contains('ver')) d.createObjectStore('ver');   // file history: key = id|time|size
    };
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
    r.onblocked = () => rej(new Error('ডাটাবেস ব্লকড'));
  });
}
function tx(stores, mode, fn) {
  return open().then(db => new Promise((res, rej) => {
    const t = db.transaction(stores, mode);
    let out;
    Promise.resolve(fn(...[].concat(stores).map(s => t.objectStore(s)))).then(v => { out = v; }, rej);
    t.oncomplete = () => res(out);
    t.onerror = () => rej(t.error);
    t.onabort = () => rej(t.error || new Error('সংরক্ষণ ব্যর্থ (স্টোরেজ ভরে গেছে?)'));
  }));
}
const req = r => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });

/* Big files go into IndexedDB as Blobs: Chromium refuses single ArrayBuffer records above ~127 MB, and a Blob is stored on disk by
   reference — it is not copied into the JS heap until someone asks for it. */
const BIG = 8 * 1048576;
const pack = buf => (buf && !(buf instanceof Blob) && buf.byteLength > BIG) ? new Blob([buf]) : buf;
const unpack = async r => (r instanceof Blob) ? r.arrayBuffer() : r;

/** Refuse a write up-front when the phone is nearly out of space (a half-written big file is worse than a clear message). */
async function guardSpace(bytes) {
  if (!bytes || bytes < 5 * 1048576) return;
  let e; try { e = await navigator.storage.estimate(); } catch { return; }
  if (e && e.quota && e.quota - e.usage < bytes * 1.3 + 30 * 1048576) throw new Error('ফোনের স্টোরেজ প্রায় ভরে গেছে — জায়গা খালি করুন বা পুরনো ফাইল মুছুন');
}
const vKey = (id, t, size) => `${id}|${t}|${size}`;

export const db = {
  async list() { return tx('meta', 'readonly', s => req(s.getAll())); },
  async meta(id) { return tx('meta', 'readonly', s => req(s.get(id))); },
  async buf(id) { const r = await tx('data', 'readonly', s => req(s.get(id))); return r ? unpack(r) : null; },
  /** The stored bytes as a Blob without loading them into memory (use with URL.createObjectURL for streaming viewers). */
  async blob(id) { const r = await tx('data', 'readonly', s => req(s.get(id))); if (!r) return null; return r instanceof Blob ? r : new Blob([r]); },
  async snap(id) { return tx('snap', 'readonly', s => req(s.get(id))); },
  async create({ name, buf, snap, kind, folder = '', extra = null }) {
    await guardSpace(buf.byteLength ?? buf.size);
    const id = uid();
    const now = Date.now();
    const meta = { id, name, kind: kind || kindOf(name), ext: extOf(name), size: buf.byteLength ?? buf.size, created: now, modified: now, opened: now, starred: false, trashed: false, folder, ...(extra || {}) };
    await tx(['meta', 'data', 'snap'], 'readwrite', (m, d, s) => {
      m.put(meta); d.put(pack(buf), id); if (snap !== undefined) s.put(snap, id);
    });
    return meta;
  },
  async save(id, { buf, snap, name }) {
    const meta = await this.meta(id);
    if (!meta) throw new Error('ফাইল পাওয়া যায়নি');
    if (buf) { await guardSpace(buf.byteLength ?? buf.size); await this._version(id, meta, false); meta.size = buf.byteLength ?? buf.size; }
    if (name) { meta.name = name; meta.ext = extOf(name); }
    meta.modified = Date.now();
    await tx(['meta', 'data', 'snap'], 'readwrite', (m, d, s) => {
      m.put(meta); if (buf) d.put(pack(buf), id); if (snap !== undefined) s.put(snap, id);
    });
    return meta;
  },
  /* ---- file history: the state *before* an editing session is kept (at most one per 10 min, last 5 per file) ---- */
  async _version(id, meta, force) {
    const now = Date.now(); if (!force && meta.verAt && now - meta.verAt < VERSION_GAP) return; if ((meta.size || 0) > VERSION_FILE_MAX) return;
    try {
      const old = await tx('data', 'readonly', s => req(s.get(id))); if (!old) return; const sn = await tx('snap', 'readonly', s => req(s.get(id)));
      await tx('ver', 'readwrite', s => { s.put({ buf: old, snap: sn, name: meta.name }, vKey(id, meta.modified || now, meta.size || 0)); }); meta.verAt = now;
      const keys = await tx('ver', 'readonly', s => req(s.getAllKeys(IDBKeyRange.bound(id + '|', id + '|\uffff')))); keys.sort((a, b) => +b.split('|')[1] - +a.split('|')[1]);
      for (const k of keys.slice(VERSION_MAX)) await tx('ver', 'readwrite', s => { s.delete(k); });
    } catch (e) { console.warn('version skipped', e); }
  },
  async versions(id) { const keys = await tx('ver', 'readonly', s => req(s.getAllKeys(IDBKeyRange.bound(id + '|', id + '|\uffff')))); return keys.map(k => { const [, t, size] = k.split('|'); return { key: k, t: +t, size: +size }; }).sort((a, b) => b.t - a.t); },
  async restoreVersion(id, key) {
    const v = await tx('ver', 'readonly', s => req(s.get(key))); if (!v) throw new Error('সংস্করণটি পাওয়া যায়নি');
    const meta = await this.meta(id); await this._version(id, meta, true);          // the current state becomes a version too — restoring is reversible
    const data = v.buf instanceof Blob ? v.buf : v.buf; meta.size = data.byteLength ?? data.size; meta.modified = Date.now();
    await tx(['meta', 'data', 'snap'], 'readwrite', (m, d, s) => { m.put(meta); d.put(data, id); if (v.snap !== undefined && v.snap !== null) s.put(v.snap, id); else s.delete(id); });
    return meta;
  },
  async patch(id, p) {
    const meta = await this.meta(id); if (!meta) return null;
    Object.assign(meta, p);
    await tx('meta', 'readwrite', s => { s.put(meta); });
    return meta;
  },
  async remove(id) { await tx(['meta', 'data', 'snap', 'ver'], 'readwrite', (m, d, s, v) => { m.delete(id); d.delete(id); s.delete(id); v.delete(IDBKeyRange.bound(id + '|', id + '|\uffff')); }); },
  async clearSnap(id) { await tx('snap', 'readwrite', s => { s.delete(id); }); },
  async kvGet(k, def) { const v = await tx('kv', 'readonly', s => req(s.get(k))); return v === undefined ? def : v; },
  async kvSet(k, v) { await tx('kv', 'readwrite', s => { s.put(v, k); }); },
  async kvDel(k) { await tx('kv', 'readwrite', s => { s.delete(k); }); },
  async wipeAll() { await tx(['meta', 'data', 'snap', 'kv', 'ver'], 'readwrite', (a, b, c, d, e) => { a.clear(); b.clear(); c.clear(); d.clear(); e.clear(); }); },
  async usage() {
    const metas = await this.list();
    const total = metas.reduce((a, m) => a + (m.size || 0), 0);
    let quota = null, used = null;
    try { const e = await navigator.storage.estimate(); quota = e.quota; used = e.usage; } catch { }
    return { count: metas.length, total, quota, used };
  },
};

export async function requestPersist() {
  try { if (navigator.storage && navigator.storage.persist) return await navigator.storage.persist(); } catch { }
  return false;
}
export async function isPersisted() { try { return navigator.storage && navigator.storage.persisted ? await navigator.storage.persisted() : false; } catch { return false; } }

// Settings with defaults
export const defaults = { theme: 'auto', lockOn: false, autoLock: 60, view: 'grid', sort: 'modified', author: '', fontSize: 'md' };
let cache = null;
export async function getSettings() { if (!cache) cache = { ...defaults, ...(await db.kvGet('settings', {})) }; return cache; }
export async function setSetting(k, v) { const s = await getSettings(); s[k] = v; await db.kvSet('settings', s); return s; }

// Unique name helper
export async function uniqueName(name) {
  const all = (await db.list()).filter(m => !m.trashed).map(m => m.name.toLowerCase());
  if (!all.includes(name.toLowerCase())) return name;
  const b = baseName(name), e = extOf(name) ? '.' + extOf(name) : '';
  for (let i = 2; i < 999; i++) { const n = `${b} (${i})${e}`; if (!all.includes(n.toLowerCase())) return n; }
  return name;
}
