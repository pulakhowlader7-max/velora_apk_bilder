// Velora text / code editor — for .txt, .json, .xml, .css, .js, .py, .srt, .log … files are saved back in their own format.
import { h, icon, btn, sheet, toast, promptDlg, KINDS, extOf, baseName, toBn, errMsg } from './util.js';

const CODE = new Set(['json', 'xml', 'css', 'js', 'ts', 'jsx', 'py', 'java', 'c', 'cpp', 'cs', 'php', 'rb', 'go', 'sql', 'sh', 'bat', 'yaml', 'yml', 'ini', 'cfg', 'conf', 'toml', 'kt', 'swift', 'rs', 'vue', 'env']);
export async function blank() { return { name: 'নতুন লেখা.txt', buf: new ArrayBuffer(0), snap: '' }; }

export async function mount(ctx) {
  const ext = extOf(ctx.meta.name), isCode = CODE.has(ext);
  let text = new TextDecoder('utf-8').decode(ctx.buf || new ArrayBuffer(0)); if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
  const bom = new Uint8Array(ctx.buf || [])[0] === 0xEF;
  let wrap = !isCode, fs = 15, lineNo = isCode;
  const ta = h('textarea', { class: 'te-ta', spellcheck: 'false', autocapitalize: 'off', autocomplete: 'off', 'aria-label': 'লেখা সম্পাদনা' }); ta.value = text;
  const gut = h('pre', { class: 'te-gut', 'aria-hidden': 'true' }), pos = h('span', null), cnt = h('span', null);
  const status = h('div', { class: 'te-status' }, pos, cnt);
  const area = h('div', { class: 'te-area' }, gut, ta), findBox = h('div', { class: 'te-find', hidden: true });
  let hdr, as;
  const mark = () => { as && as.mark(); paint(); };
  function paint() {
    ta.style.whiteSpace = wrap ? 'pre-wrap' : 'pre'; ta.style.fontSize = fs + 'px'; gut.style.fontSize = fs + 'px'; area.classList.toggle('ln', lineNo && !wrap); ta.style.overflowX = wrap ? 'hidden' : 'auto';
    const lines = ta.value.split('\n').length; if (lineNo && !wrap) gut.textContent = Array.from({ length: lines }, (_, i) => i + 1).join('\n');
    const upto = ta.value.slice(0, ta.selectionStart), ln = upto.split('\n').length, col = upto.length - upto.lastIndexOf('\n');
    pos.textContent = `লাইন ${toBn(ln)}, কলাম ${toBn(col)}`; cnt.textContent = `${toBn(lines)} লাইন · ${toBn(ta.value.length)} অক্ষর`;
  }
  ta.addEventListener('input', mark); ta.addEventListener('keyup', paint); ta.addEventListener('click', paint); ta.addEventListener('scroll', () => { gut.scrollTop = ta.scrollTop; });
  ta.addEventListener('keydown', e => { if (e.key === 'Tab' && isCode) { e.preventDefault(); document.execCommand('insertText', false, '  '); } });
  const undo = () => { ta.focus(); document.execCommand('undo'); mark(); }, redo = () => { ta.focus(); document.execCommand('redo'); mark(); };

  /* find & replace */
  function openFind() {
    findBox.hidden = false; const f = h('input', { class: 'inp', placeholder: 'খুঁজুন', 'aria-label': 'খুঁজুন' }), r = h('input', { class: 'inp', placeholder: 'বদলে যা বসবে', 'aria-label': 'বদলান' }), info = h('small', null);
    let from = 0; const count = () => { const q = f.value; if (!q) return 0; return ta.value.split(q).length - 1; };
    const next = () => { const q = f.value; if (!q) return; let i = ta.value.indexOf(q, from); if (i < 0) { i = ta.value.indexOf(q, 0); if (i < 0) { info.textContent = 'পাওয়া যায়নি'; return; } } ta.focus(); ta.setSelectionRange(i, i + q.length); from = i + q.length; info.textContent = `${toBn(count())}টি মিলেছে`; const lh = fs * 1.5; ta.scrollTop = Math.max(0, ta.value.slice(0, i).split('\n').length * lh - ta.clientHeight / 2); paint(); };
    const rep = () => { const q = f.value; if (!q) return; if (ta.value.slice(ta.selectionStart, ta.selectionEnd) === q) { ta.focus(); document.execCommand('insertText', false, r.value); mark(); } next(); };
    const all = () => { const q = f.value; if (!q) return; const n = count(); if (!n) { info.textContent = 'পাওয়া যায়নি'; return; } ta.focus(); ta.select(); document.execCommand('insertText', false, ta.value.split(q).join(r.value)); mark(); info.textContent = `${toBn(n)}টি বদলানো হয়েছে`; };
    f.addEventListener('input', () => { from = 0; info.textContent = f.value ? `${toBn(count())}টি মিলেছে` : ''; }); f.addEventListener('keydown', e => { if (e.key === 'Enter') next(); });
    findBox.replaceChildren(h('div', { class: 'te-fr' }, f, h('button', { class: 'btn', type: 'button', onclick: next }, 'পরেরটি')), h('div', { class: 'te-fr' }, r, h('button', { class: 'btn', type: 'button', onclick: rep }, 'বদলান'), h('button', { class: 'btn', type: 'button', onclick: all }, 'সব')), h('div', { class: 'te-fr' }, info, h('button', { class: 'te-x', type: 'button', onclick: () => { findBox.hidden = true; } }, 'বন্ধ'))); f.focus();
  }
  async function gotoLine() { const v = await promptDlg('কত নম্বর লাইনে যাবেন?', { type: 'number', inputmode: 'numeric' }); const n = parseInt(v, 10); if (!n) return; const lines = ta.value.split('\n'); let off = 0; for (let i = 0; i < Math.min(n - 1, lines.length - 1); i++) off += lines[i].length + 1; ta.focus(); ta.setSelectionRange(off, off); ta.scrollTop = Math.max(0, (n - 3) * fs * 1.5); paint(); }
  function fmtJson(min) { try { const o = JSON.parse(ta.value); ta.focus(); ta.select(); document.execCommand('insertText', false, JSON.stringify(o, null, min ? 0 : 2)); mark(); toast(min ? 'ছোট করা হয়েছে' : 'সুন্দর করে সাজানো হয়েছে'); } catch (e) { toast('JSON ভুল আছে: ' + errMsg(e), 5000); } }

  const tools = h('div', { class: 'te-tools' },
    btn('search', 'খুঁজুন ও বদলান', openFind, { text: 'খুঁজুন', keepFocus: false }), btn('down', 'লাইনে যান', gotoLine, { text: 'লাইন', keepFocus: false }),
    btn('minus', 'ছোট ফন্ট', () => { fs = Math.max(10, fs - 1); paint(); }, { keepFocus: false }), btn('plus', 'বড় ফন্ট', () => { fs = Math.min(28, fs + 1); paint(); }, { keepFocus: false }),
    btn('text', 'লাইন ভাঁজ', () => { wrap = !wrap; paint(); toast(wrap ? 'লাইন ভাঁজ চালু' : 'লাইন নম্বর সহ, ভাঁজ বন্ধ'); }, { text: 'ভাঁজ', keepFocus: false }));
  const extra = [];
  if (ext === 'json') extra.push({ icon: 'code', label: 'JSON সুন্দর করে সাজান', onClick: () => fmtJson(false) }, { icon: 'code', label: 'JSON ছোট করুন (minify)', onClick: () => fmtJson(true) });
  extra.push({ icon: 'down', label: 'লাইনে যান', onClick: gotoLine }, { icon: 'text', label: wrap ? 'লাইন নম্বর দেখান (ভাঁজ বন্ধ)' : 'লাইন ভাঁজ চালু', onClick: () => { wrap = !wrap; paint(); } });
  async function serialize() { const enc = new TextEncoder().encode(ta.value); let buf = enc; if (bom) { buf = new Uint8Array(enc.length + 3); buf.set([0xEF, 0xBB, 0xBF]); buf.set(enc, 3); } return { buf: buf.buffer, snap: ta.value }; }
  const exports = [{ icon: 'word', label: 'Word ডকুমেন্ট বানান', sub: '.docx', run: async () => { const m = await import('./word.js'); const r = await m.importFile(new File([ta.value], baseName(ctx.meta.name) + '.txt')); return { blob: new Blob([r.buf], { type: KINDS.word.mime }), name: r.name, kind: 'word' }; } }];
  const r = ctx.setup({ serialize, undo, redo, exports, extraMenu: extra }); hdr = r.hdr; as = r.as;
  ctx.currentBlob = async () => new Blob([(await serialize()).buf], { type: 'text/plain' });
  ctx.root.replaceChildren(hdr.el, tools, findBox, area, status); ctx.root.classList.add('te'); paint();
  return { destroy() { } };
}
