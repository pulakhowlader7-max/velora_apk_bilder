// Page setup + header/footer model for Word documents, and its DOCX (OOXML) reading/writing.
//   cfg = { size:'A4'|'A5'|'Letter'|'Legal'|'Custom', orient:'portrait'|'landscape', w,h (twips, portrait), m:{t,r,b,l} (twips),
//           hdr:{text,align}, ftr:{text,align}, pn:{pos:'none'|'header'|'footer', align, fmt}, raw:{hdr,ftr} (untouched XML of complex headers/footers) }
const X = s => String(s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
export const TWIP_PER_MM = 56.6929, MM = t => t / TWIP_PER_MM;
export const SIZES = { A4: [11906, 16838], A5: [8392, 11906], Letter: [12240, 15840], Legal: [12240, 20160] };
export const SIZE_LABEL = { A4: 'A4 (২১০×২৯৭ মিমি)', A5: 'A5 (১৪৮×২১০ মিমি)', Letter: 'Letter (৮.৫×১১ ইঞ্চি)', Legal: 'Legal (৮.৫×১৪ ইঞ্চি)' };
export const MARGINS = { normal: [1440, 'সাধারণ — ২.৫৪ সেমি'], narrow: [720, 'সরু — ১.২৭ সেমি'], moderate: [1080, 'মাঝারি — ১.৯ সেমি'], wide: [2160, 'চওড়া — ৩.৮ সেমি'], bd: [1134, 'বাংলাদেশ সাধারণ — ২ সেমি'] };
export const PN_FMT = { n: '১', 'page n': 'পাতা ১', 'n/m': '১ / ২৫', 'page n of m': 'Page 1 of 25' };
export const defaultCfg = () => ({ size: 'A4', orient: 'portrait', w: 11906, h: 16838, m: { t: 1134, r: 1134, b: 1134, l: 1134 }, hdr: { text: '', align: 'center' }, ftr: { text: '', align: 'center' }, pn: { pos: 'none', align: 'center', fmt: 'n' } });
export function normalize(c) { const d = defaultCfg(); if (!c) return d; return { ...d, ...c, m: { ...d.m, ...(c.m || {}) }, hdr: { ...d.hdr, ...(c.hdr || {}) }, ftr: { ...d.ftr, ...(c.ftr || {}) }, pn: { ...d.pn, ...(c.pn || {}) } }; }
export const pageDims = c => { const [w, h] = c.orient === 'landscape' ? [c.h, c.w] : [c.w, c.h]; return { w, h }; };
export const hasHF = c => !!(c.hdr.text.trim() || c.ftr.text.trim() || c.pn.pos !== 'none' || (c.raw && (c.raw.hdr || c.raw.ftr)));

/* ---------- writing ---------- */
const NS = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"';
const run = t => t ? `<w:r><w:t xml:space="preserve">${X(t)}</w:t></w:r>` : '';
const fld = (instr, shown) => `<w:r><w:fldChar w:fldCharType="begin"/></w:r><w:r><w:instrText xml:space="preserve"> ${instr} </w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r><w:r><w:t>${shown}</w:t></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r>`;
const para = (jc, inner) => `<w:p><w:pPr><w:spacing w:after="0"/><w:jc w:val="${jc === 'justify' ? 'both' : jc}"/></w:pPr>${inner}</w:p>`;
function pageNumRuns(fmt) {
  const P = fld('PAGE', '1'), M = fld('NUMPAGES', '1');
  return fmt === 'page n' ? run('পাতা ') + P : fmt === 'n/m' ? P + run(' / ') + M : fmt === 'page n of m' ? run('Page ') + P + run(' of ') + M : P;
}
function textParas(txt, align) { return String(txt).split('\n').map(l => para(align, run(l))).join(''); }
/** Returns { hdr:xml|null, ftr:xml|null } — the contents of header1.xml / footer1.xml */
export function hfParts(c) {
  let hdr = null, ftr = null;
  if (c.raw && c.raw.hdr) hdr = c.raw.hdr; else if (c.hdr.text.trim() || c.pn.pos === 'header') hdr = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:hdr ${NS}>${c.hdr.text.trim() ? textParas(c.hdr.text, c.hdr.align) : ''}${c.pn.pos === 'header' ? para(c.pn.align, pageNumRuns(c.pn.fmt)) : ''}</w:hdr>`;
  if (c.raw && c.raw.ftr) ftr = c.raw.ftr; else if (c.ftr.text.trim() || c.pn.pos === 'footer') ftr = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:ftr ${NS}>${c.ftr.text.trim() ? textParas(c.ftr.text, c.ftr.align) : ''}${c.pn.pos === 'footer' ? para(c.pn.align, pageNumRuns(c.pn.fmt)) : ''}</w:ftr>`;
  return { hdr, ftr };
}
export function sectXml(c, hdrRid, ftrRid) {
  const { w, h } = pageDims(c), m = c.m;
  return `<w:sectPr>${hdrRid ? `<w:headerReference w:type="default" r:id="${hdrRid}"/>` : ''}${ftrRid ? `<w:footerReference w:type="default" r:id="${ftrRid}"/>` : ''}<w:pgSz w:w="${w}" w:h="${h}"${c.orient === 'landscape' ? ' w:orient="landscape"' : ''}/><w:pgMar w:top="${m.t}" w:right="${m.r}" w:bottom="${m.b}" w:left="${m.l}" w:header="${Math.min(709, Math.round(m.t / 2))}" w:footer="${Math.min(709, Math.round(m.b / 2))}" w:gutter="0"/></w:sectPr>`;
}

/* ---------- reading ---------- */
const W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main', R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
const kids = (n, name) => [...n.getElementsByTagNameNS(W, name)];
function sizeName(w, h) { const a = Math.min(w, h), b = Math.max(w, h); for (const [k, [sw, sh]] of Object.entries(SIZES)) if (Math.abs(a - sw) < 60 && Math.abs(b - sh) < 60) return k; return 'Custom'; }
/** text paragraphs + page-number info from a header/footer part (fields are recognised, not copied as text) */
function readHF(doc) {
  const out = { paras: [], pn: null, complex: false };
  if (doc.getElementsByTagNameNS(W, 'tbl').length || doc.getElementsByTagNameNS(W, 'drawing').length || doc.getElementsByTagNameNS(W, 'pict').length || doc.getElementsByTagNameNS(W, 'sdt').length) out.complex = true;
  for (const p of kids(doc, 'p')) {
    let text = '', depth = 0, hasPage = false, hasNum = false, instr = '';
    const walk = n => { for (const c of n.children) {
      const ln = c.localName;
      if (ln === 'fldSimple') { const i = c.getAttributeNS(W, 'instr') || ''; if (/PAGE\b/i.test(i) && !/NUMPAGES/i.test(i)) hasPage = true; if (/NUMPAGES/i.test(i)) hasNum = true; if (!/PAGE|NUMPAGES/i.test(i)) out.complex = true; continue; }
      if (ln === 'r') { const fc = c.getElementsByTagNameNS(W, 'fldChar')[0]; if (fc) { const t = fc.getAttributeNS(W, 'fldCharType'); if (t === 'begin') depth++; else if (t === 'end') depth = Math.max(0, depth - 1); continue; }
        const it = c.getElementsByTagNameNS(W, 'instrText')[0]; if (it) { instr += it.textContent; if (/NUMPAGES/i.test(instr)) hasNum = true; else if (/\bPAGE\b/i.test(instr)) hasPage = true; else if (instr.trim()) out.complex = true; continue; }
        if (depth > 0) continue; for (const t of c.children) if (t.localName === 't') text += t.textContent; else if (t.localName === 'tab') text += '\t'; else if (t.localName === 'br') text += '\n'; continue; }
      if (ln === 'hyperlink' || ln === 'ins' || ln === 'smartTag') walk(c); } };
    walk(p); const jc = (kids(p, 'jc')[0] || null); let al = jc ? jc.getAttributeNS(W, 'val') : 'left'; al = al === 'both' ? 'justify' : al === 'start' ? 'left' : al === 'end' ? 'right' : al;
    if (/\t/.test(text.trim())) out.complex = true;                         // tab-aligned left/centre/right header: keep it untouched
    out.paras.push({ text: text.replace(/\t/g, ' ').trim(), align: al || 'left', hasPage, hasNum, hasField: hasPage || hasNum });
  }
  return out;
}
/** Reads sectPr / header / footer of a docx. `z` = JSZip, `rels` = document rels map {id:{t}}, `bodyEl` = document element. */
export async function readPageCfg(z, rels, doc, parse) {
  const cfg = defaultCfg(); const secs = kids(doc, 'sectPr'); const sect = secs[secs.length - 1]; if (!sect) return cfg;
  const pg = kids(sect, 'pgSz')[0], mg = kids(sect, 'pgMar')[0];
  if (pg) { let w = +pg.getAttributeNS(W, 'w') || cfg.w, h = +pg.getAttributeNS(W, 'h') || cfg.h; const land = pg.getAttributeNS(W, 'orient') === 'landscape' || w > h; if (w > h) [w, h] = [h, w]; cfg.w = w; cfg.h = h; cfg.orient = land ? 'landscape' : 'portrait'; cfg.size = sizeName(w, h); }
  if (mg) { const g = a => { const v = parseInt(mg.getAttributeNS(W, a)); return Number.isFinite(v) ? Math.max(0, v) : null; }; cfg.m = { t: g('top') ?? cfg.m.t, r: g('right') ?? cfg.m.r, b: g('bottom') ?? cfg.m.b, l: g('left') ?? cfg.m.l }; }
  const part = async type => {
    const ref = kids(sect, type + 'Reference').find(r => r.getAttributeNS(W, 'type') === 'default') || kids(sect, type + 'Reference')[0]; if (!ref) return null;
    const rid = ref.getAttributeNS(R, 'id'), r = rels[rid]; if (!r) return null; const path = r.t.startsWith('/') ? r.t.slice(1) : 'word/' + r.t, f = z.file(path); if (!f) return null;
    const xml = await f.async('string'); return { xml, doc: parse(xml) };
  };
  for (const [type, key] of [['header', 'hdr'], ['footer', 'ftr']]) {
    const p = await part(type); if (!p) continue; const info = readHF(p.doc);
    const nonEmpty = info.paras.filter(x => x.text || x.hasField);
    const risky = /\br:(id|embed)=|<w:hyperlink/.test(p.xml);                    // relationships we cannot carry over
    if (info.complex || nonEmpty.length > 4) { if (!risky) { cfg.raw = cfg.raw || {}; cfg.raw[key] = p.xml; } else { cfg[key].text = nonEmpty.map(x => x.text).filter(Boolean).join('\n'); } continue; }
    const fieldPara = nonEmpty.find(x => x.hasField), textParas = nonEmpty.filter(x => !x.hasField || x.text);
    if (fieldPara) {
      if (fieldPara.text && !/^(পাতা|page)\b\s*$/i.test(fieldPara.text.replace(/\s*(\/|of)\s*$/i, '').trim()) && !/^(পাতা|page)$/i.test(fieldPara.text.trim())) { if (!risky) { cfg.raw = cfg.raw || {}; cfg.raw[key] = p.xml; continue; } }   // "Confidential – page 3": keep untouched
      const t = fieldPara.text.trim().toLowerCase(); cfg.pn = { pos: type === 'header' ? 'header' : 'footer', align: fieldPara.align, fmt: fieldPara.hasNum ? (/of/.test(t) ? 'page n of m' : 'n/m') : (/পাতা|page/.test(t) ? 'page n' : 'n') };
    }
    const only = textParas.filter(x => !x.hasField); if (only.length) { cfg[key].text = only.map(x => x.text).join('\n'); cfg[key].align = only[0].align; }
  }
  return cfg;
}
