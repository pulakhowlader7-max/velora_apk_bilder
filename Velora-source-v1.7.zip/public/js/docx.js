// HTML <-> DOCX (OOXML) converter. No dependencies except JSZip.
import { needJSZip, esc as escHtml, dataURLtoBlob } from './util.js';
import { normalize as normCfg, hfParts, sectXml, readPageCfg } from './pagecfg.js';

const X = s => String(s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const NS = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"';
const PAGE_W = 11906, PAGE_H = 16838, MARGIN = 1134, TEXT_W = PAGE_W - MARGIN * 2;
const BLOCK = new Set(['P', 'DIV', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'UL', 'OL', 'LI', 'TABLE', 'BLOCKQUOTE', 'HR', 'PRE', 'SECTION', 'ARTICLE', 'HEADER', 'FOOTER', 'FIGURE', 'CENTER']);

let _cv;
export function toHex(c) {
  if (!c) return null; c = c.trim();
  let m = /^#([0-9a-f]{3})$/i.exec(c); if (m) return m[1].split('').map(x => x + x).join('').toUpperCase();
  m = /^#([0-9a-f]{6})$/i.exec(c); if (m) return m[1].toUpperCase();
  m = /^rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)(?:[ ,/]+([\d.]+))?/i.exec(c);
  if (m) { if (m[4] !== undefined && parseFloat(m[4]) === 0) return null; return [m[1], m[2], m[3]].map(n => (+n).toString(16).padStart(2, '0')).join('').toUpperCase(); }
  if (c === 'transparent' || c === 'inherit' || c === 'initial') return null;
  try { _cv ||= document.createElement('canvas').getContext('2d'); _cv.fillStyle = '#000'; _cv.fillStyle = c; const v = _cv.fillStyle; return /^#/.test(v) ? v.slice(1, 7).toUpperCase() : toHex(v); } catch { return null; }
}
const pxToHalfPt = px => Math.max(2, Math.round(px * 1.5));
function cssSizePx(v) {
  if (!v) return null; const m = /^([\d.]+)(px|pt|em|rem|%)?$/.exec(v.trim()); if (m) { const n = parseFloat(m[1]); return m[2] === 'pt' ? n * 4 / 3 : m[2] === 'em' || m[2] === 'rem' ? n * 16 : m[2] === '%' ? n * .16 : n; }
  const k = { 'xx-small': 9, 'x-small': 10, small: 13, medium: 16, large: 18, 'x-large': 24, 'xx-large': 32, 'xxx-large': 48 }[v]; return k || null;
}
const FONT_SIZES = [0, 10, 13, 16, 18, 24, 32, 48];

function sniffImage(bytes) {
  const b = bytes;
  if (b[0] === 0x89 && b[1] === 0x50) return { ext: 'png', w: (b[16] << 24 | b[17] << 16 | b[18] << 8 | b[19]) >>> 0, h: (b[20] << 24 | b[21] << 16 | b[22] << 8 | b[23]) >>> 0 };
  if (b[0] === 0xFF && b[1] === 0xD8) { let i = 2; while (i < b.length - 9) { if (b[i] !== 0xFF) { i++; continue; } const mk = b[i + 1]; if (mk >= 0xC0 && mk <= 0xCF && mk !== 0xC4 && mk !== 0xC8 && mk !== 0xCC) return { ext: 'jpeg', h: b[i + 5] << 8 | b[i + 6], w: b[i + 7] << 8 | b[i + 8] }; i += 2 + (b[i + 2] << 8 | b[i + 3]); } return { ext: 'jpeg', w: 400, h: 300 }; }
  if (b[0] === 0x47 && b[1] === 0x49) return { ext: 'gif', w: b[6] | b[7] << 8, h: b[8] | b[9] << 8 };
  return null;
}
async function imgBytes(src) {
  if (src.startsWith('data:')) { const blob = dataURLtoBlob(src); return new Uint8Array(await blob.arrayBuffer()); }
  const r = await fetch(src); return new Uint8Array(await r.arrayBuffer());
}
async function toPngBytes(src) { // svg / webp / other -> png via canvas
  const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; });
  const c = document.createElement('canvas'); c.width = img.naturalWidth || 300; c.height = img.naturalHeight || 200; c.getContext('2d').drawImage(img, 0, 0);
  const b = await new Promise(r => c.toBlob(r, 'image/png')); return new Uint8Array(await b.arrayBuffer());
}

/* ================= EXPORT ================= */
export async function htmlToDocx(root, { title = '', author = '', cfg = null } = {}) {
  const pc = normCfg(cfg), hf = hfParts(pc);
  const JSZip = await needJSZip();
  const ctx = { rels: [], media: [], nums: [], nextNum: 2, nextRel: 10, imgN: 0, docPr: 1, ext: new Set() };
  // pre-load images (async) into a map
  const imgs = new Map();
  for (const im of root.querySelectorAll('img')) {
    const src = im.getAttribute('src') || ''; if (!src || imgs.has(src)) continue;
    try {
      let bytes = await imgBytes(src); let info = sniffImage(bytes);
      if (!info) { bytes = await toPngBytes(src); info = sniffImage(bytes); }
      if (info) imgs.set(src, { bytes, ...info });
    } catch (e) { console.warn('image skipped', e); }
  }
  ctx.imgs = imgs;
  let body = blocks(root, ctx, {});
  if (!body || /<\/w:tbl>$/.test(body)) body += '<w:p/>';
  const sect = sectXml(pc, hf.hdr ? 'rIdHdr1' : '', hf.ftr ? 'rIdFtr1' : '');
  const doc = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document ${NS}><w:body>${body}${sect}</w:body></w:document>`;
  const z = new JSZip();
  const exts = ['<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>', '<Default Extension="xml" ContentType="application/xml"/>'];
  for (const e of ctx.ext) exts.push(`<Default Extension="${e}" ContentType="image/${e}"/>`);
  z.file('[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">${exts.join('')}${hf.hdr ? '<Override PartName="/word/header1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/>' : ''}${hf.ftr ? '<Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/>' : ''}<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/><Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>`);
  z.file('_rels/.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>`);
  const now = new Date().toISOString().replace(/\.\d+Z$/, 'Z');
  z.file('docProps/core.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${X(title)}</dc:title><dc:creator>${X(author)}</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">${now}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">${now}</dcterms:modified></cp:coreProperties>`);
  z.file('docProps/app.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>Velora</Application></Properties>`);
  z.file('word/settings.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:settings ${NS}><w:defaultTabStop w:val="720"/><w:compat><w:compatSetting w:name="compatibilityMode" w:uri="http://schemas.microsoft.com/office/word" w:val="15"/></w:compat></w:settings>`);
  z.file('word/styles.xml', STYLES);
  z.file('word/numbering.xml', numberingXml(ctx));
  const rels = ['<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>', '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/>', '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/>', ...ctx.rels, ...(hf.hdr ? ['<Relationship Id="rIdHdr1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" Target="header1.xml"/>'] : []), ...(hf.ftr ? ['<Relationship Id="rIdFtr1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/>'] : [])];
  z.file('word/_rels/document.xml.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${rels.join('')}</Relationships>`);
  z.file('word/document.xml', doc);
  if (hf.hdr) z.file('word/header1.xml', hf.hdr); if (hf.ftr) z.file('word/footer1.xml', hf.ftr);
  for (const m of ctx.media) z.file('word/media/' + m.name, m.bytes);
  return z.generateAsync({ type: 'arraybuffer', compression: 'DEFLATE', compressionOptions: { level: 6 }, mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
}

const STYLES = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:eastAsia="Calibri" w:cs="Nirmala UI"/><w:sz w:val="24"/><w:szCs w:val="24"/><w:lang w:val="en-US" w:eastAsia="en-US" w:bidi="bn-BD"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="276" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>
<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>
<w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before="240" w:after="120"/><w:outlineLvl w:val="0"/></w:pPr><w:rPr><w:b/><w:bCs/><w:sz w:val="48"/><w:szCs w:val="48"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before="200" w:after="100"/><w:outlineLvl w:val="1"/></w:pPr><w:rPr><w:b/><w:bCs/><w:sz w:val="38"/><w:szCs w:val="38"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Heading3"><w:name w:val="heading 3"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before="160" w:after="80"/><w:outlineLvl w:val="2"/></w:pPr><w:rPr><w:b/><w:bCs/><w:sz w:val="31"/><w:szCs w:val="31"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Heading4"><w:name w:val="heading 4"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:outlineLvl w:val="3"/></w:pPr><w:rPr><w:b/><w:bCs/><w:sz w:val="26"/><w:szCs w:val="26"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="ListParagraph"><w:name w:val="List Paragraph"/><w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:after="40"/><w:ind w:left="720"/></w:pPr></w:style>
<w:style w:type="character" w:default="1" w:styleId="DefaultParagraphFont"><w:name w:val="Default Paragraph Font"/><w:uiPriority w:val="1"/><w:semiHidden/></w:style>
<w:style w:type="character" w:styleId="Hyperlink"><w:name w:val="Hyperlink"/><w:rPr><w:color w:val="0563C1"/><w:u w:val="single"/></w:rPr></w:style>
<w:style w:type="table" w:default="1" w:styleId="TableNormal"><w:name w:val="Normal Table"/><w:semiHidden/><w:tblPr><w:tblInd w:w="0" w:type="dxa"/><w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="108" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/><w:right w:w="108" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style>
<w:style w:type="table" w:styleId="TableGrid"><w:name w:val="Table Grid"/><w:basedOn w:val="TableNormal"/><w:tblPr><w:tblBorders><w:top w:val="single" w:sz="4" w:space="0" w:color="808080"/><w:left w:val="single" w:sz="4" w:space="0" w:color="808080"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="808080"/><w:right w:val="single" w:sz="4" w:space="0" w:color="808080"/><w:insideH w:val="single" w:sz="4" w:space="0" w:color="808080"/><w:insideV w:val="single" w:sz="4" w:space="0" w:color="808080"/></w:tblBorders></w:tblPr></w:style></w:styles>`;

function numberingXml(ctx) {
  const bul = ['•', 'o', '▪'];
  const lvls = (fmt, i) => Array.from({ length: 9 }, (_, l) => fmt === 'bullet'
    ? `<w:lvl w:ilvl="${l}"><w:start w:val="1"/><w:numFmt w:val="bullet"/><w:lvlText w:val="${bul[l % 3]}"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="${720 * (l + 1)}" w:hanging="360"/></w:pPr><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:cs="Calibri" w:hint="default"/></w:rPr></w:lvl>`
    : `<w:lvl w:ilvl="${l}"><w:start w:val="1"/><w:numFmt w:val="${['decimal', 'lowerLetter', 'lowerRoman'][l % 3]}"/><w:lvlText w:val="%${l + 1}."/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="${720 * (l + 1)}" w:hanging="360"/></w:pPr></w:lvl>`).join('');
  let x = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:numbering xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:abstractNum w:abstractNumId="0"><w:multiLevelType w:val="hybridMultilevel"/>${lvls('bullet')}</w:abstractNum><w:abstractNum w:abstractNumId="1"><w:multiLevelType w:val="hybridMultilevel"/>${lvls('decimal')}</w:abstractNum><w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num>`;
  for (const n of ctx.nums) x += `<w:num w:numId="${n.id}"><w:abstractNumId w:val="1"/><w:lvlOverride w:ilvl="0"><w:startOverride w:val="${n.start}"/></w:lvlOverride></w:num>`;
  return x + '</w:numbering>';
}

function hasBlockChild(el) { for (const c of el.children) if (BLOCK.has(c.tagName) || (c.tagName === 'IMG' && false)) return true; return false; }
function alignOf(el) {
  const a = (el.style && el.style.textAlign) || el.getAttribute('align') || ''; return { center: 'center', right: 'right', justify: 'both', left: 'left', end: 'right', start: 'left' }[a] || '';
}
function blocks(parent, ctx, pp) {
  let out = '', run = [];
  const flush = () => { if (run.length) { if (run.some(n => n.nodeType === 1 || /\S/.test(n.data))) out += para(run, ctx, pp); run = []; } };
  for (const n of parent.childNodes) {
    if (n.nodeType === 3) { run.push(n); continue; }
    if (n.nodeType !== 1) continue;
    if (BLOCK.has(n.tagName)) { flush(); out += block(n, ctx, pp); } else run.push(n);
  }
  flush(); return out;
}
function block(n, ctx, pp) {
  const t = n.tagName, al = alignOf(n) || pp.align;
  const base = { ...pp, align: al, rs: styleRS(n, pp.rs || {}) };
  const ml = n.style && n.style.marginLeft ? Math.round((cssSizePx(n.style.marginLeft) || 0) * 15) : 0;
  if (ml) base.ind = (pp.ind || 0) + ml;
  { const lh = parseFloat(n.style && n.style.lineHeight); if (lh > 0 && lh < 6) base.lh = lh; }
  if (n.classList && n.classList.contains('pagebreak')) return '<w:p><w:r><w:br w:type="page"/></w:r></w:p>';
  if (/^H[1-6]$/.test(t)) return para(n.childNodes, ctx, { ...base, style: 'Heading' + Math.min(4, +t[1]) });
  if (t === 'HR') return '<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="999999"/></w:pBdr></w:pPr></w:p>';
  if (t === 'UL' || t === 'OL') return list(n, ctx, base, 0, t === 'OL' ? ctx.nextNum++ : 1, t === 'OL' ? n.getAttribute('start') : null);
  if (t === 'TABLE') return table(n, ctx, base);
  if (t === 'BLOCKQUOTE') { const indentOnly = !!n.getAttribute('style'); return blocks(n, ctx, { ...base, ind: (base.ind || 0) + (indentOnly ? 0 : 720), bq: !indentOnly }); }
  if (t === 'PRE') return para(n.childNodes, ctx, { ...base, pre: true }, { font: 'Consolas' });
  if (hasBlockChild(n)) return blocks(n, ctx, base);
  return para(n.childNodes, ctx, base);
}
function list(el, ctx, pp, lvl, numId, start) {
  if (numId > 1 && !ctx.nums.find(x => x.id === numId)) ctx.nums.push({ id: numId, start: Math.max(1, parseInt(start) || 1) });
  let out = '';
  for (const li of el.children) {
    if (li.tagName !== 'LI') continue;
    const inline = [], nested = [];
    for (const c of li.childNodes) { if (c.nodeType === 1 && (c.tagName === 'UL' || c.tagName === 'OL')) nested.push(c); else if (c.nodeType === 1 && (c.tagName === 'P' || c.tagName === 'DIV')) { if (inline.length) inline.push(document.createElement('br')); inline.push(...c.childNodes); } else inline.push(c); }
    out += para(inline, ctx, { ...pp, style: 'ListParagraph', num: { id: numId, lvl: Math.min(8, lvl) }, ind: 0 });
    for (const nl of nested) out += list(nl, ctx, pp, lvl + 1, nl.tagName === 'OL' ? ctx.nextNum++ : 1, nl.getAttribute('start'));
  }
  return out;
}
function para(nodes, ctx, pp, rs0) {
  let ppr = '';
  if (pp.style) ppr += `<w:pStyle w:val="${pp.style}"/>`;
  if (pp.num) ppr += `<w:numPr><w:ilvl w:val="${pp.num.lvl}"/><w:numId w:val="${pp.num.id}"/></w:numPr>`;
  if (pp.bq) ppr += '<w:pBdr><w:left w:val="single" w:sz="18" w:space="8" w:color="C3C9DE"/></w:pBdr>';
  if (pp.lh) ppr += `<w:spacing w:line="${Math.round(pp.lh * 240)}" w:lineRule="auto"/>`;
  if (pp.ind && !pp.num) ppr += `<w:ind w:left="${pp.ind}"/>`;
  if (pp.align) ppr += `<w:jc w:val="${pp.align}"/>`;
  const runs = inline([...nodes], ctx, { ...(pp.rs || {}), ...(rs0 || {}) });
  return `<w:p>${ppr ? `<w:pPr>${ppr}</w:pPr>` : ''}${runs}</w:p>`;
}
function rPr(rs) {
  let x = '';
  if (rs.font) x += `<w:rFonts w:ascii="${X(rs.font)}" w:hAnsi="${X(rs.font)}" w:cs="${X(rs.font)}"/>`;
  if (rs.b) x += '<w:b/><w:bCs/>'; if (rs.i) x += '<w:i/><w:iCs/>'; if (rs.s) x += '<w:strike/>';
  if (rs.color) x += `<w:color w:val="${rs.color}"/>`;
  if (rs.sz) x += `<w:sz w:val="${rs.sz}"/><w:szCs w:val="${rs.sz}"/>`;
  if (rs.u) x += '<w:u w:val="single"/>';
  if (rs.bg) x += `<w:shd w:val="clear" w:color="auto" w:fill="${rs.bg}"/>`;
  if (rs.sup) x += '<w:vertAlign w:val="superscript"/>'; if (rs.sub) x += '<w:vertAlign w:val="subscript"/>';
  return x ? `<w:rPr>${x}</w:rPr>` : '';
}
function tRun(text, rs) {
  if (!text) return '';
  const parts = text.split(/(\t|\n)/); let x = '';
  for (const p of parts) { if (p === '\t') x += `<w:r>${rPr(rs)}<w:tab/></w:r>`; else if (p === '\n') x += `<w:r>${rPr(rs)}<w:br/></w:r>`; else if (p) x += `<w:r>${rPr(rs)}<w:t xml:space="preserve">${X(p)}</w:t></w:r>`; }
  return x;
}
function styleRS(el, rs) {
  const n = { ...rs }, t = el.tagName, st = el.style || {};
  if (t === 'B' || t === 'STRONG') n.b = 1; if (t === 'I' || t === 'EM' || t === 'CITE') n.i = 1; if (t === 'U' || t === 'INS') n.u = 1;
  if (t === 'S' || t === 'STRIKE' || t === 'DEL') n.s = 1; if (t === 'SUP') n.sup = 1; if (t === 'SUB') n.sub = 1;
  if (t === 'CODE' || t === 'KBD' || t === 'SAMP') n.font = 'Consolas';
  if (t === 'FONT') { const c = toHex(el.getAttribute('color')); if (c) n.color = c; const f = el.getAttribute('face'); if (f) n.font = f.split(',')[0].replace(/["']/g, '').trim(); const sz = parseInt(el.getAttribute('size')); if (sz >= 1 && sz <= 7) n.sz = pxToHalfPt(FONT_SIZES[sz]); }
  if (t === 'MARK') n.bg = 'FFFF00';
  if (st.fontWeight && (st.fontWeight === 'bold' || st.fontWeight === 'bolder' || +st.fontWeight >= 600)) n.b = 1; else if (st.fontWeight && (st.fontWeight === 'normal' || +st.fontWeight < 600) && t !== 'B' && t !== 'STRONG') n.b = 0;
  if (st.fontStyle === 'italic') n.i = 1;
  const td = (st.textDecorationLine || st.textDecoration || ''); if (/underline/.test(td)) n.u = 1; if (/line-through/.test(td)) n.s = 1;
  if (st.color) { const c = toHex(st.color); if (c) n.color = c; }
  if (st.backgroundColor) { const c = toHex(st.backgroundColor); if (c) n.bg = c; }
  if (st.fontSize) { const px = cssSizePx(st.fontSize); if (px) n.sz = pxToHalfPt(px); }
  if (st.fontFamily) { const f = st.fontFamily.split(',')[0].replace(/["']/g, '').trim(); if (f && !/^(inherit|initial|sans-serif|serif|system-ui)$/i.test(f)) n.font = f; }
  if (st.verticalAlign === 'super') n.sup = 1; if (st.verticalAlign === 'sub') n.sub = 1;
  return n;
}
function inline(nodes, ctx, rs) {
  let out = '';
  for (const n of nodes) {
    if (n.nodeType === 3) { out += tRun(n.data.replace(/[\r\n\t]+/g, ' ').replace(/ {2,}/g, ' '), rs); continue; }
    if (n.nodeType !== 1) continue;
    const t = n.tagName;
    if (t === 'BR') { out += `<w:r>${rPr(rs)}<w:br/></w:r>`; continue; }
    if (t === 'IMG') { out += drawing(n, ctx); continue; }
    if (BLOCK.has(t)) { out += inline(n.childNodes, ctx, rs) + (t === 'DIV' || t === 'P' ? `<w:r><w:br/></w:r>` : ''); continue; }
    if (t === 'A' && n.getAttribute('href')) {
      const id = 'rId' + ctx.nextRel++; ctx.rels.push(`<Relationship Id="${id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" Target="${X(n.getAttribute('href'))}" TargetMode="External"/>`);
      out += `<w:hyperlink r:id="${id}" w:history="1">${inline(n.childNodes, ctx, { ...styleRS(n, rs), color: '0563C1', u: 1 })}</w:hyperlink>`; continue;
    }
    if (t === 'INPUT' || t === 'SCRIPT' || t === 'STYLE') continue;
    out += inline(n.childNodes, ctx, styleRS(n, rs));
  }
  return out;
}
function drawing(img, ctx) {
  const src = img.getAttribute('src') || ''; const d = ctx.imgs.get(src); if (!d) return '';
  let w = parseFloat(img.getAttribute('width')) || cssSizePx(img.style.width) || img.naturalWidth || d.w || 300;
  let h = parseFloat(img.getAttribute('height')) || cssSizePx(img.style.height) || 0;
  if (!h) h = w * (d.h / d.w); else if (!img.getAttribute('width') && !img.style.width) w = h * (d.w / d.h);
  const maxW = TEXT_W / 15; if (w > maxW) { h = h * maxW / w; w = maxW; }
  const cx = Math.round(w * 9525), cy = Math.round(h * 9525);
  let mname = ctx.media.find(m => m.src === src);
  if (!mname) { mname = { src, name: `image${++ctx.imgN}.${d.ext === 'jpeg' ? 'jpg' : d.ext}`, bytes: d.bytes, rid: 'rId' + ctx.nextRel++ }; ctx.media.push(mname); ctx.ext.add(d.ext === 'jpeg' ? 'jpg' : d.ext); ctx.rels.push(`<Relationship Id="${mname.rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/${mname.name}"/>`); }
  if (d.ext === 'jpeg') ctx.ext.add('jpeg');
  const id = ctx.docPr++;
  return `<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="${cx}" cy="${cy}"/><wp:docPr id="${id}" name="Picture ${id}" descr="${X(img.getAttribute('alt') || '')}"/><wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect="1"/></wp:cNvGraphicFramePr><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="${id}" name="${mname.name}"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="${mname.rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>`;
}
function table(tb, ctx, pp) {
  const rows = [...tb.rows]; if (!rows.length) return '';
  let ncols = 0; for (const r of rows) { let c = 0; for (const cell of r.cells) c += cell.colSpan || 1; ncols = Math.max(ncols, c); }
  const cw = Math.floor(TEXT_W / Math.max(1, ncols));
  const noBorder = tb.classList.contains('nob');
  const bdr = noBorder ? '' : ['top', 'left', 'bottom', 'right', 'insideH', 'insideV'].map(s => `<w:${s} w:val="single" w:sz="4" w:space="0" w:color="808080"/>`).join('');
  let x = `<w:tbl><w:tblPr><w:tblW w:w="${TEXT_W}" w:type="dxa"/>${bdr ? `<w:tblBorders>${bdr}</w:tblBorders>` : ''}<w:tblLayout w:type="fixed"/><w:tblCellMar><w:top w:w="40" w:type="dxa"/><w:left w:w="100" w:type="dxa"/><w:bottom w:w="40" w:type="dxa"/><w:right w:w="100" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid>${Array.from({ length: ncols }, () => `<w:gridCol w:w="${cw}"/>`).join('')}</w:tblGrid>`;
  const occ = {}; // "r,c" -> true when covered by a rowspan from above
  rows.forEach((tr, ri) => {
    x += '<w:tr>'; let c = 0;
    const emitCont = () => { while (occ[ri + ',' + c]) { x += `<w:tc><w:tcPr><w:tcW w:w="${cw}" w:type="dxa"/><w:vMerge/></w:tcPr><w:p/></w:tc>`; c++; } };
    for (const cell of tr.cells) {
      emitCont();
      const cs = cell.colSpan || 1, rsn = cell.rowSpan || 1;
      let tcpr = `<w:tcW w:w="${cw * cs}" w:type="dxa"/>`;
      if (cs > 1) tcpr += `<w:gridSpan w:val="${cs}"/>`;
      if (rsn > 1) { tcpr += '<w:vMerge w:val="restart"/>'; for (let k = 1; k < rsn; k++) for (let j = 0; j < cs; j++) occ[(ri + k) + ',' + (c + j)] = true; }
      const bg = toHex(cell.style.backgroundColor || cell.getAttribute('bgcolor')); if (bg) tcpr += `<w:shd w:val="clear" w:color="auto" w:fill="${bg}"/>`;
      let inner = blocks(cell, ctx, { ...pp, ind: 0, align: alignOf(cell) || (cell.tagName === 'TH' ? 'center' : '') });
      if (cell.tagName === 'TH') inner = inner.replace(/<w:rPr>/g, '<w:rPr><w:b/><w:bCs/>').replace(/<w:r>(?!<w:rPr>)/g, '<w:r><w:rPr><w:b/><w:bCs/></w:rPr>');
      if (!inner) inner = '<w:p/>';
      x += `<w:tc><w:tcPr>${tcpr}</w:tcPr>${inner}</w:tc>`; c += cs;
    }
    emitCont(); x += '</w:tr>';
  });
  return x + '</w:tbl><w:p><w:pPr><w:spacing w:after="0" w:line="120" w:lineRule="exact"/></w:pPr></w:p>';
}

/* ================= IMPORT ================= */
const W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
const el = (p, n) => { for (const c of p.children) if (c.localName === n) return c; return null; };
const els = (p, n) => [...p.children].filter(c => c.localName === n);
const wv = (p, n, a = 'val') => { const e = p && el(p, n); return e ? (e.getAttributeNS(W, a) ?? e.getAttribute('w:' + a)) : null; };
const onoff = (p, n) => { const e = p && el(p, n); if (!e) return null; const v = e.getAttributeNS(W, 'val') ?? e.getAttribute('w:val'); return !(v === '0' || v === 'false' || v === 'off'); };
const parseXml = s => new DOMParser().parseFromString(s, 'application/xml');
const mimeOf = n => ({ png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', bmp: 'image/bmp', webp: 'image/webp', svg: 'image/svg+xml' })[(n.split('.').pop() || '').toLowerCase()];

export async function docxToHtml(buf) {
  const JSZip = await needJSZip(); const z = await JSZip.loadAsync(buf);
  const docF = z.file('word/document.xml'); if (!docF) throw new Error('এটি বৈধ .docx ফাইল নয়');
  const doc = parseXml(await docF.async('string'));
  if (doc.querySelector('parsererror')) throw new Error('ডকুমেন্ট পড়া যায়নি');
  const rels = {}; const rf = z.file('word/_rels/document.xml.rels');
  if (rf) for (const r of parseXml(await rf.async('string')).getElementsByTagName('Relationship')) rels[r.getAttribute('Id')] = { t: r.getAttribute('Target'), mode: r.getAttribute('TargetMode'), type: r.getAttribute('Type') };
  // styles
  const styles = {}; let defRun = null;
  const sf = z.file('word/styles.xml');
  if (sf) {
    const sd = parseXml(await sf.async('string'));
    const dd = sd.getElementsByTagNameNS(W, 'rPrDefault')[0]; if (dd) defRun = el(dd, 'rPr');
    for (const s of sd.getElementsByTagNameNS(W, 'style')) styles[s.getAttributeNS(W, 'styleId')] = { name: wv(s, 'name') || '', based: wv(s, 'basedOn'), ppr: el(s, 'pPr'), rpr: el(s, 'rPr'), type: s.getAttributeNS(W, 'type') };
  }
  const defSz = parseInt(wv(defRun, 'sz')) || 22;
  // numbering
  const nums = {}, abs = {};
  const nf = z.file('word/numbering.xml');
  if (nf) {
    const nd = parseXml(await nf.async('string'));
    for (const a of nd.getElementsByTagNameNS(W, 'abstractNum')) { const lv = {}; for (const l of els(a, 'lvl')) lv[wv(l, 'ilvl') ?? l.getAttributeNS(W, 'ilvl')] = wv(l, 'numFmt'); abs[a.getAttributeNS(W, 'abstractNumId')] = lv; }
    for (const n of nd.getElementsByTagNameNS(W, 'num')) { nums[n.getAttributeNS(W, 'numId')] = { abs: wv(n, 'abstractNumId'), ov: {} }; for (const o of els(n, 'lvlOverride')) { const s = el(o, 'startOverride'); if (s) nums[n.getAttributeNS(W, 'numId')].ov[o.getAttributeNS(W, 'ilvl')] = +wv(o, 'startOverride'); } }
  }
  const mediaCache = {};
  async function mediaUrl(rid) {
    const r = rels[rid]; if (!r) return null; if (mediaCache[rid] !== undefined) return mediaCache[rid];
    let p = r.t.startsWith('/') ? r.t.slice(1) : 'word/' + r.t; p = p.replace(/\/\.\//g, '/'); while (/[^/]+\/\.\.\//.test(p)) p = p.replace(/[^/]+\/\.\.\//, '');
    const f = z.file(p); const mt = mimeOf(p);
    if (!f || !mt) return (mediaCache[rid] = null);
    const b64 = await f.async('base64'); return (mediaCache[rid] = `data:${mt};base64,${b64}`);
  }
  function styleChain(id) { const ch = []; let g = 0; while (id && styles[id] && g++ < 10) { ch.unshift(styles[id]); id = styles[id].based; } return ch; }
  function runProps(rpr) {
    const o = {}; if (!rpr) return o;
    let v;
    if ((v = onoff(rpr, 'b')) !== null) o.b = v; if ((v = onoff(rpr, 'i')) !== null) o.i = v; if ((v = onoff(rpr, 'strike')) !== null) o.s = v;
    const u = wv(rpr, 'u'); if (u !== null) o.u = u !== 'none'; const c = wv(rpr, 'color'); if (c && c !== 'auto') o.color = c;
    const sz = wv(rpr, 'sz'); if (sz) o.sz = +sz; const sh = el(rpr, 'shd'); if (sh) { const f = sh.getAttributeNS(W, 'fill'); if (f && f !== 'auto') o.bg = f; }
    const hl = wv(rpr, 'highlight'); if (hl && hl !== 'none') o.bg = ({ yellow: 'FFFF00', green: '00FF00', cyan: '00FFFF', magenta: 'FF00FF', blue: '0000FF', red: 'FF0000', darkBlue: '000080', darkCyan: '008080', darkGreen: '008000', darkMagenta: '800080', darkRed: '800000', darkYellow: '808000', darkGray: '808080', lightGray: 'C0C0C0', black: '000000', white: 'FFFFFF' })[hl] || 'FFFF00';
    const rf = el(rpr, 'rFonts'); if (rf) { const f = rf.getAttributeNS(W, 'ascii') || rf.getAttributeNS(W, 'cs') || rf.getAttributeNS(W, 'hAnsi'); if (f) o.font = f; }
    const va = wv(rpr, 'vertAlign'); if (va === 'superscript') o.sup = 1; if (va === 'subscript') o.sub = 1;
    return o;
  }
  const hdrSet = new Set(); // style ids that mean heading
  function headingLevel(sid) {
    const st = styles[sid]; const nm = ((st && st.name) || sid || '').toLowerCase();
    let m = /^heading\s*(\d)/.exec(nm); if (m) return Math.min(+m[1], 4); if (nm === 'title') return 1; if (nm === 'subtitle') return 2; return 0;
  }
  const cssRun = (o, base) => {
    let s = '';
    if (o.b && !base.b) s += 'font-weight:bold;'; if (o.i && !base.i) s += 'font-style:italic;';
    const td = []; if (o.u) td.push('underline'); if (o.s) td.push('line-through'); if (td.length) s += 'text-decoration:' + td.join(' ') + ';';
    if (o.color) s += `color:#${o.color};`; if (o.bg) s += `background-color:#${o.bg};`;
    if (o.sz && o.sz !== defSz) s += `font-size:${(o.sz / 1.5).toFixed(1).replace(/\.0$/, '')}px;`;
    if (o.font && !/^(calibri|nirmala ui|times new roman|arial|cambria|aptos|calibri light)$/i.test(o.font)) s += `font-family:'${o.font.replace(/'/g, '')}',inherit;`;
    return s;
  };
  async function runs(p, ctx2) {
    let out = ''; let pending = null;
    async function handleRun(r, linkWrap) {
      const rprDirect = el(r, 'rPr'); let o = { ...ctx2.pstyleRun };
      const rs = wv(rprDirect, 'rStyle'); if (rs) for (const st of styleChain(rs)) Object.assign(o, runProps(st.rpr));
      Object.assign(o, runProps(rprDirect));
      let inner = '';
      for (const c of r.children) {
        const n = c.localName;
        if (n === 't') inner += escHtml(c.textContent);
        else if (n === 'tab') inner += '&emsp;';
        else if (n === 'br' || n === 'cr') { const ty = c.getAttributeNS(W, 'type'); if (ty === 'page') { ctx2.pageBreakAfter = true; inner += '\u0001PB\u0001'; } else inner += '<br>'; }
        else if (n === 'noBreakHyphen') inner += '‑';
        else if (n === 'sym') { const ch = c.getAttributeNS(W, 'char'); if (ch) inner += String.fromCharCode(parseInt(ch, 16) & 0xFFFF > 0xF000 ? parseInt(ch, 16) - 0xF000 : parseInt(ch, 16)); }
        else if (n === 'drawing' || n === 'pict') {
          const blip = c.getElementsByTagNameNS('*', 'blip')[0]; let rid = blip && (blip.getAttribute('r:embed') || blip.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships', 'embed'));
          if (!rid) { const im = c.getElementsByTagNameNS('*', 'imagedata')[0]; rid = im && (im.getAttribute('r:id') || im.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships', 'id')); }
          const url = rid && await mediaUrl(rid);
          if (url) {
            const ext = c.getElementsByTagNameNS('*', 'extent')[0]; let wh = '';
            if (ext) { const cx = +ext.getAttribute('cx'), cy = +ext.getAttribute('cy'); if (cx) wh = ` width="${Math.round(cx / 9525)}" height="${Math.round(cy / 9525)}"`; }
            inner += `<img src="${url}"${wh} alt="">`;
          }
        }
      }
      if (!inner) return '';
      const css = cssRun(o, ctx2.pstyleBase);
      let t = css ? `<span style="${css}">${inner}</span>` : inner;
      return t;
    }
    for (const c of p.children) {
      const n = c.localName;
      if (n === 'r') out += await handleRun(c);
      else if (n === 'hyperlink') {
        let inner = ''; for (const r of els(c, 'r')) inner += await handleRun(r);
        const rid = c.getAttribute('r:id') || c.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships', 'id');
        const href = rid && rels[rid] ? rels[rid].t : null;
        out += href && /^(https?:|mailto:|tel:)/i.test(href) ? `<a href="${escHtml(href)}">${inner}</a>` : inner;
      }
      else if (n === 'sdt') { const sc = el(c, 'sdtContent'); if (sc) out += await runs(sc, ctx2); }
      else if (n === 'ins' || n === 'smartTag' || n === 'fldSimple') { out += await runs(c, ctx2); }
      else if (n === 'AlternateContent') { const ch = el(c, 'Choice') || el(c, 'Fallback'); if (ch) { const tmp = { children: ch.children }; for (const r of els(ch, 'r')) out += await handleRun(r); } }
    }
    return out;
  }
  let html = ''; let stack = [];
  const closeLists = () => { while (stack.length) html += `</li></${stack.pop().tag}>`; };
  function listItem(tag, lvl, inner, start) {
    while (stack.length && stack[stack.length - 1].lvl > lvl) html += `</li></${stack.pop().tag}>`;
    const top = stack[stack.length - 1];
    if (top && top.lvl === lvl) { if (top.tag !== tag) { html += `</li></${stack.pop().tag}><${tag}${start > 1 ? ` start="${start}"` : ''}><li>`; stack.push({ tag, lvl }); } else html += '</li><li>'; }
    else { html += `<${tag}${tag === 'ol' && start > 1 ? ` start="${start}"` : ''}><li>`; stack.push({ tag, lvl }); }
    html += inner;
  }
  async function paragraph(p, out) {
    const ppr = el(p, 'pPr'); const sid = wv(ppr, 'pStyle');
    let o = {}; let jc = null, ind = 0; const chain = styleChain(sid);
    for (const st of chain) { Object.assign(o, runProps(st.rpr)); const j = st.ppr && wv(st.ppr, 'jc'); if (j) jc = j; const ie = st.ppr && el(st.ppr, 'ind'); if (ie) ind = parseInt(ie.getAttributeNS(W, 'left') || ie.getAttributeNS(W, 'start') || 0) || ind; }
    const lvl = headingLevel(sid);
    const pBase = lvl ? { b: true, sz: null } : {};
    const run0 = lvl ? { ...o, b: undefined, sz: undefined } : o; // heading tags carry size/weight
    const pj = wv(ppr, 'jc'); if (pj) jc = pj;
    const ie = ppr && el(ppr, 'ind'); if (ie) { const l = ie.getAttributeNS(W, 'left') ?? ie.getAttributeNS(W, 'start'); if (l !== null && l !== '') ind = parseInt(l) || 0; }
    const ctx2 = { pstyleRun: run0, pstyleBase: lvl ? { b: true } : {}, pageBreakAfter: false };
    let inner = await runs(p, ctx2);
    const pbBefore = ppr && el(ppr, 'pageBreakBefore'); const hasPB = inner.includes('\u0001PB\u0001');
    const num = ppr && el(ppr, 'numPr');
    const align = { center: 'center', right: 'right', end: 'right', both: 'justify', distribute: 'justify' }[jc] || '';
    const spE = ppr && el(ppr, 'spacing'), spLine = spE ? parseInt(spE.getAttributeNS(W, 'line') || '0') : 0, spRule = spE ? (spE.getAttributeNS(W, 'lineRule') || 'auto') : 'auto', lhv = spLine && spRule === 'auto' && Math.abs(spLine - 240) > 12 && !lvl ? (spLine / 240).toFixed(2).replace(/0+$/, '').replace(/\.$/, '') : '';
    const style = (align ? `text-align:${align};` : '') + (lhv ? `line-height:${lhv};` : '') + (ind && !num && ind > 100 ? `margin-left:${Math.round(ind / 15)}px;` : '');
    const hrBorder = ppr && el(ppr, 'pBdr') && el(el(ppr, 'pBdr'), 'bottom');
    if (pbBefore) { closeLists(); html += '<div class="pagebreak" contenteditable="false"></div>'; }
    const emit = txt => {
      if (num && wv(num, 'numId') !== '0' && wv(num, 'numId') !== null) {
        const nid = wv(num, 'numId'), il = wv(num, 'ilvl') || '0';
        const info = nums[nid]; const fmt = info && abs[info.abs] && abs[info.abs][il]; const tag = fmt && fmt !== 'bullet' && fmt !== 'none' ? 'ol' : 'ul';
        listItem(tag, +il, txt || '<br>', info && info.ov[il] || 1);
      } else {
        closeLists();
        if (hrBorder && !/\S/.test(txt.replace(/<[^>]*>/g, ''))) { html += '<hr>'; return; }
        const tg = lvl ? 'h' + lvl : 'p'; html += `<${tg}${style ? ` style="${style}"` : ''}>${txt || '<br>'}</${tg}>`;
      }
    };
    if (hasPB) { const parts = inner.split('\u0001PB\u0001'); parts.forEach((pt, i) => { if (pt || i === 0) emit(pt); if (i < parts.length - 1) { closeLists(); html += '<div class="pagebreak" contenteditable="false"></div>'; } }); }
    else emit(inner);
  }
  async function tableEl(tbl, after) {
    closeLists();
    const tpr = el(tbl, 'tblPr'); const borders = tpr && el(tpr, 'tblBorders'); const sidT = wv(tpr, 'tblStyle');
    const hasB = (borders && [...borders.children].some(b => { const v = b.getAttributeNS(W, 'val'); return v && v !== 'nil' && v !== 'none'; })) || (sidT && /grid|table|accent|light|medium|dark|list/i.test(sidT) && !/normal/i.test(sidT));
    const rows = els(tbl, 'tr'); const grid = []; let th = '';
    const saved = html, savedStack = stack;
    let out = `<table${hasB ? '' : ' class="nob"'}><tbody>`;
    const origin = {};
    for (let ri = 0; ri < rows.length; ri++) {
      out += '<tr>'; let col = 0;
      for (const tc of els(rows[ri], 'tc')) {
        const tcp = el(tc, 'tcPr'); const span = parseInt(wv(tcp, 'gridSpan')) || 1; const vm = tcp && el(tcp, 'vMerge');
        if (vm && wv(tcp, 'vMerge') !== 'restart') { const o = origin[col]; if (o) { o.rs++; o.node.rowspan = o.rs; } col += span; continue; }
        const shd = tcp && el(tcp, 'shd'); const fill = shd && shd.getAttributeNS(W, 'fill');
        // render cell content via nested conversion
        html = ''; stack = [];
        for (const ch of tc.children) { if (ch.localName === 'p') await paragraph(ch); else if (ch.localName === 'tbl') await tableEl(ch); }
        closeLists(); let cellHtml = html || '<p><br></p>'; const one = /^<p>((?:(?!<\/?p[ >]).)*)<\/p>$/s.exec(cellHtml); if (one) cellHtml = one[1] || '<br>';
        const node = { rowspan: 1 }; origin[col] = { rs: 1, node, idx: out.length };
        out += `\u0002${col}_${ri}\u0003`; // placeholder for opening tag
        origin[col].html = cellHtml; origin[col].span = span; origin[col].fill = fill; origin[col].ph = `\u0002${col}_${ri}\u0003`;
        origin[col].key = out.length;
        out += cellHtml + '</td>';
        origin[col].ph2 = origin[col].ph; origin[col].tagInfo = { span, fill };
        origin['p' + col + '_' + ri] = origin[col];
        col += span;
      }
      out += '</tr>';
    }
    out += '</tbody></table>';
    out = out.replace(/\u0002(\d+)_(\d+)\u0003/g, (m, c, r) => { const o = origin['p' + c + '_' + r]; return `<td${o.span > 1 ? ` colspan="${o.span}"` : ''}${o.node.rowspan > 1 ? ` rowspan="${o.node.rowspan}"` : ''}${o.fill && o.fill !== 'auto' ? ` style="background-color:#${o.fill}"` : ''}>`; });
    html = saved; stack = savedStack; html += out + (after === 'p' ? '' : '<p><br></p>');
  }
  const body = doc.getElementsByTagNameNS(W, 'body')[0];
  async function walk(parent) {
    for (const ch of parent.children) {
      const n = ch.localName;
      if (n === 'p') await paragraph(ch);
      else if (n === 'tbl') await tableEl(ch, ch.nextElementSibling && ch.nextElementSibling.localName);
      else if (n === 'sdt') { const sc = el(ch, 'sdtContent'); if (sc) await walk(sc); }
    }
  }
  await walk(body); closeLists();
  // title from core props
  let title = ''; const cf = z.file('docProps/core.xml');
  if (cf) { const m = /<dc:title>([^<]*)<\/dc:title>/.exec(await cf.async('string')); if (m) title = m[1]; }
  let cfg = null; try { cfg = await readPageCfg(z, rels, doc, parseXml); } catch (e) { console.warn('page setup not read', e); }
  return { html: html || '<p><br></p>', title, cfg };
}
