// Spreadsheet editor: canvas grid, formulas, formatting, sort/filter, clipboard, undo, XLSX/CSV/PDF.
import { ruleAt, check as dvCheck, listItems as dvItems, sqOf, intersects as dvIntersects, TYPE_LABEL as DV_TYPES, OP_LABEL as DV_OPS, describe as dvDescribe } from './validation.js';
import { h, icon, btn, sheet as actionSheet, modal, promptDlg, confirmDlg, pickColor, pickFiles, toast, busy, withBusy, toBn, esc, readText, readBuf, baseName, extOf, debounce, errMsg, saveToDevice, clamp } from './util.js';
import { getSettings } from './db.js';
import { Engine, FUNCTIONS, colName, addr, parseAddr, parseRange, rangeStr, shiftFormula, transformRefs, isErr, MAXR } from './formula.js';
import { formatValue, PRESETS } from './numfmt.js';
import { newSheet, newWorkbook, cloneSheet, serializeWb, loadWb, wbToXlsx, xlsxToWb, csvToWb, parseCSV, parseInput, sheetToCSV } from './xlsx.js';
import { SHEET_TPLS } from './templates.js';

/* ---------- create / import ---------- */
function tplToWb(t) {
  const wb = newWorkbook(); wb.sheets = t.sheets.map(sd => {
    const sh = newSheet(sd.name);
    (sd.rows || []).forEach((row, r) => row.forEach((it, c) => { if (it === '' || it === null || it === undefined) return; let cell = {}; const val = (it && typeof it === 'object') ? it.v : it; if (typeof val === 'string' && val[0] === '=') cell.f = val.slice(1); else cell.v = val; if (it && typeof it === 'object' && it.s) cell.s = { ...it.s }; sh.cells[r + ',' + c] = cell; }));
    (sd.colW || []).forEach((w, i) => sh.colW[i] = w); if (sd.freeze) sh.freeze = sd.freeze; return sh;
  });
  return wb;
}
async function packWb(wb, name) { const eng = new Engine(wb); const s = await getSettings(); return { buf: await wbToXlsx(wb, (si, r, c) => eng.value(si, r, c), { title: baseName(name), author: s.author || '' }), snap: serializeWb(wb) }; }
export async function blank({ tpl } = {}) {
  const t = SHEET_TPLS.find(x => x.id === tpl) || SHEET_TPLS[0]; const wb = tplToWb(t); const p = await packWb(wb, t.file);
  return { name: t.file + '.xlsx', ...p };
}
export async function importFile(file) {
  const ext = extOf(file.name); let wb;
  if (ext === 'xlsx' && file.size > 1.2 * 1048576) return { name: baseName(file.name) + '.xlsx', buf: await readBuf(file) };   // big: keep the original bytes, parse lazily when opened
  if (ext === 'csv' || ext === 'tsv') wb = csvToWb(await readText(file), 'Sheet1'); else wb = await xlsxToWb(await readBuf(file));
  const name = baseName(file.name) + '.xlsx'; return { name, ...(await packWb(wb, name)) };
}

/* ---------- editor ---------- */
const BASE_RH = 28, BASE_CW = 96, HDR_W = 46, HDR_H = 28;
const COLORS = { red: '#d92d20', blue: '#2e5bff', green: '#14884f', yellow: '#b7950b', magenta: '#a855f7', cyan: '#0e7090', black: '#000', white: '#fff' };
const FONT_FAM = 'system-ui,-apple-system,"Segoe UI","Noto Sans Bengali","Kalpurush","Nirmala UI",Roboto,sans-serif';
const toBnS = s => String(s).replace(/\d/g, d => '০১২৩৪৫৬৭৮৯'[d]);

export async function mount(ctx) {
  let wb;
  const HEAVY_BYTES = 1.2 * 1048576;
  if (typeof ctx.snap === 'string') wb = loadWb(ctx.snap);
  else {
    const bigFile = ctx.buf && ctx.buf.byteLength > HEAVY_BYTES, bz = bigFile ? busy('বড় ফাইল লোড হচ্ছে…') : null;
    try { wb = await xlsxToWb(ctx.buf, { onProgress: v => bz && bz.set(`বড় ফাইল লোড হচ্ছে… ${toBn(Math.round(v * 100))}%`) }); } finally { bz && bz.done(); }
  }
  let heavy = !!(ctx.buf && ctx.buf.byteLength > HEAVY_BYTES) || wb.sheets.some(s => { let n = 0; for (const _ in s.cells) if (++n > 60000) return true; return false; });
  if (heavy) ctx.saveDelay = 5000;
  const eng = new Engine(wb);
  let sh = wb.sheets[wb.active];
  const dark = () => document.documentElement.dataset.theme === 'dark';
  let Z = 1, showGrid = true;
  let sel = { r: 0, c: 0 }, rng = { r1: 0, c1: 0, r2: 0, c2: 0 };
  let nrows = 300, ncols = 30, rowPos = [], colPos = [];
  let hdr, as;
  let clip = null; // internal clipboard
  let editing = null; // {text, src}

  /* ---------- DOM ---------- */
  const grid = h('div', { class: 'xl-grid' });
  const spacer = h('div', { class: 'xl-canvas' });
  const cv = h('canvas', { style: { position: 'sticky', top: 0, left: 0, display: 'block', touchAction: 'auto' } });
  const ov = h('div', { style: { position: 'sticky', top: 0, left: 0, height: 0, width: 0, zIndex: 4 } });
  grid.append(spacer, cv, ov);
  // sticky canvas needs to overlay spacer: use negative margin trick
  const g2 = cv.getContext('2d');
  const nameBox = h('button', { class: 'xl-name', type: 'button', onclick: gotoDlg }, 'A1');
  const fInput = h('input', { class: 'xl-input', type: 'text', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', 'aria-label': 'সূত্র বার', enterkeyhint: 'done' });
  const fxBtn = h('button', { class: 'xl-fx tb', type: 'button', onmousedown: e => e.preventDefault(), onclick: fnPicker, 'aria-label': 'ফাংশন' }, 'fx');
  const fbar = h('div', { class: 'xl-formula' }, nameBox, fxBtn, fInput);
  const tabsBar = h('div', { class: 'xl-sheets' });
  const status = h('div', { class: 'xl-status' });
  const edTa = h('textarea', { class: 'xl-cell-edit', rows: 1, spellcheck: 'false', autocapitalize: 'off', style: { display: 'none', pointerEvents: 'auto' } });
  const hSE = h('div', { style: handleCss() }), hNW = h('div', { style: handleCss() });
  ov.append(hNW, hSE, edTa);
  function handleCss() { return { position: 'absolute', width: '22px', height: '22px', margin: '-11px 0 0 -11px', borderRadius: '50%', background: 'var(--brand)', border: '3px solid var(--surface)', touchAction: 'none', pointerEvents: 'auto', display: 'none', zIndex: 3, boxShadow: '0 1px 4px rgba(0,0,0,.35)' }; }

  /* ---------- layout ---------- */
  function used() { return eng.used(wb.active); }
  function relayout() {
    const u = used(); nrows = Math.max(nrows, u.r + 60, 120); ncols = Math.max(ncols, u.c + 8, 26);
    rowPos = [0]; for (let r = 0; r < nrows; r++) rowPos.push(rowPos[r] + (sh.hiddenRows && sh.hiddenRows[r] ? 0 : (sh.rowH[r] || BASE_RH) * Z));
    colPos = [0]; for (let c = 0; c < ncols; c++) colPos.push(colPos[c] + (sh.colW[c] || BASE_CW) * Z);
    const fr = sh.freeze.r, fc = sh.freeze.c;
    spacer.style.width = (HDR_W * Z + colPos[ncols]) + 'px'; spacer.style.height = (HDR_H * Z + rowPos[nrows]) + 'px';
    spacer.style.marginBottom = '0px';
  }
  const hw = () => HDR_W * Z, hh = () => HDR_H * Z;
  const fW = () => colPos[sh.freeze.c], fH = () => rowPos[sh.freeze.r];
  // screen x/y of column/row start (content coordinates -> viewport)
  function sx(c) { return hw() + (c < sh.freeze.c ? colPos[c] : fW() + colPos[c] - colPos[sh.freeze.c] - grid.scrollLeft); }
  function sy(r) { return hh() + (r < sh.freeze.r ? rowPos[r] : fH() + rowPos[r] - rowPos[sh.freeze.r] - grid.scrollTop); }
  const cw = c => colPos[c + 1] - colPos[c], rh = r => rowPos[r + 1] - rowPos[r];
  function findIdx(pos, v) { let lo = 0, hi = pos.length - 2; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (pos[m] <= v) lo = m; else hi = m - 1; } return lo; }
  function colAt(x) { x -= hw(); if (x < 0) return -1; if (x < fW()) return findIdx(colPos, x); return findIdx(colPos, x - fW() + colPos[sh.freeze.c] + grid.scrollLeft); }
  function rowAt(y) { y -= hh(); if (y < 0) return -1; if (y < fH()) return findIdx(rowPos, y); return findIdx(rowPos, y - fH() + rowPos[sh.freeze.r] + grid.scrollTop); }

  /* merges */
  let mergeOrigin = new Map(), mergeCovered = new Set();
  function indexMerges() { mergeOrigin = new Map(); mergeCovered = new Set(); for (const m of sh.merges) { mergeOrigin.set(m.r1 + ',' + m.c1, m); for (let r = m.r1; r <= m.r2; r++) for (let c = m.c1; c <= m.c2; c++) if (r !== m.r1 || c !== m.c1) mergeCovered.add(r + ',' + c); } }
  const mergeOf = (r, c) => { for (const m of sh.merges) if (r >= m.r1 && r <= m.r2 && c >= m.c1 && c <= m.c2) return m; return null; };

  /* ---------- value & display ---------- */
  const val = (r, c) => eng.value(wb.active, r, c);
  function display(r, c) {
    const cell = sh.cells[r + ',' + c]; if (!cell) return { t: '' };
    let v = val(r, c); if (v && v.rows) v = v.a[0][0];
    const f = formatValue(v, cell.s && cell.s.nf); let t = f.text; if (wb.bn && typeof v === 'number') t = toBnS(t);
    return { t, color: f.color, v };
  }

  /* ---------- conditional formatting ---------- */
  function cfOf(r, c) {
    if (!sh.cf || !sh.cf.length) return null; let out = null; let v = null;
    for (const q of sh.cf) {
      if (r < q.r1 || r > q.r2 || c < q.c1 || c > q.c2) continue; if (v === null) { v = val(r, c); if (v && v.rows) v = v.a[0][0]; if (v === null) v = ''; }
      let ok = false; const isN = typeof v === 'number';
      if (q.op === 'text') ok = String(v).toLowerCase().includes(String(q.a).toLowerCase()) && q.a !== '';
      else if (isN) { const a = parseFloat(q.a), b = parseFloat(q.b); ok = q.op === 'gt' ? v > a : q.op === 'lt' ? v < a : q.op === 'ge' ? v >= a : q.op === 'le' ? v <= a : q.op === 'eq' ? v === a : q.op === 'ne' ? v !== a : q.op === 'between' ? v >= Math.min(a, b) && v <= Math.max(a, b) : false; }
      else if (v !== '') { const a = String(q.a).toLowerCase(), t = String(v).toLowerCase(); ok = q.op === 'eq' ? t === a : q.op === 'ne' ? t !== a : false; }
      if (ok) { out = { bg: q.bg || (out && out.bg), color: q.color || (out && out.color) }; break; }
    }
    return out;
  }
  const CF_OPS = [['gt', 'এর চেয়ে বড় (>)'], ['lt', 'এর চেয়ে ছোট (<)'], ['ge', 'বড় বা সমান (≥)'], ['le', 'ছোট বা সমান (≤)'], ['eq', 'সমান (=)'], ['ne', 'সমান নয় (≠)'], ['between', 'দুই মানের মাঝে'], ['text', 'লেখা ধারণ করে']];
  function cfDlg() {
    let op = 'gt', bg = '#fecaca', color = '#991b1b'; const a = h('input', { class: 'inp', placeholder: 'মান' }), b2 = h('input', { class: 'inp', placeholder: 'দ্বিতীয় মান', style: { display: 'none' } });
    const sel2 = h('select', { class: 'inp', onchange: () => { op = sel2.value; b2.style.display = op === 'between' ? '' : 'none'; a.placeholder = op === 'text' ? 'যে লেখা খুঁজবেন' : 'মান'; } }, CF_OPS.map(([k, t]) => h('option', { value: k }, t)));
    const presets = [['লাল', '#fecaca', '#991b1b'], ['সবুজ', '#bbf7d0', '#166534'], ['হলুদ', '#fef08a', '#854d0e'], ['নীল', '#bfdbfe', '#1e40af']];
    const sw = h('div', { style: { display: 'flex', gap: '8px', flexWrap: 'wrap' } }, presets.map(([n, b, c]) => h('button', { type: 'button', class: 'btn', style: { background: b, color: c, borderColor: c }, onclick: () => { bg = b; color = c; [...sw.children].forEach(x => x.style.outline = ''); event.currentTarget.style.outline = '2px solid ' + c; } }, n)));
    const list = (sh.cf || []).length ? h('div', { class: 'hint' }, `এই শিটে ${toBn(sh.cf.length)}টি নিয়ম আছে`) : null;
    modal({ title: 'শর্তসাপেক্ষ রং — ' + rangeStr(rng), body: h('div', { style: { display: 'grid', gap: '10px' } }, sel2, a, b2, h('div', { class: 'hint' }, 'রঙ বাছুন:'), sw, list), actions: [{ label: 'বাতিল', ghost: true }, ...((sh.cf || []).length ? [{ label: 'সব নিয়ম মুছুন', ghost: true, onClick: () => act(() => structural(() => { sh.cf = []; })) }] : []), { label: 'প্রয়োগ', primary: true, onClick: () => { if (a.value === '') { toast('মান লিখুন'); return false; } const n = v => (v !== '' && !isNaN(+v)) ? +v : v; act(() => structural(() => { sh.cf = sh.cf || []; sh.cf.push({ r1: rng.r1, c1: rng.c1, r2: isWholeCol() ? 9999 : rng.r2, c2: isWholeRow() ? 99 : rng.c2, op, a: n(a.value), b: n(b2.value), bg, color }); })); } }] });
  }

  /* ---------- drawing ---------- */
  let raf = 0; const draw = () => { if (!raf) raf = requestAnimationFrame(() => { raf = 0; render(); }); };
  function fontOf(s) { return `${s && s.i ? 'italic ' : ''}${s && s.b ? 'bold ' : ''}${((s && s.fs) || 11) * 1.3333 * Z}px ${s && s.font ? `"${s.font}",` : ''}${FONT_FAM}`; }
  function render() {
    const W = grid.clientWidth, H = grid.clientHeight; if (!W || !H) return;
    const dpr = window.devicePixelRatio || 1; if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); cv.style.width = W + 'px'; cv.style.height = H + 'px'; }
    const g = g2; g.setTransform(dpr, 0, 0, dpr, 0, 0);
    const D = dark(); const bg = D ? '#181c30' : '#fff', line = D ? '#2c3252' : '#dfe3ee', txt = D ? '#eceefa' : '#171b2e', hbg = D ? '#222742' : '#f1f3fa', hline = D ? '#343b63' : '#d3d8e8', hsel = D ? '#34407a' : '#dbe4ff';
    g.fillStyle = bg; g.fillRect(0, 0, W, H);
    const fr = sh.freeze.r, fc = sh.freeze.c;
    const r0 = findIdx(rowPos, rowPos[fr] + grid.scrollTop), c0 = findIdx(colPos, colPos[fc] + grid.scrollLeft);
    let r1 = r0; while (r1 < nrows - 1 && sy(r1 + 1) < H) r1++; let c1 = c0; while (c1 < ncols - 1 && sx(c1 + 1) < W) c1++;
    const regions = [[fr, nrows - 1, fc, ncols - 1, hw() + fW(), hh() + fH(), W, H, r0, r1, c0, c1], [0, fr - 1, fc, ncols - 1, hw() + fW(), hh(), W, hh() + fH(), 0, fr - 1, c0, c1], [fr, nrows - 1, 0, fc - 1, hw(), hh() + fH(), hw() + fW(), H, r0, r1, 0, fc - 1], [0, fr - 1, 0, fc - 1, hw(), hh(), hw() + fW(), hh() + fH(), 0, fr - 1, 0, fc - 1]];
    indexMerges();
    for (const [, , , , x0, y0, x1, y1, ra, rb, ca, cb] of regions) {
      if (rb < ra || cb < ca) continue;
      g.save(); g.beginPath(); g.rect(x0, y0, x1 - x0, y1 - y0); g.clip();
      // cell backgrounds
      for (let r = ra; r <= rb; r++) { if (rh(r) <= 0) continue; for (let c = ca; c <= cb; c++) { const cell = sh.cells[r + ',' + c]; if (!cell) continue; const cfx = cfOf(r, c); const bgc = (cfx && cfx.bg) || (cell.s && cell.s.bg); if (bgc) { const m = mergeOrigin.get(r + ',' + c); if (mergeCovered.has(r + ',' + c)) continue; const w = m ? sx(m.c2 + 1) - sx(c) : cw(c), hgt = m ? sy(m.r2 + 1) - sy(r) : rh(r); g.fillStyle = bgc; g.fillRect(sx(c), sy(r), w, hgt); } } }
      // grid lines
      if (showGrid) { g.strokeStyle = line; g.lineWidth = 1; g.beginPath(); for (let r = ra; r <= rb + 1; r++) { const y = Math.round(sy(r)) + .5; g.moveTo(x0, y); g.lineTo(x1, y); } for (let c = ca; c <= cb + 1; c++) { const x = Math.round(sx(c)) + .5; g.moveTo(x, y0); g.lineTo(x, y1); } g.stroke(); }
      // content
      for (let r = ra; r <= rb; r++) { if (rh(r) <= 0) continue; for (let c = ca; c <= cb; c++) { const key = r + ',' + c; const cell = sh.cells[key]; if (!cell || mergeCovered.has(key)) continue; drawCell(g, r, c, cell, txt, x1, bg); } }
      g.restore();
    }
    // selection
    const R = rng, rx0 = sx(R.c1), ry0 = sy(R.r1); let rx1 = sx(R.c2 + 1), ry1 = sy(R.r2 + 1);
    if (R.c2 >= ncols - 1 && R.c2 + 1 >= ncols) rx1 = sx(ncols); if (R.r1 === 0 && R.r2 >= nrows - 1) ry1 = sy(nrows);
    g.save(); g.beginPath(); g.rect(hw(), hh(), W - hw(), H - hh()); g.clip();
    const multi = R.r1 !== R.r2 || R.c1 !== R.c2 || mergeOf(R.r1, R.c1);
    if (multi) { g.fillStyle = D ? 'rgba(111,140,255,.18)' : 'rgba(49,87,224,.10)'; g.fillRect(rx0, ry0, rx1 - rx0, ry1 - ry0); }
    g.strokeStyle = D ? '#6f8cff' : '#3157e0'; g.lineWidth = 2; g.strokeRect(rx0 + 1, ry0 + 1, rx1 - rx0 - 2, ry1 - ry0 - 2);
    { const rl = !multi && ruleAt(sh, R.r1, R.c1); if (rl && rl.type === 'list') { const sz = 6 * Z, cx = rx1 - 12 * Z, cy = (ry0 + ry1) / 2; g.fillStyle = D ? '#6f8cff' : '#3157e0'; g.beginPath(); g.moveTo(cx - sz, cy - sz / 2); g.lineTo(cx + sz, cy - sz / 2); g.lineTo(cx, cy + sz / 1.2); g.closePath(); g.fill(); } }
    if (clip && clip.cut) { g.setLineDash([5, 4]); g.strokeStyle = '#f79009'; const cx0 = sx(clip.c1), cy0 = sy(clip.r1); g.strokeRect(cx0, cy0, sx(clip.c1 + clip.w) - cx0, sy(clip.r1 + clip.h) - cy0); g.setLineDash([]); }
    g.restore();
    // headers
    g.fillStyle = hbg; g.fillRect(0, 0, W, hh()); g.fillRect(0, 0, hw(), H);
    g.font = `600 ${12.5 * Z}px ${FONT_FAM}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.strokeStyle = hline; g.lineWidth = 1;
    const inR = (a, b, v) => v >= a && v <= b;
    const drawColH = c => { const x = sx(c), w = cw(c); if (x + w < hw() || x > W) return; const on = inR(rng.c1, rng.c2, c); if (on) { g.fillStyle = hsel; g.fillRect(x, 0, w, hh()); } g.fillStyle = on ? (D ? '#fff' : '#1f3a93') : (D ? '#9aa1c0' : '#5a627c'); g.fillText(colName(c), x + w / 2, hh() / 2); g.beginPath(); g.moveTo(Math.round(x + w) + .5, 0); g.lineTo(Math.round(x + w) + .5, hh()); g.stroke(); };
    const drawRowH = r => { const y = sy(r), hgt = rh(r); if (hgt <= 0 || y + hgt < hh() || y > H) return; const on = inR(rng.r1, rng.r2, r); if (on) { g.fillStyle = hsel; g.fillRect(0, y, hw(), hgt); } g.fillStyle = on ? (D ? '#fff' : '#1f3a93') : (D ? '#9aa1c0' : '#5a627c'); g.fillText(wb.bn ? toBnS(r + 1) : String(r + 1), hw() / 2, y + hgt / 2); g.beginPath(); g.moveTo(0, Math.round(y + hgt) + .5); g.lineTo(hw(), Math.round(y + hgt) + .5); g.stroke(); };
    g.save(); g.beginPath(); g.rect(hw(), 0, W - hw(), hh()); g.clip(); for (let c = 0; c < fc; c++) drawColH(c); g.restore();
    g.save(); g.beginPath(); g.rect(hw() + fW(), 0, W, hh()); g.clip(); for (let c = c0; c <= c1; c++) drawColH(c); g.restore();
    g.save(); g.beginPath(); g.rect(0, hh(), hw(), H); g.clip(); for (let r = 0; r < fr; r++) drawRowH(r); g.restore();
    g.save(); g.beginPath(); g.rect(0, hh() + fH(), hw(), H); g.clip(); for (let r = r0; r <= r1; r++) drawRowH(r); g.restore();
    g.strokeStyle = hline; g.beginPath(); g.moveTo(0, hh() + .5); g.lineTo(W, hh() + .5); g.moveTo(hw() + .5, 0); g.lineTo(hw() + .5, H); g.stroke();
    if (fc || fr) { g.strokeStyle = D ? '#6f8cff' : '#8aa0ee'; g.lineWidth = 2; g.beginPath(); if (fr) { g.moveTo(0, hh() + fH()); g.lineTo(W, hh() + fH()); } if (fc) { g.moveTo(hw() + fW(), 0); g.lineTo(hw() + fW(), H); } g.stroke(); }
    g.fillStyle = hbg; g.fillRect(0, 0, hw(), hh());
    placeOverlay(rx0, ry0, rx1, ry1);
    updateStatus();
  }
  function drawCell(g, r, c, cell, txt, clipRight, bg) {
    const s = cell.s || {}; const m = mergeOrigin.get(r + ',' + c);
    const x = sx(c), y = sy(r); const w = m ? sx(m.c2 + 1) - x : cw(c), hgt = m ? sy(m.r2 + 1) - y : rh(r);
    if (s.bd) { g.strokeStyle = '#222'; g.lineWidth = 1; const bc = k => s.bd[k] === 1 ? (dark() ? '#c9cfee' : '#222') : s.bd[k]; for (const [k, x0, y0, x1, y1] of [['t', x, y, x + w, y], ['b', x, y + hgt, x + w, y + hgt], ['l', x, y, x, y + hgt], ['r', x + w, y, x + w, y + hgt]]) if (s.bd[k]) { g.strokeStyle = bc(k); g.beginPath(); g.moveTo(Math.round(x0) + .5, Math.round(y0) + .5); g.lineTo(Math.round(x1) + .5, Math.round(y1) + .5); g.stroke(); } }
    const d = display(r, c); if (d.t === '' ) return;
    g.font = fontOf(s); const cfx = cfOf(r, c); g.fillStyle = d.color ? (COLORS[d.color] || txt) : ((cfx && cfx.color) || s.color || (((cfx && cfx.bg) || s.bg) && dark() ? '#171b2e' : ((cfx && cfx.bg) || s.bg) ? '#171b2e' : txt)); g.textBaseline = 'middle';
    const isNum = typeof d.v === 'number', isErrV = isErr(d.v), isBool = typeof d.v === 'boolean';
    let ha = s.ha || (isNum ? 'right' : (isErrV || isBool) ? 'center' : 'left'); const pad = 5 * Z;
    let text = d.t;
    g.save(); g.beginPath(); g.rect(x, y, w, hgt); g.clip();
    if (s.wrap && !isNum) {
      const maxW = w - pad * 2, lines = []; for (const para of text.split('\n')) { let cur = ''; for (const ch of para.split(/(\s+)/)) { if (g.measureText(cur + ch).width > maxW && cur) { lines.push(cur.trimEnd()); cur = ch.trimStart(); } else cur += ch; } lines.push(cur); }
      const lh = (((s.fs || 11) * 1.3333) + 3) * Z; const tot = lines.length * lh; let ty = s.va === 'bottom' ? y + hgt - tot - 2 : s.va === 'top' ? y + 2 : y + (hgt - tot) / 2; g.textBaseline = 'top'; g.textAlign = ha === 'right' ? 'right' : ha === 'center' ? 'center' : 'left';
      for (const ln of lines) { g.fillText(ln, ha === 'right' ? x + w - pad : ha === 'center' ? x + w / 2 : x + pad, ty); if (s.u) { const tw = g.measureText(ln).width; g.fillRect(ha === 'right' ? x + w - pad - tw : ha === 'center' ? x + w / 2 - tw / 2 : x + pad, ty + lh - 4 * Z, tw, 1); } ty += lh; }
      g.restore(); return;
    }
    text = text.replace(/\n/g, ' ');
    let tw = g.measureText(text).width;
    if (isNum && tw > w - pad * 2 && !isErrV) { text = '#'.repeat(Math.max(1, Math.floor((w - pad) / (g.measureText('#').width)))); tw = g.measureText(text).width; }
    const va = s.va === 'top' ? y + (((s.fs || 11) * 1.3333 * Z) / 2 + 3) : s.va === 'bottom' ? y + hgt - ((s.fs || 11) * 1.3333 * Z) / 2 - 3 : y + hgt / 2 + .5;
    let tx;
    if (ha === 'right') { g.textAlign = 'right'; tx = x + w - pad; } else if (ha === 'center') { g.textAlign = 'center'; tx = x + w / 2; } else { g.textAlign = 'left'; tx = x + pad; }
    // overflow of left-aligned text into empty neighbours
    if (!m && !isNum && tw > w - pad * 2 && ha === 'left') { let ex = w; let cc = c + 1; while (ex < tw + pad * 2 && cc < ncols && !sh.cells[r + ',' + cc]) { ex += cw(cc); cc++; } g.restore(); g.save(); g.beginPath(); g.rect(x, y, ex, hgt); g.clip(); }
    g.fillText(text, tx, va);
    if (s.u || s.s) { const lx = ha === 'right' ? tx - tw : ha === 'center' ? tx - tw / 2 : tx; if (s.u) g.fillRect(lx, va + ((s.fs || 11) * 1.3333 * Z) / 2, tw, 1); if (s.s) g.fillRect(lx, va, tw, 1); }
    g.restore();
  }
  function placeOverlay(rx0, ry0, rx1, ry1) {
    const W = grid.clientWidth, H = grid.clientHeight; const show = !editing;
    const vis = (x, y) => x > hw() - 2 && y > hh() - 2 && x < W + 12 && y < H + 12;
    hSE.style.display = show && vis(rx1, ry1) ? 'block' : 'none'; hSE.style.left = rx1 + 'px'; hSE.style.top = ry1 + 'px';
    hNW.style.display = show && (rng.r1 !== rng.r2 || rng.c1 !== rng.c2) && vis(rx0, ry0) ? 'block' : 'none'; hNW.style.left = rx0 + 'px'; hNW.style.top = ry0 + 'px';
    if (editing) positionEditor();
  }
  function updateStatus() {
    const R = rng; nameBox.textContent = (R.r1 === R.r2 && R.c1 === R.c2) ? addr(sel.r, sel.c) : rangeStr(R);
    if (R.r1 !== R.r2 || R.c1 !== R.c2) { let n = 0, sum = 0, cnt = 0; const r2 = Math.min(R.r2, used().r), c2 = Math.min(R.c2, used().c); for (let r = R.r1; r <= r2; r++) for (let c = R.c1; c <= c2; c++) { const v = val(r, c); if (v !== null && v !== '') cnt++; if (typeof v === 'number') { n++; sum += v; } } status.textContent = n ? `যোগ: ${formatValue(sum, 'General').text}  গড়: ${formatValue(sum / n, 'General').text}  গণনা: ${cnt}` : `গণনা: ${cnt}`; if (wb.bn) status.textContent = toBnS(status.textContent); } else status.textContent = '';
    if (!editing) { const c = sh.cells[sel.r + ',' + sel.c]; fInput.value = c ? (c.f ? '=' + c.f : rawText(c)) : ''; }
    syncToolbar();
  }
  const rawText = c => { const v = c.v; if (v === undefined || v === null) return ''; if (typeof v === 'number' && c.s && c.s.nf && /[dmyh]/i.test(c.s.nf) && !/^[0#,.%"]/.test(c.s.nf)) return formatValue(v, c.s.nf).text; if (typeof v === 'number' && c.s && /%/.test(c.s.nf || '')) return formatValue(v, c.s.nf).text; if (typeof v === 'boolean') return v ? 'TRUE' : 'FALSE'; if (isErr(v)) return v.err; return String(v); };

  /* ---------- history ---------- */
  const hist = []; let hi = -1; let tx = null;
  // fast structural deep copy of JSON-like data (≈10× quicker than JSON round-trips; matters when a sort touches a million cells)
  const clone = function cd(o) { if (o === null || typeof o !== 'object') return o; if (Array.isArray(o)) { const a = new Array(o.length); for (let i = 0; i < o.length; i++) a[i] = cd(o[i]); return a; } const r = {}; for (const k in o) r[k] = cd(o[k]); return r; };
  const noteUsed = (s, r, c, exists) => { const u = s._used; if (!u || s._usedDirty) return; if (exists) { if (r > u.r) u.r = r; if (c > u.c) u.c = c; } else if (r === u.r || c === u.c) s._usedDirty = true; };
  const HIST_CELL_CAP = 1500000; let histCells = 0;
  function begin() { tx = { cells: [], snaps: [] }; }
  function putCell(r, c, cell, si = wb.active) { const s = wb.sheets[si]; const key = r + ',' + c; const before = s.cells[key]; if (cell === undefined || (cell && cell.v === undefined && !cell.f && !(cell.s && Object.keys(cell.s).length))) { if (before === undefined) return; delete s.cells[key]; noteUsed(s, r, c, false); tx.cells.push({ si, key, before, after: undefined }); } else { if (cell.s && !Object.keys(cell.s).length) delete cell.s; s.cells[key] = cell; noteUsed(s, r, c, true); tx.cells.push({ si, key, before, after: clone(cell) }); } }
  function structural(fn) { const si = wb.active; const snap = () => JSON.stringify({ cells: sh.cells, colW: sh.colW, rowH: sh.rowH, merges: sh.merges, freeze: sh.freeze, hiddenRows: sh.hiddenRows, cf: sh.cf, dv: sh.dv }); const before = snap(); fn(); sh._usedDirty = true; tx.snaps.push({ si, before, after: snap() }); }
  function sheetsStructural(fn) { const before = serializeWb(wb); fn(); tx.wbSnap = { before, after: serializeWb(wb) }; }
  function end() { const t = tx; tx = null; if (!t || (!t.cells.length && !t.snaps.length && !t.wbSnap)) return; hist.length = hi + 1; hist.push(t); if (hist.length > 100) hist.shift();
    histCells = hist.reduce((a, x) => a + x.cells.length + (x.snaps.length ? 50000 : 0), 0);   // bound undo memory on huge sheets
    while (hist.length > 1 && histCells > HIST_CELL_CAP) { const d = hist.shift(); histCells -= d.cells.length + (d.snaps.length ? 50000 : 0); }
    hi = hist.length - 1; changed(); }
  function applySnap(t, undo) {
    if (t.wbSnap) { const w2 = loadWb(undo ? t.wbSnap.before : t.wbSnap.after); wb.sheets = w2.sheets; wb.active = Math.min(w2.active, wb.sheets.length - 1); sh = wb.sheets[wb.active]; renderTabs(); }
    for (const s of (undo ? [...t.snaps].reverse() : t.snaps)) { const d = JSON.parse(undo ? s.before : s.after); const tgt = wb.sheets[s.si]; if (tgt) tgt._usedDirty = true; if (tgt) Object.assign(tgt, { cells: d.cells, colW: d.colW, rowH: d.rowH, merges: d.merges, freeze: d.freeze, hiddenRows: d.hiddenRows || {}, cf: d.cf || [], dv: d.dv || [] }); }
    for (const cch of (undo ? [...t.cells].reverse() : t.cells)) { const tgt = wb.sheets[cch.si]; if (!tgt) continue; const v = undo ? cch.before : cch.after; { const ix = cch.key.indexOf(','), rr = +cch.key.slice(0, ix), cc = +cch.key.slice(ix + 1); if (v === undefined) { delete tgt.cells[cch.key]; noteUsed(tgt, rr, cc, false); } else { tgt.cells[cch.key] = clone(v); noteUsed(tgt, rr, cc, true); } } }
  }
  function undo() { if (editing) { cancelEdit(); return; } if (hi < 0) return; applySnap(hist[hi], true); hi--; changed(true); }
  function redo() { if (hi >= hist.length - 1) return; hi++; applySnap(hist[hi], false); changed(true); }
  function changed(fromUndo) {
    for (const s of wb.sheets) s._ver = (s._ver || 0) + 1; eng.invalidate(); relayout(); clampSel(); draw(); as && as.mark(); hdr && hdr.setUndo(hi >= 0, hi < hist.length - 1);
  }
  const clampSel = () => { sel.r = clamp(sel.r, 0, nrows - 1); sel.c = clamp(sel.c, 0, ncols - 1); rng.r1 = clamp(rng.r1, 0, nrows - 1); rng.r2 = clamp(rng.r2, 0, nrows - 1); rng.c1 = clamp(rng.c1, 0, ncols - 1); rng.c2 = clamp(rng.c2, 0, ncols - 1); };
  const act = fn => { begin(); try { fn(); } finally { end(); } };

  /* ---------- selection ---------- */
  function select(r, c, extend) {
    r = clamp(r, 0, nrows - 1); c = clamp(c, 0, ncols - 1);
    if (extend) { rng = { r1: Math.min(sel.r, r), c1: Math.min(sel.c, c), r2: Math.max(sel.r, r), c2: Math.max(sel.c, c) }; }
    else { sel = { r, c }; const m = mergeOf(r, c); rng = m ? { ...m } : { r1: r, c1: c, r2: r, c2: c }; if (m) sel = { r: m.r1, c: m.c1 }; }
    ensureVisible(extend ? r : sel.r, extend ? c : sel.c); draw();
  }
  function ensureVisible(r, c) {
    const W = grid.clientWidth, H = grid.clientHeight; const fr = sh.freeze.r, fc = sh.freeze.c;
    if (r >= fr) { const y = sy(r), b = sy(r + 1); if (y < hh() + fH()) grid.scrollTop += y - hh() - fH(); else if (b > H) grid.scrollTop += b - H; }
    if (c >= fc) { const x = sx(c), b = sx(c + 1); if (x < hw() + fW()) grid.scrollLeft += x - hw() - fW(); else if (b > W) grid.scrollLeft += b - W; }
    if (r > nrows - 20) { nrows += 100; relayout(); } if (c > ncols - 6) { ncols += 10; relayout(); }
  }
  function selectCols(c1, c2) { const last = Math.max(used().r, 0); rng = { r1: 0, c1: Math.min(c1, c2), r2: Math.max(last, 100), c2: Math.max(c1, c2) }; sel = { r: 0, c: Math.min(c1, c2) }; draw(); }
  function selectRows(r1, r2) { rng = { r1: Math.min(r1, r2), c1: 0, r2: Math.max(r1, r2), c2: Math.max(used().c, 7) }; sel = { r: Math.min(r1, r2), c: 0 }; draw(); }
  const isWholeCol = () => rng.r1 === 0 && rng.r2 >= Math.max(used().r, 100); const isWholeRow = () => rng.c1 === 0 && rng.c2 >= Math.max(used().c, 7);
  const rangeCells = (cb, limit = true) => { const ur = used(); const r2 = limit && isWholeCol() ? Math.max(ur.r, 0) + 0 : rng.r2, c2 = limit && isWholeRow() ? Math.max(ur.c, 0) : rng.c2; for (let r = rng.r1; r <= r2; r++) for (let c = rng.c1; c <= c2; c++) cb(r, c); };

  /* ---------- pointer interaction ---------- */
  let down = null;
  cv.addEventListener('pointerdown', e => {
    if (editing && e.pointerType) { /* handled in up (ref insert) */ }
    const rect = cv.getBoundingClientRect(); const x = e.clientX - rect.left, y = e.clientY - rect.top;
    down = { x, y, t: Date.now(), type: e.pointerType, moved: false, id: e.pointerId, sx: grid.scrollLeft, sy: grid.scrollTop };
    if (e.pointerType === 'mouse') { cv.setPointerCapture(e.pointerId); const c = colAt(x), r = rowAt(y); if (r >= 0 && c >= 0 && !editing) { if (e.shiftKey) select(r, c, true); else select(r, c); down.drag = true; } }
  });
  cv.addEventListener('pointermove', e => {
    if (!down) return; const rect = cv.getBoundingClientRect(); const x = e.clientX - rect.left, y = e.clientY - rect.top;
    if (Math.abs(x - down.x) + Math.abs(y - down.y) > 8) down.moved = true;
    if (down.drag && e.pointerType === 'mouse') { const c = colAt(x), r = rowAt(y); if (r >= 0 && c >= 0) select(r, c, true); if (x > grid.clientWidth - 20) grid.scrollLeft += 20; if (y > grid.clientHeight - 20) grid.scrollTop += 20; }
  });
  cv.addEventListener('pointerup', e => {
    if (!down) return; const d = down; down = null; if (d.moved || d.drag) return;
    if (grid.scrollLeft !== d.sx || grid.scrollTop !== d.sy) return;
    const c = colAt(d.x), r = rowAt(d.y);
    if (editing) { if (r >= 0 && c >= 0 && formulaRefMode()) { insertRef(r, c); return; } if (!commitEdit(0, 0)) return; }
    if (r < 0 && c < 0) { rng = { r1: 0, c1: 0, r2: Math.max(used().r, 100), c2: Math.max(used().c, 7) }; sel = { r: 0, c: 0 }; draw(); return; }
    if (r < 0) { if (rng.r1 === 0 && isWholeCol() && c >= rng.c1 && c <= rng.c2 && rng.c1 === rng.c2) colMenu(c); else selectCols(c, c); return; }
    if (c < 0) { if (isWholeRow() && r >= rng.r1 && r <= rng.r2 && rng.r1 === rng.r2) rowMenu(r); else selectRows(r, r); return; }
    const same = sel.r === r && sel.c === c && rng.r1 === rng.r2 && rng.c1 === rng.c2 || (mergeOf(r, c) && mergeOf(sel.r, sel.c) === mergeOf(r, c));
    { const rl = same && ruleAt(sh, r, c); if (rl && rl.type === 'list') { openDropdown(r, c, rl); return; } }
    if (same && Date.now() - lastTap < 700) { startEdit(); return; }
    select(r, c); lastTap = Date.now();
  });
  cv.addEventListener('dblclick', () => { if (!editing) startEdit(); });
  cv.addEventListener('pointercancel', () => { down = null; });
  let lastTap = 0;
  function dragHandle(el, which) {
    el.addEventListener('pointerdown', e => {
      e.preventDefault(); e.stopPropagation(); el.setPointerCapture(e.pointerId);
      const anchor = which === 'se' ? { r: rng.r1, c: rng.c1 } : { r: rng.r2, c: rng.c2 };
      const move = ev => { const rect = cv.getBoundingClientRect(); const x = ev.clientX - rect.left - 0, y = ev.clientY - rect.top - 0 - (ev.pointerType === 'touch' ? 24 : 0); let c = colAt(x), r = rowAt(y); if (c < 0) c = which === 'se' ? rng.c2 : rng.c1; if (r < 0) r = which === 'se' ? rng.r2 : rng.r1; if (which === 'se') { r = Math.max(r, 0); } rng = { r1: Math.min(anchor.r, r), c1: Math.min(anchor.c, c), r2: Math.max(anchor.r, r), c2: Math.max(anchor.c, c) }; if (ev.clientX - rect.left > grid.clientWidth - 24) grid.scrollLeft += 18; if (ev.clientY - rect.top > grid.clientHeight - 36) grid.scrollTop += 18; if (ev.clientX - rect.left < hw() + 24) grid.scrollLeft -= 18; if (ev.clientY - rect.top < hh() + 24) grid.scrollTop -= 18; draw(); };
      const up = () => { el.removeEventListener('pointermove', move); el.removeEventListener('pointerup', up); el.removeEventListener('pointercancel', up); }; el.addEventListener('pointermove', move); el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up);
    });
  }
  dragHandle(hSE, 'se'); dragHandle(hNW, 'nw');
  grid.addEventListener('scroll', () => { if (grid.scrollTop + grid.clientHeight > spacer.offsetHeight - 300 && nrows < 50000) { nrows += 100; relayout(); } if (grid.scrollLeft + grid.clientWidth > spacer.offsetWidth - 300 && ncols < 702) { ncols += 10; relayout(); } draw(); }, { passive: true });
  // pinch zoom
  let pz = null;
  grid.addEventListener('touchstart', e => { if (e.touches.length === 2) pz = { d: Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY), z: Z }; }, { passive: true });
  grid.addEventListener('touchmove', e => { if (pz && e.touches.length === 2) { e.preventDefault(); const d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY); setZoom(pz.z * d / pz.d); } }, { passive: false });
  grid.addEventListener('touchend', () => { pz = null; });
  function setZoom(z) { const old = Z; Z = clamp(Math.round(z * 100) / 100, .5, 2.2); const f = Z / old; const sl = grid.scrollLeft * f, st = grid.scrollTop * f; relayout(); grid.scrollLeft = sl; grid.scrollTop = st; draw(); }
  new ResizeObserver(() => { render(); }).observe(grid);

  /* ---------- editing ---------- */
  function startEdit(initial, src = 'cell') {
    if (editing) return; const c = sh.cells[sel.r + ',' + sel.c];
    const text = initial !== undefined ? initial : (c ? (c.f ? '=' + c.f : rawText(c)) : '');
    editing = { text, src, orig: text };
    edTa.value = text; edTa.style.display = 'block'; positionEditor(); hSE.style.display = hNW.style.display = 'none';
    if (src === 'cell') { edTa.focus(); const l = edTa.value.length; edTa.setSelectionRange(l, l); } fInput.value = text;
  }
  function positionEditor() {
    const m = mergeOf(sel.r, sel.c); const x = sx(sel.c), y = sy(sel.r); const c = sh.cells[sel.r + ',' + sel.c]; const s = (c && c.s) || {};
    const w = Math.max(m ? sx(m.c2 + 1) - x : cw(sel.c), 90 * Z); const lines = edTa.value.split('\n').length;
    Object.assign(edTa.style, { left: x + 'px', top: y + 'px', width: w + 'px', height: Math.max(m ? sy(m.r2 + 1) - y : rh(sel.r), lines * 22 * Z) + 'px', font: fontOf(s), color: dark() ? '#eceefa' : '#111', background: dark() ? '#181c30' : '#fff', textAlign: s.ha || 'left' });
  }
  edTa.addEventListener('input', () => { if (!editing) return; editing.text = edTa.value; fInput.value = edTa.value; positionEditor(); });
  edTa.addEventListener('keydown', e => editKey(e));
  fInput.addEventListener('focus', () => { if (!editing) { startEdit(undefined, 'bar'); } });
  fInput.addEventListener('input', () => { if (editing) { editing.text = fInput.value; edTa.value = fInput.value; } });
  fInput.addEventListener('keydown', e => editKey(e));
  function editKey(e) {
    if (e.key === 'Enter' && !e.altKey && !e.shiftKey) { e.preventDefault(); commitEdit(1, 0); }
    else if (e.key === 'Enter' && e.shiftKey) { e.preventDefault(); commitEdit(-1, 0); }
    else if (e.key === 'Tab') { e.preventDefault(); commitEdit(0, e.shiftKey ? -1 : 1); }
    else if (e.key === 'Escape') { e.preventDefault(); cancelEdit(); }
    else if (e.key === 'Enter' && e.altKey) { e.preventDefault(); const t = e.target; const s = t.selectionStart; t.value = t.value.slice(0, s) + '\n' + t.value.slice(t.selectionEnd); t.setSelectionRange(s + 1, s + 1); t.dispatchEvent(new Event('input')); }
  }
  edTa.addEventListener('blur', () => { setTimeout(() => { if (editing && editing.src === 'cell' && document.activeElement !== fInput && document.activeElement !== edTa && !refTapping) commitEdit(0, 0); }, 120); });
  fInput.addEventListener('blur', () => { setTimeout(() => { if (editing && editing.src === 'bar' && document.activeElement !== edTa && document.activeElement !== fInput && !refTapping) commitEdit(0, 0); }, 150); });
  let refTapping = false;
  function formulaRefMode() { if (!editing || !editing.text.startsWith('=')) return false; const t = editing.text.slice(0, (editing.src === 'cell' ? edTa : fInput).selectionStart ?? editing.text.length); return /[=(,+\-*/^&<>:;]$/.test(t) || t === '='; }
  function insertRef(r, c) {
    const inp = editing.src === 'cell' ? edTa : fInput; const pos = inp.selectionStart ?? inp.value.length; const ref = addr(r, c);
    inp.value = inp.value.slice(0, pos) + ref + inp.value.slice(inp.selectionEnd ?? pos); const np = pos + ref.length; editing.text = inp.value; edTa.value = inp.value; fInput.value = inp.value; inp.focus(); inp.setSelectionRange(np, np);
  }
  const dvRead = (name, r, c) => { const si = name ? wb.sheets.findIndex(s => s.name === name) : wb.active; return si < 0 ? null : eng.value(si, r, c); };
  function commitEdit(dr, dc) {
    if (!editing) return true; const rule = ruleAt(sh, sel.r, sel.c);
    if (rule && !String(editing.text).startsWith('=') && String(editing.text) !== ((c0 => c0 ? (c0.f ? '=' + c0.f : rawText(c0)) : '')(sh.cells[sel.r + ',' + sel.c]))) { const res = dvCheck(rule, editing.text, dvRead); if (!res.ok) { toast(res.msg, 3800); return false; } }   // data validation: the editor stays open so the value can be corrected
    const text = editing.text; editing = null; edTa.style.display = 'none'; edTa.blur(); fInput.blur();
    const key = sel.r + ',' + sel.c; const prev = sh.cells[key]; const prevText = prev ? (prev.f ? '=' + prev.f : rawText(prev)) : '';
    if (text !== prevText) setInput(sel.r, sel.c, text);
    if (dr || dc) { select(sel.r + dr, sel.c + dc); } else { updateStatus(); draw(); }
    return true;
  }
  function cancelEdit() { if (!editing) return; editing = null; edTa.style.display = 'none'; edTa.blur(); fInput.blur(); updateStatus(); draw(); }
  function setInput(r, c, text) {
    act(() => {
      const p = parseInput(text); const old = sh.cells[r + ',' + c]; const s = old && old.s ? { ...old.s } : {};
      if (p.nf && (!s.nf || s.nf === 'General')) s.nf = p.nf;
      if (p.f !== undefined) putCell(r, c, { f: p.f, ...(Object.keys(s).length ? { s } : {}) });
      else if (p.v === undefined) putCell(r, c, Object.keys(s).length ? { s } : undefined);
      else putCell(r, c, { v: p.v, ...(Object.keys(s).length ? { s } : {}) });
    });
  }

  /* ---------- keyboard ---------- */
  document.addEventListener('keydown', onKey);
  function onKey(e) {
    if (editing || !ctx.root.isConnected) return; const t = e.target; if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT') && t !== document.body) return; if (document.querySelector('.ov.in')) return;
    const mod = e.ctrlKey || e.metaKey, k = e.key;
    if (mod && k.toLowerCase() === 'c') { e.preventDefault(); copy(false); } else if (mod && k.toLowerCase() === 'x') { e.preventDefault(); copy(true); } else if (mod && k.toLowerCase() === 'v') { e.preventDefault(); paste(); }
    else if (mod && k.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? redo() : undo(); } else if (mod && k.toLowerCase() === 'y') { e.preventDefault(); redo(); }
    else if (mod && k.toLowerCase() === 'b') { e.preventDefault(); toggleStyle('b'); } else if (mod && k.toLowerCase() === 'i') { e.preventDefault(); toggleStyle('i'); } else if (mod && k.toLowerCase() === 'u') { e.preventDefault(); toggleStyle('u'); }
    else if (mod && k.toLowerCase() === 'a') { e.preventDefault(); rng = { r1: 0, c1: 0, r2: Math.max(used().r, 0), c2: Math.max(used().c, 0) }; draw(); }
    else if (mod && k.toLowerCase() === 'd') { e.preventDefault(); fill('down'); } else if (mod && k.toLowerCase() === 'r') { e.preventDefault(); fill('right'); }
    else if (mod && k.toLowerCase() === 'f') { e.preventDefault(); findDlg(); } else if (mod && k.toLowerCase() === 's') { e.preventDefault(); as.now(true); }
    else if (k === 'ArrowDown') { e.preventDefault(); move(1, 0, e.shiftKey, mod); } else if (k === 'ArrowUp') { e.preventDefault(); move(-1, 0, e.shiftKey, mod); } else if (k === 'ArrowLeft') { e.preventDefault(); move(0, -1, e.shiftKey, mod); } else if (k === 'ArrowRight') { e.preventDefault(); move(0, 1, e.shiftKey, mod); }
    else if (k === 'Tab') { e.preventDefault(); move(0, e.shiftKey ? -1 : 1); } else if (k === 'Enter' || k === 'F2') { e.preventDefault(); startEdit(); }
    else if (k === 'Delete' || k === 'Backspace') { e.preventDefault(); clearRange('contents'); }
    else if (k === 'PageDown') { e.preventDefault(); move(Math.floor(grid.clientHeight / BASE_RH / Z) - 1, 0); } else if (k === 'PageUp') { e.preventDefault(); move(-(Math.floor(grid.clientHeight / BASE_RH / Z) - 1), 0); }
    else if (k === 'Home') { e.preventDefault(); select(mod ? 0 : sel.r, 0); }
    else if (!mod && !e.altKey && k.length === 1) { e.preventDefault(); startEdit(k); }
  }
  function move(dr, dc, ext, jump) {
    let r = (ext ? (sel.r === rng.r1 ? rng.r2 : rng.r1) : sel.r) + dr, c = (ext ? (sel.c === rng.c1 ? rng.c2 : rng.c1) : sel.c) + dc;
    if (jump) { const u = used(); if (dr) r = dr > 0 ? u.r : 0; if (dc) c = dc > 0 ? u.c : 0; }
    if (ext) { select(r, c, true); } else select(r, c);
  }

  /* ---------- styling ---------- */
  function applyStyle(patch) {
    act(() => rangeCells((r, c) => { if (mergeCovered.has(r + ',' + c)) return; const old = sh.cells[r + ',' + c]; const cell = old ? clone(old) : {}; const s = { ...(cell.s || {}) }; for (const k in patch) { if (patch[k] === undefined || patch[k] === false || patch[k] === null) delete s[k]; else s[k] = patch[k]; } if (Object.keys(s).length) cell.s = s; else delete cell.s; putCell(r, c, Object.keys(cell).length ? cell : undefined); }));
  }
  const styleOf = (r, c) => (sh.cells[r + ',' + c] && sh.cells[r + ',' + c].s) || {};
  function toggleStyle(k) { const on = !!styleOf(sel.r, sel.c)[k]; applyStyle({ [k]: on ? undefined : 1 }); }
  function setNf(nf) { applyStyle({ nf: nf === 'General' ? undefined : nf }); }
  function changeDecimals(d) { const cur = styleOf(sel.r, sel.c).nf || 'General'; let nf; const v = val(sel.r, sel.c); if (cur === 'General') { const s = typeof v === 'number' ? String(v) : ''; const dec = (s.split('.')[1] || '').length; nf = (d > 0 ? '0.' + '0'.repeat(dec + 1) : '0'); if (d < 0 && dec <= 0) return; if (d < 0) nf = dec - 1 > 0 ? '0.' + '0'.repeat(dec - 1) : '0'; } else { const m = /^(.*?0)(?:\.(0+))?(.*)$/.exec(cur); if (!m) return; const dec = m[2] ? m[2].length : 0; const nd = Math.max(0, dec + d); nf = m[1] + (nd ? '.' + '0'.repeat(nd) : '') + m[3]; } applyStyle({ nf }); }
  function setBorder(kind) {
    act(() => rangeCells((r, c) => { const old = sh.cells[r + ',' + c]; const cell = old ? clone(old) : {}; const s = { ...(cell.s || {}) }; let bd = { ...(s.bd || {}) };
      if (kind === 'none') bd = {}; else if (kind === 'all') bd = { t: 1, r: 1, b: 1, l: 1 }; else if (kind === 'outer') { if (r === rng.r1) bd.t = 1; if (r === rng.r2) bd.b = 1; if (c === rng.c1) bd.l = 1; if (c === rng.c2) bd.r = 1; } else if (kind === 'bottom') { if (r === rng.r2) bd.b = 1; } else if (kind === 'top') { if (r === rng.r1) bd.t = 1; } else if (kind === 'thickbottom') { if (r === rng.r2) bd.b = 1; }
      if (Object.keys(bd).length) s.bd = bd; else delete s.bd; if (Object.keys(s).length) cell.s = s; else delete cell.s; putCell(r, c, Object.keys(cell).length ? cell : undefined); }));
  }
  function mergeSel() { if (rng.r1 === rng.r2 && rng.c1 === rng.c2) return toast('একাধিক ঘর সিলেক্ট করুন'); act(() => structural(() => { sh.merges = sh.merges.filter(m => !(m.r1 <= rng.r2 && m.r2 >= rng.r1 && m.c1 <= rng.c2 && m.c2 >= rng.c1)); sh.merges.push({ ...rng }); for (let r = rng.r1; r <= rng.r2; r++) for (let c = rng.c1; c <= rng.c2; c++) if (r !== rng.r1 || c !== rng.c1) delete sh.cells[r + ',' + c]; })); sel = { r: rng.r1, c: rng.c1 }; draw(); }
  function unmergeSel() { act(() => structural(() => { sh.merges = sh.merges.filter(m => !(m.r1 <= rng.r2 && m.r2 >= rng.r1 && m.c1 <= rng.c2 && m.c2 >= rng.c1)); })); }
  function clearRange(what) {
    act(() => rangeCells((r, c) => { const old = sh.cells[r + ',' + c]; if (!old) return; if (what === 'all') putCell(r, c, undefined); else if (what === 'format') { const n = clone(old); delete n.s; putCell(r, c, Object.keys(n).length ? n : undefined); } else { const n = { s: old.s }; if (!n.s) putCell(r, c, undefined); else putCell(r, c, n); } }));
  }

  /* ---------- clipboard ---------- */
  const tsvOf = (r1, c1, r2, c2) => { const rows = []; for (let r = r1; r <= r2; r++) { const row = []; for (let c = c1; c <= c2; c++) { const d = display(r, c).t; row.push(/[\t\n"]/.test(d) ? '"' + d.replace(/"/g, '""') + '"' : d); } rows.push(row.join('\t')); } return rows.join('\n'); };
  async function copy(cut) {
    const ur = used(); const r2 = isWholeCol() ? Math.max(ur.r, 0) : rng.r2, c2 = isWholeRow() ? Math.max(ur.c, 0) : rng.c2;
    const cells = []; for (let r = rng.r1; r <= r2; r++) { const row = []; for (let c = rng.c1; c <= c2; c++) row.push(clone(sh.cells[r + ',' + c])); cells.push(row); }
    const text = tsvOf(rng.r1, rng.c1, r2, c2); clip = { cells, r1: rng.r1, c1: rng.c1, h: r2 - rng.r1 + 1, w: c2 - rng.c1 + 1, text, cut: !!cut, si: wb.active };
    try { await navigator.clipboard.writeText(text); } catch { }
    toast(cut ? 'কাট হয়েছে — পেস্ট করুন' : 'কপি হয়েছে'); draw();
  }
  async function paste(valuesOnly) {
    let text = ''; try { text = await navigator.clipboard.readText(); } catch { }
    const useInternal = clip && (!text || text === clip.text);
    if (!useInternal && !text) return toast('পেস্ট করার মতো কিছু নেই');
    act(() => {
      if (useInternal) {
        const dr = sel.r - clip.r1, dc = sel.c - clip.c1;
        clip.cells.forEach((row, i) => row.forEach((cell, j) => { const r = sel.r + i, c = sel.c + j; if (cell === undefined) { if (!valuesOnly) putCell(r, c, undefined); return; } const n = clone(cell); if (n.f && !(clip.cut)) n.f = shiftFormula(n.f, dr, dc); else if (n.f && clip.cut) { /* keep refs on move */ } if (valuesOnly) { const v = val2(clip.si, clip.r1 + i, clip.c1 + j); const o = { v }; if (v === null) return; if (cell.s && cell.s.nf) o.s = { nf: cell.s.nf }; putCell(r, c, o); } else putCell(r, c, n); }));
        if (clip.cut) { const src = wb.sheets[clip.si]; for (let i = 0; i < clip.h; i++) for (let j = 0; j < clip.w; j++) { const r = clip.r1 + i, c = clip.c1 + j; if (r >= sel.r && r < sel.r + clip.h && c >= sel.c && c < sel.c + clip.w && clip.si === wb.active) continue; putCell(r, c, undefined, clip.si); } clip = null; }
        rng = { r1: sel.r, c1: sel.c, r2: sel.r + (clip ? clip.h : 1) - 1, c2: sel.c };
      } else {
        const rows = parseCSV(text.replace(/\r\n/g, '\n'), '\t'); if (rows.length && rows[rows.length - 1].length === 1 && rows[rows.length - 1][0] === '') rows.pop();
        rows.forEach((row, i) => row.forEach((t, j) => { const r = sel.r + i, c = sel.c + j; const p = parseInput(t); const old = sh.cells[r + ',' + c]; const s = old && old.s ? { ...old.s } : {}; if (p.nf && !s.nf) s.nf = p.nf; const n = p.f !== undefined ? { f: p.f } : p.v !== undefined ? { v: p.v } : {}; if (Object.keys(s).length) n.s = s; putCell(r, c, Object.keys(n).length ? n : undefined); }));
        rng = { r1: sel.r, c1: sel.c, r2: sel.r + rows.length - 1, c2: sel.c + Math.max(...rows.map(r => r.length)) - 1 };
      }
    });
  }
  const val2 = (si, r, c) => eng.value(si, r, c);
  async function pasteMenu() { actionSheet('পেস্ট', [{ icon: 'paste', label: 'সব পেস্ট (ফরম্যাট সহ)', onClick: () => paste(false) }, { icon: 'text', label: 'শুধু মান (Values)', onClick: () => paste(true) }]); }

  /* ---------- fill ---------- */
  function fill(dir) {
    if (rng.r1 === rng.r2 && dir === 'down') return toast('নিচে ভরতে একাধিক সারি সিলেক্ট করুন'); if (rng.c1 === rng.c2 && dir === 'right') return toast('ডানে ভরতে একাধিক কলাম সিলেক্ট করুন');
    act(() => { if (dir === 'down') { for (let c = rng.c1; c <= rng.c2; c++) { const src = sh.cells[rng.r1 + ',' + c]; for (let r = rng.r1 + 1; r <= rng.r2; r++) { if (!src) { putCell(r, c, undefined); continue; } const n = clone(src); if (n.f) n.f = shiftFormula(n.f, r - rng.r1, 0); putCell(r, c, n); } } } else { for (let r = rng.r1; r <= rng.r2; r++) { const src = sh.cells[r + ',' + rng.c1]; for (let c = rng.c1 + 1; c <= rng.c2; c++) { if (!src) { putCell(r, c, undefined); continue; } const n = clone(src); if (n.f) n.f = shiftFormula(n.f, 0, c - rng.c1); putCell(r, c, n); } } } });
  }
  function fillSeries() {
    const vert = rng.r2 - rng.r1 >= rng.c2 - rng.c1; act(() => {
      const lines = vert ? rng.c2 - rng.c1 + 1 : rng.r2 - rng.r1 + 1;
      for (let k = 0; k < lines; k++) { const get = i => vert ? val(rng.r1 + i, rng.c1 + k) : val(rng.r1 + k, rng.c1 + i); const n = vert ? rng.r2 - rng.r1 + 1 : rng.c2 - rng.c1 + 1; const a = get(0); const b = n > 1 ? get(1) : null; const text = typeof a === 'string' && /^(.*?)(\d+)$/.exec(a);
        for (let i = 1; i < n; i++) { let v; if (typeof a === 'number') { const step = typeof b === 'number' && n > 2 && i >= 2 ? (typeof get(1) === 'number' ? get(1) - a : 1) : (typeof b === 'number' && n > 1 ? b - a : 1); v = a + step * i; } else if (text) v = text[1] + (parseInt(text[2]) + i); else v = a; const r = vert ? rng.r1 + i : rng.r1 + k, c = vert ? rng.c1 + k : rng.c1 + i; const old = sh.cells[r + ',' + c]; putCell(r, c, { v, ...(old && old.s ? { s: old.s } : (sh.cells[(vert ? rng.r1 : rng.r1 + k) + ',' + (vert ? rng.c1 + k : rng.c1)] || {}).s ? { s: clone(sh.cells[(vert ? rng.r1 : rng.r1 + k) + ',' + (vert ? rng.c1 + k : rng.c1)].s) } : {}) }); } }
    });
  }

  /* ---------- structure: insert/delete rows & cols ---------- */
  function adjustFormulas(axis, at, n) { // n>0 insert, n<0 delete (-n count)
    wb.sheets.forEach((s2, s2i) => { for (const k in s2.cells) { const cell = s2.cells[k]; if (!cell.f) continue;
      const nf = transformRefs(cell.f, (t, shName, role) => { const ti = shName == null ? s2i : wb.sheets.findIndex(x => x.name.toLowerCase() === shName.toLowerCase()); if (ti !== wb.active) return t; const key = axis === 'r' ? 'r' : 'c'; const v = t[key]; if (n > 0) { if (v >= at) t[key] = v + n; return t; } const cnt = -n; if (v >= at && v < at + cnt) { if (role === 'single') return null; if (role === 'start') t[key] = at; else t[key] = at - 1; return t; } if (v >= at + cnt) t[key] = v - cnt; return t; });
      if (nf !== cell.f) cell.f = nf; } });
  }
  function shiftCells(axis, at, n) {
    const out = {}; for (const k in sh.cells) { let [r, c] = k.split(',').map(Number); const v = axis === 'r' ? r : c; let nv = v; if (n > 0) { if (v >= at) nv = v + n; } else { const cnt = -n; if (v >= at && v < at + cnt) continue; if (v >= at + cnt) nv = v - cnt; } if (axis === 'r') r = nv; else c = nv; out[r + ',' + c] = sh.cells[k]; } sh.cells = out;
    const sizes = axis === 'r' ? sh.rowH : sh.colW; const ns = {}; for (const k in sizes) { let v = +k; if (n > 0) { if (v >= at) v += n; } else { const cnt = -n; if (v >= at && v < at + cnt) continue; if (v >= at + cnt) v -= cnt; } ns[v] = sizes[k]; } if (axis === 'r') sh.rowH = ns; else sh.colW = ns;
    sh.merges = sh.merges.map(m => { const lo = axis === 'r' ? 'r1' : 'c1', hi = axis === 'r' ? 'r2' : 'c2'; const o = { ...m }; if (n > 0) { if (o[lo] >= at) { o[lo] += n; o[hi] += n; } else if (o[hi] >= at) o[hi] += n; } else { const cnt = -n; const f = x => x >= at + cnt ? x - cnt : x >= at ? at : x; const a = o[lo] >= at && o[lo] < at + cnt ? at : f(o[lo]); const b = o[hi] >= at && o[hi] < at + cnt ? at - 1 : f(o[hi]); o[lo] = a; o[hi] = b; } return o; }).filter(m => m.r2 >= m.r1 && m.c2 >= m.c1 && (m.r2 > m.r1 || m.c2 > m.c1));
    if (axis === 'r' && sh.hiddenRows) { const nh = {}; for (const k in sh.hiddenRows) { let v = +k; if (n > 0) { if (v >= at) v += n; } else { const cnt = -n; if (v >= at && v < at + cnt) continue; if (v >= at + cnt) v -= cnt; } nh[v] = 1; } sh.hiddenRows = nh; }
  }
  function insertRC(axis, after, count = 1) { const at = axis === 'r' ? (after ? rng.r2 + 1 : rng.r1) : (after ? rng.c2 + 1 : rng.c1); const n = count || (axis === 'r' ? rng.r2 - rng.r1 + 1 : rng.c2 - rng.c1 + 1); act(() => structural(() => { adjustFormulas(axis, at, n); shiftCells(axis, at, n); })); }
  function deleteRC(axis) { const at = axis === 'r' ? rng.r1 : rng.c1; const n = axis === 'r' ? rng.r2 - rng.r1 + 1 : rng.c2 - rng.c1 + 1; act(() => structural(() => { adjustFormulas(axis, at, -n); shiftCells(axis, at, -n); })); }
  async function sizeDlg(axis) {
    const cur = axis === 'c' ? (sh.colW[rng.c1] || BASE_CW) : (sh.rowH[rng.r1] || BASE_RH);
    const v = await promptDlg(axis === 'c' ? 'কলামের প্রস্থ (পিক্সেল)' : 'সারির উচ্চতা (পিক্সেল)', { value: String(Math.round(cur)), type: 'number', inputmode: 'numeric' }); if (v == null) return; const n = clamp(+v || cur, 16, 600);
    act(() => structural(() => { if (axis === 'c') for (let c = rng.c1; c <= rng.c2; c++) sh.colW[c] = n; else for (let r = rng.r1; r <= rng.r2; r++) sh.rowH[r] = n; }));
  }
  function autoFit(axis) {
    const g = document.createElement('canvas').getContext('2d');
    act(() => structural(() => { if (axis === 'c') { for (let c = rng.c1; c <= rng.c2; c++) { let mw = 40; for (const k in sh.cells) { const [r, cc] = k.split(',').map(Number); if (cc !== c) continue; const d = display(r, c); g.font = fontOf(sh.cells[k].s).replace(/[\d.]+px/, m => parseFloat(m) / Z + 'px'); mw = Math.max(mw, g.measureText(d.t.split('\n').reduce((a, b) => a.length > b.length ? a : b, '')).width + 16); } sh.colW[c] = Math.min(500, Math.ceil(mw)); } } else { for (let r = rng.r1; r <= rng.r2; r++) { let lines = 1, fs = 11; for (let c = 0; c <= used().c; c++) { const cell = sh.cells[r + ',' + c]; if (!cell) continue; const s = cell.s || {}; fs = Math.max(fs, s.fs || 11); if (s.wrap) { g.font = fontOf(s).replace(/[\d.]+px/, m => parseFloat(m) / Z + 'px'); const w = sh.colW[c] || BASE_CW; let n = 0; for (const p of display(r, c).t.split('\n')) n += Math.max(1, Math.ceil(g.measureText(p).width / (w - 10))); lines = Math.max(lines, n); } } sh.rowH[r] = Math.max(BASE_RH, Math.round(lines * (fs * 1.3333 + 3) + 8)); } } }));
  }
  function colMenu(c) {
    actionSheet('কলাম ' + colName(rng.c1) + (rng.c1 !== rng.c2 ? '–' + colName(rng.c2) : ''), [
      { icon: 'plus', label: 'বামে কলাম ঢোকান', onClick: () => insertRC('c', false) }, { icon: 'plus', label: 'ডানে কলাম ঢোকান', onClick: () => insertRC('c', true) }, { icon: 'trash', label: 'কলাম মুছুন', danger: true, onClick: () => deleteRC('c') }, { sep: true },
      { icon: 'maximize', label: 'প্রস্থ ঠিক করুন', onClick: () => sizeDlg('c') }, { icon: 'maximize', label: 'অটো-ফিট', onClick: () => autoFit('c') }, { icon: 'sort', label: 'A → Z সাজান', onClick: () => sortBy(true) }, { icon: 'sort', label: 'Z → A সাজান', onClick: () => sortBy(false) }]);
  }
  function rowMenu(r) {
    actionSheet('সারি ' + toBn(rng.r1 + 1) + (rng.r1 !== rng.r2 ? '–' + toBn(rng.r2 + 1) : ''), [
      { icon: 'plus', label: 'উপরে সারি ঢোকান', onClick: () => insertRC('r', false) }, { icon: 'plus', label: 'নিচে সারি ঢোকান', onClick: () => insertRC('r', true) }, { icon: 'trash', label: 'সারি মুছুন', danger: true, onClick: () => deleteRC('r') }, { sep: true },
      { icon: 'maximize', label: 'উচ্চতা ঠিক করুন', onClick: () => sizeDlg('r') }, { icon: 'maximize', label: 'অটো-ফিট', onClick: () => autoFit('r') }, { icon: 'eye', label: 'সারি লুকান', onClick: () => act(() => structural(() => { sh.hiddenRows = sh.hiddenRows || {}; for (let k = rng.r1; k <= rng.r2; k++) sh.hiddenRows[k] = 1; })) }, { icon: 'eye', label: 'সব সারি দেখান', onClick: () => act(() => structural(() => { sh.hiddenRows = {}; })) }]);
  }

  /* ---------- sort / filter ---------- */
  async function sortBy(asc) {
    if (used().r < 20000) return sortByNow(asc);
    const bz = busy('সাজানো হচ্ছে…'); await new Promise(r => setTimeout(r, 40)); try { sortByNow(asc); } finally { bz.done(); }
  }
  function sortByNow(asc) {
    const ur = used(); let r1 = rng.r1, r2 = rng.r2, c1 = rng.c1, c2 = rng.c2; const auto = r1 === r2 && c1 === c2 || isWholeCol();
    if (r1 === r2 && c1 === c2 || isWholeCol()) { r1 = 0; r2 = ur.r; if (c1 === c2 || isWholeCol()) { c1 = 0; c2 = ur.c; } } else if (isWholeRow()) { c1 = 0; c2 = ur.c; }
    if (auto) { const isTot = r => { for (let c = c1; c <= c2; c++) { const x = sh.cells[r + ',' + c]; if (x && x.f && /^\s*(SUM|AVERAGE|COUNT|MAX|MIN|SUBTOTAL)\(/i.test(x.f)) return true; } return false; }; while (r2 > r1 && isTot(r2)) r2--; }
    const key = sel.c; if (key < c1 || key > c2) return toast('সাজানোর কলাম রেঞ্জের ভেতরে থাকতে হবে');
    let start = r1; const topAllText = (() => { for (let c = c1; c <= c2; c++) { const v = val(r1, c); if (v !== null && typeof v !== 'string') return false; } return true; })(); const below = (() => { for (let r = r1 + 1; r <= r2; r++) { const v = val(r, key); if (typeof v === 'number') return true; } return false; })();
    if (r2 > r1 && topAllText && below) { start = r1 + 1; toast('প্রথম সারি হেডার ধরা হয়েছে'); }
    const rows = []; for (let r = start; r <= r2; r++) { const cells = []; for (let c = c1; c <= c2; c++) cells.push(clone(sh.cells[r + ',' + c])); rows.push({ cells, v: val(r, key), from: r }); }
    const rank = v => v === null || v === '' ? 3 : typeof v === 'number' ? 0 : typeof v === 'string' ? 1 : 2;
    rows.sort((a, b) => { const ra = rank(a.v), rb = rank(b.v); if (ra === 3 || rb === 3) return ra === rb ? 0 : ra === 3 ? 1 : -1; if (ra !== rb) return ra - rb; const x = typeof a.v === 'string' ? a.v.toLowerCase() : a.v, y = typeof b.v === 'string' ? b.v.toLowerCase() : b.v; const c = x < y ? -1 : x > y ? 1 : 0; return asc ? c : -c; });
    act(() => rows.forEach((row, i) => row.cells.forEach((cell, j) => { const r = start + i, c = c1 + j; if (cell && cell.f && r !== row.from) cell.f = shiftFormula(cell.f, r - row.from, 0); putCell(r, c, cell); })));
  }
  function filterDlg() {
    const col = sel.c; const u = used(); const vals = new Map(); for (let r = 1; r <= u.r; r++) { const t = display(r, col).t; vals.set(t, (vals.get(t) || 0) + 1); }
    const hiddenNow = new Set(); const list = h('div', { style: { maxHeight: '50vh', overflow: 'auto' } });
    const boxes = [...vals.keys()].sort((a, b) => a.localeCompare(b, 'bn', { numeric: true })).map(t => { const cb = h('input', { type: 'checkbox', checked: true }); list.append(h('label', { class: 'row', style: { padding: '8px 4px', gap: '10px' } }, cb, h('span', { class: 'rt' }, t === '' ? '(ফাঁকা)' : t), h('small', null, toBn(vals.get(t))))); return { t, cb }; });
    modal({ title: 'ফিল্টার — কলাম ' + colName(col), body: list, actions: [{ label: 'বাতিল', ghost: true }, { label: 'সব দেখান', ghost: true, onClick: () => act(() => structural(() => { sh.hiddenRows = {}; })) }, { label: 'প্রয়োগ', primary: true, onClick: () => { const keep = new Set(boxes.filter(b => b.cb.checked).map(b => b.t)); act(() => structural(() => { sh.hiddenRows = {}; for (let r = 1; r <= u.r; r++) if (!keep.has(display(r, col).t)) sh.hiddenRows[r] = 1; })); } }] });
  }

  /* ---------- find / go to / functions ---------- */
  async function gotoDlg() { const v = await promptDlg('যে ঘরে যাবেন', { placeholder: 'যেমন: B12 বা A1:C5' }); if (!v) return; const g = parseRange(v.toUpperCase()); if (!g) return toast('ঠিকানা বুঝতে পারিনি'); sel = { r: g.r1, c: g.c1 }; rng = { ...g }; ensureVisible(g.r1, g.c1); draw(); }
  function findDlg() {
    const f = h('input', { class: 'inp', placeholder: 'খুঁজুন' }), r = h('input', { class: 'inp', placeholder: 'বদলে লিখুন' }), info = h('div', { class: 'hint' }, '');
    let pos = -1; const matches = () => { const q = f.value.toLowerCase(); if (!q) return []; const out = []; const keys = Object.keys(sh.cells).map(k => k.split(',').map(Number)).sort((a, b) => a[0] - b[0] || a[1] - b[1]); for (const [rr, cc] of keys) { const cell = sh.cells[rr + ',' + cc]; const t = (cell.f ? '=' + cell.f : display(rr, cc).t + ' ' + rawText(cell)).toLowerCase(); if (t.includes(q)) out.push([rr, cc]); } return out; };
    const next = () => { const m = matches(); if (!m.length) { info.textContent = 'পাওয়া যায়নি'; return; } pos = (pos + 1) % m.length; const [rr, cc] = m[pos]; select(rr, cc); info.textContent = `${toBn(pos + 1)} / ${toBn(m.length)}`; };
    const replAll = () => { const q = f.value; if (!q) return; const re = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'); let n = 0; act(() => { for (const [rr, cc] of matches()) { const cell = clone(sh.cells[rr + ',' + cc]); if (cell.f) { cell.f = cell.f.replace(re, () => { n++; return r.value; }); } else if (typeof cell.v === 'string') { cell.v = cell.v.replace(re, () => { n++; return r.value; }); } else { const p = parseInput(rawText(cell).replace(re, () => { n++; return r.value; })); if (p.v !== undefined) cell.v = p.v; } putCell(rr, cc, cell); } }); info.textContent = `${toBn(n)}টি বদলানো হয়েছে`; };
    const body = h('div', { style: { display: 'grid', gap: '10px' } }, f, r, info, h('div', { style: { display: 'flex', gap: '8px' } }, h('button', { class: 'btn', type: 'button', onclick: next }, 'পরেরটি'), h('button', { class: 'btn', type: 'button', onclick: replAll }, 'সব বদলান')));
    f.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); next(); } });
    modal({ title: 'খুঁজুন ও বদলান', body, actions: [{ label: 'বন্ধ', primary: true }] }); setTimeout(() => f.focus(), 100);
  }
  const FN_DESC = { SUM: 'যোগফল', AVERAGE: 'গড়', COUNT: 'সংখ্যা গণনা', COUNTA: 'খালি নয় এমন ঘর', MAX: 'সর্বোচ্চ', MIN: 'সর্বনিম্ন', IF: 'শর্ত: IF(শর্ত, হ্যাঁ, না)', VLOOKUP: 'টেবিল থেকে খুঁজে আনা', SUMIF: 'শর্তসাপেক্ষ যোগ', COUNTIF: 'শর্তসাপেক্ষ গণনা', ROUND: 'গোল করা', TODAY: 'আজকের তারিখ', NOW: 'এখনকার সময়', CONCAT: 'লেখা জোড়া', TEXT: 'ফরম্যাট করা লেখা', XLOOKUP: 'আধুনিক লুকআপ', IFERROR: 'ত্রুটি হলে বিকল্প', LEN: 'অক্ষর সংখ্যা', DATEDIF: 'তারিখের ব্যবধান', PMT: 'কিস্তির হিসাব' };
  function fnPicker() {
    const q = h('input', { class: 'inp', placeholder: 'ফাংশন খুঁজুন…' }); const list = h('div', { style: { maxHeight: '46vh', overflow: 'auto', marginTop: '8px' } });
    let ov; const show = () => { const t = q.value.toUpperCase(); list.replaceChildren(...FUNCTIONS.filter(n => n.includes(t)).slice(0, 80).map(n => h('button', { class: 'sheet-i', type: 'button', onclick: () => { ov.close(); insertFn(n); } }, h('span', { class: 'sheet-tx' }, h('span', { style: { fontWeight: 600 } }, n), FN_DESC[n] ? h('small', null, FN_DESC[n]) : null)))); };
    q.addEventListener('input', show); show(); ov = modal({ title: 'ফাংশন (fx)', body: h('div', null, q, list), wide: true, actions: [{ label: 'বন্ধ', ghost: true }] }); setTimeout(() => q.focus(), 100);
  }
  function insertFn(name) {
    if (!editing) startEdit('=' + name + '(', 'bar'); else { const inp = editing.src === 'cell' ? edTa : fInput; const p = inp.selectionStart; inp.value = inp.value.slice(0, p) + name + '(' + inp.value.slice(p); editing.text = inp.value; edTa.value = fInput.value = inp.value; }
    fInput.focus(); const l = fInput.value.length; fInput.setSelectionRange(l, l);
  }
  function autoSum(fnName = 'SUM') {
    const u = used(); let r = sel.r, c = sel.c;
    if (rng.r1 !== rng.r2 || rng.c1 !== rng.c2) { const rr = rng.r2 + 1, cc = rng.c1; const f = rng.c1 === rng.c2 || rng.r2 - rng.r1 >= rng.c2 - rng.c1 ? `${fnName}(${rangeStr(rng)})` : `${fnName}(${rangeStr(rng)})`; if (rng.c1 === rng.c2) { setInput(rng.r2 + 1, rng.c1, '=' + f); } else { act(() => { for (let cc2 = rng.c1; cc2 <= rng.c2; cc2++) putCell(rng.r2 + 1, cc2, { f: `${fnName}(${addr(rng.r1, cc2)}:${addr(rng.r2, cc2)})` }); }); } return; }
    let r0 = r - 1; while (r0 >= 0 && typeof val(r0, c) === 'number') r0--; if (r0 < r - 1) { setInput(r, c, `=${fnName}(${addr(r0 + 1, c)}:${addr(r - 1, c)})`); return; }
    let c0 = c - 1; while (c0 >= 0 && typeof val(r, c0) === 'number') c0--; if (c0 < c - 1) { setInput(r, c, `=${fnName}(${addr(r, c0 + 1)}:${addr(r, c - 1)})`); return; }
    startEdit('=' + fnName + '(', 'bar'); fInput.focus();
  }

  /* ---------- sheets (tabs) ---------- */
  function renderTabs() {
    tabsBar.replaceChildren(...wb.sheets.map((s, i) => h('button', { class: 'tab' + (i === wb.active ? ' on' : ''), type: 'button', onclick: () => { if (i === wb.active) return sheetMenu(i); switchSheet(i); } }, s.name)), h('button', { class: 'tb', type: 'button', 'aria-label': 'নতুন শিট', onclick: addSheet }, icon('plus', 20)), status);
  }
  function switchSheet(i) { cancelEdit(); wb.active = i; sh = wb.sheets[i]; sel = { r: 0, c: 0 }; rng = { r1: 0, c1: 0, r2: 0, c2: 0 }; nrows = 120; ncols = 26; relayout(); grid.scrollTop = grid.scrollLeft = 0; renderTabs(); draw(); as.mark(); }
  function addSheet() { begin(); sheetsStructural(() => { let n = wb.sheets.length + 1; while (wb.sheets.some(s => s.name === 'Sheet' + n)) n++; wb.sheets.push(newSheet('Sheet' + n)); }); end(); switchSheet(wb.sheets.length - 1); }
  async function sheetMenu(i) {
    actionSheet(wb.sheets[i].name, [
      { icon: 'pen', label: 'নাম পরিবর্তন', onClick: async () => { const v = await promptDlg('শিটের নাম', { value: wb.sheets[i].name }); if (!v || !v.trim()) return; const nn = v.trim().replace(/[\\/?*[\]:]/g, '_').slice(0, 31); if (wb.sheets.some((s, k) => k !== i && s.name.toLowerCase() === nn.toLowerCase())) return toast('এই নামে আরেকটি শিট আছে'); act(() => sheetsStructural(() => { const old = wb.sheets[i].name; wb.sheets.forEach(s => { for (const k in s.cells) { const c = s.cells[k]; if (c.f && c.f.includes(old)) c.f = c.f.split("'" + old + "'!").join("'" + nn + "'!").split(old + '!').join((/^[A-Za-z_]\w*$/.test(nn) ? nn : "'" + nn + "'") + '!'); } }); wb.sheets[i].name = nn; })); renderTabs(); } },
      { icon: 'copy', label: 'কপি তৈরি', onClick: () => { begin(); sheetsStructural(() => { const c = cloneSheet(wb.sheets[i]); c.name = wb.sheets[i].name + ' (2)'; wb.sheets.splice(i + 1, 0, c); }); end(); switchSheet(i + 1); } },
      { icon: 'left', label: 'বামে সরান', disabled: i === 0, onClick: () => { begin(); sheetsStructural(() => { const [s] = wb.sheets.splice(i, 1); wb.sheets.splice(i - 1, 0, s); wb.active = i - 1; }); end(); sh = wb.sheets[wb.active]; renderTabs(); draw(); } },
      { icon: 'right', label: 'ডানে সরান', disabled: i === wb.sheets.length - 1, onClick: () => { begin(); sheetsStructural(() => { const [s] = wb.sheets.splice(i, 1); wb.sheets.splice(i + 1, 0, s); wb.active = i + 1; }); end(); sh = wb.sheets[wb.active]; renderTabs(); draw(); } },
      { icon: 'trash', label: 'শিট মুছুন', danger: true, disabled: wb.sheets.length < 2, onClick: async () => { if (!(await confirmDlg('শিট মুছবেন?', `"${wb.sheets[i].name}" শিটের সব তথ্য মুছে যাবে।`, { ok: 'মুছুন', danger: true }))) return; begin(); sheetsStructural(() => { wb.sheets.splice(i, 1); wb.active = Math.max(0, Math.min(wb.active, wb.sheets.length - 1)); }); end(); sh = wb.sheets[wb.active]; relayout(); renderTabs(); draw(); } }]);
  }

  /* ---------- toolbar ---------- */
  const T = {}; const mk = (id, ic, label, fn, o) => (T[id] = btn(ic, label, fn, o));
  let fillC = '#fde047', fontC = '#d92d20';
  const colorBtn = (ic, label, get, set, key) => { const sw = h('i', { style: { background: get() } }); const b = h('button', { class: 'tb colorbtn', type: 'button', 'aria-label': label, title: label, onmousedown: e => e.preventDefault() }, icon(ic, 20), sw); b.addEventListener('click', async () => { const c = await pickColor({ title: label, current: get(), none: true, noneLabel: 'রঙ সরান' }); if (c === undefined) return; if (c === null) { applyStyle({ [key]: undefined }); return; } set(c); sw.style.background = c; applyStyle({ [key]: c }); }); return b; };
  const sizeLab = h('span', { class: 'tb-t' }, '১১');
  const tabsDef = {
    home: () => [mk('copy', 'copy', 'কপি', () => copy(false)), mk('cut', 'cut', 'কাট', () => copy(true)), btn('paste', 'পেস্ট', pasteMenu), h('span', { class: 'tsep' }),
      mk('b', 'bold', 'বোল্ড', () => toggleStyle('b')), mk('i', 'italic', 'ইটালিক', () => toggleStyle('i')), mk('u', 'underline', 'আন্ডারলাইন', () => toggleStyle('u')), mk('s', 'strike', 'কাটা', () => toggleStyle('s')),
      btn('minus', 'ছোট ফন্ট', () => applyStyle({ fs: Math.max(6, (styleOf(sel.r, sel.c).fs || 11) - 1) })), h('button', { class: 'tb', type: 'button', onclick: () => actionSheet('ফন্টের মাপ', [8, 9, 10, 11, 12, 14, 16, 18, 20, 24, 28, 36, 48].map(n => ({ icon: 'type', label: toBn(n), active: (styleOf(sel.r, sel.c).fs || 11) === n, onClick: () => applyStyle({ fs: n === 11 ? undefined : n }) }))), onmousedown: e => e.preventDefault(), style: { minWidth: '38px' } }, sizeLab), btn('plus', 'বড় ফন্ট', () => applyStyle({ fs: Math.min(72, (styleOf(sel.r, sel.c).fs || 11) + 1) })),
      colorBtn('fontColor', 'লেখার রঙ', () => fontC, c => fontC = c, 'color'), colorBtn('fill', 'ঘরের রঙ', () => fillC, c => fillC = c, 'bg'), h('span', { class: 'tsep' }),
      mk('aL', 'alignL', 'বামে', () => applyStyle({ ha: styleOf(sel.r, sel.c).ha === 'left' ? undefined : 'left' })), mk('aC', 'alignC', 'মাঝে', () => applyStyle({ ha: styleOf(sel.r, sel.c).ha === 'center' ? undefined : 'center' })), mk('aR', 'alignR', 'ডানে', () => applyStyle({ ha: styleOf(sel.r, sel.c).ha === 'right' ? undefined : 'right' })),
      btn('arrowUp', 'উপরে', () => applyStyle({ va: 'top' })), btn('hr', 'মাঝখানে', () => applyStyle({ va: 'middle' })), btn('arrowDown', 'নিচে', () => applyStyle({ va: 'bottom' })),
      mk('wrap', 'pageBreak', 'র‍্যাপ টেক্সট', () => applyStyle({ wrap: styleOf(sel.r, sel.c).wrap ? undefined : 1 })), btn('merge', 'ঘর মেলান / ভাগ', () => actionSheet('ঘর', [{ icon: 'merge', label: 'ঘর মেলান', onClick: mergeSel }, { icon: 'grid', label: 'মেলানো ছাড়ুন', onClick: unmergeSel }])),
      btn('fill', 'শর্তসাপেক্ষ রং', cfDlg, { text: 'কন্ডিশনাল' }), btn('borders', 'বর্ডার', () => actionSheet('বর্ডার', [['all', 'সব দিকে'], ['outer', 'বাইরের দিকে'], ['bottom', 'নিচে'], ['top', 'উপরে'], ['none', 'বর্ডার মুছুন']].map(([k, t]) => ({ icon: 'borders', label: t, onClick: () => setBorder(k) })))), h('span', { class: 'tsep' }),
      btn('list', 'সংখ্যার ধরন', () => actionSheet('সংখ্যার ধরন', PRESETS.map(([f, t]) => ({ icon: 'sigma', label: t, sub: f === 'General' ? '' : f, active: (styleOf(sel.r, sel.c).nf || 'General') === f, onClick: () => setNf(f) })).concat([{ sep: true }, { icon: 'pen', label: 'নিজের ফরম্যাট…', onClick: async () => { const v = await promptDlg('কাস্টম ফরম্যাট', { value: styleOf(sel.r, sel.c).nf || '', placeholder: '#,##0.00', hint: 'যেমন: 0.00, #,##0, dd/mm/yyyy, "৳"#,##0' }); if (v) setNf(v.trim()); } }])), { text: 'ফরম্যাট' }),
      btn('', '৳', () => setNf('"৳"#,##0.00'), { text: '৳' }), btn('', '%', () => setNf('0%'), { text: '%' }), btn('', '.0←', () => changeDecimals(-1), { text: '.0−' }), btn('', '.00→', () => changeDecimals(1), { text: '.00+' }),
      h('span', { class: 'tsep' }), btn('eraser', 'মুছুন', () => actionSheet('মুছুন', [{ icon: 'eraser', label: 'শুধু লেখা/মান', onClick: () => clearRange('contents') }, { icon: 'eraser', label: 'শুধু ফরম্যাট', onClick: () => clearRange('format') }, { icon: 'trash', label: 'সব কিছু', onClick: () => clearRange('all') }]))],
    insert: () => [btn('plus', 'উপরে সারি', () => insertRC('r', false), { text: 'সারি ↑' }), btn('plus', 'নিচে সারি', () => insertRC('r', true), { text: 'সারি ↓' }), btn('plus', 'বামে কলাম', () => insertRC('c', false), { text: 'কলাম ←' }), btn('plus', 'ডানে কলাম', () => insertRC('c', true), { text: 'কলাম →' }), h('span', { class: 'tsep' }),
      btn('minus', 'সারি মুছুন', () => deleteRC('r'), { text: 'সারি' }), btn('minus', 'কলাম মুছুন', () => deleteRC('c'), { text: 'কলাম' }), h('span', { class: 'tsep' }),
      btn('sigma', 'অটো সাম', () => autoSum('SUM'), { text: 'Σ যোগ' }), btn('sigma', 'গড়', () => autoSum('AVERAGE'), { text: 'গড়' }), btn('sigma', 'সংখ্যা', () => autoSum('COUNT'), { text: 'গণনা' }), btn('sigma', 'সর্বোচ্চ', () => autoSum('MAX'), { text: 'Max' }), btn('sigma', 'সর্বনিম্ন', () => autoSum('MIN'), { text: 'Min' }), btn('', 'fx', fnPicker, { text: 'fx ফাংশন' }), h('span', { class: 'tsep' }), btn('chart', 'চার্ট', chartDlg, { text: 'চার্ট' })],
    data: () => [btn('sort', 'A→Z', () => sortBy(true), { text: 'A→Z' }), btn('sort', 'Z→A', () => sortBy(false), { text: 'Z→A' }), btn('filter', 'ফিল্টার', filterDlg, { text: 'ফিল্টার' }), btn('search', 'খুঁজুন', findDlg, { text: 'খুঁজুন' }), h('span', { class: 'tsep' }),
      btn('arrowDown', 'নিচে ভরুন', () => fill('down'), { text: 'নিচে ভরুন' }), btn('arrowR', 'ডানে ভরুন', () => fill('right'), { text: 'ডানে ভরুন' }), btn('plus', 'ক্রমিক', fillSeries, { text: '১,২,৩…' }), h('span', { class: 'tsep' }),
      btn('lock', 'ফ্রিজ', () => actionSheet('ফ্রিজ পেন', [{ icon: 'lock', label: 'প্রথম সারি ফ্রিজ', onClick: () => act(() => structural(() => { sh.freeze = { r: 1, c: sh.freeze.c }; })) }, { icon: 'lock', label: 'প্রথম কলাম ফ্রিজ', onClick: () => act(() => structural(() => { sh.freeze = { r: sh.freeze.r, c: 1 }; })) }, { icon: 'lock', label: 'এই ঘরের আগ পর্যন্ত ফ্রিজ', onClick: () => act(() => structural(() => { sh.freeze = { r: sel.r, c: sel.c }; })) }, { icon: 'unlock', label: 'ফ্রিজ বন্ধ', onClick: () => act(() => structural(() => { sh.freeze = { r: 0, c: 0 }; })) }]), { text: 'ফ্রিজ' })],
    view: () => [btn('zoomOut', 'ছোট', () => setZoom(Z - .1)), h('span', { class: 'tb-t', style: { minWidth: '44px', textAlign: 'center' } }, zoomLab), btn('zoomIn', 'বড়', () => setZoom(Z + .1)), btn('maximize', '১০০%', () => setZoom(1), { text: '১০০%' }), h('span', { class: 'tsep' }),
      btn('grid', 'গ্রিডলাইন', () => { showGrid = !showGrid; draw(); }, { text: 'গ্রিড' }), btn('type', 'বাংলা সংখ্যা', () => { wb.bn = !wb.bn; changed(); toast(wb.bn ? 'বাংলা সংখ্যা চালু' : 'ইংরেজি সংখ্যা'); }, { text: '১২৩ ⇄ 123' }), h('span', { class: 'tsep' }),
      btn('maximize', 'কলামের প্রস্থ', () => sizeDlg('c'), { text: 'প্রস্থ' }), btn('maximize', 'সারির উচ্চতা', () => sizeDlg('r'), { text: 'উচ্চতা' }), btn('maximize', 'অটো-ফিট', () => { autoFit('c'); }, { text: 'অটো-ফিট' })],
  };
  const zoomLab = h('span', null, '১০০%');
  const TABS = [['home', 'হোম'], ['insert', 'ঢোকান'], ['data', 'ডাটা'], ['view', 'দেখুন']];
  let curTab = 'home'; const tabsEl = h('div', { class: 'tabs' }); const toolsEl = h('div', { class: 'tools' }); const cache = {};
  function showTab(k) { curTab = k; [...tabsEl.children].forEach((b, i) => b.classList.toggle('on', TABS[i][0] === k)); toolsEl.replaceChildren(...(cache[k] ||= tabsDef[k]().filter(Boolean))); syncToolbar(); }
  TABS.forEach(([k, t]) => tabsEl.append(h('button', { class: 'tab', type: 'button', onclick: () => showTab(k) }, t)));
  function syncToolbar() { const s = styleOf(sel.r, sel.c); const set = (id, on) => T[id] && T[id].classList.toggle('on', !!on); set('b', s.b); set('i', s.i); set('u', s.u); set('s', s.s); set('aL', s.ha === 'left'); set('aC', s.ha === 'center'); set('aR', s.ha === 'right'); set('wrap', s.wrap); sizeLab.textContent = toBn(s.fs || 11); zoomLab.textContent = toBn(Math.round(Z * 100)) + '%'; }

  /* ---------- chart ---------- */
  function chartDlg() {
    const g = { ...rng }; if (g.r1 === g.r2 && g.c1 === g.c2) { const u = used(); g.r1 = 0; g.c1 = 0; g.r2 = u.r; g.c2 = u.c; }
    const labels = [], series = []; const hasHead = typeof val(g.r1, g.c1 + 1) === 'string' || typeof val(g.r1, g.c1) === 'string';
    const startR = hasHead ? g.r1 + 1 : g.r1; for (let r = startR; r <= g.r2; r++) labels.push(display(r, g.c1).t || String(r - startR + 1));
    for (let c = g.c1 + 1; c <= g.c2; c++) series.push({ name: hasHead ? display(g.r1, c).t : 'সিরিজ ' + (c - g.c1), data: Array.from({ length: g.r2 - startR + 1 }, (_, i) => { const v = val(startR + i, c); return typeof v === 'number' ? v : 0; }) });
    if (!series.length) return toast('চার্টের জন্য অন্তত দুটি কলামের ডাটা সিলেক্ট করুন (প্রথমটি নাম, বাকিগুলো সংখ্যা)');
    let type = 'bar'; const cvs = h('canvas', { width: 640, height: 400, style: { width: '100%', borderRadius: '10px', background: '#fff' } });
    const draw2 = () => drawChart(cvs, type, labels, series); const seg = h('div', { class: 'seg', style: { marginBottom: '10px' } }, [['bar', 'বার'], ['line', 'লাইন'], ['pie', 'পাই']].map(([k, t]) => h('button', { type: 'button', class: k === type ? 'on' : '', onclick: e => { type = k; [...seg.children].forEach(b => b.classList.toggle('on', b === e.target)); draw2(); } }, t)));
    modal({ title: 'চার্ট', body: h('div', null, seg, cvs), wide: true, actions: [{ label: 'বন্ধ', ghost: true }, { label: 'ছবি হিসেবে সেভ', primary: true, onClick: async () => { const b = await new Promise(r => cvs.toBlob(r, 'image/png')); const { offerOutput } = await import('./edkit.js'); await offerOutput(ctx, { blob: b, name: baseName(ctx.meta.name) + ' চার্ট.png', kind: 'image' }); return false; } }] }); setTimeout(draw2, 60);
  }
  function drawChart(cvs, type, labels, series) {
    const g = cvs.getContext('2d'), W = cvs.width, H = cvs.height; g.fillStyle = '#fff'; g.fillRect(0, 0, W, H); const P = ['#3157e0', '#e4572e', '#14884f', '#f5a623', '#8a4fd8', '#0e7090', '#d92d20', '#6a7189']; g.font = `15px ${FONT_FAM}`; g.textBaseline = 'middle';
    if (type === 'pie') { const d = series[0].data.map(v => Math.max(0, v)); const tot = d.reduce((a, b) => a + b, 0) || 1; let a0 = -Math.PI / 2; const cx = W * .35, cy = H / 2, R = Math.min(W * .3, H * .42); d.forEach((v, i) => { const a1 = a0 + v / tot * Math.PI * 2; g.beginPath(); g.moveTo(cx, cy); g.arc(cx, cy, R, a0, a1); g.closePath(); g.fillStyle = P[i % P.length]; g.fill(); a0 = a1; }); labels.slice(0, 12).forEach((l, i) => { g.fillStyle = P[i % P.length]; g.fillRect(W * .7, 40 + i * 28, 14, 14); g.fillStyle = '#222'; g.textAlign = 'left'; g.fillText(`${l} (${Math.round(d[i] / tot * 100)}%)`, W * .7 + 22, 48 + i * 28); }); return; }
    const L = 60, Rr = 20, Tp = 30, B = 70; const all = series.flatMap(s => s.data); let mx = Math.max(...all, 0), mn = Math.min(...all, 0); if (mx === mn) mx = mn + 1; const step = Math.pow(10, Math.floor(Math.log10(mx - mn))) / (((mx - mn) / Math.pow(10, Math.floor(Math.log10(mx - mn)))) < 3 ? 5 : 2); mx = Math.ceil(mx / step) * step; mn = Math.floor(mn / step) * step;
    const y = v => Tp + (H - Tp - B) * (1 - (v - mn) / (mx - mn)); g.strokeStyle = '#e1e4ee'; g.fillStyle = '#6a7189'; g.textAlign = 'right'; for (let v = mn; v <= mx + 1e-9; v += step) { g.beginPath(); g.moveTo(L, y(v)); g.lineTo(W - Rr, y(v)); g.stroke(); g.fillText(formatValue(v, 'General').text, L - 8, y(v)); }
    const n = labels.length, bw = (W - L - Rr) / n; g.textAlign = 'center'; labels.forEach((l, i) => { g.fillStyle = '#444'; g.save(); g.translate(L + bw * (i + .5), H - B + 14); if (n > 8) g.rotate(-Math.PI / 5); g.textAlign = n > 8 ? 'right' : 'center'; g.fillText(l.slice(0, 14), 0, 8); g.restore(); });
    series.forEach((s, si) => { g.fillStyle = g.strokeStyle = P[si % P.length]; if (type === 'bar') { const w = bw * .8 / series.length; s.data.forEach((v, i) => { const x = L + bw * i + bw * .1 + w * si; g.fillRect(x, Math.min(y(v), y(0)), w - 2, Math.abs(y(v) - y(0))); }); } else { g.lineWidth = 3; g.beginPath(); s.data.forEach((v, i) => { const x = L + bw * (i + .5); i ? g.lineTo(x, y(v)) : g.moveTo(x, y(v)); }); g.stroke(); s.data.forEach((v, i) => { g.beginPath(); g.arc(L + bw * (i + .5), y(v), 4, 0, 7); g.fill(); }); } });
    if (series.length > 1 || series[0].name) series.forEach((s, i) => { g.fillStyle = P[i % P.length]; g.fillRect(L + i * 130, 8, 12, 12); g.fillStyle = '#222'; g.textAlign = 'left'; g.fillText(s.name.slice(0, 12), L + i * 130 + 18, 15); });
  }

  /* ---------- export ---------- */
  function displayHtml(si) {
    const s = wb.sheets[si]; const u = eng.used(si); const colsN = u.c + 1, rowsN = u.r + 1; let totalW = 0;
    for (let c = 0; c < colsN; c++) totalW += s.colW[c] || BASE_CW;
    const mo = new Map(), cov = new Set(); for (const m of s.merges) { mo.set(m.r1 + ',' + m.c1, m); for (let r = m.r1; r <= m.r2; r++) for (let c = m.c1; c <= m.c2; c++) if (r !== m.r1 || c !== m.c1) cov.add(r + ',' + c); }
    let t = `<table class="xlt" style="table-layout:fixed;width:${totalW}px"><colgroup>${Array.from({ length: colsN }, (_, c) => `<col style="width:${s.colW[c] || BASE_CW}px">`).join('')}</colgroup><tbody>`;
    for (let r = 0; r < rowsN; r++) { if (s.hiddenRows && s.hiddenRows[r]) continue; t += `<tr style="height:${s.rowH[r] || BASE_RH}px">`; for (let c = 0; c < colsN; c++) { const key = r + ',' + c; if (cov.has(key)) continue; const cell = s.cells[key]; const st = (cell && cell.s) || {}; let v = eng.value(si, r, c); if (v && v.rows) v = v.a[0][0]; const f = formatValue(v, st.nf); const cfH = s.cf && s.cf.length && si === wb.active ? cfOf(r, c) : null; const m = mo.get(key); const bd = st.bd || {}; const bdc = k => bd[k] ? `border-${{ t: 'top', b: 'bottom', l: 'left', r: 'right' }[k]}:1px solid ${bd[k] === 1 ? '#222' : bd[k]};` : ''; const ha = st.ha || (typeof v === 'number' ? 'right' : 'left'); t += `<td${m ? ` colspan="${m.c2 - m.c1 + 1}" rowspan="${m.r2 - m.r1 + 1}"` : ''} style="text-align:${ha};vertical-align:${st.va === 'top' ? 'top' : st.va === 'bottom' ? 'bottom' : 'middle'};${(cfH && cfH.bg) || st.bg ? `background:${(cfH && cfH.bg) || st.bg};` : ''}${(cfH && cfH.color) || st.color ? `color:${(cfH && cfH.color) || st.color};` : ''}${st.b ? 'font-weight:bold;' : ''}${st.i ? 'font-style:italic;' : ''}${st.u ? 'text-decoration:underline;' : ''}${st.fs ? `font-size:${st.fs * 1.333}px;` : ''}${st.wrap ? 'white-space:pre-wrap;' : 'white-space:nowrap;overflow:hidden;'}${bdc('t')}${bdc('b')}${bdc('l')}${bdc('r')}">${esc(wb.bn && typeof v === 'number' ? toBnS(f.text) : f.text)}</td>`; } t += '</tr>'; }
    return { html: t + '</tbody></table>', w: totalW };
  }
  const XL_CSS = `.pdfdoc{font-family:system-ui,'Noto Sans Bengali','Kalpurush','Nirmala UI',Arial,sans-serif;font-size:14px;color:#111}.xlt{border-collapse:collapse}.xlt td{border:1px solid #cfd4e2;padding:2px 5px;line-height:1.25;overflow:hidden}`;
  const exportsList = [
    { icon: 'pdf', label: 'বর্তমান শিট PDF করুন', sub: 'প্রস্থ অনুযায়ী পাতায় ভাগ হয়ে', async run() { const b = busy('PDF তৈরি হচ্ছে…'); try { const { html, w } = displayHtml(wb.active); const holder = h('div'); const avail = 1123 - 80; const z = w > avail ? avail / w : 1; holder.innerHTML = `<div style="zoom:${z}">${html}</div>`; const { paginatedPdf } = await import('./pdfexport.js'); const bytes = await paginatedPdf(holder, { css: XL_CSS, title: ctx.meta.name, landscape: true, margin: 40, onProgress: (i, n) => b.set(`পাতা ${toBn(i)}/${toBn(n)}`) }); return { blob: new Blob([bytes], { type: 'application/pdf' }), name: baseName(ctx.meta.name) + '.pdf', kind: 'pdf' }; } finally { b.done(); } } },
    { icon: 'file', label: 'CSV হিসেবে সেভ (বর্তমান শিট)', async run() { const text = sheetToCSV(sh, (r, c) => display(r, c).t); await saveToDevice(new Blob([text], { type: 'text/csv;charset=utf-8' }), baseName(ctx.meta.name) + '.csv'); return null; } },
    { icon: 'print', label: 'প্রিন্ট', async run() { const { html } = displayHtml(wb.active); const holder = h('div'); holder.innerHTML = html; const { printElement } = await import('./pdfexport.js'); printElement(holder, XL_CSS, ctx.meta.name); return null; } },
  ];
  ctx.afterExport = async r => { const { offerOutput } = await import('./edkit.js'); return offerOutput(ctx, r); };

  /* ---------- assemble ---------- */
  async function serialize() {
    if (heavy) {   // big workbook: serialise once, build the .xlsx in the background worker so typing/scrolling never stalls
      const { call } = await import('./workclient.js'); const snap = serializeWb(wb);
      const buf = await call('xlsxPack', { snap, title: baseName(ctx.meta.name), author: (await getSettings()).author || '' });
      return { buf, snap: null };
    }
    const buf = await wbToXlsx(wb, (si, r, c) => eng.value(si, r, c), { title: baseName(ctx.meta.name), author: (await getSettings()).author || '' });
    return { buf, snap: serializeWb(wb) };
  }

  /* ---- data tools: remove duplicates, text → columns ---- */
  function dataRange() { const u = used(); let { r1, c1, r2, c2 } = rng; if (r1 === r2 && c1 === c2) { r1 = 0; r2 = u.r; c1 = 0; c2 = u.c; } else if (isWholeCol()) { r1 = 0; r2 = u.r; } else if (isWholeRow()) { c1 = 0; c2 = u.c; } return { r1, c1, r2, c2 }; }
  function removeDuplicates() {
    const { r1, c1, r2, c2 } = dataRange(); if (r2 <= r1) return toast('কমপক্ষে দুটি সারি বেছে নিন');
    const hasHead = (() => { for (let c = c1; c <= c2; c++) { const v = val(r1, c); if (v !== null && v !== '' && typeof v !== 'string') return false; } return true; })();
    const start = hasHead ? r1 + 1 : r1, seen = new Set(), keep = [];
    for (let r = start; r <= r2; r++) {
      const cells = []; let key = '', empty = true;
      for (let c = c1; c <= c2; c++) { const v = val(r, c); if (v !== null && v !== '') empty = false; key += (typeof v === 'string' ? v.trim().toLowerCase() : String(v)) + '\u0001'; cells.push(clone(sh.cells[r + ',' + c])); }
      if (empty) continue; if (seen.has(key)) continue; seen.add(key); keep.push({ cells, from: r });
    }
    const removed = (r2 - start + 1) - keep.length; if (!removed) return toast('কোনো ডুপ্লিকেট সারি পাওয়া যায়নি');
    act(() => {
      keep.forEach((row, i) => row.cells.forEach((cell, j) => { const r = start + i, c = c1 + j; if (cell && cell.f && r !== row.from) cell.f = shiftFormula(cell.f, r - row.from, 0); putCell(r, c, cell); }));
      for (let r = start + keep.length; r <= r2; r++) for (let c = c1; c <= c2; c++) putCell(r, c, undefined);
    });
    toast(`${toBn(removed)}টি ডুপ্লিকেট সারি মোছা হয়েছে`);
  }
  async function textToColumns() {
    const { r1, c1, r2 } = dataRange(); const DELIMS = [[',', 'কমা ( , )'], [';', 'সেমিকোলন ( ; )'], ['\t', 'ট্যাব'], [' ', 'স্পেস'], ['-', 'হাইফেন ( - )'], ['/', 'স্ল্যাশ ( / )'], ['|', 'পাইপ ( | )'], ['custom', 'নিজে লিখব…']];
    const d = await new Promise(res => { let done = false; const fin = v => { if (!done) { done = true; res(v); } }; const ov = actionSheet('কোন চিহ্ন দিয়ে ভাগ হবে?', DELIMS.map(([k, tt]) => ({ icon: 'table', label: tt, onClick: async () => { if (k === 'custom') { const v = await promptDlg('ভাগ করার চিহ্ন', { value: '' }); fin(v ? v : null); } else fin(k); } }))); const o = ov.el; const obs = new MutationObserver(() => { if (!document.body.contains(o)) { obs.disconnect(); setTimeout(() => fin(null), 600); } }); obs.observe(document.body, { childList: true }); });
    if (!d) return; let maxParts = 1;
    act(() => {
      for (let r = r1; r <= r2; r++) { const v = val(r, c1); if (typeof v !== 'string' || !v.includes(d)) continue; const parts = v.split(d).map(x => x.trim()); maxParts = Math.max(maxParts, parts.length); parts.forEach((x, i) => { const cell = parseInput(x); const old = clone(sh.cells[r + ',' + (c1 + i)]); if (old && old.s && i === 0) cell.s = old.s; putCell(r, c1 + i, cell); }); }
    });
    toast(maxParts > 1 ? `${toBn(maxParts)}টি কলামে ভাগ হয়েছে` : 'ভাগ করার মতো কিছু পাওয়া যায়নি');
  }

  /* ---- data validation: dropdown + rule dialog ---- */
  function openDropdown(r, c, rule) {
    const items = dvItems(rule, dvRead); if (!items.length) return toast('তালিকা ফাঁকা — ভ্যালিডেশন নিয়ম ঠিক করুন');
    const cur = String(val(r, c) ?? '');
    actionSheet('একটি মান বেছে নিন', [...items.map(v => ({ icon: v === cur ? 'check' : 'down', label: v, onClick: () => act(() => setInput(r, c, v)) })), ...(rule.allowBlank !== false ? [{ sep: true }, { icon: 'trash', label: 'ঘর খালি করুন', onClick: () => act(() => setInput(r, c, '')) }] : [])]);
  }
  function validationDlg() {
    const here = ruleAt(sh, sel.r, sel.c), d = here ? { ...here } : { type: 'list', op: 'between', f1: '', f2: '', allowBlank: true, err: '' }, area = { r1: rng.r1, c1: rng.c1, r2: rng.r2, c2: rng.c2 };
    const body = h('div', { class: 'pg-form' }); const inp = (k, ph, type = 'text') => { const i = h('input', { class: 'inp', type, placeholder: ph, value: d[k] ?? '', 'aria-label': ph }); i.addEventListener('input', () => { d[k] = i.value; }); return i; };
    const draw = () => {
      const seg = (items, cur, on) => h('div', { class: 'seg' }, items.map(([k, tt]) => h('button', { type: 'button', class: cur === k ? 'on' : '', onclick: () => { on(k); draw(); } }, tt)));
      const two = ['between', 'notBetween'].includes(d.op);
      body.replaceChildren(
        h('div', { class: 'pg-f' }, h('span', null, 'রেঞ্জ: ' + sqOf(area))), h('div', { class: 'cr-ratios' }, Object.entries(DV_TYPES).map(([k, tt]) => h('button', { type: 'button', class: 'chip' + (d.type === k ? ' on' : ''), onclick: () => { d.type = k; if (k === 'list') { d.f1 = d.f1 || ''; } draw(); } }, tt))),
        d.type === 'list' ? h('div', { class: 'pg-f' }, h('span', null, 'তালিকার মান — কমা দিয়ে লিখুন, অথবা রেঞ্জ (যেমন Sheet2!A1:A9)'), inp('f1src', 'হ্যাঁ,না,হয়তো'))
          : h('div', { class: 'pg-f' }, seg(Object.entries(DV_OPS).filter(([k]) => d.type !== 'textLength' || k !== 'x'), d.op, k => { d.op = k; }), h('div', { class: 'pg-grid' }, inp('f1', two ? 'সর্বনিম্ন' : 'মান'), two ? inp('f2', 'সর্বোচ্চ') : h('span'))),
        h('div', { class: 'pg-f' }, h('span', null, 'ভুল মান দিলে বার্তা (ঐচ্ছিক)'), inp('err', 'যেমন: শুধু ১ থেকে ১০০')),
        h('button', { type: 'button', class: 'cl-tg' + (d.allowBlank !== false ? ' on' : ''), onclick: () => { d.allowBlank = d.allowBlank === false; draw(); } }, h('span', { class: 'switch' + (d.allowBlank !== false ? ' on' : '') }), h('span', null, 'ফাঁকা ঘর অনুমোদিত')));
    };
    d.f1src = d.type === 'list' ? String(d.f1 || '').replace(/^"|"$/g, '') : ''; draw();
    modal({ title: 'ডেটা ভ্যালিডেশন', wide: true, body, actions: [{ label: 'বাতিল', ghost: true }, ...(here ? [{ label: 'নিয়ম মুছুন', ghost: true, danger: true, onClick: () => act(() => structural(() => { sh.dv = (sh.dv || []).filter(x => !dvIntersects(x, area)); })) }] : []),
      { label: 'প্রয়োগ', primary: true, onClick: () => {
        if (d.type === 'list') { const raw = String(d.f1src || '').trim(); if (!raw) { toast('তালিকার মান লিখুন'); return false; } d.f1 = /^(?:'[^']+'!|[^'!,]+!)?\$?[A-Za-z]{1,3}\$?\d+(?::\$?[A-Za-z]{1,3}\$?\d+)?$/.test(raw) ? raw : '"' + raw.replace(/"/g, '') + '"'; d.f2 = ''; d.op = 'between'; }
        else { if (String(d.f1 ?? '') === '' || (['between', 'notBetween'].includes(d.op) && String(d.f2 ?? '') === '')) { toast('মান লিখুন'); return false; } }
        const rule = { sq: sqOf(area), type: d.type, op: d.op || 'between', f1: String(d.f1 ?? ''), f2: String(d.f2 ?? ''), allowBlank: d.allowBlank !== false, err: d.err || '' };
        act(() => structural(() => { sh.dv = (sh.dv || []).filter(x => !dvIntersects(x, area)); sh.dv.push(rule); })); toast('ভ্যালিডেশন নিয়ম বসেছে');
      } }] });
  }

  const dataTools = () => [{ icon: 'check', label: 'ডেটা ভ্যালিডেশন', sub: 'ড্রপডাউন তালিকা, সংখ্যার সীমা', onClick: validationDlg }, { icon: 'filter', label: 'ডুপ্লিকেট সারি মুছুন', sub: 'বেছে নেওয়া রেঞ্জ বা পুরো শিট', onClick: removeDuplicates }, { icon: 'table', label: 'টেক্সট → কলাম', sub: 'কমা/স্পেস ইত্যাদি দিয়ে ভাগ করুন', onClick: textToColumns }];
  const r0 = ctx.setup({ serialize, undo, redo, exports: exportsList, extraMenu: [...dataTools(), { icon: 'sparkle', label: 'AI ফর্মুলা সহায়ক', sub: 'ফর্মুলা বানান / বুঝে নিন', onClick: () => import('./ai.js').then(m => m.aiChat({ title: 'Excel AI', system: 'You are an Excel formula expert inside a spreadsheet app that supports standard Excel functions (SUM, IF, IFS, VLOOKUP, XLOOKUP, SUMIF(S), COUNTIF(S), INDEX, MATCH, TEXT, DATE, etc.). Give the exact formula in a code span, then a short Bangla explanation with an example. Reply in Bangla unless asked otherwise.', chips: ['VLOOKUP কীভাবে লিখব?', 'দুই তারিখের মধ্যে দিন গণনা', 'শর্ত অনুযায়ী যোগফল (SUMIF)', 'গড় থেকে গ্রেড বের করার ফর্মুলা'] })) }, { icon: 'search', label: 'খুঁজুন ও বদলান', onClick: findDlg }, { icon: 'tpl', label: 'বাংলা/ইংরেজি সংখ্যা', onClick: () => { wb.bn = !wb.bn; changed(); } }] });
  hdr = r0.hdr; as = r0.as; hdr.setUndo(false, false);
  const body = h('div', { class: 'ed-body' }, tabsEl, toolsEl, fbar, grid, tabsBar);
  ctx.root.replaceChildren(hdr.el, body);
  showTab('home'); renderTabs(); relayout();
  // stacking: canvas must overlay spacer
  spacer.style.marginBottom = '0'; cv.style.marginTop = '0';
  requestAnimationFrame(() => { spacer.style.position = 'absolute'; spacer.style.top = '0'; spacer.style.left = '0'; spacer.style.pointerEvents = 'none'; render(); });
  const tmo = setTimeout(render, 150);
  window.__xl = { cancelEdit, startEdit, commitEdit, validationDlg, openDropdown, dvRead, removeDuplicates, textToColumns, wb, eng, get sh() { return sh; }, setInput, select, act, applyStyle, startEdit, commitEdit, rngGet: () => rng, selGet: () => sel, sortBy, insertRC, deleteRC, undo, redo, copy, paste, mergeSel, fill, display };
  return { destroy() { clearTimeout(tmo); document.removeEventListener('keydown', onKey); } };
}
