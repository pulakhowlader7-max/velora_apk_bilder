// Velora live camera — a full-screen viewfinder with an optional guide frame, torch and gallery fallback.
// liveCapture({title, ratio, hint}) → Promise<canvas | null>
import { h, icon, toast, pickFiles, loadImage } from './util.js';
import { screen } from './screen.js';

const cnv = (w, hh) => { const c = document.createElement('canvas'); c.width = w; c.height = hh; return c; };
export async function fileToCanvas(file, max = 4096) {
  const url = URL.createObjectURL(file);
  try {
    const img = await loadImage(url), s = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
    const c = cnv(Math.round(img.naturalWidth * s), Math.round(img.naturalHeight * s)); c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); return c;
  } finally { URL.revokeObjectURL(url); }
}
/** The phone's own camera app / gallery (always works, even when the live preview is blocked). */
export async function pickPhoto({ camera = false } = {}) {
  const [f] = await pickFiles({ accept: 'image/*', capture: camera ? 'environment' : undefined }); return f ? fileToCanvas(f) : null;
}

export function liveCapture({ title = 'ছবি তুলুন', ratio = 0, hint = 'কাগজটি ফ্রেমের ভেতরে রাখুন', allowGallery = true } = {}) {
  return new Promise(resolve => {
    let stream = null, settled = false, torch = false;
    const finish = v => { if (settled) return; settled = true; stop(); resolve(v); };
    const stop = () => { if (stream) { stream.getTracks().forEach(t => t.stop()); stream = null; } };
    const scr = screen({ title, cls: 'livecam', onClose: () => finish(null) });
    const video = h('video', { class: 'lc-video', autoplay: true, playsinline: true, muted: true });
    const guide = h('div', { class: 'lc-guide' + (ratio ? ' fixed' : '') }); if (ratio) guide.style.aspectRatio = String(ratio);
    const hintEl = h('div', { class: 'lc-hint' }, hint);
    const stage = h('div', { class: 'lc-stage' }, video, guide, hintEl);
    const shot = h('button', { class: 'sc-shot', type: 'button', 'aria-label': 'ছবি তুলুন' });
    const torchB = h('button', { class: 'lc-side', type: 'button', hidden: true, 'aria-label': 'ফ্ল্যাশ' }, icon('sparkle', 22), h('small', null, 'আলো'));
    const galB = h('button', { class: 'lc-side', type: 'button', hidden: !allowGallery, 'aria-label': 'গ্যালারি' }, icon('image', 22), h('small', null, 'গ্যালারি'));
    scr.body.append(stage, h('div', { class: 'lc-bar' }, galB, shot, torchB));
    scr.body.classList.add('lc-body');

    (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 2560 }, height: { ideal: 1440 } }, audio: false });
        video.srcObject = stream; await video.play().catch(() => { });
        const tr = stream.getVideoTracks()[0], cap = tr.getCapabilities ? tr.getCapabilities() : {};
        if (cap.torch) { torchB.hidden = false; torchB.onclick = async () => { torch = !torch; try { await tr.applyConstraints({ advanced: [{ torch }] }); torchB.classList.toggle('on', torch); } catch { torch = false; } }; }
      } catch (e) { console.warn(e); stop(); hintEl.textContent = 'লাইভ ক্যামেরা চালু হয়নি — নিচের বোতামে ফোনের ক্যামেরা খুলবে'; }
    })();
    shot.onclick = async () => {
      if (stream && video.videoWidth) {
        const c = cnv(video.videoWidth, video.videoHeight); c.getContext('2d').drawImage(video, 0, 0); finish(c); scr.close();
      } else { try { const c = await pickPhoto({ camera: true }); if (c) { finish(c); scr.close(); } } catch (e) { toast('ছবি পড়া যায়নি', 3000); } }
    };
    galB.onclick = async () => { try { const c = await pickPhoto(); if (c) { finish(c); scr.close(); } } catch (e) { toast('ছবি পড়া যায়নি', 3000); } };
  });
}
