// Velora device self-test — run it on a real phone and share the report; it measures what matters for large files.
import { h, icon, toast, busy, fmtSize, toBn, shareFile, saveToDevice, errMsg } from './util.js';
import { screen } from './screen.js';
import { db } from './db.js';
import { deviceLine, readLog, clearLog, formatLog } from './errlog.js';

const ok = '✓', warn = '⚠', bad = '✗';
const ms = t => Math.round(performance.now() - t) + 'ms';
async function frames(sec = 1) { return new Promise(res => { const f = []; let last = performance.now(), end = last + sec * 1000; const loop = n => { f.push(n - last); last = n; if (n < end) requestAnimationFrame(loop); else res(f); }; requestAnimationFrame(loop); }); }

export const TESTS = [
  ['ডিভাইস', async () => { const n = navigator, mem = n.deviceMemory; return { s: mem && mem <= 2 ? warn : ok, t: `${deviceLine()}\n${mem && mem <= 2 ? 'কম RAM — "লাইট মোড" চালু হবে (ছোট প্রিভিউ, কম মেমরি)' : 'RAM যথেষ্ট'}` }; }],
  ['স্টোরেজ বরাদ্দ', async () => { const e = await navigator.storage.estimate(), free = e.quota - e.usage, per = navigator.storage.persisted ? await navigator.storage.persisted() : false; return { s: free < 300 * 1048576 ? warn : ok, t: `বরাদ্দ ${fmtSize(e.quota)} · ব্যবহৃত ${fmtSize(e.usage)} · ফাঁকা ${fmtSize(free)} · স্থায়ী: ${per ? 'হ্যাঁ' : 'না'}` }; }],
  ['বড় ফাইল লেখা/পড়া (৫০ MB)', async () => { const b = new Blob([new Uint8Array(50 * 1048576)]); let t = performance.now(); await db.kvSet('__diag', b); const w = ms(t); t = performance.now(); const r = await db.kvGet('__diag'); const ab = await r.arrayBuffer(); const rd = ms(t); await db.kvDel('__diag'); return { s: ab.byteLength === 50 * 1048576 ? ok : bad, t: `লেখা ${w} · পড়া ${rd}` }; }],
  ['ব্যাকগ্রাউন্ড ওয়ার্কার + Excel গতি', async () => { const { sheetsToXlsx } = await import('./formats.js'), { xlsxToWbFast } = await import('./xlsx.js'); const rows = []; for (let r = 0; r < 20000; r++) rows.push([r, 'নাম ' + r, r * 2.5, 'D' + (r % 7), r % 3 ? 'x' : 'y']); const buf = await sheetsToXlsx([{ name: 'T', rows }]); const t = performance.now(); const wb = await xlsxToWbFast(buf, () => { }); const d = Math.round(performance.now() - t); const n = Object.keys(wb.sheets[0].cells).length; return { s: d > 4000 ? warn : ok, t: `${toBn(n)}টি সেল ${d}ms-এ পড়া হয়েছে (১০ লাখ সেল হলে আনুমানিক ${Math.round(d / n * 1e6 / 100) / 10} সেকেন্ড)` }; }],
  ['ছবির মেমরি (ক্যানভাস)', async () => { const out = []; for (const s of [3000, 4096, 6000, 8000]) { try { const c = document.createElement('canvas'); c.width = c.height = s; const g = c.getContext('2d'); g.fillRect(0, 0, 10, 10); const ok2 = g.getImageData(0, 0, 1, 1).data[3] === 255; out.push(`${s}²:${ok2 ? ok : bad}`); } catch { out.push(`${s}²:${bad}`); } } const bestOk = out.filter(x => x.endsWith(ok)).length; return { s: bestOk >= 2 ? ok : warn, t: out.join('  ') + (bestOk < 3 ? '\nবড় ছবি স্বয়ংক্রিয়ভাবে ছোট করে নেওয়া হবে' : '') }; }],
  ['স্ক্রিন স্মুথনেস', async () => { const f = await frames(1); const avg = f.reduce((a, x) => a + x, 0) / f.length, worst = Math.max(...f.slice(1)); return { s: avg > 24 ? warn : ok, t: `গড় ফ্রেম ${avg.toFixed(1)}ms (≈${Math.round(1000 / avg)} fps) · সবচেয়ে খারাপ ${Math.round(worst)}ms` }; }],
  ['ক্যামেরা', async () => { if (!navigator.mediaDevices) return { s: bad, t: 'ক্যামেরা API নেই' }; const d = (await navigator.mediaDevices.enumerateDevices()).filter(x => x.kind === 'videoinput'); let perm = '?'; try { perm = (await navigator.permissions.query({ name: 'camera' })).state; } catch { } return { s: d.length ? ok : warn, t: `${d.length}টি ক্যামেরা · অনুমতি: ${perm}` }; }],
  ['PDF / ফাইল ইঞ্জিন', async () => { const { needPDFLib, needPdfJs, needJSZip } = await import('./util.js'); const t = performance.now(); await needJSZip(); await needPDFLib(); await needPdfJs(); return { s: ok, t: `JSZip, pdf-lib, pdf.js লোড ${ms(t)}` }; }],
  ['AI / OCR', async () => { const { hasKey } = await import('./ai.js'); return { s: ok, t: (await hasKey()) ? 'Gemini কী আছে — হাতের লেখা OCR চালু' : 'Gemini কী নেই — ছাপা লেখা OCR চলবে, হাতের লেখা দুর্বল' }; }],
];

export async function runDiag(onStep) {
  const res = [];
  for (const [name, fn] of TESTS) { onStep && onStep(name); try { res.push({ name, ...(await fn()) }); } catch (e) { res.push({ name, s: bad, t: errMsg(e) }); } await new Promise(r => setTimeout(r, 30)); }
  return res;
}
export const reportText = res => 'Velora ডিভাইস টেস্ট — ' + new Date().toLocaleString('en-GB') + '\n\n' + res.map(r => `${r.s} ${r.name}\n   ${r.t.replace(/\n/g, '\n   ')}`).join('\n\n');

export function openDiag() {
  const scr = screen({ title: 'ডিভাইস টেস্ট ও সমস্যার লগ', cls: 'diag' }), body = h('div', { class: 'dg-body' }); scr.body.append(body);
  let report = '';
  const card = (title, kids) => h('div', { class: 'card' }, h('div', { class: 'card-h' }, title), ...kids);
  async function run() {
    body.replaceChildren(h('div', { class: 'dg-run' }, h('div', { class: 'spin' }), h('b', null, 'টেস্ট চলছে…'), h('small', { id: 'dgstep' }, '')));
    const res = await runDiag(n => { const e = body.querySelector('#dgstep'); if (e) e.textContent = n; }); report = reportText(res); show(res);
  }
  async function show(res) {
    const log = await readLog();
    body.replaceChildren(
      card('টেস্টের ফল', res.map(r => h('div', { class: 'row dg-r' }, h('span', { class: 'dg-s s' + (r.s === ok ? 'o' : r.s === warn ? 'w' : 'b') }, r.s), h('div', { class: 'rt' }, r.name, h('small', { style: { whiteSpace: 'pre-wrap' } }, r.t))))),
      h('div', { class: 'dg-acts' },
        h('button', { class: 'btn', type: 'button', onclick: async () => { try { await navigator.clipboard.writeText(report); toast('রিপোর্ট কপি হয়েছে'); } catch { toast('কপি করা যায়নি'); } } }, icon('copy', 18), 'কপি'),
        h('button', { class: 'btn primary', type: 'button', onclick: () => shareFile(new Blob([report + '\n\n--- ত্রুটির লগ ---\n' + formatLog(log)], { type: 'text/plain' }), 'velora-diagnostic.txt') }, icon('share', 18), 'ডেভেলপারকে পাঠান')),
      card(`ত্রুটির লগ (${toBn(log.length)})`, [log.length ? h('pre', { class: 'dg-log' }, formatLog(log.slice(-12))) : h('div', { class: 'row' }, icon('check', 22), h('div', { class: 'rt' }, 'কোনো ত্রুটি রেকর্ড হয়নি')),
        log.length ? h('button', { class: 'row danger', type: 'button', onclick: async () => { await clearLog(); toast('লগ মুছেছে'); show(res); } }, icon('trash', 22), h('div', { class: 'rt' }, 'লগ মুছুন')) : null].filter(Boolean)),
      h('button', { class: 'btn', type: 'button', onclick: run, style: { margin: '4px 12px 20px' } }, 'আবার টেস্ট করুন'));
  }
  run();
}
