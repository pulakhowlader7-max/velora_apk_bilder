// Velora export helpers shared by scanner, ID-card, cleanup and OCR screens.
import { needPDFLib, toBn } from './util.js';

export const cnv = (w, hh) => { const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(hh)); return c; };
export const ctx2 = c => c.getContext('2d', { willReadFrequently: true });
export const toBlob = (c, type = 'image/jpeg', q = .9) => new Promise(r => c.toBlob(r, type, q));
export const stampName = (prefix = 'স্ক্যান') => prefix + ' ' + new Date().toLocaleDateString('en-GB').replace(/\//g, '-');

/** Down-scale a canvas so its longest side is ≤ max (returns the same canvas when already small). */
export function fitMax(c, max) {
  const s = Math.min(1, max / Math.max(c.width, c.height)); if (s >= 1) return c;
  const n = cnv(c.width * s, c.height * s), g = n.getContext('2d'); g.imageSmoothingQuality = 'high'; g.drawImage(c, 0, 0, n.width, n.height); return n;
}
/** canvases → one PDF.  opts.a4: every page is A4 (image is fitted & centred), else each page has its image's own size. */
export async function pdfFromCanvases(list, { a4 = false, quality = .88, onProgress } = {}) {
  const { PDFDocument } = await needPDFLib(); const pdf = await PDFDocument.create(); pdf.setProducer('Velora');
  for (let i = 0; i < list.length; i++) {
    onProgress && onProgress(i + 1, list.length);
    const c = list[i], img = await pdf.embedJpg(new Uint8Array(await (await toBlob(c, 'image/jpeg', quality)).arrayBuffer()));
    if (a4) {
      const PW = 595.28, PH = 841.89, s = Math.min(PW / c.width, PH / c.height), w = c.width * s, hh = c.height * s;
      const pg = pdf.addPage([PW, PH]); pg.drawImage(img, { x: (PW - w) / 2, y: (PH - hh) / 2, width: w, height: hh });
    } else {
      const k = Math.min(1, 1190 / Math.max(c.width, c.height)); const w = c.width * k * .75, hh = c.height * k * .75; // keep pages a sensible physical size
      const pg = pdf.addPage([w, hh]); pg.drawImage(img, { x: 0, y: 0, width: w, height: hh });
    }
  }
  return (await pdf.save()).buffer;
}
export const progressMsg = (i, n) => `পাতা ${toBn(i)}/${toBn(n)}`;
