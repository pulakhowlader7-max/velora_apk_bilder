// Fast, DOM-free scanner for OOXML spreadsheet parts. Runs inside a Web Worker (no DOMParser there) and is ~10-20× quicker
// than building a DOM for a million cells. Output is column-oriented typed arrays so it can be *transferred* to the page for free.
import { shiftFormula } from './formula.js';

const ENT = { '&amp;': '&', '&lt;': '<', '&gt;': '>', '&quot;': '"', '&apos;': "'" };
export const unent = s => s.indexOf('&') < 0 ? s : s.replace(/&(amp|lt|gt|quot|apos|#x[0-9a-fA-F]+|#\d+);/g, m => ENT[m] || (m[2] === 'x' ? String.fromCodePoint(parseInt(m.slice(3, -1), 16)) : String.fromCodePoint(parseInt(m.slice(2, -1), 10))));

/** <si> items of sharedStrings.xml → string[]  (phonetic <rPh> runs are ignored, rich text runs are joined) */
export function scanSharedStrings(xml) {
  const out = []; let p = 0;
  while (true) {
    let a = xml.indexOf('<si', p); if (a < 0) break; const c = xml.charCodeAt(a + 3); if (c !== 62 && c !== 32 && c !== 47) { p = a + 3; continue; }   // '<si>' / '<si ' / '<si/>'
    const gt = xml.indexOf('>', a); if (xml.charCodeAt(gt - 1) === 47) { out.push(''); p = gt + 1; continue; }
    const e = xml.indexOf('</si>', gt); let body = xml.slice(gt + 1, e < 0 ? xml.length : e); p = e < 0 ? xml.length : e + 5;
    if (body.indexOf('<rPh') >= 0) body = body.replace(/<rPh[\s\S]*?<\/rPh>/g, '');
    let s = '', q = 0;
    while (true) {
      const t = body.indexOf('<t', q); if (t < 0) break; const tc = body.charCodeAt(t + 2); if (tc !== 62 && tc !== 32 && tc !== 47) { q = t + 2; continue; }
      const tg = body.indexOf('>', t); if (body.charCodeAt(tg - 1) === 47) { q = tg + 1; continue; }
      const te = body.indexOf('</t>', tg); s += body.slice(tg + 1, te < 0 ? body.length : te); q = te < 0 ? body.length : te + 4;
    }
    out.push(unent(s));
  }
  return out;
}
const attr = (tag, name) => { let i = tag.indexOf(' ' + name + '="'); if (i < 0) return null; i += name.length + 3; return tag.slice(i, tag.indexOf('"', i)); };
export const KIND = { NUM: 0, SST: 1, STR: 2, BOOL: 3, ERR: 4, NONE: 5 };

/**
 * Scans <sheetData>. Returns { n, r, c, k, x, num, ref, fi, strs, rowH, ok }.
 *  k = KIND; ref = index into the shared-string table (KIND.SST) or into `strs` (STR/ERR); fi = index into `strs` of the formula or -1.
 *  ok=false means the XML uses a prefix or layout this fast path does not understand → caller falls back to the DOM reader.
 */
export function scanSheetData(xml) {
  const s0 = xml.indexOf('<sheetData'); if (s0 < 0) return { ok: false };
  if (xml.indexOf('<x:c ') >= 0 || xml.indexOf('<x:row') >= 0) return { ok: false };
  const sEnd = xml.indexOf('</sheetData>'), end = sEnd < 0 ? xml.length : sEnd;
  let cap = 1 << 16, n = 0;
  let R = new Int32Array(cap), C = new Int32Array(cap), K = new Uint8Array(cap), X = new Int32Array(cap), REF = new Int32Array(cap), FI = new Int32Array(cap), NUM = new Float64Array(cap);
  const grow = () => { cap *= 2; const g = (A, T) => { const B = new T(cap); B.set(A); return B; }; R = g(R, Int32Array); C = g(C, Int32Array); K = g(K, Uint8Array); X = g(X, Int32Array); REF = g(REF, Int32Array); FI = g(FI, Int32Array); NUM = g(NUM, Float64Array); };
  const strs = [], rowH = {}, shared = new Map();
  let p = xml.indexOf('<row', s0), ri = -1;
  while (p >= 0 && p < end) {
    const c4 = xml.charCodeAt(p + 4); if (c4 !== 32 && c4 !== 62 && c4 !== 47) { p = xml.indexOf('<row', p + 4); continue; }
    const gt = xml.indexOf('>', p), rowTag = xml.slice(p, gt), selfClose = xml.charCodeAt(gt - 1) === 47;
    const ra = attr(rowTag, 'r'); ri = ra ? +ra - 1 : ri + 1;
    const ht = attr(rowTag, 'ht'); if (ht && attr(rowTag, 'customHeight') !== '0') rowH[ri] = Math.round(parseFloat(ht) / 0.75);
    if (selfClose) { p = xml.indexOf('<row', gt); continue; }
    const rowEnd = xml.indexOf('</row>', gt); let q = gt + 1, ci = 0; const lim = rowEnd < 0 ? end : rowEnd;
    while (true) {
      const a = xml.indexOf('<c', q); if (a < 0 || a >= lim) break; const ch = xml.charCodeAt(a + 2); if (ch !== 32 && ch !== 62 && ch !== 47) { q = a + 2; continue; }
      const g = xml.indexOf('>', a), tag = xml.slice(a, g), sc = xml.charCodeAt(g - 1) === 47; let inner = '';
      if (sc) q = g + 1; else { const ce = xml.indexOf('</c>', g); inner = xml.slice(g + 1, ce < 0 ? lim : ce); q = ce < 0 ? lim : ce + 4; }
      const ref = attr(tag, 'r'); let row = ri, col = ci;
      if (ref) { let i = 0, cc = 0; for (; i < ref.length; i++) { const ch2 = ref.charCodeAt(i) - 64; if (ch2 < 1 || ch2 > 26) { const ch3 = ref.charCodeAt(i) - 96; if (ch3 >= 1 && ch3 <= 26) { cc = cc * 26 + ch3; continue; } break; } cc = cc * 26 + ch2; } col = cc - 1; row = parseInt(ref.slice(i), 10) - 1; }
      ci = col + 1; const t = attr(tag, 't'), sidx = attr(tag, 's'); let kind = KIND.NONE, num = 0, rf = -1, fi = -1;
      if (inner) {
        const fs = inner.indexOf('<f'); let formula = null;
        if (fs >= 0 && (inner.charCodeAt(fs + 2) === 32 || inner.charCodeAt(fs + 2) === 62 || inner.charCodeAt(fs + 2) === 47)) {
          const fg = inner.indexOf('>', fs), ftag = inner.slice(fs, fg), fclose = inner.charCodeAt(fg - 1) === 47;
          const ftext = fclose ? '' : unent(inner.slice(fg + 1, inner.indexOf('</f>', fg)));
          if (attr(ftag, 't') === 'shared') { const si = attr(ftag, 'si'); if (ftext) { shared.set(si, { f: ftext, r: row, c: col }); formula = ftext; } else { const sh = shared.get(si); if (sh) formula = shiftFormula(sh.f, row - sh.r, col - sh.c); } } else formula = ftext;
        }
        if (formula) { fi = strs.length; strs.push(formula.replace(/^=/, '')); }
        const vs = inner.indexOf('<v>');
        if (vs >= 0) { const raw = inner.slice(vs + 3, inner.indexOf('</v>', vs)); if (t === 's') { kind = KIND.SST; rf = +raw; } else if (t === 'str') { kind = KIND.STR; rf = strs.length; strs.push(unent(raw)); } else if (t === 'b') { kind = KIND.BOOL; num = raw === '1' ? 1 : 0; } else if (t === 'e') { kind = KIND.ERR; rf = strs.length; strs.push(raw); } else if (raw !== '') { kind = KIND.NUM; num = parseFloat(raw); } }
        else if (t === 'inlineStr') { let s = '', z = 0; while (true) { const ta = inner.indexOf('<t', z); if (ta < 0) break; const tg = inner.indexOf('>', ta); const te = inner.indexOf('</t>', tg); if (te < 0) break; s += inner.slice(tg + 1, te); z = te + 4; } kind = KIND.STR; rf = strs.length; strs.push(unent(s)); }
      }
      const xi = sidx !== null && sidx !== '' ? +sidx : -1; if (kind === KIND.NONE && fi < 0 && xi < 0) continue;
      if (n === cap) grow(); R[n] = row; C[n] = col; K[n] = kind; X[n] = xi; REF[n] = rf; FI[n] = fi; NUM[n] = num; n++;
    }
    p = rowEnd < 0 ? -1 : xml.indexOf('<row', rowEnd);
  }
  return { ok: true, n, r: R.slice(0, n), c: C.slice(0, n), k: K.slice(0, n), x: X.slice(0, n), ref: REF.slice(0, n), fi: FI.slice(0, n), num: NUM.slice(0, n), strs, rowH, head: xml.slice(0, s0) + xml.slice(end + 12) };
}
