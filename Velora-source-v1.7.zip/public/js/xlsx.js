// XLSX / CSV reader & writer (workbook model <-> OOXML).
import { needJSZip } from './zip.js';
import { KIND } from './xlsxscan.js';
import { colName, colIndex, parseAddr, parseRange, shiftFormula, addr, isErr, parseDateStr } from './formula.js';
import { BUILTIN, isDateFmt } from './numfmt.js';

const X = s => String(s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const MAIN = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
const RELNS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
const REV = {}; for (const k in BUILTIN) REV[BUILTIN[k]] = +k;
const bad = s => s.replace(/[\\/?*[\]:]/g, '_').slice(0, 31) || 'Sheet';

export function newSheet(name = 'Sheet1') { return { name, cells: {}, colW: {}, rowH: {}, merges: [], freeze: { r: 0, c: 0 }, hiddenRows: {}, cf: [], dv: [], _ver: 0 }; }
export function newWorkbook() { return { sheets: [newSheet()], active: 0, bn: false }; }
export function cloneSheet(s) { const c = JSON.parse(JSON.stringify({ name: s.name, cells: s.cells, colW: s.colW, rowH: s.rowH, merges: s.merges, freeze: s.freeze, hiddenRows: s.hiddenRows, cf: s.cf || [] })); c._ver = 0; return c; }
export function serializeWb(wb) { return JSON.stringify({ v: 1, active: wb.active, bn: wb.bn, sheets: wb.sheets.map(s => ({ name: s.name, cells: s.cells, colW: s.colW, rowH: s.rowH, merges: s.merges, freeze: s.freeze, hiddenRows: s.hiddenRows || {}, cf: s.cf || [], dv: s.dv || [] })) }); }
export function loadWb(json) { const o = typeof json === 'string' ? JSON.parse(json) : json; const wb = { sheets: o.sheets.map(s => ({ ...newSheet(s.name), ...s, _ver: 0 })), active: Math.min(o.active || 0, o.sheets.length - 1), bn: !!o.bn }; return wb; }

/* ================= write ================= */
export async function wbToXlsx(wb, valueOf, { title = '', author = '' } = {}) {
  const JSZip = await needJSZip(); const z = new JSZip();
  const sst = [], sstMap = new Map();
  const si = s => { let i = sstMap.get(s); if (i === undefined) { i = sst.length; sst.push(s); sstMap.set(s, i); } return i; };
  const fonts = [], fills = [], borders = [], numFmts = [], xfs = []; const fmap = {};
  const getIdx = (arr, key, mk) => { let i = arr.findIndex(x => x.key === key); if (i < 0) { arr.push({ key, xml: mk() }); i = arr.length - 1; } return i; };
  getIdx(fonts, 'def', () => '<font><sz val="11"/><name val="Calibri"/><family val="2"/></font>');
  getIdx(fills, 'n', () => '<fill><patternFill patternType="none"/></fill>'); getIdx(fills, 'g', () => '<fill><patternFill patternType="gray125"/></fill>');
  getIdx(borders, 'none', () => '<border><left/><right/><top/><bottom/><diagonal/></border>');
  xfs.push({ key: '', xml: '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>' });
  const rgb = c => 'FF' + String(c).replace('#', '').toUpperCase().padStart(6, '0');
  function xfOf(s) {
    if (!s || !Object.keys(s).length) return 0;
    const key = JSON.stringify(s); if (fmap[key] !== undefined) return fmap[key];
    const fk = [s.b, s.i, s.u, s.s, s.color, s.fs, s.font].join('|');
    const fi = fk === '|||||||'.slice(0, 6) || fk === '||||||' ? 0 : getIdx(fonts, fk, () => `<font>${s.b ? '<b/>' : ''}${s.i ? '<i/>' : ''}${s.s ? '<strike/>' : ''}${s.u ? '<u/>' : ''}<sz val="${s.fs || 11}"/>${s.color ? `<color rgb="${rgb(s.color)}"/>` : ''}<name val="${X(s.font || 'Calibri')}"/><family val="2"/></font>`);
    const fl = s.bg ? getIdx(fills, 'f' + s.bg, () => `<fill><patternFill patternType="solid"><fgColor rgb="${rgb(s.bg)}"/><bgColor indexed="64"/></patternFill></fill>`) : 0;
    const bd = s.bd; const bk = bd ? ['t', 'r', 'b', 'l'].map(k => bd[k] ? (bd[k] === 1 ? '1' : bd[k]) : '').join('|') : '';
    const bi = bd && /[^|]/.test(bk) ? getIdx(borders, bk, () => { const e = (tag, v) => v ? `<${tag} style="thin"><color ${v === 1 ? 'auto="1"' : `rgb="${rgb(v)}"`}/></${tag}>` : `<${tag}/>`; return `<border>${e('left', bd.l)}${e('right', bd.r)}${e('top', bd.t)}${e('bottom', bd.b)}<diagonal/></border>`; }) : 0;
    let nid = 0; if (s.nf && s.nf !== 'General') { if (REV[s.nf] !== undefined) nid = REV[s.nf]; else { let k = numFmts.findIndex(x => x.fmt === s.nf); if (k < 0) { numFmts.push({ fmt: s.nf, id: 164 + numFmts.length }); k = numFmts.length - 1; } nid = numFmts[k].id; } }
    const al = (s.ha || s.va || s.wrap) ? `<alignment${s.ha ? ` horizontal="${s.ha}"` : ''}${s.va ? ` vertical="${s.va === 'middle' ? 'center' : s.va}"` : ''}${s.wrap ? ' wrapText="1"' : ''}/>` : '';
    xfs.push({ key, xml: `<xf numFmtId="${nid}" fontId="${fi}" fillId="${fl}" borderId="${bi}" xfId="0"${nid ? ' applyNumberFormat="1"' : ''}${fi ? ' applyFont="1"' : ''}${fl ? ' applyFill="1"' : ''}${bi ? ' applyBorder="1"' : ''}${al ? ' applyAlignment="1">' + al + '</xf>' : '/>'}` });
    return (fmap[key] = xfs.length - 1);
  }
  const sheetXml = []; const dxfs = [];
  wb.sheets.forEach((sh, sIdx) => {
    const rows = {}; let maxR = 0, maxC = 0;
    for (const k in sh.cells) { const [r, c] = k.split(',').map(Number); (rows[r] ||= []).push([c, sh.cells[k]]); if (r > maxR) maxR = r; if (c > maxC) maxC = c; }
    for (const r in sh.rowH) { if (+r > maxR) maxR = +r; }
    let x = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="${MAIN}" xmlns:r="${RELNS}">`;
    x += `<dimension ref="A1:${addr(maxR, maxC)}"/>`;
    x += `<sheetViews><sheetView workbookViewId="0"${sIdx === wb.active ? ' tabSelected="1"' : ''}>`;
    const fz = sh.freeze || { r: 0, c: 0 };
    if (fz.r || fz.c) x += `<pane${fz.c ? ` xSplit="${fz.c}"` : ''}${fz.r ? ` ySplit="${fz.r}"` : ''} topLeftCell="${addr(fz.r, fz.c)}" activePane="${fz.r && fz.c ? 'bottomRight' : fz.r ? 'bottomLeft' : 'topRight'}" state="frozen"/>`;
    x += '</sheetView></sheetViews><sheetFormatPr defaultRowHeight="15"/>';
    const cw = Object.keys(sh.colW).map(Number).sort((a, b) => a - b);
    if (cw.length) x += '<cols>' + cw.map(c => `<col min="${c + 1}" max="${c + 1}" width="${(Math.max(2, (sh.colW[c] - 5) / 7)).toFixed(2)}" customWidth="1"/>`).join('') + '</cols>';
    x += '<sheetData>';
    const rkeys = new Set([...Object.keys(rows).map(Number), ...Object.keys(sh.rowH).map(Number)]);
    for (const r of [...rkeys].sort((a, b) => a - b)) {
      const ht = sh.rowH[r]; x += `<row r="${r + 1}"${sh.hiddenRows && sh.hiddenRows[r] ? ' hidden="1"' : ''}${ht ? ` ht="${(ht * 0.75).toFixed(2)}" customHeight="1"` : ''}>`;
      for (const [c, cell] of (rows[r] || []).sort((a, b) => a[0] - b[0])) {
        const s = xfOf(cell.s); const ref = addr(r, c); const attrs = ` r="${ref}"${s ? ` s="${s}"` : ''}`;
        const hasF = cell.f !== undefined && cell.f !== null && cell.f !== '';
        let v = hasF ? valueOf(sIdx, r, c) : cell.v;
        if (v && typeof v === 'object' && v.rows) v = v.a[0][0];
        const f = hasF ? `<f>${X(cell.f)}</f>` : '';
        if (v === null || v === undefined || v === '') { x += hasF ? `<c${attrs}>${f}</c>` : (s ? `<c${attrs}/>` : ''); }
        else if (typeof v === 'number') x += `<c${attrs}>${f}<v>${isFinite(v) ? v : 0}</v></c>`;
        else if (typeof v === 'boolean') x += `<c${attrs} t="b">${f}<v>${v ? 1 : 0}</v></c>`;
        else if (isErr(v)) x += `<c${attrs} t="e">${f}<v>${X(v.err)}</v></c>`;
        else if (hasF) x += `<c${attrs} t="str">${f}<v>${X(v)}</v></c>`;
        else x += `<c${attrs} t="s"><v>${si(String(v))}</v></c>`;
      }
      x += '</row>';
    }
    x += '</sheetData>';
    if (sh.merges && sh.merges.length) x += `<mergeCells count="${sh.merges.length}">${sh.merges.map(m => `<mergeCell ref="${addr(m.r1, m.c1)}:${addr(m.r2, m.c2)}"/>`).join('')}</mergeCells>`;
    if (sh.cf && sh.cf.length) sh.cf.forEach((r, ri) => { const dk = (r.bg || '') + '|' + (r.color || ''); let di = dxfs.findIndex(d => d.key === dk); if (di < 0) { dxfs.push({ key: dk, xml: `<dxf>${r.color ? `<font><color rgb="FF${r.color.replace('#', '').toUpperCase()}"/></font>` : ''}${r.bg ? `<fill><patternFill patternType="solid"><fgColor rgb="FF${r.bg.replace('#', '').toUpperCase()}"/><bgColor rgb="FF${r.bg.replace('#', '').toUpperCase()}"/></patternFill></fill>` : ''}</dxf>` }); di = dxfs.length - 1; }
      const ref = `${addr(r.r1, r.c1)}:${addr(r.r2, r.c2)}`; const q = v => X(String(v)); if (r.op === 'text') x += `<conditionalFormatting sqref="${ref}"><cfRule type="containsText" dxfId="${di}" priority="${ri + 1}" operator="containsText" text="${q(r.a)}"><formula>NOT(ISERROR(SEARCH("${q(r.a)}",${addr(r.r1, r.c1)})))</formula></cfRule></conditionalFormatting>`; else { const op = { gt: 'greaterThan', lt: 'lessThan', ge: 'greaterThanOrEqual', le: 'lessThanOrEqual', eq: 'equal', ne: 'notEqual', between: 'between' }[r.op] || 'equal'; const fv = v => isNaN(+v) || v === '' ? `"${q(v)}"` : q(+v); x += `<conditionalFormatting sqref="${ref}"><cfRule type="cellIs" dxfId="${di}" priority="${ri + 1}" operator="${op}"><formula>${fv(r.a)}</formula>${r.op === 'between' ? `<formula>${fv(r.b)}</formula>` : ''}</cfRule></conditionalFormatting>`; } });
    if (sh.dv && sh.dv.length) x += `<dataValidations count="${sh.dv.length}">${sh.dv.map(d => `<dataValidation type="${d.type}"${d.type !== 'list' && d.op && d.op !== 'between' ? ` operator="${d.op}"` : ''}${d.allowBlank === false ? '' : ' allowBlank="1"'} showInputMessage="1" showErrorMessage="1"${d.err ? ` error="${X(d.err)}"` : ''} sqref="${X(d.sq)}"><formula1>${X(d.f1 ?? '')}</formula1>${d.type !== 'list' && (d.op || 'between') .startsWith('b') || d.op === 'notBetween' ? `<formula2>${X(d.f2 ?? '')}</formula2>` : ''}</dataValidation>`).join('')}</dataValidations>`;
    x += '<pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/></worksheet>';
    sheetXml.push(x);
  });
  sheetXml.forEach((x, i) => z.file(`xl/worksheets/sheet${i + 1}.xml`, x));
  z.file('xl/sharedStrings.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><sst xmlns="${MAIN}" count="${sst.length}" uniqueCount="${sst.length}">${sst.map(s => `<si><t xml:space="preserve">${X(s)}</t></si>`).join('')}</sst>`);
  z.file('xl/styles.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="${MAIN}">${numFmts.length ? `<numFmts count="${numFmts.length}">${numFmts.map(n => `<numFmt numFmtId="${n.id}" formatCode="${X(n.fmt)}"/>`).join('')}</numFmts>` : ''}<fonts count="${fonts.length}">${fonts.map(f => f.xml).join('')}</fonts><fills count="${fills.length}">${fills.map(f => f.xml).join('')}</fills><borders count="${borders.length}">${borders.map(f => f.xml).join('')}</borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="${xfs.length}">${xfs.map(f => f.xml).join('')}</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>${dxfs.length ? `<dxfs count="${dxfs.length}">${dxfs.map(d => d.xml).join('')}</dxfs>` : ''}</styleSheet>`);
  const names = wb.sheets.map(s => bad(s.name));
  z.file('xl/workbook.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="${MAIN}" xmlns:r="${RELNS}"><bookViews><workbookView activeTab="${wb.active}"/></bookViews><sheets>${names.map((n, i) => `<sheet name="${X(n)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets><calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>`);
  const n = wb.sheets.length;
  z.file('xl/_rels/workbook.xml.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${names.map((_, i) => `<Relationship Id="rId${i + 1}" Type="${RELNS}/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${n + 1}" Type="${RELNS}/styles" Target="styles.xml"/><Relationship Id="rId${n + 2}" Type="${RELNS}/sharedStrings" Target="sharedStrings.xml"/></Relationships>`);
  z.file('_rels/.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="${RELNS}/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>`);
  const now = new Date().toISOString().replace(/\.\d+Z$/, 'Z');
  z.file('docProps/core.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${X(title)}</dc:title><dc:creator>${X(author)}</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">${now}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">${now}</dcterms:modified></cp:coreProperties>`);
  z.file('[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>${names.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/></Types>`);
  return z.generateAsync({ type: 'arraybuffer', compression: 'DEFLATE', mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
}

/* ================= read ================= */
const dxfRef = { list: [] };
const parse = s => new DOMParser().parseFromString(s, 'application/xml');
const kids = (p, n) => [...p.children].filter(c => c.localName === n);
const kid = (p, n) => { for (const c of p.children) if (c.localName === n) return c; return null; };
const THEME = ['FFFFFF', '000000', 'E7E6E6', '44546A', '4472C4', 'ED7D31', 'A5A5A5', 'FFC000', '5B9BD5', '70AD47'];
const INDEXED = ['000000', 'FFFFFF', 'FF0000', '00FF00', '0000FF', 'FFFF00', 'FF00FF', '00FFFF', '000000', 'FFFFFF', 'FF0000', '00FF00', '0000FF', 'FFFF00', 'FF00FF', '00FFFF', '800000', '008000', '000080', '808000', '800080', '008080', 'C0C0C0', '808080'];
function tint(hex, t) { if (!t) return hex; const c = [0, 2, 4].map(i => parseInt(hex.substr(i, 2), 16)); const o = c.map(v => { v = t < 0 ? v * (1 + t) : v + (255 - v) * t; return Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0'); }); return o.join('').toUpperCase(); }
function colorOf(e) { if (!e) return null; if (e.getAttribute('rgb')) return e.getAttribute('rgb').slice(-6).toUpperCase(); if (e.getAttribute('theme') !== null && e.getAttribute('theme') !== '') return '#'.slice(1) + tint(THEME[+e.getAttribute('theme')] || '000000', parseFloat(e.getAttribute('tint') || 0)); if (e.getAttribute('indexed') !== null) return INDEXED[+e.getAttribute('indexed')] || null; return null; }
const hex = c => c ? '#' + c : undefined;

const FAST_MIN = 1.2 * 1048576;
function readStyles(stylesXml) {
  const numFmtMap = {}, xfList = [];
  {
    const sd = parse(stylesXml);
    for (const n of sd.getElementsByTagNameNS('*', 'numFmt')) numFmtMap[n.getAttribute('numFmtId')] = n.getAttribute('formatCode');
    const fonts = [...kid(sd.documentElement, 'fonts')?.children || []].map(f => { const o = {}; for (const c of f.children) { const n = c.localName; if (n === 'b') o.b = c.getAttribute('val') !== '0'; else if (n === 'i') o.i = c.getAttribute('val') !== '0'; else if (n === 'u') o.u = c.getAttribute('val') !== 'none'; else if (n === 'strike') o.s = c.getAttribute('val') !== '0'; else if (n === 'sz') o.fs = Math.round(parseFloat(c.getAttribute('val'))); else if (n === 'color') { const k = colorOf(c); if (k && k !== '000000') o.color = hex(k); } else if (n === 'name') { const nm = c.getAttribute('val'); if (nm && nm !== 'Calibri') o.font = nm; } } return o; });
    const fills = [...kid(sd.documentElement, 'fills')?.children || []].map(f => { const p = kid(f, 'patternFill'); if (!p || p.getAttribute('patternType') !== 'solid') return null; const k = colorOf(kid(p, 'fgColor')); return k && k !== 'FFFFFF' ? hex(k) : (k ? hex(k) : null); });
    const bds = [...kid(sd.documentElement, 'borders')?.children || []].map(b => { const o = {}; for (const [tag, k] of [['top', 't'], ['right', 'r'], ['bottom', 'b'], ['left', 'l']]) { const e = kid(b, tag); if (e && e.getAttribute('style')) { const c = colorOf(kid(e, 'color')); o[k] = c && c !== '000000' ? hex(c) : 1; } } return Object.keys(o).length ? o : null; });
    const dxfList = [...(kid(sd.documentElement, 'dxfs')?.children || [])].map(d => { const o = {}; const f = kid(d, 'font'); const fc = f && colorOf(kid(f, 'color')); if (fc) o.color = hex(fc); const fl = kid(d, 'fill'); const pf = fl && kid(fl, 'patternFill'); const bc = pf && (colorOf(kid(pf, 'bgColor')) || colorOf(kid(pf, 'fgColor'))); if (bc) o.bg = hex(bc); return o; }); dxfRef.list = dxfList;
    for (const xf of kid(sd.documentElement, 'cellXfs')?.children || []) {
      const s = {}; const f = fonts[+xf.getAttribute('fontId')]; if (f) { if (f.b) s.b = 1; if (f.i) s.i = 1; if (f.u) s.u = 1; if (f.s) s.s = 1; if (f.color) s.color = f.color; if (f.fs && f.fs !== 11) s.fs = f.fs; if (f.font) s.font = f.font; }
      const fl = fills[+xf.getAttribute('fillId')]; if (fl) s.bg = fl; const b = bds[+xf.getAttribute('borderId')]; if (b) s.bd = b;
      const nid = xf.getAttribute('numFmtId'); const fmt = numFmtMap[nid] || BUILTIN[nid]; if (fmt && fmt !== 'General') s.nf = fmt;
      const al = kid(xf, 'alignment'); if (al) { const h = al.getAttribute('horizontal'); if (h && h !== 'general') s.ha = h === 'centerContinuous' ? 'center' : h; const v = al.getAttribute('vertical'); if (v) s.va = v === 'center' ? 'middle' : v; if (al.getAttribute('wrapText') === '1') s.wrap = 1; }
      xfList.push(s);
    }
  }
  return xfList;
}
function readSheetExtras(root, sh) {
  const cols = kid(root, 'cols'); if (cols) for (const c of kids(cols, 'col')) { const mn = +c.getAttribute('min') - 1, mx = Math.min(+c.getAttribute('max') - 1, mn + 200); const w = parseFloat(c.getAttribute('width')); if (w && c.getAttribute('hidden') !== '1') for (let k = mn; k <= mx; k++) sh.colW[k] = Math.round(w * 7 + 5); }
  for (const cfEl of kids(root, 'conditionalFormatting')) { const g = parseRange(cfEl.getAttribute('sqref').split(' ')[0]); if (!g) continue; for (const rule of kids(cfEl, 'cfRule')) { const dx = (dxfRef.list || [])[+rule.getAttribute('dxfId')]; if (!dx) continue; const t = rule.getAttribute('type'); const fs = kids(rule, 'formula').map(f => f.textContent.replace(/^"|"$/g, '')); if (t === 'cellIs') { const op = { greaterThan: 'gt', lessThan: 'lt', greaterThanOrEqual: 'ge', lessThanOrEqual: 'le', equal: 'eq', notEqual: 'ne', between: 'between' }[rule.getAttribute('operator')]; if (op) sh.cf.push({ ...g, op, a: isNaN(+fs[0]) ? fs[0] : +fs[0], b: isNaN(+fs[1]) ? fs[1] : +fs[1], ...dx }); } else if (t === 'containsText' && rule.getAttribute('text')) sh.cf.push({ ...g, op: 'text', a: rule.getAttribute('text'), ...dx }); } }
  const mc = kid(root, 'mergeCells'); if (mc) for (const m of kids(mc, 'mergeCell')) { const g = parseRange(m.getAttribute('ref')); if (g) sh.merges.push(g); }
  sh.dv = []; for (const d of root.getElementsByTagNameNS('*', 'dataValidation')) {
    const type = d.getAttribute('type'); if (!['list', 'whole', 'decimal', 'date', 'textLength'].includes(type)) continue;   // custom/time rules are not supported yet
    const f1 = kid(d, 'formula1'), f2 = kid(d, 'formula2'); sh.dv.push({ sq: d.getAttribute('sqref') || '', type, op: d.getAttribute('operator') || 'between', f1: f1 ? f1.textContent : '', f2: f2 ? f2.textContent : '', allowBlank: d.getAttribute('allowBlank') === '1' || d.getAttribute('allowBlank') === 'true', err: d.getAttribute('error') || '' });
  }
  const sv = kid(root, 'sheetViews'); const pane = sv && kid(kid(sv, 'sheetView') || sv, 'pane'); if (pane && pane.getAttribute('state') === 'frozen') sh.freeze = { r: +pane.getAttribute('ySplit') || 0, c: +pane.getAttribute('xSplit') || 0 };
}

const tick = () => new Promise(r => setTimeout(r, 0));
/** Builds sheet.cells from the scanner's typed arrays in short slices so the UI never freezes. */
async function buildCells(sh, sc, sst, xfList, onProgress, base, span) {
  const { n, r, c, k, x, ref, fi, num, strs } = sc, cells = sh.cells; let t0 = performance.now();
  for (let i = 0; i < n; i++) {
    const cell = {}, kd = k[i];
    if (kd === KIND.NUM) cell.v = num[i]; else if (kd === KIND.SST) cell.v = sst[ref[i]] ?? ''; else if (kd === KIND.STR) cell.v = strs[ref[i]]; else if (kd === KIND.BOOL) cell.v = num[i] === 1; else if (kd === KIND.ERR) cell.v = { err: strs[ref[i]] };
    if (fi[i] >= 0) { cell.f = strs[fi[i]]; delete cell.v; }
    const xs = x[i] >= 0 ? xfList[x[i]] : null; if (xs && Object.keys(xs).length) cell.s = xs;   // shared, copy-on-write everywhere in the editor
    if (cell.v !== undefined || cell.f || cell.s) cells[r[i] + ',' + c[i]] = cell;
    if ((i & 8191) === 8191 && performance.now() - t0 > 14) { onProgress && onProgress(base + span * i / n); await tick(); t0 = performance.now(); }
  }
}
async function xlsxToWbFast(buf, onProgress) {
  const { call } = await import('./workclient.js');
  const res = await call('xlsxParse', { buf: buf.slice(0) }, [], p => onProgress && onProgress(p * .6));
  if (!res || res.fallback) return null;
  const xfList = res.styles ? readStyles(res.styles) : [], sheets = [];
  for (let i = 0; i < res.sheets.length; i++) {
    const s = res.sheets[i], sh = newSheet(s.name); sheets.push(sh); if (!s.scan) continue;
    Object.assign(sh.rowH, s.scan.rowH); await buildCells(sh, s.scan, res.sst, xfList, onProgress, .6 + .4 * i / res.sheets.length, .4 / res.sheets.length);
    if (s.head) readSheetExtras(parse(s.head).documentElement, sh);
  }
  if (!sheets.length) sheets.push(newSheet());
  onProgress && onProgress(1); return { sheets, active: 0, bn: false };
}
/** Big files are parsed off the main thread (typed arrays, no DOM); small ones and odd layouts use the classic DOM reader. */
export async function xlsxToWb(buf, { onProgress } = {}) {
  if (buf.byteLength > FAST_MIN && typeof Worker !== 'undefined') { try { const w = await xlsxToWbFast(buf, onProgress); if (w) return w; } catch (e) { console.warn('fast xlsx path failed → DOM reader', e); } }
  return xlsxToWbDom(buf);
}
export async function xlsxToWbDom(buf) {
  const JSZip = await needJSZip(); const z = await JSZip.loadAsync(buf);
  const wbF = z.file('xl/workbook.xml'); if (!wbF) throw new Error('এটি বৈধ .xlsx ফাইল নয়');
  const wbx = parse(await wbF.async('string'));
  const rels = {}; const rf = z.file('xl/_rels/workbook.xml.rels');
  if (rf) for (const r of parse(await rf.async('string')).getElementsByTagName('Relationship')) rels[r.getAttribute('Id')] = r.getAttribute('Target');
  const sst = []; const sf = z.file('xl/sharedStrings.xml');
  if (sf) for (const si of parse(await sf.async('string')).getElementsByTagNameNS('*', 'si')) { let t = ''; for (const n of si.getElementsByTagNameNS('*', 't')) { if (n.parentNode.localName === 'rPh') continue; t += n.textContent; } sst.push(t); }
  const stylesF = z.file('xl/styles.xml'); const xfList = stylesF ? readStyles(await stylesF.async('string')) : [];
  const sheets = [];
  for (const sn of wbx.getElementsByTagNameNS('*', 'sheet')) {
    const rid = sn.getAttributeNS(RELNS, 'id') || sn.getAttribute('r:id'); let t = rels[rid] || ''; t = t.startsWith('/') ? t.slice(1) : 'xl/' + t;
    const f = z.file(t); const sh = newSheet(sn.getAttribute('name')); sheets.push(sh); if (!f) continue;
    const d = parse(await f.async('string')); const root = d.documentElement;
    const shared = {};
    const sd = kid(root, 'sheetData');
    if (sd) for (const row of kids(sd, 'row')) {
      const ri = +row.getAttribute('r') - 1; const ht = row.getAttribute('ht'); if (ht && row.getAttribute('customHeight') !== '0') sh.rowH[ri] = Math.round(parseFloat(ht) / 0.75);
      let ci = 0;
      for (const c of kids(row, 'c')) {
        const ref = c.getAttribute('r'); let r = ri, col = ci; if (ref) { const p = parseAddr(ref); if (p) { r = p.r; col = p.c; } } ci = col + 1;
        const fe = kid(c, 'f'), ve = kid(c, 'v'), t = c.getAttribute('t'); const cell = {};
        let formula = null;
        if (fe) {
          if (fe.getAttribute('t') === 'shared') { const si = fe.getAttribute('si'); if (fe.textContent) { shared[si] = { f: fe.textContent, r, c: col }; formula = fe.textContent; } else if (shared[si]) formula = shiftFormula(shared[si].f, r - shared[si].r, col - shared[si].c); }
          else formula = fe.textContent;
        }
        const raw = ve ? ve.textContent : null;
        if (t === 's') cell.v = sst[+raw] ?? ''; else if (t === 'str') cell.v = raw ?? ''; else if (t === 'b') cell.v = raw === '1'; else if (t === 'e') cell.v = { err: raw }; else if (t === 'inlineStr') cell.v = [...c.getElementsByTagNameNS('*', 't')].map(x => x.textContent).join(''); else if (raw !== null && raw !== '') cell.v = parseFloat(raw);
        if (formula) { cell.f = formula.replace(/^=/, ''); delete cell.v; }
        const sidx = c.getAttribute('s'); if (sidx && xfList[+sidx] && Object.keys(xfList[+sidx]).length) cell.s = { ...xfList[+sidx] };
        if (cell.v !== undefined || cell.f || cell.s) sh.cells[r + ',' + col] = cell;
      }
    }
    readSheetExtras(root, sh);
  }
  if (!sheets.length) sheets.push(newSheet());
  return { sheets, active: 0, bn: false };
}

/* ================= CSV ================= */
export function parseCSV(text, delim) {
  text = text.replace(/^﻿/, '');
  if (!delim) { const first = text.split('\n')[0] || ''; const cnt = d => (first.match(new RegExp(d === '\t' ? '\\t' : '\\' + d, 'g')) || []).length; delim = [',', '\t', ';', '|'].sort((a, b) => cnt(b) - cnt(a))[0]; }
  const rows = []; let row = [], cur = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (q) { if (ch === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += ch; }
    else if (ch === '"') q = true; else if (ch === delim) { row.push(cur); cur = ''; } else if (ch === '\n' || ch === '\r') { if (ch === '\r' && text[i + 1] === '\n') i++; row.push(cur); cur = ''; rows.push(row); row = []; } else cur += ch;
  }
  if (cur !== '' || row.length) { row.push(cur); rows.push(row); }
  return rows;
}
/** Convert typed text into a cell value (numbers, dates, booleans, formulas). */
export function parseInput(txt) {
  if (txt === '' || txt === null || txt === undefined) return {};
  let s = String(txt).replace(/[০-৯]/g, d => '০১২৩৪৫৬৭৮৯'.indexOf(d));
  if (s.startsWith("'")) return { v: String(txt).slice(1) };
  if (s.startsWith('=') && s.length > 1) return { f: s.slice(1) };
  const t = s.trim();
  if (/^[-+]?(\d{1,3}(,\d{3})+|\d+)(\.\d+)?([eE][+-]?\d+)?$/.test(t)) { const n = parseFloat(t.replace(/,/g, '')); if (isFinite(n) && !(/^0\d/.test(t) && !t.includes('.'))) return { v: n, nf: /,/.test(t) ? '#,##0' + (t.includes('.') ? '.' + '0'.repeat(t.split('.')[1].length) : '') : undefined }; }
  if (/^[-+]?\.\d+$/.test(t)) return { v: parseFloat(t) };
  if (/^[-+]?\d+(\.\d+)?%$/.test(t)) return { v: parseFloat(t) / 100, nf: t.includes('.') ? '0.00%' : '0%' };
  if (/^TRUE$/i.test(t)) return { v: true }; if (/^FALSE$/i.test(t)) return { v: false };
  if (/^\d{1,2}[/\-.]\d{1,2}[/\-.]\d{4}$/.test(t) || /^\d{4}-\d{1,2}-\d{1,2}$/.test(t)) { const d = parseDateStr(t); if (d !== null) return { v: d, nf: /^\d{4}/.test(t) ? 'yyyy-mm-dd' : 'dd/mm/yyyy' }; }
  if (/^\d{1,2}:\d{2}(:\d{2})?$/.test(t)) { const d = parseDateStr(t); if (d !== null) return { v: d, nf: 'h:mm' }; }
  return { v: String(txt) };
}
export function csvToWb(text, name = 'Sheet1') {
  const rows = parseCSV(text); const sh = newSheet(name);
  rows.forEach((row, r) => row.forEach((v, c) => { if (v === '') return; const p = parseInput(v); const cell = {}; if (p.v !== undefined) cell.v = p.v; else if (p.f) cell.v = v; if (p.nf) cell.s = { nf: p.nf }; sh.cells[r + ',' + c] = cell; }));
  return { sheets: [sh], active: 0, bn: false };
}
export function sheetToCSV(sh, display) {
  let mr = -1, mc = -1; for (const k in sh.cells) { const [r, c] = k.split(',').map(Number); if (r > mr) mr = r; if (c > mc) mc = c; }
  const esc = s => /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; const out = [];
  for (let r = 0; r <= mr; r++) { const row = []; for (let c = 0; c <= mc; c++) row.push(esc(display(r, c))); out.push(row.join(',')); }
  return '﻿' + out.join('\r\n');
}
export { xlsxToWbFast };
