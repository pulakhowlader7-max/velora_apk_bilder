// Velora image engine — pure JavaScript, no dependence on canvas filters (ctx.filter is missing/unreliable in some Android WebViews).
//   applyFx(img, params)      light, colour, detail, noise, vignette, grain, split-toning, mono   (img = {data,width,height}, edited in place)
//   autoParams(img)           analyses the picture (histogram, colour cast, noise, clipping) and returns the settings a retoucher would pick
//   PRESETS                   looks (parameter sets) with an intensity blend
//   docClean(img, opts)       document modes: colour / text / grey / black-white (adaptive) with shadow removal
import { lumaOf, boxBlurPlane, removeNoise, estimateNoise, backgroundPlane, autoLevels, textBoost } from './imgproc.js';

export const FX0 = Object.freeze({ exposure: 0, brightness: 0, contrast: 0, highlights: 0, shadows: 0, saturation: 0, vibrance: 0, temp: 0, tint: 0, fade: 0, clarity: 0, sharpen: 0, denoise: 0, vignette: 0, grain: 0, mono: 0, split: null });
const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
const c8 = v => v < 0 ? 0 : v > 255 ? 255 : v;
export const isNeutral = p => Object.keys(FX0).every(k => k === 'split' ? !(p && p.split) : !(p && p[k]));

/** single-channel tone curve: exposure (in linear light), brightness, contrast (S-curve), fade */
function toneLut(p) {
  const lut = new Float32Array(256), ev = Math.pow(2, p.exposure / 100 * 2.5), br = p.brightness / 100 * .25, c = p.contrast / 100, fd = p.fade / 100;
  for (let i = 0; i < 256; i++) {
    let v = i / 255;
    if (p.exposure) v = Math.pow(Math.pow(v, 2.2) * ev, 1 / 2.2);
    v += br;
    if (c > 0) { const g = 1 + c * .95, x = clamp(v, 0, 1); v = x < .5 ? .5 * Math.pow(2 * x, g) : 1 - .5 * Math.pow(2 * (1 - x), g); }
    else if (c < 0) v = .5 + (v - .5) * (1 + c * .8);
    if (fd) v = v * (1 - fd * .18) + fd * .07;
    lut[i] = clamp(v, 0, 1) * 255;
  }
  return lut;
}
let seed = 1; const rnd = () => (seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296;

/** clarity + sharpening on luma only (no colour fringes), processed in horizontal bands so a 12 MP photo never needs full-size float planes */
function detailPass(img, clarity, sharpen) {
  const { data, width: w, height: h } = img, rc = Math.max(2, Math.round(Math.max(w, h) / 60)), rs = Math.max(1, Math.round(Math.max(w, h) / 1600)), margin = Math.max(rc * 2, rs) + 2, BAND = 768;
  for (let a = 0; a < h; a += BAND) {
    const b = Math.min(h, a + BAND), y0 = Math.max(0, a - margin), y1 = Math.min(h, b + margin), bh = y1 - y0, L = new Float32Array(w * bh);
    for (let y = 0; y < bh; y++) for (let x = 0, i = ((y0 + y) * w) * 4, o = y * w; x < w; x++, i += 4, o++) L[o] = .299 * data[i] + .587 * data[i + 1] + .114 * data[i + 2];
    const big = clarity ? boxBlurPlane(boxBlurPlane(L, w, bh, rc), w, bh, rc) : null, sm = sharpen ? boxBlurPlane(L, w, bh, rs) : null, ca = clarity / 100 * 1.1, sa = sharpen / 100 * 1.7;
    for (let y = a - y0; y < b - y0; y++) for (let x = 0, o = y * w, i = ((y0 + y) * w) * 4; x < w; x++, o++, i += 4) {
      const l = L[o]; let d = 0;
      if (big) { const m = 1 - Math.pow(Math.abs(l / 127.5 - 1), 2); d += (l - big[o]) * ca * m; }
      if (sm) { let t = l - sm[o]; t = t > 0 ? Math.max(0, t - 1.2) : Math.min(0, t + 1.2); d += t * sa; }   // dead-zone: noise is not sharpened
      if (d) { data[i] = c8(data[i] + d); data[i + 1] = c8(data[i + 1] + d); data[i + 2] = c8(data[i + 2] + d); }
    }
  }
}

export function applyFx(img, p0) {
  const p = { ...FX0, ...p0 }, { data, width: w, height: h } = img, n = w * h;
  if (p.denoise > 0) removeNoise(img, p.denoise);
  const lut = toneLut(p), sh = p.shadows / 100, hl = p.highlights / 100, sat = 1 + p.saturation / 100, vib = p.vibrance / 100, mono = p.mono / 100;
  const gr = 1 + p.temp / 100 * .26 + p.tint / 100 * .05, gb = 1 - p.temp / 100 * .26 + p.tint / 100 * .05, gg = 1 - p.tint / 100 * .16, vig = p.vignette / 100, grain = p.grain / 100 * 38, sp = p.split;
  const needPix = sh || hl || p.temp || p.tint || p.saturation || p.vibrance || mono || vig || grain || sp, cx = w / 2, cy = h / 2, inv = 1 / (cx * cx + cy * cy); seed = 7;
  for (let i = 0, px = 0; px < n; px++, i += 4) {
    let r = lut[data[i]], g = lut[data[i + 1]], b = lut[data[i + 2]];
    if (needPix) {
      let L = (.299 * r + .587 * g + .114 * b) / 255;
      if (sh || hl) { const d = sh * .38 * (1 - L) * (1 - L) + hl * .38 * L * L, f = clamp((L + d) / (L + .002), .45, 4); r *= f; g *= f; b *= f; }
      if (gr !== 1 || gb !== 1 || gg !== 1) { r *= gr; g *= gg; b *= gb; }
      if (sat !== 1 || vib) { const mx = Math.max(r, g, b), mn = Math.min(r, g, b), sp0 = mx > 0 ? (mx - mn) / mx : 0, s = sat + vib * (1 - sp0) * .9, y = .299 * r + .587 * g + .114 * b; r = y + (r - y) * s; g = y + (g - y) * s; b = y + (b - y) * s; }
      if (mono) { const y = .299 * r + .587 * g + .114 * b; r += (y - r) * mono; g += (y - g) * mono; b += (y - b) * mono; }
      if (sp) { L = (.299 * r + .587 * g + .114 * b) / 255; const ws = (1 - L) * sp.amt * 62, wh = L * sp.amt * 62; r += (sp.sh[0] - .5) * ws * 2 + (sp.hi[0] - .5) * wh * 2; g += (sp.sh[1] - .5) * ws * 2 + (sp.hi[1] - .5) * wh * 2; b += (sp.sh[2] - .5) * ws * 2 + (sp.hi[2] - .5) * wh * 2; }
      if (vig) { const x = px % w - cx, y = ((px / w) | 0) - cy, d = (x * x + y * y) * inv, f = 1 - vig * .75 * clamp((d - .18) / .82, 0, 1) ** 1.6; r *= f; g *= f; b *= f; }
      if (grain) { const nz = (rnd() - .5) * grain; r += nz; g += nz; b += nz; }
    }
    data[i] = c8(r); data[i + 1] = c8(g); data[i + 2] = c8(b);
  }
  if (p.clarity || p.sharpen) detailPass(img, p.clarity, p.sharpen);
  return img;
}
/** blend: result = original + (filtered - original) * k */
export function blendInto(dst, orig, k) { if (k >= .999) return dst; const a = dst.data, b = orig.data; for (let i = 0; i < a.length; i += 4) { a[i] = b[i] + (a[i] - b[i]) * k; a[i + 1] = b[i + 1] + (a[i + 1] - b[i + 1]) * k; a[i + 2] = b[i + 2] + (a[i + 2] - b[i + 2]) * k; } return dst; }
export const cloneImg = img => ({ data: new Uint8ClampedArray(img.data), width: img.width, height: img.height });

/* ============================ auto enhance ============================ */
/** Reads the picture like a retoucher: exposure, contrast, clipped highlights, lifted shadows, colour cast, saturation, noise. */
export function analyse(img) {
  const { data, width: w, height: h } = img, step = Math.max(1, Math.floor(Math.sqrt(w * h / 60000))), hist = new Uint32Array(256); let n = 0, sr = 0, sg = 0, sb = 0, ss = 0, clipHi = 0, clipLo = 0, dark = 0, bright = 0;
  for (let y = 0; y < h; y += step) for (let x = 0; x < w; x += step) { const i = (y * w + x) * 4, r = data[i], g = data[i + 1], b = data[i + 2], l = (.299 * r + .587 * g + .114 * b) | 0; hist[l]++; n++; sr += r; sg += g; sb += b; const mx = Math.max(r, g, b), mn = Math.min(r, g, b); ss += mx ? (mx - mn) / mx : 0; if (mx > 250) clipHi++; if (mx < 6) clipLo++; if (l < 90) dark++; if (l > 200) bright++; }
  const pct = q => { let a = 0; const t = q * n; for (let i = 0; i < 256; i++) { a += hist[i]; if (a >= t) return i; } return 255; };
  const cw = Math.min(w, 600), ch = Math.min(h, 600), crop = { data: new Uint8ClampedArray(cw * ch * 4), width: cw, height: ch }, ox = (w - cw) >> 1, oy = (h - ch) >> 1;
  for (let y = 0; y < ch; y++) crop.data.set(data.subarray(((oy + y) * w + ox) * 4, ((oy + y) * w + ox + cw) * 4), y * cw * 4);
  return { p1: pct(.01), p10: pct(.1), p50: pct(.5), p90: pct(.9), p99: pct(.99), mean: [sr / n, sg / n, sb / n], sat: ss / n, clipHi: clipHi / n, clipLo: clipLo / n, darkFrac: dark / n, brightFrac: bright / n, noise: estimateNoise(crop) };
}
export function autoParams(img) {
  const a = analyse(img), m = a.p50 / 255, spread = (a.p99 - a.p1) / 255, [mr, mg, mb] = a.mean, avg = (mr + mg + mb) / 3 || 1;
  const doc = a.brightFrac > .5 && a.sat < .22 && a.darkFrac > .015 && a.darkFrac < .3;
  const p = {};
  const stops = clamp(Math.log2(Math.pow(.47 / Math.max(.04, m), 2.2)) * .85, -1.6, 2.2);          // photographic stops needed to bring the median to mid-grey
  p.exposure = Math.abs(stops) < .12 ? 0 : Math.round(clamp(stops / 2.5 * 100, -64, 88));
  p.contrast = Math.round(spread < .85 && m > .3 && m < .68 ? clamp((.88 - spread) * 110, 0, 38) : spread < .6 ? 10 : 0);   // an S-curve darkens dark pictures — only used when exposure is already fine
  p.highlights = a.clipHi > .015 ? -Math.round(clamp(a.clipHi * 700, 12, 55)) : (a.p90 > 235 ? -14 : 0);
  p.shadows = a.p10 < 40 ? Math.round(clamp((50 - a.p10) * 1.1, 0, 55)) : (m < .4 ? 14 : 0);
  p.saturation = Math.round(a.sat < .22 ? 18 : a.sat < .4 ? 9 : a.sat > .6 ? -7 : 3);
  p.vibrance = a.sat < .5 ? 22 : 8;
  const cast = (mr - mb) / avg;                                       // warm(+) / cool(-) cast; ignore small differences (real warm light is intentional)
  p.temp = Math.abs(cast) > .1 ? -Math.round(clamp(cast * 55, -20, 20)) : 0;
  p.tint = Math.abs((mg - (mr + mb) / 2) / avg) > .08 ? -Math.round(clamp((mg - (mr + mb) / 2) / avg * 45, -10, 10)) : 0;
  p.denoise = a.noise > 3 ? Math.round(clamp(a.noise * 4.2 + 8, 12, 80)) : 0;
  p.clarity = 20; p.sharpen = a.noise > 8 ? 14 : 30;
  return { params: p, kind: doc ? 'doc' : 'photo', info: a };
}

/* ============================ looks ============================ */
const S = (sh, hi, amt) => ({ sh, hi, amt });
export const PRESETS = [
  { id: 'orig', name: 'আসল', p: {} },
  { id: 'vivid', name: 'ভিভিড', p: { contrast: 14, vibrance: 38, saturation: 14, clarity: 18 } },
  { id: 'warm', name: 'উষ্ণ', p: { temp: 24, tint: 4, contrast: 6, vibrance: 14, shadows: 8 } },
  { id: 'cool', name: 'শীতল', p: { temp: -26, contrast: 8, vibrance: 8 } },
  { id: 'matte', name: 'ম্যাট', p: { fade: 55, contrast: -6, saturation: -8, highlights: -12 } },
  { id: 'film', name: 'ফিল্ম', p: { fade: 35, contrast: 10, temp: 10, saturation: -6, grain: 26, vignette: 18, split: S([.42, .5, .6], [.62, .52, .38], .5) } },
  { id: 'cine', name: 'সিনেমা', p: { contrast: 18, saturation: 6, vibrance: 12, vignette: 22, split: S([.35, .55, .62], [.66, .52, .35], .9) } },
  { id: 'portrait', name: 'পোর্ট্রেট', p: { exposure: 6, shadows: 18, highlights: -10, temp: 8, vibrance: 14, clarity: -10, sharpen: 14, saturation: -4 } },
  { id: 'hdr', name: 'HDR', p: { shadows: 42, highlights: -34, clarity: 46, contrast: 14, vibrance: 24, sharpen: 24 } },
  { id: 'drama', name: 'ড্রামাটিক', p: { contrast: 34, clarity: 38, saturation: -12, vignette: 34, highlights: -14, shadows: -8 } },
  { id: 'bw', name: 'সাদা-কালো', p: { mono: 100, contrast: 18, clarity: 22 } },
  { id: 'noir', name: 'নোয়ার', p: { mono: 100, contrast: 48, exposure: -8, vignette: 36, clarity: 30, grain: 18 } },
  { id: 'sepia', name: 'সেপিয়া', p: { mono: 100, contrast: 10, fade: 12, split: S([.5, .42, .3], [.68, .55, .38], .85) } },
  { id: 'vintage', name: 'ভিন্টেজ', p: { fade: 42, temp: 18, saturation: -14, contrast: -4, vignette: 28, grain: 22 } },
  { id: 'soft', name: 'নরম', p: { exposure: 8, clarity: -22, contrast: -8, vibrance: 10, shadows: 14 } },
  { id: 'pop', name: 'পপ', p: { contrast: 22, saturation: 30, vibrance: 20, exposure: 4, sharpen: 20 } },
];
export const presetById = id => PRESETS.find(p => p.id === id) || PRESETS[0];

/* ============================ documents ============================ */
/** local (Sauvola-style) threshold: crisp black text on pure white even with uneven light and shadows */
export function adaptiveBW(img, { sens = 50 } = {}) {
  const { data, width: w, height: h } = img, n = w * h, L = lumaOf(img), r = Math.max(8, Math.round(Math.max(w, h) / 55)), k = .12 + sens / 100 * .26;
  const mean = boxBlurPlane(boxBlurPlane(L, w, h, r), w, h, Math.max(2, r >> 1)), sq = new Float32Array(n); for (let i = 0; i < n; i++) sq[i] = L[i] * L[i];
  const msq = boxBlurPlane(sq, w, h, r);
  for (let i = 0, p = 0; p < n; p++, i += 4) { const m = mean[p], sd = Math.sqrt(Math.max(0, msq[p] - m * m)), T = m * (1 + k * (sd / 128 - 1)), v = clamp((L[p] - T + 14) / 28, 0, 1) * 255; data[i] = data[i + 1] = data[i + 2] = v; }
  return img;
}
/** lifts the paper to white by dividing out the slowly-varying background (shadows, uneven light, yellow tint). amount 0..1 */
export function flattenBackground(img, amount = 1) {
  const { data, width: w, height: h } = img, n = w * h, L = lumaOf(img), B = backgroundPlane(L, w, h);
  for (let i = 0, p = 0; p < n; p++, i += 4) { const bg = Math.max(60, B[p]), k = 1 + (255 / bg - 1) * amount; data[i] = c8(data[i] * k); data[i + 1] = c8(data[i + 1] * k); data[i + 2] = c8(data[i + 2] * k); }
  return img;
}
/** paper → neutral white: scales R,G,B so the average paper colour (the bright pixels) becomes 255 — removes yellow / blue casts */
export function whitePaper(img) {
  const { data, width: w, height: h } = img, step = Math.max(1, Math.floor(Math.sqrt(w * h / 40000))), ls = []; let sr = 0, sg = 0, sb = 0, n = 0;
  for (let y = 0; y < h; y += step) for (let x = 0; x < w; x += step) ls.push(.299 * data[(y * w + x) * 4] + .587 * data[(y * w + x) * 4 + 1] + .114 * data[(y * w + x) * 4 + 2]);
  const sorted = ls.slice().sort((a, b) => a - b), thr = sorted[Math.floor(sorted.length * .8)] || 200;
  for (let y = 0, k = 0; y < h; y += step) for (let x = 0; x < w; x += step, k++) if (ls[k] >= thr) { const i = (y * w + x) * 4; sr += data[i]; sg += data[i + 1]; sb += data[i + 2]; n++; }
  if (!n) return img; const gr = clamp(255 / (sr / n), .8, 1.4), gg = clamp(255 / (sg / n), .8, 1.4), gb = clamp(255 / (sb / n), .8, 1.4);
  if (Math.abs(gr - 1) < .01 && Math.abs(gg - 1) < .01 && Math.abs(gb - 1) < .01) return img;
  for (let i = 0; i < data.length; i += 4) { data[i] = c8(data[i] * gr); data[i + 1] = c8(data[i + 1] * gg); data[i + 2] = c8(data[i + 2] * gb); } return img;
}
export const DOC_MODES = [['auto', 'অটো'], ['color', 'রঙিন'], ['text', 'লেখা স্পষ্ট'], ['gray', 'গ্রে'], ['bw', 'সাদা-কালো'], ['orig', 'আসল']];
/**
 * Scanner / paper pipeline. opts: { mode, power 0..100 (strength of the clean-up), shadow 0..100 (remove shadows), denoise 'auto'|0..100,
 * brightness, contrast, sharpen (-100..100 / 0..100) }
 * Returns the mode that was actually used (relevant for 'auto').
 */
export function docClean(img, o = {}) {
  const O = { mode: 'auto', power: 70, shadow: 80, denoise: 'auto', brightness: 0, contrast: 0, sharpen: 30, ...o }; let mode = O.mode;
  if (mode === 'orig') { if (O.brightness || O.contrast) applyFx(img, { brightness: O.brightness, contrast: O.contrast }); return 'orig'; }
  const a = analyse(img);
  if (mode === 'auto') mode = a.sat < .24 ? 'text' : 'color';   // grey/white paper with ink → crisp text; coloured forms, receipts, photos → colour
  const nz = O.denoise === 'auto' ? (a.noise > 2.5 ? clamp(a.noise * 4.5 + 10, 20, 90) : 0) : +O.denoise, pw = O.power / 100;
  if (nz > 0) removeNoise(img, nz * (.55 + .45 * pw));
  if (O.shadow > 0) flattenBackground(img, O.shadow / 100);
  if (mode === 'bw') adaptiveBW(img, { sens: 35 + 45 * pw });
  else if (mode === 'text') { textBoost(img, { strength: .35 + .65 * pw, color: true }); }
  else if (mode === 'gray') { applyFx(img, { mono: 100 }); autoLevels(img, .006 + .01 * pw); applyFx(img, { contrast: 10 + 24 * pw }); }
  else { whitePaper(img); autoLevels(img, .004 + .006 * pw); applyFx(img, { vibrance: 18 * pw, contrast: 10 * pw }); }
  if (mode !== 'bw' && (O.brightness || O.contrast || O.sharpen)) applyFx(img, { brightness: O.brightness, contrast: O.contrast, sharpen: O.sharpen * (nz > 30 ? .6 : 1) });
  else if (mode === 'bw' && O.contrast) { /* thresholded output has no tone to adjust */ }
  return mode;
}
