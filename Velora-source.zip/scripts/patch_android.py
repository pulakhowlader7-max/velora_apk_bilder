#!/usr/bin/env python3
"""Runs in CI right after `npx cap add android`: turns the blank Capacitor project into the real Velora app
(open-with / share-to intents, camera permission, native plugin, icons, signing, version)."""
import json, os, re, shutil, sys
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
A = ROOT / 'android'
cfg = json.loads((ROOT / 'capacitor.config.json').read_text())
APP_ID = cfg['appId']
pkg = json.loads((ROOT / 'package.json').read_text())
run = os.environ.get('GITHUB_RUN_NUMBER', '1')
VERSION_CODE = int(run) if run.isdigit() else 1
VERSION_NAME = str(pkg.get('version', '1.1'))
BRAND_BG = '#2a47b5'

def log(m): print('[patch]', m)

# ---------------- manifest ----------------
OFFICE_MIMES = [
    'application/pdf',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.template',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.template',
    'application/vnd.openxmlformats-officedocument.presentationml.slideshow',
    'application/vnd.ms-word.document.macroEnabled.12',
    'application/vnd.ms-excel.sheet.macroEnabled.12',
    'application/msword', 'application/vnd.ms-excel', 'application/vnd.ms-powerpoint',
    'application/vnd.oasis.opendocument.text', 'application/vnd.oasis.opendocument.spreadsheet',
    'application/vnd.oasis.opendocument.presentation', 'application/rtf', 'text/rtf',
    'text/csv', 'text/comma-separated-values', 'application/csv', 'text/tab-separated-values',
    'text/plain', 'text/markdown', 'text/html', 'application/json', 'application/xml', 'text/xml',
    # WhatsApp / Telegram / Gmail / file managers often label Office files with these generic types
    'application/octet-stream', 'application/zip', 'application/x-zip-compressed', 'binary/octet-stream',
    'application/x-pdf', 'application/vnd.ms-office',
]
IMAGE_MIMES = ['image/*']
EXTS = ['docx', 'xlsx', 'pptx', 'pdf', 'csv', 'txt', 'doc', 'xls', 'ppt', 'rtf', 'odt', 'ods', 'odp', 'md', 'tsv',
        'jpg', 'jpeg', 'png', 'webp']


def build_filters():
    view_mimes = ''.join(f'<data android:mimeType="{m}"/>' for m in OFFICE_MIMES + IMAGE_MIMES)
    send_mimes = view_mimes
    # pathPattern matching is case-sensitive and ".*" is not greedy over dots, so add the upper-case and "double dot" variants
    pats = []
    for e in EXTS:
        for ee in {e, e.upper()}:
            pats.append(f'<data android:pathPattern=".*\\\\.{ee}"/>')
            pats.append(f'<data android:pathPattern=".*\\\\..*\\\\.{ee}"/>')
            pats.append(f'<data android:pathPattern=".*\\\\..*\\\\..*\\\\.{ee}"/>')
    path_data = ''.join(pats)
    return f'''
            <!-- velora-patched: files from other apps -->
            <intent-filter>
                <action android:name="android.intent.action.VIEW"/>
                <action android:name="android.intent.action.EDIT"/>
                <category android:name="android.intent.category.DEFAULT"/>
                <category android:name="android.intent.category.BROWSABLE"/>
                <data android:scheme="content"/>
                <data android:scheme="file"/>
                {view_mimes}
            </intent-filter>
            <intent-filter>
                <action android:name="android.intent.action.VIEW"/>
                <category android:name="android.intent.category.DEFAULT"/>
                <category android:name="android.intent.category.BROWSABLE"/>
                <data android:scheme="content"/>
                <data android:scheme="file"/>
                <data android:host="*"/>
                <data android:mimeType="*/*"/>
                {path_data}
            </intent-filter>
            <intent-filter>
                <action android:name="android.intent.action.SEND"/>
                <category android:name="android.intent.category.DEFAULT"/>
                {send_mimes}
            </intent-filter>
            <intent-filter>
                <action android:name="android.intent.action.SEND_MULTIPLE"/>
                <category android:name="android.intent.category.DEFAULT"/>
                {send_mimes}
            </intent-filter>
'''


def patch_manifest(x):
    """Takes the manifest text `npx cap add android` made and returns the Velora version."""
    if 'velora-patched' in x:
        return x
    # the filters must go inside the MainActivity element (the one that has the LAUNCHER filter)
    m = re.search(r'<activity\b[^>]*android:name="[^"]*MainActivity"[^>]*>.*?</activity>', x, re.S)
    if not m:
        m = re.search(r'<activity\b.*?</activity>', x, re.S)
    if not m:
        raise SystemExit('PATCH ERROR: no <activity> in AndroidManifest.xml')
    end = m.end() - len('</activity>')
    x = x[:end] + build_filters() + '        ' + x[end:]
    perms = '''
    <uses-permission android:name="android.permission.CAMERA"/>
    <uses-feature android:name="android.hardware.camera" android:required="false"/>
    <uses-feature android:name="android.hardware.camera.autofocus" android:required="false"/>
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28"/>
'''
    j = x.rindex('</manifest>')
    x = x[:j] + perms + x[j:]
    x = re.sub(r'<application\b', '<application android:largeHeap="true" android:hardwareAccelerated="true"', x, count=1)
    if 'windowSoftInputMode' not in x:
        x = re.sub(r'(<activity\b)', r'\1 android:windowSoftInputMode="adjustResize"', x, count=1)
    return x


def patch_manifest_file():
    mf = A / 'app/src/main/AndroidManifest.xml'
    mf.write_text(patch_manifest(mf.read_text(encoding='utf-8')), encoding='utf-8'); log('manifest patched')

def adaptive_fg(icon, size):
    """Adaptive-icon layer: the same blue gradient, with the picture shrunk to 66% so round/squircle masks never cut it."""
    S = icon.width
    px = icon.convert('RGB').load()
    grad = Image.new('RGB', (S, S)); gp = grad.load()
    c1, c2 = (30, 52, 140), (64, 112, 255)
    for y in range(S):
        for x in range(S):
            tt = (x * 0.35 + y * 0.65) / S
            gp[x, y] = tuple(int(c1[i] + (c2[i] - c1[i]) * tt) for i in range(3))
    mask = Image.new('L', (S, S), 0); mp = mask.load()
    for y in range(S):
        for x in range(S):
            a, b = px[x, y], gp[x, y]
            if max(abs(a[0] - b[0]), abs(a[1] - b[1]), abs(a[2] - b[2])) > 10: mp[x, y] = 255
    k = int(S * .66)
    out = grad.convert('RGBA')
    sm = icon.resize((k, k), Image.LANCZOS); mk = mask.resize((k, k), Image.LANCZOS)
    out.paste(sm, ((S - k) // 2, (S - k) // 2), mk)
    return out.resize((size, size), Image.LANCZOS)

def main():
    patch_manifest_file()
    # ---------------- java ----------------
    jdir = A / 'app/src/main/java' / Path(*APP_ID.split('.'))
    jdir.mkdir(parents=True, exist_ok=True)
    for f in (ROOT / 'native/java').glob('*.java'):
        t = f.read_text(encoding='utf-8').replace('package com.pulak.velora;', f'package {APP_ID};')
        (jdir / f.name).write_text(t, encoding='utf-8')
    log('java copied -> ' + str(jdir))

    # ---------------- icons / splash ----------------
    res = A / 'app/src/main/res'
    icon = Image.open(ROOT / 'scripts/icon-1024.png').convert('RGBA')
    legacy = {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}
    fg = {'mdpi': 108, 'hdpi': 162, 'xhdpi': 216, 'xxhdpi': 324, 'xxxhdpi': 432}
    _fg = adaptive_fg(icon, 1024)
    for d, sz in legacy.items():
        m = res / f'mipmap-{d}'; m.mkdir(parents=True, exist_ok=True)
        sq = icon.resize((sz, sz), Image.LANCZOS)
        mask = Image.new('L', (sz, sz), 0); ImageDraw.Draw(mask).rounded_rectangle((0, 0, sz - 1, sz - 1), radius=int(sz * .22), fill=255)
        out = Image.new('RGBA', (sz, sz), (0, 0, 0, 0)); out.paste(sq, (0, 0), mask); out.save(m / 'ic_launcher.png')
        cm = Image.new('L', (sz, sz), 0); ImageDraw.Draw(cm).ellipse((0, 0, sz - 1, sz - 1), fill=255)
        rd = Image.new('RGBA', (sz, sz), (0, 0, 0, 0)); rd.paste(sq, (0, 0), cm); rd.save(m / 'ic_launcher_round.png')
        _fg.resize((fg[d], fg[d]), Image.LANCZOS).save(m / 'ic_launcher_foreground.png')
    (res / 'values').mkdir(parents=True, exist_ok=True)
    (res / 'values/ic_launcher_background.xml').write_text(f'<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">{BRAND_BG}</color>\n</resources>\n')
    n = 0
    for sp in res.rglob('splash.png'):
        w, h = Image.open(sp).size
        bg = Image.new('RGBA', (w, h), BRAND_BG); s = int(min(w, h) * .32)
        bg.paste(icon.resize((s, s), Image.LANCZOS), ((w - s) // 2, (h - s) // 2)); bg.convert('RGB').save(sp); n += 1
    log(f'icons written, {n} splash images')

    # ---------------- gradle: version + signing ----------------
    ks = ROOT / 'keystore/velora.jks'
    shutil.copy(ks, A / 'app/velora.jks')
    bg = A / 'app/build.gradle'
    g = bg.read_text(encoding='utf-8')
    if 'velora-signing' not in g:
        g = re.sub(r'versionCode\s+\d+', f'versionCode {VERSION_CODE}', g, count=1)
        g = re.sub(r'versionName\s+"[^"]*"', f'versionName "{VERSION_NAME}"', g, count=1)
        g += '''

    // velora-signing: fixed key so every build installs as an update over the previous one
    android {
        signingConfigs {
            velora {
                storeFile file('velora.jks')
                storePassword 'velora-secure-2026'
                keyAlias 'velora'
                keyPassword 'velora-secure-2026'
            }
        }
        buildTypes {
            release {
                signingConfig signingConfigs.velora
                minifyEnabled false
            }
            debug {
                signingConfig signingConfigs.velora
            }
        }
        lint {
            abortOnError false
            checkReleaseBuilds false
        }
    }
    '''
        bg.write_text(g, encoding='utf-8'); log(f'gradle patched (v{VERSION_NAME}, code {VERSION_CODE})')
    log('done')


if __name__ == "__main__":
    main()
